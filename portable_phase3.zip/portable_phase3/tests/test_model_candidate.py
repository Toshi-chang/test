"""Agent C tests; artifacts are private to tests/_work/M/<uuid>."""
import copy
from dataclasses import replace
from pathlib import Path
import unittest
import uuid

import numpy as np
from nv_runner.model_candidate import CandidateNormalModel, FeatureBatch
from nv_runner.models import NormalModel
from nv_runner.common import read_json, write_json, sha
from nv_runner.acoustic_generator import acoustic_settings, generate_acoustic
from nv_runner.input_adapter import DatasetPlanner, InputAdapter
from nv_runner.profiles import acoustic_experiment
from nv_runner.routes import FixedWindow
from nv_runner.signals import SignalService

ROOT = Path(__file__).resolve().parents[1]
CONFIG = read_json(ROOT/'configs/parallel/model_comparison.json')


class ModelCandidate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = ROOT/'tests/_work/M'/uuid.uuid4().hex
        cls.root.mkdir(parents=True)
        # Fixed deterministic numeric fixture, not labels used as model output.
        rng = np.random.default_rng(CONFIG['seed'])
        cls.fit = rng.normal(size=(40, 3))
        cls.evaluation = rng.normal(size=(11, 3))
        cls.schema = (('pressure_rms', 'Pa'), ('velocity_rms', 'm/s'), ('correlation', '1'))
        cls.processing = {'window_seconds': 1, 'spectral_convention': 'mean_square_bin_v2'}

    def batch(self, values):
        return FeatureBatch(values, self.schema, copy.deepcopy(self.processing))

    def test_01_matches_existing_models_and_deterministic_fit(self):
        for config in CONFIG['models']:
            with self.subTest(kind=config['kind']):
                baseline = NormalModel().fit(self.fit, config, CONFIG['seed'])
                candidate = CandidateNormalModel().fit(self.fit, config, CONFIG['seed'])
                scores = candidate.score(self.evaluation)
                np.testing.assert_allclose(scores, baseline.score(self.evaluation), **CONFIG['score_comparison'])
                np.testing.assert_array_equal(scores, CandidateNormalModel().fit(self.fit, config, 42).score(self.evaluation))
                self.assertEqual(scores.shape, (11,))
                self.assertTrue(np.isfinite(scores).all())

    def test_02_evaluation_and_batch_order_do_not_mutate_fit(self):
        for config in CONFIG['models']:
            with self.subTest(kind=config['kind']):
                model = CandidateNormalModel().fit(self.batch(self.fit), config, 42)
                path = self.root/(config['kind']+'.joblib')
                model.save(path)
                before = sha(path)
                scores = model.score(self.batch(self.evaluation))
                split = np.concatenate([model.score(self.batch(row[None])) for row in self.evaluation])
                np.testing.assert_allclose(scores, split, **CONFIG['score_comparison'])
                np.testing.assert_allclose(scores, model.score(self.batch(self.evaluation[::-1]))[::-1], **CONFIG['score_comparison'])
                model.score(self.batch(self.evaluation*100))
                model.save(path)
                self.assertEqual(before, sha(path))
                np.testing.assert_allclose(model.scaler.mean_, self.fit.mean(axis=0))

    def test_03_schema_names_order_units_processing_and_version_rejected(self):
        batch = self.batch(self.fit)
        model = CandidateNormalModel().fit(batch, CONFIG['models'][0], 42)
        other = self.batch(self.evaluation)
        variants = [replace(other, feature_schema=(('other', 'Pa'), *self.schema[1:])),
                    replace(other, feature_schema=self.schema[::-1]),
                    replace(other, feature_schema=(('pressure_rms', 'kPa'), *self.schema[1:])),
                    replace(other, processing={**self.processing, 'window_seconds': 2}),
                    replace(other, schema_version='2.0')]
        for bad in variants:
            with self.subTest(batch=bad), self.assertRaises(ValueError):
                model.score(bad)
        self.assertEqual(len(model.schema_sha256), 64)
        # Dictionary insertion order does not alter the recipe's meaning.
        model.score(replace(other, processing=dict(reversed(list(self.processing.items())))))

    def test_04_schema_shape_and_bad_declarations_rejected(self):
        batch = self.batch(self.fit)
        variants = [replace(batch, feature_schema=self.schema[:2]),
                    replace(batch, feature_schema=(self.schema[0], self.schema[0], self.schema[2])),
                    replace(batch, feature_schema=(('', 'Pa'), *self.schema[1:])),
                    replace(batch, processing={}), replace(batch, processing={'bad': float('nan')}),
                    replace(batch, processing={'bad': object()})]
        for bad in variants:
            with self.subTest(batch=bad), self.assertRaises(ValueError):
                CandidateNormalModel().fit(bad, CONFIG['models'][0], 42)

    def test_05_typed_and_untyped_modes_cannot_silently_mix(self):
        typed = CandidateNormalModel().fit(self.batch(self.fit), CONFIG['models'][0], 42)
        bare = CandidateNormalModel().fit(self.fit, CONFIG['models'][0], 42)
        with self.assertRaisesRegex(ValueError, 'feature_schema_mismatch'):
            typed.score(self.evaluation)
        with self.assertRaisesRegex(ValueError, 'feature_schema_mismatch'):
            bare.score(self.batch(self.evaluation))
        # Explicit limitation: a bare array has no name/unit/order information.
        self.assertIsNone(bare.schema_sha256)
        self.assertEqual(bare.score(self.evaluation[:, ::-1]).shape, (11,))

    def test_06_bad_matrix_values_and_width_rejected(self):
        bad_inputs = [self.fit.tolist(), self.fit.astype(object), self.fit.astype(complex),
                      self.fit.astype(bool), self.fit.ravel(), np.empty((3, 0)),
                      np.full((3, 3), np.nan), np.full((3, 3), np.inf)]
        model = CandidateNormalModel().fit(self.fit, CONFIG['models'][0], 42)
        for bad in bad_inputs:
            with self.subTest(dtype=getattr(bad, 'dtype', None)):
                with self.assertRaises(ValueError): CandidateNormalModel().fit(bad, CONFIG['models'][0], 42)
                with self.assertRaises(ValueError): model.score(bad)
        with self.assertRaisesRegex(ValueError, 'feature_width_mismatch'):
            model.score(np.zeros((2, 2)))
        self.assertEqual(model.score(np.empty((0, 3))).shape, (0,))

    def test_07_insufficient_unknown_config_and_unfitted(self):
        for config in CONFIG['models']:
            with self.assertRaisesRegex(ValueError, '^insufficient_training_samples$'):
                CandidateNormalModel().fit(self.fit[:1], config, 42)
        for bad in [{'kind': 'unknown'}, {'kind': 'pca', 'components': True},
                    {'kind': 'pca', 'unknown': 1}, {'kind': 'pca', 'min_samples': 0}]:
            with self.assertRaises(ValueError): CandidateNormalModel().fit(self.fit, bad, 42)
        with self.assertRaises(ValueError): CandidateNormalModel().fit(self.fit, CONFIG['models'][0], True)
        with self.assertRaisesRegex(ValueError, 'model_not_fitted'):
            CandidateNormalModel().score(self.evaluation)
        with self.assertRaisesRegex(ValueError, 'model_not_fitted'):
            CandidateNormalModel().save(self.root/'unfitted.joblib')

    def test_08_inputs_config_and_failed_refit_leave_state_unchanged(self):
        config = copy.deepcopy(CONFIG['models'][0])
        batch = self.batch(self.fit.copy())
        original = batch.values.copy()
        model = CandidateNormalModel().fit(batch, config, 42)
        model.score(self.batch(self.evaluation))
        np.testing.assert_array_equal(original, batch.values)
        self.assertEqual(config, CONFIG['models'][0])
        self.assertEqual(batch.processing, self.processing)
        path = self.root/'state.joblib'
        model.save(path)
        before = sha(path)
        with self.assertRaises(ValueError): model.fit(self.fit[:1], config, 42)
        model.save(path)
        self.assertEqual(sha(path), before)
        # Caller metadata mutation is detected against the saved snapshot.
        batch.processing['window_seconds'] = 2
        with self.assertRaisesRegex(ValueError, 'feature_schema_mismatch'): model.score(batch)

    def test_09_pca_direction_is_anomaly_error(self):
        x = np.column_stack([np.arange(30.), np.arange(30.), np.arange(30.)])
        model = CandidateNormalModel().fit(x, {'kind': 'pca', 'components': 1}, 42)
        good, bad = model.score(np.array([[15., 15., 15.], [15., 15., 500.]]))
        self.assertGreater(bad, good)
        self.assertEqual(model.score_direction, 'higher_is_more_anomalous')

    def test_10_acoustic_adapter_split_route_model_comparison(self):
        root = self.root/'acoustic'
        cfg = acoustic_settings('quick')
        cfg.update(CONFIG['acoustic_generation_overrides'])
        generate_acoustic(root/'data', cfg)
        self.assertTrue(read_json(root/'data/train_manifest.json')['normal_only_attested'])
        # Neither truth.json nor generator truth arrays are read below.
        training = InputAdapter().load(root/'data/train_manifest.json')
        evaluation = InputAdapter().load(root/'data/eval_manifest.json')
        experiment = acoustic_experiment('data', 'runs')
        fit, calibration, split = DatasetPlanner().plan(training, evaluation, experiment['split'], 42)
        write_json(root/'split.json', split)
        write_json(root/'generation.json', cfg)
        write_json(root/'experiment.json', experiment)
        route = FixedWindow(experiment['routes'][0])
        service = SignalService(experiment['signal'])
        prepared = [route.prepare(records, service) for records in (fit, calibration, evaluation)]
        matrices = [np.array([p.values[k] for k in sorted(p.values)]) for p in prepared]
        metadata = {'route': experiment['routes'][0], 'signal': experiment['signal']}
        batches = [FeatureBatch(x, route.feature_schema(), metadata) for x in matrices]
        comparison = []
        for config in CONFIG['models']:
            candidate = CandidateNormalModel().fit(batches[0], config, 42)
            baseline = NormalModel().fit(matrices[0], config, 42)
            path = root/(config['kind']+'.joblib')
            candidate.save(path)
            digest = sha(path)
            for batch, matrix in zip(batches[1:], matrices[1:]):
                np.testing.assert_allclose(candidate.score(batch), baseline.score(matrix), **CONFIG['score_comparison'])
            # RoutePlugin's existing bare-array consumer can use the candidate.
            bare = CandidateNormalModel().fit(matrices[0], config, 42)
            actual = route.score(bare, prepared[2], batch_size=7)
            expected = route.score(baseline, prepared[2], batch_size=1)
            self.assertEqual(len(actual), len(expected))
            for observed, reference in zip(actual, expected):
                np.testing.assert_allclose(observed['anomaly_score'], reference['anomaly_score'], **CONFIG['score_comparison'])
                self.assertEqual({k: v for k, v in observed.items() if k != 'anomaly_score'},
                                 {k: v for k, v in reference.items() if k != 'anomaly_score'})
            candidate.score(replace(batches[2], values=matrices[2]*100))
            candidate.save(path)
            self.assertEqual(sha(path), digest)
            comparison.append({'kind': config['kind'], 'fit_rows': len(matrices[0]),
                               'calibration_rows': len(matrices[1]), 'evaluation_rows': len(matrices[2]),
                               'max_absolute_score_difference': float(np.max(abs(candidate.score(batches[2])-baseline.score(matrices[2])))),
                               'model_sha256': digest, 'schema_sha256': candidate.schema_sha256})
        np.savez_compressed(root/'feature_rows.npz', fit=matrices[0], calibration=matrices[1], evaluation=matrices[2])
        write_json(root/'comparison.json', comparison)


if __name__ == '__main__':
    unittest.main(verbosity=2)
