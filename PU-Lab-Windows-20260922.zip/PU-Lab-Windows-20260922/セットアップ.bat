@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto check
py -3.12 -c "import sys; assert sys.version_info[:2] == (3,12)" >nul 2>&1
if errorlevel 1 goto fallback
py -3.12 -m venv .venv
if errorlevel 1 goto fail
goto check
:fallback
python -c "import sys; assert sys.version_info[:2] == (3,12)" >nul 2>&1
if errorlevel 1 goto missing
python -m venv .venv
if errorlevel 1 goto fail
:check
".venv\Scripts\python.exe" -c "import sys,struct; assert sys.version_info[:2] == (3,12) and struct.calcsize('P') == 8"
if errorlevel 1 goto missing
".venv\Scripts\python.exe" -m pip install -r "pu_lab\requirements.txt"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -c "import numpy,scipy,sklearn,matplotlib,threadpoolctl"
if errorlevel 1 goto fail
echo Setup complete. Run the launch BAT file.
if /i not "%~1"=="--no-pause" pause
exit /b 0
:missing
echo Python 3.12 64-bit is required. Install it from https://www.python.org/downloads/windows/
echo Enable the Python launcher or Add python.exe to PATH, then retry.
goto fail
:fail
echo Setup failed. Check the messages above. Internet access is needed for pip install.
if /i not "%~1"=="--no-pause" pause
exit /b 1
