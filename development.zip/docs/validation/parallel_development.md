# 独立機能の並列開発・選択統合 実施記録

対象: PoC 0.2.0 / ResultBundle schema 1.0。日付: 2026-10-15 JST。

## 状態

A/B/Cの独立開発・単独試験と、Bの選択統合5試験は成功。最終全体回帰・既定CLI比較の実行結果は下記結果表に確定する。今回の目的は開発方式の実証であり、検出性能向上ではない。

## 実際の並列実行

rootを統合担当Iとし、独立した3つのsub-agentを実際に起動した。別Git checkout/Worktreeは作らず、同じ作業フォルダで所有ファイルと生成物保存先を分離した。

|担当 / 既存所有者|独立agent|担当実装・試験・設定|単独結果|
|---|---|---|---|
|A / D|/root/input_adapter|nv_runner/input_candidate.py、tests/test_input_candidate.py、configs/parallel/input_dummy_columns.json|13成功 / 4.487秒|
|B / RA|/root/route_candidate|nv_runner/route_a_candidate.py、tests/test_route_a_candidate.py、configs/parallel/route_a_candidate.json|10成功 / 1.692秒|
|C / M|/root/model_candidate|nv_runner/model_candidate.py、tests/test_model_candidate.py、configs/parallel/model_comparison.json|10成功 / 1.957秒|
|I|/root|共有接続、tests/test_parallel_integration.py、tools/run_parallel_verification.py、所有範囲監査|結合5成功 / 32.771秒|

並列期間の根拠（記録済み時刻。agent起動時刻そのものと混同しない）：

- Bの明示時刻記録: 2026-10-14 22:29:52〜22:32:05 UTC（翌日07:29:52〜07:32:05 JST）。調査開始はこれより前。
- Cの実装開始観測〜完了: 22:30:01〜22:32:56 UTC（07:30:01〜07:32:56 JST）。
- Aの実測単独試験期間: 22:31:44〜22:31:49 UTC（07:31:44〜07:31:49 JST）。この期間がB/C双方の作業期間内にある。

3担当の作業期間は重なっている。実際のCPU命令が同時実行された割合や、逐次開発に対する速度改善は測っていない。共有接続はBの単独試験合格通知後、Iだけが実施した。

各担当のログ/時刻/hash/再開情報は `reports/parallel_development/A/state.json`、`B/state.json`、`C/result.json`。担当説明は `docs/workstreams/input.md`、`route_a.md`、`model.md`。

## 候補の内容と採用判断

### A: column JSON入力Adapter（本番登録なし）

独自ダミー形式 `nv_dummy_columns@1.0` のtime/p/u/rpm列を標準NPZ/manifestへ変換し、既存InputAdapterを通してC01 Recordを生成する。SI単位・等間隔時刻・共置pair・方向・校正・必須metadata・IDを検査。変換は新しい出力フォルダへ限定する。

原本SHAとcanonical NPZのSHAは別々にprovenance sidecarへ記録する。truth/未知のtop-level項目をRecordへ渡さず、派生元IDを明示的に保持する。既存入力経路は変更していない。実機の校正情報や虚偽metadataを科学的に検証したものではない。複数測定の本番登録・実測フォーマット接続は未実施。

### B: 全時間窓経路（今回の選択統合対象）

`FixedWindowCandidate` は最大64窓ずつまとめてHann周波数特徴・RMS等を計算する。既存A全域と同じ8特徴・単位を維持し、C03のID生成とfit/score/集約を既存基底から利用する。既存Aのprepareを呼ぶだけのwrapperではなく、候補専用の内部計算を持つ。

新しいplugin名 `fixed_window_candidate`、経路key `A_candidate` を割り当てた。従来の `fixed_window` と既定profilesは変更しない。選択領域は候補の対象外であり、selection.enabled=trueを明示拒否する。科学的な特徴定義、閾値、共有signal mapは変更していない。

既存REGISTRYには遅延factoryを追加しただけで、同じconfig→pluginの呼出規約を維持。runnerの必須parameter辞書へ候補を登録し、有効な候補だけ専用設定検査を呼ぶ。選択されていなければmoduleのimportも実行もしない。

同config/IDでの単独比較は特徴・スコアをrtol=atol=1e-12、座標/ID/状態/閾値/個体結果を厳密比較して成功（70評価入力、7ケース）。本番では別plugin/keyがIDを変え、ID順に並べたfit行順も変わる。このため旧本番Aと候補のIFモデルhash・スコアの完全一致は合格条件にしていない。元測定座標で対応づけた特徴量・状態の同等性を結合試験で検査する。既定経路の前後比較は別途厳密比較する。

### C: schema照合付きモデル（本番登録なし）

候補内にIF/PCAのfit/score/saveを独立実装。裸ndarrayは既存C04互換、任意の `FeatureBatch` は名前・順序・単位・処理条件・版をcanonical JSONとSHAで識別する。学習時のschema snapshotと推論時のschemaが不一致なら拒否する。

正常fitデータだけでStandardScalerとモデルを学習する。学習40行、cal20行、eval70行の同batch比較ではIF/PCAとも旧モデルとの差0。裸ndarrayは列の意味を表せず、意味の並び替えを検出できない。schema付き入力を全経路の必須型にする場合はC03/C04の変更審査が必要だが、今回は候補内部で完結したため共通契約変更はない。

## 結合試験と受入

`tests/test_parallel_integration.py` は新しいUUID生成先で観測データから学習・校正・評価・Bundle保存を実行する。既存CLIを別プロセスで呼び、以下を検査する。

1. A/B/Cの候補moduleをimport時に利用不能にしても、既定5経路が完走する。
2. Bだけ選択すると、A/Cを利用不能にしたままBが完走し、候補moduleの読込はBだけになる。
3. Bのenabled=falseでBを利用不能にしても既定5経路が完走し、Bの入力・結果を生成しない。
4. Bを選択してBの依存moduleが欠落した構成は、実行前の設定検証で明示失敗する。
5. 不正な窓設定・未対応selectionを設定検証で拒否する。

選択時は既存Aと全splitの元測定ID/座標/状態/理由/8特徴を比較し、入力IDとscoreの集合対応、finiteスコア、旧Readerによるschema1.0読込、別プロセスviewerを検査する。依存欠落はimport hookで模擬し、ソースや過去データを削除していない。

## 結果表・保存物

|検証|結果|証拠|
|---|---|---|
|作業開始時baseline|59/59成功、182.040秒。既存記録との件数/合否差なし|reports/parallel_development/I/baseline.log|
|候補単独|A13/B10/C10成功|A/unit_tests.log、B/tests.log、C/unit_tests.log|
|結合|5/5成功、32.771秒|I/integration.log|
|所有範囲・保護|提出4ファイル×3担当のhash一致、所有範囲逸脱/最終ファイル競合なし。既存試験/契約資料28ファイル不変|I/ownership_audit.json|
|全体回帰・既定比較・候補CLI|最終実行中|I/final/state.json、all_tests.log、default_comparison.json|

baseline CLIはacoustic quick既定（seed42、正常学習12個体、評価7個体、2測定/個体、4秒、1024Hz）。モデル・calibration・分割は既存experiment.jsonのまま。候補単独/結合は正常6個体、3秒等の軽量条件を用い、それぞれ設定を保存した。別の条件を同一検出結果として比較しない。

既定CLI前後比較は `tools/compare_extraction.py` を再利用し、同じ観測・同じexperiment.jsonを両版で実行する。全9table、分割、metrics、truth、モデル/閾値/保存配列を照合する。run_id、実行時間、時刻、ソースhash等の実行由来差を除外し、両BundleはそれぞれReaderで完全性検証する。

## 再実行コマンド

PoCルートで実行。Python/依存は既存requirements.txt（今回追加・変更なし）。Windowsではpythonを `.venv/Scripts/python.exe` に置換できる。

```powershell
python -m unittest discover -s tests -p test_input_candidate.py -v
python -m unittest discover -s tests -p test_route_a_candidate.py -v
python -m unittest discover -s tests -p test_model_candidate.py -v
python -m unittest discover -s tests -p test_parallel_integration.py -v
python -m unittest discover -s tests -v
```

通常の実験JSONのroutesへ `configs/parallel/route_a_candidate.json` の1要素を追加するとBを選択できる。Bを使わない場合はその要素を削除、またはenabled=falseにする。旧A〜D設定はそのまま使える。断片JSONを直接executeの完全設定として渡さない。

```powershell
# 下のbaselineは今回保存した変更前demo。既存出力を上書きしない新output名を指定する。
python tools/run_parallel_verification.py --baseline reports/parallel_development/I/baseline_demo --output reports/parallel_development/I/recheck_new
```

この補助コマンドは全試験→既定CLI/前後比較→B追加CLI→Reader→viewer→ローカルimportを行う。失敗段階とログをstate.jsonへ保存し、失敗を完了に置き換えない。再開は原因修正後、新output名で行う。過去データを移送できない環境では変更前版のdemoでbaselineを新規生成し、同じ観測を変更後版から実行する。変更前版がなければ「既定再現性検査」であり、過去版との前後比較とは呼ばない。

## 変更範囲・切戻し

既存共有本番の変更は `nv_runner/routes.py` の遅延factory/登録と `nv_runner/runner.py` の候補パラメータ検証だけ。Iが変更した。input_adapter.py、models.py、signals.py、selection.py、profiles.py、CLI、BundleReader/Collector、schema/version、requirements、既存59試験と契約書は変更していない。

その他のI成果物は `development/ownership.json` のI所有ファイル追記、`tests/test_parallel_integration.py`、`tools/run_parallel_verification.py`、本報告。A/B/Cは各3候補ファイルと既存担当説明各1ファイルのみ。詳細なbefore/after SHAはownership_audit.json、生成成果物は担当別reports/parallel_developmentまたはtests/_work/{D,RA,M,I}/<uuid>。

最小切戻しは候補routeを無効化するだけ。本番コードの撤去が必要ならIが追加factory/REGISTRY key、validatorの候補項目/検査分岐を戻す。A/Cは本番へ配線していない。候補moduleがなくても非選択の既定CLIは動作することを試験済み。過去Bundleには何も追記・改変しない。

## 不整合・初回失敗・未実施・次回改善

- 共通契約変更、未解決CR、既存59試験の削除/緩和はない。候補登録は既存C08の登録手順内で実施し、新しいregistry APIを設けていない。
- Aの初回1失敗は担当試験のSTFT設定key誤記。Cの初回1失敗は担当試験がbatch差のPCA端数を厳密比較したこと。新規試験だけ修正し、既存許容差1e-12を使用した。初回失敗ログを残し、最終成功と区別する。
- 本番の強制アクセス制御はない。ファイル所有表と前後snapshot/担当提出hashで最終状態を検査した。誰かが他担当ファイルを一時編集して元に戻した行為まで検知できるとは主張しない。Git/Worktree操作は行っていない。
- A/Cの本番採用、実データ、外部システム実接続、全機能の動的交換・削除基盤、異OS、開発速度比較は未実施。外部受渡しは既存のローカルBundle importまで。
- 今回Bは全域A互換候補であり、選択領域や別特徴への拡張は次回。Cの意味schemaを必須化する場合はCRでproducer/consumer両側を揃える。裸配列のまま自動検出できると扱わない。
- 次回は開始直後の時刻記録を各担当で統一し、単独試験・提出hash・許可パスを同じ形式で出すと監査を簡素化できる。今回agent間でstateのfield名は異なるためIが対応づけた。
