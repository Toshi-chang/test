# Phase 3：明示Registry・設定宣言・選択交換 実施記録

対象はPoC 0.2.0 / ResultBundle schema 1.0。2026-10-15 JST。既存の97試験とC01〜C08を基準に、現行のRoutePlugin lifecycleを維持した段階移行を実施した。

## 状態と実装

**Phase 3は完了。全130試験が合格し、既定5経路とcandidate追加6経路の両方で移行前後の結果・モデル・閾値・配列が一致した。** 新規プラグインは実装・登録定義・専用試験・利用構成の追加だけで動作し、中央Runner/Validatorの個別変更が不要であることを実証した。未完了作業はない。

調査で存在を確認した設計パスは `docs/parallel_contracts/` と `docs/plugin_architecture/`。`docs/plugin_lab/` は存在しないため作成していない。DESIGN.mdの将来向けrun/Composition APIは現行学習系へ導入せず、実際のprepare/fit/score/aggregate/calibrate/decideを使用した。

|実装ファイル|責務|
|---|---|
|nv_runner/plugin_descriptor.py|plugin_id、implementation_version、descriptor/API版、factory、config_schema、入出力契約、model契約、任意制約validatorの宣言|
|nv_runner/plugin_registry.py|明示登録/削除/参照、宣言整合、遅延factory解決、実メソッド呼出署名の事前検査、Mapping互換|
|nv_runner/plugin_catalog.py|レビュー済み5実装の登録定義。既存4種類とA_candidate。経路構成は従来どおりA全域/A選択/B/C/Dの5経路|
|nv_runner/plugin_validation.py|宣言schemaによる設定検査。共通のmodel/selection検査。プラグイン名による分岐なし|
|nv_runner/routes.py|数値計算を維持。末尾REGISTRYを新registryの互換aliasへ接続|
|nv_runner/runner.py|経路固有の必須parameter表とcandidate専用分岐を撤去しREGISTRY.validateへ委譲。実行/保存処理は維持|

登録・一覧・存在確認・factory参照の段階ではプラグインをimportしない。選択した経路だけ設定と依存を検査する。無効経路は従来どおりkeyの確認後にスキップする。

Descriptorの対応版はdescriptor/APIとも1.0、入力C01/C02=1.0、出力C03/C05=1.0、モデルC04@1.0を完全一致で確認する。対応しない版・契約・重複plugin_id・不正schema定義は登録時に拒否する。1つのplugin_idにつき1実装版を登録する方式であり、複数版同時解決やsemver範囲選択は実装していない。構成でimplementation_versionを明示した場合は登録版との完全一致を要求する。無指定なら登録版を使い、構成へ値を書き足さない。

factoryと制約validatorは信頼済みPython登録定義の `module:attribute`。構成JSONの任意factory値を解決しない。自動directory探索、ユーザー提供Pythonファイルの自動実行、コードsandboxは実装していない。

## 設定互換性とschema

既存profiles/config、model計算、閾値、sample ID生成、時間/周波数座標、状態・理由、分割、真値境界、保存schemaを変更していない。検証はdefaultを注入せず構成を書き換えない。

既存必須正数の宣言は `type:number, exclusiveMinimum:0, allow_bool:true, finite:false`。旧Python検証が許容したbool等を新Validatorで勝手に厳格化しないための互換指定である。ファイルJSONの非有限数拒否は従来のread_jsonが担う。candidateには既存のvalidate_candidate_configも適用し、その厳密性を維持する。

新規宣言はbool数値化・非有限値を既定で拒否できる。対応schemaはtype、objectのproperties/required/additionalProperties、arrayのitems/minItems/maxItems、number/integerの範囲・allow_bool/finite、enum。完全なJSON Schema実装ではなく、default、$ref等の未対応keywordは拒否する。詳細は `docs/workstreams/phase3_validator.md`。

旧 `REGISTRY[id](config)`、iteration、membershipを互換層で維持する。新登録は `register(PluginDescriptor)` を使い、旧dictへの直接代入による宣言なし登録は新APIの対象外。model種別は引き続き既存IF/PCAであり、モデル基盤の汎用化まで実施したものではない。

## 新プラグインの追加・交換手順

1. 専用Python moduleに現行RoutePlugin契約を満たすクラスを実装する。constructor(config)、capabilities/feature_schema/prepare/fit/score/aggregate/calibrate/decideを備え、C03 PreparedSetとC05の状態・null・根拠を維持する。
2. `plugin_catalog.py` のBUILTIN_DESCRIPTORSへレビュー済みDescriptorを1件追加する。Runnerや共通Validatorの条件分岐は追加しない。プロセス内の検証用途では明示的なDEFAULT_REGISTRY.registerも利用できる。
3. 専用試験を実行し、構成のroutes要素でpluginを選択する。既存設定は変更不要。無効化はenabled=false、撤去は構成から除外後に登録定義を削除する。
4. 不正設定/依存/宣言版が起動前に拒否されること、旧Readerで新Bundleを読めることを確認する。契約外の新しいデータ型やモデルを要求する場合は本追加手順へ無理に混ぜず、C契約の変更審査へ分離する。

Descriptor例（コード側の登録定義。新moduleの実在/レビューは別途必要）：

```python
PluginDescriptor(
    plugin_id="my_window", implementation_version="0.1.0",
    factory="nv_runner.my_window:MyWindow",
    config_schema={
        "type": "object", "additionalProperties": True,
        "required": ["window_seconds", "hop_seconds"],
        "properties": {
            "window_seconds": {"type": "number", "exclusiveMinimum": 0},
            "hop_seconds": {"type": "number", "exclusiveMinimum": 0},
        },
    },
)
```

設定だけの既存実装交換には `configs/parallel/plugin_exchange_legacy.json` と `plugin_exchange_candidate.json` を使える。いずれもroutesへ挿入する断片であり、単独の完全experiment.jsonではない。plugin/keyが異なるため生成IDの同一性は要求せず、元測定・範囲・feature_schemaで対応づける。

## 中央コード無変更の実証

`tests/phase3_fixture_plugin.py` にテスト専用ExtensionWindowを置き、独自必須設定template_tagをDescriptorに宣言した。`tests/test_plugin_exchange.py` が新Descriptorを明示registerして既存ExperimentRunnerを起動し、正常fit/calibration・評価の全工程と実モデルを実行する。finally相当のtearDownで登録を除去し、他試験へ残さない。

この追加の前後でrunner.py、routes.py、plugin_registry.py、plugin_validation.pyのSHA256が不変。130 sample resultsとschema1.0 Bundleを生成した単独証拠は `tests/_work/P3T/03dd67dd78a14b06b9e0b56143d6ec81/central_unchanged_evidence.json`。再実行時は新UUIDへ保存される。第三実装は登録拡張用fixtureで、既存FixedWindow計算を再利用する。独立した内部計算の交換実証は既存fixed_windowとfixed_window_candidateで別途行っている。

独自schema不正・未知契約版・API版・不足factoryを出力ディレクトリ作成前に拒否。別プロセスでcandidate/不足moduleのimportを禁止しても、非選択・無効のまま既定5経路が完走する。登録を除去しても独立経路の検証は成立する。

## 担当・並列作業・所有範囲

|担当|専有実装/試験|結果記録|
|---|---|---|
|P / phase3_registry|plugin_descriptor.py、plugin_registry.py、plugin_catalog.py、test_plugin_registry.py|reports/phase3/P/state.json、registry_tests.log|
|V / phase3_validator|plugin_validation.py、test_plugin_validation.py|reports/phase3/V/status.json、attempt01.txt|
|T / phase3_exchange|test_plugin_exchange.py、phase3_fixture_plugin.py、plugin_exchange_*.json|reports/phase3/T/exchange_tests.log、status_by_integrator.json|
|I / root|runner.py/routes.py接続、test_plugin_compatibility.py、verify_phase3.py、所有表、監査/報告|reports/phase3/I/|

P/V/Tを3つのsub-agentとして実際に同時起動し、専用ファイルで開発した。PとVはAPIを直接確認し、Tはテストを並列作成してIの共有接続後に実行した。共有本番ファイルの変更はIだけ。担当説明はdocs/workstreams/phase3_{registry,validator,exchange}.md。

Tは7件成功の結果提出後、最終応答で利用制限に到達した。Iが保存済みコード・ログ・中央SHA証拠を確認し、再実装せず全体検証を引き継いだ。Tの開始終了時刻は保存されていないため推測しない。全担当が最終応答まで通常完了したとは報告しない。

development/ownership.jsonへP3P/P3V/P3TとIの専用パスを追加。既存所有範囲・97試験・共通契約を変更していない。Git初期化・設定・Worktree操作は行っていない。

## 試験結果

|検証|結果|
|---|---|
|開始時baseline|97/97成功、196.809秒。前回記録との差なし|
|Registry|12/12成功、1.086秒|
|Validator|12/12成功、0.002秒|
|独立登録・交換|7/7成功、12.669秒|
|I互換接続|2/2成功、0.021秒|
|全体回帰|130/130成功、206.318秒（既存97＋Registry12＋Validator12＋交換7＋互換2）。final_tests.log|
|既定5経路の前後比較|成功。9,243入力・35個体×経路行。default_comparison.json|
|candidate追加6経路の前後比較|成功。candidate_comparison.json。異なる構成同士ではなく同一構成の移行前後を比較|
|旧Reader/viewer/output adapter|成功。別プロセスviewer、ローカルimported、unresolved_sources=[]。viewer.log/import.log|
|保護・所有範囲|既存試験/契約32ファイル不変、旧経路の7クラス/関数定義AST不変、19変更ファイルの所有範囲と提出hash適合。scope_audit.json|

証拠は `reports/phase3/I/`。candidate Bundleは `candidate_runs/run_0f15a562241e439e9d4ae6d9ac3aa48b`、manifest SHA256は `efd6a0d3f2eb054717648bd6faae35e686ceec0cb0731c0fbab0c0bc777c6cbf`。閲覧は `reports/phase3/I/viewer.html`。完了記録はcompletion.json/state.json、最終consumer検証完了は2026-10-15 23:45:01 JST。途中のT利用制限は上記のとおり引継ぎ済みで、失敗中の受入項目はない。

変更一覧はscope_audit.jsonにbefore/after SHAとownerを保存した。既存共有本番の変更はrunner.pyとroutes.pyだけ。新規本番4ファイル、専用試験4ファイル＋fixture1、設定断片2、担当説明3＋本報告、所有表、検証ツールを含む計19ファイル。models.py、signals.py、input_adapter.py、profiles.py、CLI、Bundleコード、A_candidateの実装は不変。契約の破壊的変更・未解決CRはない。

baselineデータは既定acoustic quick（seed42、正常学習12個体、評価7個体、各2測定、4秒、1024Hz）。同じ入力・設定を移行後にも使用し、既定5経路とcandidate追加6経路をそれぞれ同構成で比較する。異なるplugin/key間にスコア・ID完全一致を強制した比較ではない。

前後比較は既存compare_extractionを利用。全tableのID/座標/状態/理由/数値、モデル・閾値・配列の内容一致を検査する。run_id、実行時間・時刻、ソースhash等の正当に変化する来歴は除外する。Bundle自体は旧Readerで検証し、別プロセスviewerとローカルoutput adapterで確認する。

## 再実行と再開

PoCルートで既存requirements.txtの環境を使う。依存追加なし。Windowsはpythonを `.venv/Scripts/python.exe` に置換可能。

```powershell
python -m unittest discover -s tests -p 'test_plugin_*.py' -v
python -m unittest discover -s tests -v
```

今回の保存証拠を再検証する場合：

```powershell
python tools/verify_phase3.py --evidence reports/phase3/I
```

新たな前後比較には移行前版で新規demoとcandidate構成を作り、移行後版で同じJSONをexecuteする。今回のログ名はbaseline.log、baseline_cli.log、baseline_candidate.log、final_tests.log、after_default.log、after_candidate.log。before/after BundleパスはCLIログ末行。baseline_demo/summary.json、baseline_candidate.json、baseline_hashes.json、runner_before.py、routes_before.pyも証拠として保存済み。

verify_phase3は保存ログの合格・試験数、新旧Bundle、既存試験/契約hash、旧経路の計算AST、非変更のモデル/入力/CLI/Reader等を検査し、viewer/importを別プロセスで実行する。学習を省略して試験したと装うものではなく、先に実行したログ/Bundleの検証用。失敗はverification_failure.json、成功はcompletion.json/state.jsonへ保存する。過去結果を移送できない別環境ではデータ生成・学習・評価を再実行する。

## 制約・次段階

- Descriptorは宣言とメソッド署名を検査するが、科学的同等性や実際の戻り値の全内容を実行前に証明しない。C01〜C08契約試験・各専用試験・Reader検証は引き続き必要。
- preflightと実行の両方でconstructorが呼ばれる。constructorは設定保持など副作用のない処理に限定する。prepare/fit/scoreはpreflightで呼ばない。既存実装はこの条件を満たす。
- 明示登録は信頼コード前提。悪意あるPythonへの隔離ではない。登録更新と同時実行のthread safety、実行中hotswap、汎用依存DAG、複数版同時選択は未実装。
- C04のモデル種別/保存説明はIF/PCAのまま。新モデルや新入出力契約が必要なら別の変更審査を行う。今回のRegistryが任意の将来契約を自動理解するとは扱わない。
- 実測・外部システム実接続・異OS検証・性能向上評価は未実施。受渡しはローカルBundleのみ。
- 次段階の候補は、登録Descriptorの任意来歴保存、純粋なconstructorの専用チェック、モデル拡張境界の設計審査。現段階の完成条件とは分離し、自動で追加実装しない。

切戻しは候補経路を無効化する方法が最小。Registry移行全体を戻す場合は保存したrunner_before.py/routes_before.pyとの差分をIが確認して戻す。後続変更をファイル全体で上書きしない。保存済みBundleは変更不要。
