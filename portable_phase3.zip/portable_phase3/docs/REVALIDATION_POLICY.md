# 01のみを移植する継続検証方針書

版1.0 / 2026-10-12 / 対象ソフトウェア0.2.0・ResultBundle 1.0

## 1. 採用方針

移植対象は01_runtimeのみ。02_viewingと03_evidenceは不要とし、合成データ・モデル・閾値・Bundle・viewer.html・試験ログは移植先で再生成する。過去の大容量結果の完全再現ではなく、同じコード・設定に基づく再検証として記録する。

01内の本書とdocs/BASELINE_REFERENCE.jsonに過去の軽量な基準情報を残す。基準情報は過去の実測定結果ファイルやモデルの代用品ではない。旧0.1の完全ソーススナップショットは収録していないため、旧版のビット単位再現は対象外。現行acoustic版を新しい検証の起点とする。

過去に確認した事実：Windows / Python 3.12.14で32試験成功。acoustic quick/comparisonでA全領域・A選択・B・C・D完走。物理式の数値照合とブラウザー閲覧確認に成功。別OSの合格を意味しない。移植先で以下を改めて実行する。

## 2. Gitと成果物の管理

Gitにはnv_runner（viewer.htmlテンプレートを含む）、configs、docs、testsのコード、tools、requirements.txt、README、実行スクリプト、.gitignoreを登録する。ZIP自体をGitへ登録せず、展開した01の中身をリポジトリのルートに置く。

同梱.gitignoreでdata/runs/demos/examples/evaluation_inbox/workspace/reports、仮想環境、試験一時データ、NPZ・joblib・ZIPを除外する。既に追跡済みのファイルには.gitignoreが効かないため、登録前にgit statusとgit ls-filesで対象を確認する。履歴からの削除は別途判断し、この方針では自動実施しない。

毎回Gitへ残す軽量な検証記録はdocs/validation/<日付>_<環境名>.mdまたは小さなJSONとする。記録内容：

- コミットID・未コミット差分の有無、Python/OS/CPU、依存版、実行日時。
- 設定ファイルまたはそのコミット/ハッシュ、seed、独立個体/派生元数、分割方法。
- 合否、試験件数、経路別TP/FP/FN/TN/判定不可、未ラベル数、異常種類別・外乱のみの結果。
- run_id、Bundle manifestのSHA256、データ登録manifestのSHA256、実行時間、エラー、差分理由。
- 大容量成果物の保管先識別子、保存期限、原本取得方法。機密情報・認証情報は記載しない。

合成の開発中成果は再生成可能なものとして扱える。ただし正式比較に使ったBundleと設定はGit外の管理ストレージに保存するのが望ましい。実測原本は再生成できないため、Git外で必ず保存・バックアップし、ハッシュで参照する。保管先がない場合は正式評価の証跡保全を未達と明記する。

## 3. 新環境での再試験手順

### 3.1 環境と移送確認

Python 3.12 64bitを用意し、01_runtime内で実行する。旧.venvは持ち込まない。通常実行はCPUでよく、Node.jsは不要。閉域環境では対象OS/CPU/Python用のwheelとPythonインストーラを別途準備する（TRANSFER_GUIDE参照）。

Windows PowerShell：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe tools/verify_transfer.py .
New-Item -ItemType Directory -Force reports | Out-Null
.\.venv\Scripts\python.exe -m pip freeze | Set-Content reports/environment_packages.txt
```

TRANSFER_MANIFESTは配布時点の完全性確認用。開発でソース変更後に不一致となるのは正常であり、新コミットと新しい配布manifestで管理する。macOS/Linuxではpython3.12と.venv/bin/pythonを使う。新OSの互換性はこの後の試験で確認する。

### 3.2 数理・隔離・異常処理の試験

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v *> reports/regression_tests.txt
if ($LASTEXITCODE -ne 0) { throw 'Regression failed; inspect reports/regression_tests.txt' }
.\.venv\Scripts\python.exe -m nv_runner.verify_physics --output reports/physics
if ($LASTEXITCODE -ne 0) { throw 'Physics verification failed' }
```

現時点では32件が基準。件数が変わった場合は追加/廃止理由を記録し、単に32件に合わせない。合格条件は全試験成功。個体/派生元の混入防止、正解隔離、評価変更時のモデル/閾値不変、ID対応、回転欠落、空選択、イベント0件、部分失敗、Bundle破損・未知版拒否を含む。

物理検証は実装済みの許容誤差で判定し、環境差を理由に閾値を無断で緩めない。失敗した場・周波数・方向・演算を特定する。これは数理実装試験であって実音場性能試験ではない。

### 3.3 quickを新規生成して全経路を確認

```powershell
.\.venv\Scripts\python.exe -m nv_runner demo --generator acoustic --profile quick --output demos/revalidation_quick
```

出力先は未作成の名前を指定する。実行後はdemos/revalidation_quick/summary.jsonでBundle位置を確認。demos/revalidation_quick/viewer.htmlをブラウザーで開く。

合格条件：5経路の学習/閾値設定/評価完了、Bundle complete、正常・異常・外乱のみが保存され、ローカル取込receiptのunresolved_sourcesが空。個体×経路から入力の時間・周波数・位置・元波形へ辿れる。生成器真値とモデル出力が表示上分離される。

保存済みBundleを別プロセスで再読込する：

```powershell
.\.venv\Scripts\python.exe -m nv_runner inspect --bundle "<summary.jsonのbundle>"
.\.venv\Scripts\python.exe -m nv_runner view --bundle "<summary.jsonのbundle>" --output reports/reopened.html
```

閲覧では5経路の行/点選択、時間軸、正解表示切替、p–u位相・MSC・インテンシティ・Z表示を確認する。任意の自動UI試験はtests/viewer_smoke.cjsを使用（Node.js/Playwright/ブラウザーは追加導入）。

### 3.4 comparisonと継続実験

```powershell
.\.venv\Scripts\python.exe -m nv_runner demo --generator acoustic --profile comparison --output demos/revalidation_comparison
```

過去基準はdocs/BASELINE_REFERENCE.json。現在の条件・同一依存版での差分を調査するが、検出件数の一致だけを数理・処理系の合格条件にはしない。異OS/CPUの微小差が閾値付近の判定を変える場合は、スコア差・閾値差・該当個体を記録する。run_id、時刻、パスは一致対象外。検出率100%は要求しない。

変更可能なデータ設定はconfigs/acoustic_*_data.json、処理設定はconfigs/acoustic_*.json。個別実行する場合はgenerate → validate → executeの順で、configのtrain/eval/truth/outputパスを生成先に合わせる。demoはprofiles.pyの既定設定から生成するため、configsだけを編集してdemoへ反映されると考えない。

現行comparisonは40学習個体、28評価シナリオだが、評価ベース実現は4群。これを独立28個体として信頼区間を計算しない。次の比較では独立個体/seedを増やし、開発・calibration・最終評価を分ける。対比較には同じ正常実現を使い、統計集計では派生元の群単位を維持する。

## 4. 継続的な再試験の範囲

|変更|最低限の再試験|
|---|---|
|新OS/Python/依存版|環境記録、全試験、物理検証、quick、comparison、閲覧|
|音源/センサー/信号解析|関連解析式の試験、全試験、物理検証、quick、comparison|
|経路/特徴/モデル/閾値|全試験、quick、comparison、正常/異常/外乱別差分|
|入力アダプタ|形式・単位・同期・欠損・分割の試験、quick、実測の既知条件試験|
|Bundle/出力アダプタ|完全性・未知版・再送・衝突・部分失敗・参照解決、別プロセス閲覧|
|viewer|保存Bundleの再生成、行/点/時間/正解切替、表示座標と計算範囲|

Git CIでは全試験とquickを基本とし、生成物をコミットしない。comparisonと条件掃引は新環境導入時・解析変更時・節目に実行する。CIの設定自体は未実装。CIを使わない場合も同じ実行記録を残す。保存容量を確保し、tests/_work等の保持期限を決める。

## 5. 実データ接続後の検証計画（提案）

以下は今後実施する項目であり、現在合格済みではない。数値許容差は測定器仕様・校正不確かさ・対象用途から事前に決める。値が決まっていない項目は未検証とし、推定値で合格にしない。

|段階・項目|実施方法|判定と残す証跡|
|---|---|---|
|入力形式と登録|既知ファイルのサンプル数、ch、キー、dtype、単位、ID、ハッシュを照合。欠損/重複/不正単位を投入|正しいファイルのみ受理。不明単位を推測しない。元ファイルと変換の由来を記録|
|p/u絶対校正|測定系に適した校正手順・証明値とSI換算を照合。飽和/クリッピング、自己雑音を確認|校正の有効帯域と不確かさを記録。帯域外・低SNRは評価対象外|
|相対位相・遅延|共通励振や校正治具で周波数別のp/u位相と遅延を確認。補正前後を保存|校正許容差内。強制的に位相0へ合わせない。近接場本来の位相を残す|
|位置・方向・共置|座標系を定義し、u軸反転でuとインテンシティの符号変化を確認。pは不変か調べる|向きと符号が一致。非共置・多センサーは現行対応外として明示|
|既知音場の整合|適用条件を満たす進行波/近接場等で、周波数・距離を変えてp/uを比較|音場の前提と校正不確かさの範囲で整合。あらゆる場所にp/u=ρcを要求しない|
|時間軸・rpm|サンプル時刻/ドリフト/遅延とパルスまたはrpmを独立計測と比較。停止、急変、欠落を含める|同期と次数位置が規定内。Bが不成立なら理由付き未評価。他経路は継続|
|計測品質と帯域|アンチエイリアス、DC、ノイズ床、欠測、極小u、選択maskを調べる|NaN/無限値や偽の大きなZを生成しない。validity・除外理由を追跡|
|繰返し再現性|同一個体の連続測定、付け直し、別日、別操作者、別計測器で比較|個体差と測定系差を分離して報告。日/機器等の混入で性能が上がっていないか確認|
|正常分布と分割|正常確認済みの独立個体を用意し、個体/派生元単位でfit/calibration/評価を分割|同一個体の窓や再測定が分割を跨がない。運転条件別coverageを記録|
|正常誤判定|固定済みモデル・閾値で未使用の正常個体を評価|個体単位のFP/TN/判定不可と信頼区間。入力窓数を独立個体数にしない|
|外乱だけの変化|対象状態を固定し外乱音源、背景、距離、位置条件を変更。対になる基準測定を取得|通常正常と外乱のみを分けて集計。p/uの混合場変化を対象故障と混同しない|
|既知異常|独立した検査・保全記録等で状態を確認し、種類/強度別に評価|TP/FN/判定不可と評価母数。独立正解がない場合は精度を主張しない|
|経路比較|pのみ/uのみ/p–u、A全/選択、B、C、Dを同一分割で比較|入力選択、特徴、モデル、閾値の寄与を切り分ける。生スコアを経路間で平均しない|
|根拠の逆引き|高スコア/正常/未評価の例を原本に戻して時間・周波数・運転条件・センサーを照合|表示範囲、演算支持範囲、maskが一致。異常スコアを故障部位の確定と呼ばない|
|運用変化|未知回転域、温度/負荷、センサー交換、経時変化でcoverageと誤判定を監視|適用範囲外・再校正・再学習の条件を設定。最終評価を学習へ自動流用しない|

まず少数の既知条件で計測・変換の整合を確認し、次に正常繰返し、独立正常個体、外乱、既知異常へ進む。統計評価の個体数は許容誤判定率と信頼区間幅から決める。少数測定で誤判定0件でも安全性/性能の保証とはしない。

実測接続時はInputAdapter.loadを交換/拡張する。現行契約は共置p/u 1ペア、SI校正済み、等間隔・共通時間軸。パルス復号・同期化・単位変換・多センサーは必要に応じてアダプタで実装する。実測configでは生成器truth_pathを外せる。生成器の真値を実測正解として流用しない。

## 6. 固定モデルと外部システム接続の追加検証

現状のexecuteは再学習から実行する。過去モデルだけで新測定を推論する専用CLIは未実装。導入時はモデル・前処理・特徴順序/単位・閾値・版を固定してロードし、同じ入力の再現、バッチ順不変、入力追加時のモデル/閾値不変、互換性の拒否を試験する。

外部受渡しはEvaluationAdapterを交換する。現状はローカルBundle取込のみ。接続後の検証項目：

- 正常なBundleの受領、未知schema/欠損/改変/中断stagingの拒否。
- 同一run再送の冪等性、同一IDで内容が異なる場合の衝突検出。
- 一部経路失敗や未評価を正常/スコア0に置換せず受け渡すこと。
- 元測定参照の解決、参照不能の通知、受領記録、タイムアウト後の再送。
- 相手側表示とローカル台帳の個体ID・判定・閾値・根拠の一致。
- アクセス権、認証、保存期間、監査記録は接続先要件に沿って設定。

01だけの移植でも、新規demoが作るBundleを使ってこの接続試験を開始できる。過去の03_evidenceは必須ではない。

## 7. 完了判定と引継ぎ記録

新環境への移植完了：全試験＋物理検証＋quick/comparison＋保存Bundle閲覧が成功し、差分を記録した状態。

実測入力接続完了：形式・SI校正・位相/同期・位置/軸・原本逆引きを既知条件で確認し、適用帯域と未対応条件を明記した状態。

実測での経路評価完了：独立した評価データで、事前固定した条件と合格基準により誤判定・見逃し・判定不可を報告した状態。検出率100%は要求しない。

外部接続完了：相手側との受領・再送・部分失敗・参照解決・表示一致の試験が成功した状態。ローカル取込成功だけで外部接続完了とはしない。

01を再配布する場合：python tools/build_transfer.py --runtime-only --output transfer_<新しい名前>。このモードは02/03や過去のexamples/reportsを要求しない。
