"""Atomic ResultBundle publisher, defensive reader, local output adapter."""
import shutil
from pathlib import Path
import numpy as np
from .common import read_json, write_json, read_lines, sha, require_version, inside, utc

TABLES = ["specimens", "cases", "measurements", "artifacts", "samples", "sample_results", "route_case_results", "case_results", "errors"]
REQUIRED = {f"{t}.jsonl" for t in TABLES} | {"experiment.json", "dataset_split.json", "environment.json", "metrics.json"}


class ResultCollector:
    def finalize(self, staging, manifest, destination):
        staging, destination = Path(staging), Path(destination)
        members = {}
        for path in sorted(staging.rglob("*")):
            if path.is_file() and path.name != "manifest.json":
                members[path.relative_to(staging).as_posix()] = {"bytes": path.stat().st_size, "sha256": sha(path)}
        manifest.update(schema_version="1.0", members=members, completed_at=utc())
        write_json(staging / "manifest.json", manifest)
        BundleReader(staging, allow_staging=True).validate()
        staging.rename(destination)
        return destination


class BundleReader:
    def __init__(self, path, allow_staging=False):
        self.path = Path(path).resolve()
        if ".staging" in self.path.name and not allow_staging:
            raise ValueError("staging bundle is not readable")

    def validate(self):
        manifest = read_json(self.path / "manifest.json")
        require_version(manifest)
        if manifest.get("bundle_status") not in ("complete", "partial"):
            raise ValueError("bundle is not finalized")
        members = manifest["members"]
        if not REQUIRED <= set(members):
            raise ValueError("missing required bundle members")
        actual = {p.relative_to(self.path).as_posix() for p in self.path.rglob("*") if p.is_file() and p != self.path / "manifest.json"}
        if actual != set(members):
            raise ValueError("bundle member set mismatch")
        for relative, desc in members.items():
            path = inside(self.path, relative)
            if not path.is_file() or path.stat().st_size != desc["bytes"] or sha(path) != desc["sha256"]:
                raise ValueError(f"bundle hash/size mismatch: {relative}")
            if path.suffix == ".json":
                read_json(path)
            elif path.suffix == ".jsonl":
                for line in path.read_text(encoding="utf-8").splitlines():
                    import json
                    json.loads(line, parse_constant=lambda v: (_ for _ in ()).throw(ValueError("non-finite JSON")))
        require_version(read_json(self.path / "experiment.json"))
        for filename in ("dataset_split.json", "environment.json", "metrics.json"):
            require_version(read_json(self.path / filename))
        tables = {t: read_lines(self.path / f"{t}.jsonl") for t in TABLES}
        def index(table, key):
            rows = tables[table]
            indexed = {r[key]: r for r in rows}
            if len(rows) != len(indexed):
                raise ValueError(f"duplicate {key}")
            return indexed
        samples = index("samples", "sample_id")
        artifacts = index("artifacts", "artifact_id")
        measurements = index("measurements", "measurement_id")
        cases = index("cases", "case_id")
        index("specimens", "specimen_id")
        for artifact in artifacts.values():
            require_version(artifact)
            if "threshold" in artifact:
                require_version(artifact["threshold"])
            desc = artifact.get("array_file")
            if desc:
                path = inside(self.path, desc["path"])
                if desc["sha256"] != sha(path):
                    raise ValueError("array hash mismatch")
                with np.load(path, allow_pickle=False) as arrays:
                    if set(arrays.files) != set(desc["arrays"]):
                        raise ValueError("array key mismatch")
                    for key, definition in desc["arrays"].items():
                        a = arrays[key]
                        if list(a.shape) != definition["shape"] or str(a.dtype) != definition["dtype"] or not np.isfinite(a).all():
                            raise ValueError("array shape/dtype/finite mismatch")
            for ref in artifact.get("parent_refs", []):
                if ref not in artifacts and ref not in measurements:
                    raise ValueError(f"broken artifact parent: {ref}")
        for s in samples.values():
            m = measurements[s["measurement_id"]]
            if s["case_id"] != m["case_id"] or s["specimen_id"] != m["specimen_id"]:
                raise ValueError("sample ownership mismatch")
            if not (0 <= s["start_sample"] < s["end_sample"] <= m["n_samples"]):
                raise ValueError("invalid sample range")
            if not (0 <= s["support_start_sample"] <= s["start_sample"] < s["end_sample"] <= s["support_end_sample"] <= m["n_samples"]):
                raise ValueError("invalid computation support")
            if not (0 <= s["frequency_hz"][0] <= s["frequency_hz"][1] <= m["timebase"]["sample_rate_hz"]/2):
                raise ValueError("invalid frequency range")
            for key in ("config_ref", "map_ref", "mask_ref", "input_ref", "angular_ref", "detector_ref"):
                if s.get(key) is not None and s[key] not in artifacts:
                    raise ValueError(f"broken {key}")
            if s.get("input_ref"):
                inputs = artifacts[s["input_ref"]]
                if inputs["sample_ids"][s["input_row"]] != s["sample_id"]:
                    raise ValueError("input row/sample identity mismatch")
                if inputs["array_file"]["arrays"]["features"]["shape"] != [len(inputs["sample_ids"]), len(inputs["feature_schema"])]:
                    raise ValueError("input feature schema shape mismatch")
        results = index("sample_results", "sample_id")
        if set(results) != set(samples):
            raise ValueError("sample/result completeness mismatch")
        for r in results.values():
            required = {"run_id", "route_key", "case_id", "sample_id", "model_ref", "status", "anomaly_score", "score_definition_ref", "evidence_ref"}
            if not required <= r.keys() or r["evidence_ref"] != r["sample_id"]:
                raise ValueError("invalid SampleResult")
            s = samples[r["sample_id"]]
            if (r["route_key"], r["case_id"]) != (s["route_key"], s["case_id"]):
                raise ValueError("score ownership mismatch")
            for key in ("model_ref", "score_definition_ref"):
                if r[key] is not None and r[key] not in artifacts:
                    raise ValueError("broken model/score reference")
            if (r["status"] == "scored") != (r["anomaly_score"] is not None):
                raise ValueError("unscored value must be null")
            if r["run_id"] != manifest["run_id"] or r["status"] not in ("scored", "unscored"):
                raise ValueError("unknown sample status or run mismatch")
        seen = set()
        for r in tables["route_case_results"]:
            key = (r["route_key"], r["case_id"])
            if key in seen or r["case_id"] not in cases:
                raise ValueError("duplicate/unknown route-case")
            seen.add(key)
            if r["decision"] not in ("within", "outside", "undetermined") or r["execution_status"] not in ("completed", "failed", "skipped") or r["coverage_status"] not in ("sufficient", "insufficient", "not_applicable"):
                raise ValueError("unknown result status")
            ss = [s for s in samples.values() if (s["route_key"], s["case_id"]) == key and s["split"] == "evaluation"]
            if r["n_created"] != len(ss) or r["n_scored"] != sum(results[s["sample_id"]]["status"] == "scored" for s in ss):
                raise ValueError("route sample counts mismatch")
            for ref in r["evidence_refs"]:
                if ref not in samples:
                    raise ValueError("unknown evidence reference")
            for ref in (r["threshold_ref"], r["aggregation_ref"]):
                if ref is not None and ref not in artifacts:
                    raise ValueError("broken route reference")
        eval_cases = {c["case_id"] for c in cases.values() if c["split"] == "evaluation"}
        expected = {(route, case) for route in manifest["requested_routes"] for case in eval_cases}
        if seen != expected:
            raise ValueError("missing route-case outputs")
        if {r["case_id"] for r in tables["case_results"]} != eval_cases:
            raise ValueError("fusion outputs incomplete")
        if len(tables["case_results"]) != len(eval_cases):
            raise ValueError("duplicate fusion outputs")
        for row in tables["case_results"]:
            if row["decision"] not in ("within", "outside", "undetermined"):
                raise ValueError("unknown fusion decision")
        self.manifest, self.tables = manifest, tables
        return self


class EvaluationAdapter:
    def import_bundle(self, bundle_path, destination, path_mapping=None):
        bundle = BundleReader(bundle_path).validate()
        destination = Path(destination).resolve()
        destination.mkdir(parents=True, exist_ok=True)
        target = inside(destination, bundle.manifest["run_id"])
        digest = sha(bundle.path / "manifest.json")
        if target.exists():
            BundleReader(target).validate()
            if sha(target / "manifest.json") != digest:
                raise ValueError("run_id conflict: different manifest hash")
            status = "already_imported"
        else:
            temp = destination / (target.name + ".staging")
            shutil.copytree(bundle.path, temp)
            BundleReader(temp, allow_staging=True).validate()
            temp.rename(target)
            status = "imported"
        unresolved = []
        for m in bundle.tables["measurements"]:
            source = m["source_path"]
            for old, new in (path_mapping or {}).items():
                if source.startswith(old):
                    source = new + source[len(old):]
                    break
            if not Path(source).is_file() or sha(source) != m["source_sha256"]:
                unresolved.append({"measurement_id": m["measurement_id"], "reason": "source_unavailable"})
        receipt = {"schema_version": "1.0", "run_id": bundle.manifest["run_id"], "manifest_sha256": digest,
                   "status": status, "bundle_path": str(target), "unresolved_sources": unresolved}
        write_json(destination / (target.name + ".receipt.json"), receipt)
        return receipt
