"""Physical identities, independent analytic expectations and end-to-end isolation."""
import copy
from pathlib import Path
import unittest
import uuid
import numpy as np
from nv_runner.acoustics import field_transfer, axial_transfer, synthesize, sensor_response
from nv_runner.acoustic_generator import acoustic_settings, sources_for, generate_acoustic
from nv_runner.input_adapter import MeasurementRecord, InputAdapter
from nv_runner.signals import SignalService, pu_diagnostics
from nv_runner.common import read_json, write_json, sha
from nv_runner.profiles import acoustic_experiment
from nv_runner.runner import ExperimentRunner
from nv_runner.bundle import BundleReader


class AcousticPhysics(unittest.TestCase):
    def setUp(self):
        self.cfg = acoustic_settings()
        self.medium = self.cfg["medium"]
        self.receiver = {"position_m":[.08,0,0],"axis":[1,0,0]}
        self.f = np.array([20.,100.,300.])

    def source(self,field):
        common = {"field":field,"position_m":[0,0,0],"seed_key":1,"name":"test","drive_rms":.01,
                  "role":"target_normal","excitation":{"kind":"tone","frequency_hz":128.,"phase_radians":0.}}
        return {**common,**{"plane":{"drive_unit":"Pa","direction":[1,0,0]},
            "monopole":{"drive_unit":"m^3/s"},"piston":{"drive_unit":"m/s","normal":[1,0,0],"radius_m":.0375},
            "rigid_wall":{"drive_unit":"Pa","normal":[1,0,0],"incident_direction":[-1,0,0]}}[field]}

    def test_01_plane_impedance_direction_and_active_flux(self):
        source = self.source("plane")
        p,u = axial_transfer(self.f,source,self.receiver,self.medium)
        z0 = 1.2*343
        np.testing.assert_allclose(p/u,z0,rtol=1e-14)
        np.testing.assert_allclose(.5*(p*u.conj()).real,.5/z0,rtol=1e-14)
        for axis,expected in [([-1,0,0],-1),([0,1,0],0)]:
            _,v = axial_transfer(self.f,source,{**self.receiver,"axis":axis},self.medium)
            np.testing.assert_allclose(v,expected*u,atol=1e-15)

    def test_02_monopole_near_far_impedance_and_distance(self):
        source = self.source("monopole")
        p,u = axial_transfer(self.f,source,self.receiver,self.medium)
        kr = 2*np.pi*self.f/343*.08
        expected = 1.2*343*(1j*kr)/(1+1j*kr)
        np.testing.assert_allclose(p/u,expected,rtol=1e-14)
        self.assertTrue(np.all(np.angle(p/u)>0))
        q,v = axial_transfer(self.f,source,{**self.receiver,"position_m":[.16,0,0]},self.medium)
        np.testing.assert_allclose(abs(q/p),.5,rtol=1e-14)
        np.testing.assert_allclose(((p*u.conj()).real)/((q*v.conj()).real),4,rtol=1e-13)
        p,u = axial_transfer(np.array([1000.]),source,{**self.receiver,"position_m":[100.,0,0]},self.medium)
        self.assertLess(abs((p/u)[0]/(1.2*343)-1),.001)

    def test_03_piston_impedance(self):
        source = self.source("piston")
        p,u = axial_transfer(self.f,source,self.receiver,self.medium)
        r,a = .08,.0375
        alpha = r/np.sqrt(r*r+a*a)
        gamma = (2*np.pi*self.f/343)*(np.sqrt(r*r+a*a)-r)/2
        expected = 1.2*343*(1-np.exp(-2j*gamma))/(1-alpha*np.exp(-2j*gamma))
        np.testing.assert_allclose(p/u,expected,rtol=1e-13)
        with self.assertRaisesRegex(ValueError,"axis"):
            field_transfer(self.f,source,{"position_m":[.08,.01,0]},self.medium)

    def test_04_euler_equation_finite_difference(self):
        for field in ("plane","monopole","rigid_wall","piston"):
            source = self.source(field)
            if field=="rigid_wall":
                source["incident_direction"] = [-.8,.6,0]
            _,u = field_transfer(self.f,source,self.receiver,self.medium)
            for axis in ([0] if field=="piston" else [0,1,2]):
                plus,minus = copy.deepcopy(self.receiver),copy.deepcopy(self.receiver)
                h = 1e-6
                plus["position_m"][axis] += h
                minus["position_m"][axis] -= h
                pp,_ = field_transfer(self.f,source,plus,self.medium)
                pm,_ = field_transfer(self.f,source,minus,self.medium)
                from_gradient = -(pp-pm)/(2*h)/(1j*2*np.pi*self.f*1.2)
                np.testing.assert_allclose(from_gradient,u[:,axis],rtol=2e-7,atol=1e-10)

    def test_05_rigid_wall_boundary_and_reactive_flux(self):
        source = self.source("rigid_wall")
        p,u = axial_transfer(self.f,source,{**self.receiver,"position_m":[0,0,0]},self.medium)
        np.testing.assert_allclose(p,2)
        np.testing.assert_allclose(u,0,atol=1e-15)
        p,u = axial_transfer(self.f,source,self.receiver,self.medium)
        kr = 2*np.pi*self.f/343*.08
        np.testing.assert_allclose(p,2*np.cos(kr),rtol=1e-14)
        np.testing.assert_allclose(u,-2j*np.sin(kr)/(1.2*343),rtol=1e-14)
        np.testing.assert_allclose((p*u.conj()).real,0,atol=1e-14)
        self.assertTrue(np.all((p*u.conj()).imag>0))

    def test_06_single_tone_time_domain_impedance(self):
        for field in ("plane","monopole","piston","rigid_wall"):
            source = self.source(field)
            rec = synthesize(self.cfg,[source],123)
            pair = rec["waveform"]
            t = np.arange(len(pair))/self.cfg["sample_rate_hz"]
            # Demodulate a central interval, independently of the synthesis FFT grid.
            keep = (t>=1)&(t<3)
            phasor = (2*np.mean(pair[keep]*np.exp(-2j*np.pi*128*t[keep,None]),axis=0))
            gp,gu = axial_transfer(np.array([128.]),source,self.cfg["receiver"],self.medium)
            np.testing.assert_allclose(phasor[0]/phasor[1],(gp/gu)[0],rtol=3e-4,atol=1e-6)
            intensity = np.mean(pair[keep,0]*pair[keep,1])
            expected = .5*(phasor[0]*phasor[1].conj()).real
            self.assertAlmostEqual(intensity,expected,delta=max(1e-10,abs(expected)*1e-4))

    def test_07_superposition_and_sensor_response(self):
        source = self.source("plane")
        other = {**source,"seed_key":2,"direction":[-.6,.8,0],"excitation":{"kind":"tone","frequency_hz":180.}}
        combined = synthesize(self.cfg,[source,other],22)
        a,b = synthesize(self.cfg,[source],22),synthesize(self.cfg,[other],22)
        np.testing.assert_allclose(combined["waveform"],a["waveform"]+b["waveform"],atol=1e-14)
        np.testing.assert_allclose(combined["truth"]["source_waveforms"].sum(axis=0),combined["waveform"],atol=1e-14)
        modified = copy.deepcopy(self.cfg)
        modified["sensor"].update(gain_db=[0.,6.],phase_degrees=[0.,15.],delay_seconds=[0.,.0002])
        observed = synthesize(modified,[source],22)["waveform"]
        time = np.arange(len(observed))/modified["sample_rate_hz"]
        keep = (time>=1)&(time<3)
        phasor = 2*np.mean(observed[keep]*np.exp(-2j*np.pi*128*time[keep,None]),axis=0)
        expected = 10**(6/20)*np.exp(1j*np.deg2rad(15)-2j*np.pi*128*.0002)/(1.2*343)
        np.testing.assert_allclose(phasor[1]/phasor[0],expected,rtol=3e-4)

    def test_08_bin_parseval_and_intensity_integral(self):
        fs,n = 1024,4096
        t = np.arange(n)/fs
        p = np.sqrt(2)*.2*np.sin(2*np.pi*128*t)
        u = p/(1.2*343)
        record = MeasurementRecord({"measurement_id":"analytic","timebase":{"sample_rate_hz":fs},"validity":[]},np.c_[p,u],None)
        config = {"nfft":128,"hop_samples":64,"average_frames":5,"spectral_convention":"mean_square_bin_v2"}
        maps = SignalService(config).maps(record)
        window = np.hanning(128)
        frames = np.stack([record.signals[a:a+128] for a in maps["frame_start"]])
        expected_power = np.sum(frames[:,:,0]**2*window**2,axis=1)/np.sum(window**2)
        np.testing.assert_allclose(maps["p_power"].sum(axis=1),expected_power,rtol=1e-14)
        np.testing.assert_allclose(maps["intensity"].sum(axis=1)[2:-2],.2**2/(1.2*343),rtol=1e-6)
        diagnostics = pu_diagnostics(record)
        df = diagnostics["frequency_hz"][1]
        self.assertAlmostEqual(float(diagnostics["p_psd"].sum()*df),.2**2,places=12)
        self.assertAlmostEqual(float(diagnostics["active_intensity_psd"].sum()*df),.2**2/(1.2*343),places=12)
        frequency_bin = np.argmin(abs(diagnostics["frequency_hz"]-128))
        self.assertAlmostEqual(diagnostics["impedance_real"][frequency_bin],1.2*343,places=10)
        self.assertAlmostEqual(diagnostics["msc"][frequency_bin],1.,places=12)

    def test_09_zero_energy_undefined_relation_masked(self):
        record = MeasurementRecord({"measurement_id":"zero","timebase":{"sample_rate_hz":1024},"validity":[]},np.zeros((2048,2)),None)
        maps = SignalService({"nfft":128,"hop_samples":64,"average_frames":5,"spectral_convention":"mean_square_bin_v2"}).maps(record)
        self.assertFalse(maps["valid"].any())
        self.assertFalse(pu_diagnostics(record)["valid"].any())

    def test_10_guard_convergence(self):
        source = self.source("monopole")
        source["excitation"] = {"kind":"events","frequency_hz":300.,"center_fractions":[.5],"sigma_seconds":.03}
        first = synthesize(self.cfg,[source],10)["waveform"]
        second_cfg = copy.deepcopy(self.cfg)
        second_cfg["numerics"]["guard_seconds"] = 1.
        second = synthesize(second_cfg,[source],10)["waveform"]
        relative_error = np.linalg.norm(first-second,axis=0)/np.linalg.norm(second,axis=0)
        self.assertTrue(np.all(relative_error < 1e-4),relative_error)

    def test_11_rpm_sensor_changes_only_observed_rpm(self):
        sources = sources_for(self.cfg,"normal",99,0)
        reference = synthesize(self.cfg,sources,23,self.cfg["ramp_rotation"])
        cfg = copy.deepcopy(self.cfg)
        cfg["rpm_sensor"].update(enabled=True,delay_seconds=.05,gain_error_fraction=.02,quantization_rpm=10.,dropout_fraction=.1)
        modified = synthesize(cfg,sources,23,cfg["ramp_rotation"])
        np.testing.assert_array_equal(reference["waveform"],modified["waveform"])
        np.testing.assert_array_equal(reference["truth"]["rpm_true"],modified["truth"]["rpm_true"])
        self.assertGreater(np.max(abs(reference["rpm_measured"]-modified["rpm_measured"])),10)

    def test_12_disturbance_preserves_target_and_generates_both_channels(self):
        normal = synthesize(self.cfg,sources_for(self.cfg,"normal",100000,0),51)
        external = synthesize(self.cfg,sources_for(self.cfg,"disturbance",100000,0),51)
        np.testing.assert_array_equal(normal["truth"]["source_waveforms"],external["truth"]["source_waveforms"][:-1])
        delta = external["waveform"]-normal["waveform"]
        self.assertGreater(np.std(delta[:,0]),.001)
        self.assertGreater(np.std(delta[:,1]),1e-6)
        np.testing.assert_allclose(delta[:,1],delta[:,0]*(-.6)/(1.2*343),atol=1e-15)

    def test_13_invalid_physical_configuration_rejected(self):
        source = self.source("monopole")
        with self.assertRaises(ValueError):
            axial_transfer(self.f,source,{"position_m":[0,0,0],"axis":[1,0,0]},self.medium)
        source["drive_unit"] = "Pa"
        with self.assertRaises(ValueError):
            field_transfer(self.f,source,self.receiver,self.medium)
        with self.assertRaises(ValueError):
            synthesize(self.cfg,[self.source("plane"),self.source("rigid_wall")],1)
        cfg = copy.deepcopy(self.cfg)
        cfg["receiver"]["axis"] = [2,0,0]
        with self.assertRaises(ValueError):
            synthesize(cfg,[self.source("plane")],1)


class AcousticPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parent/"_work"/("acoustic_"+uuid.uuid4().hex)
        cls.root.mkdir(parents=True)
        cfg = acoustic_settings()
        cfg.update(train_specimens=6,duration_seconds=3)
        generate_acoustic(cls.root/"data",cfg)
        cls.config = acoustic_experiment("data","runs")
        for r in cls.config["routes"]:
            if r["model"]["kind"]=="isolation_forest":
                r["model"]["n_estimators"] = 16
        write_json(cls.root/"experiment.json",cls.config)
        cls.path = ExperimentRunner().execute(cls.root/"experiment.json")
        cls.bundle = BundleReader(cls.path).validate()

    def test_14_all_models_fit_and_truth_isolated_from_input(self):
        self.assertEqual(self.bundle.manifest["bundle_status"],"complete")
        for r in self.config["routes"]:
            self.assertTrue((self.path/"models"/(r["key"]+".joblib")).is_file())
        records = InputAdapter().load(self.root/"data"/"eval_manifest.json")
        for r in records:
            self.assertFalse(hasattr(r,"truth"))
            self.assertNotIn("scenario",r.meta)
            with np.load(r.meta["source_path"],allow_pickle=False) as data:
                self.assertEqual(set(data.files),{"waveform","shaft_rpm"})
        artifacts = self.bundle.tables["artifacts"]
        self.assertTrue(any(a["operation"]=="generator_truth_only_after_inference" for a in artifacts))
        self.assertTrue(any(a["operation"]=="welch_measured_pu_diagnostics" for a in artifacts))

    def test_15_mutated_truth_arrays_do_not_change_models(self):
        truth_path = self.root/"data"/"truth.json"
        truth = read_json(truth_path)
        for case in truth["cases"]:
            case["label"] = "normal"
        entry = truth["source_artifacts"][-1]
        file = self.root/"data"/entry["array_file"]["path"]
        with np.load(file,allow_pickle=False) as z:
            arrays = {k:z[k].copy() for k in z.files}
        arrays["rpm_true"] *= 7
        arrays["source_waveforms"] *= 100
        np.savez_compressed(file,**arrays)
        entry["array_file"]["sha256"] = sha(file)
        write_json(truth_path,truth)
        second = ExperimentRunner().execute(self.root/"experiment.json")
        for r in self.config["routes"]:
            for suffix in (".joblib","_threshold.json"):
                self.assertEqual(sha(self.path/"models"/(r["key"]+suffix)),sha(second/"models"/(r["key"]+suffix)))


if __name__=="__main__":
    unittest.main(verbosity=2)
