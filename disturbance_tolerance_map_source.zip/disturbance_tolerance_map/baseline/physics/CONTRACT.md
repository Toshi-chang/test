# 分布音源PoCの契約と物理的意味

## 版・責務

入力schema_version=`distributed-acoustics/1.0`。未知版を拒否。実装0.1.0。既存NVのacoustic_schema_version/ResultBundleと互換を宣言しない。

`geometry.py`：形状を数値積分点と面積／体積重みへ変換。
`engine.py`：空間分布・励振・伝達を適用しpとUを生成。
`artifacts.py`：観測と正解を分けて保存、完全性検査、保存結果の閲覧。

## 主な入力

|項目|定義|
|propagation|free_space_equivalent または baffled_plane。共通の静止・均質・無損失媒質|
|medium|density_kg_m3 [kg/m³]、sound_speed_m_s [m/s]、正の有限値|
|simulation|sample_rate_hz、duration_seconds、guard_seconds、非負整数seed。時間長×fsは整数|
|sources[].id|シーン内で一意な音源ID。数値特徴量ではない|
|geometry.kind|point、rectangle、disk、box/sphere/cylinderのsurfaceまたはvolume|
|geometry.center_m|ローカル原点の世界座標[m]。既定[0,0,0]|
|geometry.rotation|ローカル→世界の正規直交行列、det=+1。既定単位行列|
|geometry.resolution|1〜32の整数。各方向の分割／Gauss点数の基準。球体体積の半径積分は最低2点|
|size_m/radius_m/height_m|形状寸法[m]。円柱はローカルz軸、長方形／円板はローカルxy面|
|distribution|uniform、またはGaussianのcenter_mとsigma_m。ローカル座標|
|phase|offset_rad、gradient_rad_per_m、delay_gradient_s_per_m、opposite_halves_axis（0/1/2）。要素位相=offset+gradient·x−ω delay_gradient·x|
|receivers|一意ID、position_m、単位長のaxis。内部計算はUの3成分、保存uはaxisへの符号付き投影|
|container_annotation|表示・説明のための形状。acoustic_boundaryはnoneのみ。実際の壁として使用しない|

矩形は中点格子、円板はr²のGauss積分×方位角等間隔、球はcosθのGauss×方位角等間隔（体積は半径Gaussを追加）、円柱は側面＋両端面または内部体積。箱表面は6面を含む。局所密度分布が細かいときは分割収束を別途確認する。

## 強さと離散化

|strength_mode|drive_unit|要素への重み|
|total_volume_velocity|m^3/s|面積／体積×振幅分布を総和1に正規化。点は1|
|surface_density|m/s|面積×振幅分布。自由空間では等価単極子密度、バッフルでは法線振動速度|
|volume_density|1/s|体積×振幅分布。体積速度の体積当たり密度|

drive_rmsは音源のスカラー励振の中央区間RMS。正の有限値。Gaussian分布は全体強さモードでは分布の重み総量を再正規化、密度モードではピーク密度を維持する。符号変化は負のRMSではなく位相で指定する。

**独立雑音を数値積分点ごとに勝手に割り当てない。** 数値メッシュを変えることで物理的な独立音源の数が変わると、分割収束の意味が失われる。独立した物理部品／領域はsourcesの別項目にし、独立seed_keyで励振する。同じseed_keyなら同じ雑音系列（同じ帯域・時間条件の場合）。任意の部分相関モデルは未対応。

## 伝搬の式

時間規約 exp(+jωt)、k=ω/c。自由空間で各体積速度要素Q_jについて、r_j=|x−x_j|、n_j=(x−x_j)/r_j：

P_j = jωρ Q_j exp(−jkr_j)/(4πr_j)

U_j = Q_j (1+jkr_j) exp(−jkr_j) n_j/(4πr_j²)

P=ΣP_j、U=ΣU_j。複素振幅で合成し、パワーを直接足さない。表面分布でもこの自由空間式の場合は等価単極子であり、法線指向性・固体の遮蔽を与えない。

バッフル付き平面はQ_j=v_n,j ΔS_j、分母4πを2πに置き換えたRayleigh積分。すべての面が同一の無限平面と同じ法線を共有し、観測はその正側の半空間に限る。任意閉曲面へこの係数を適用しない。

DCは音響AC対象外としてp/Uとも0。表面上、体積音源内部、要素から1µm以下の特異点近傍は拒否。1µmは数値ガードで、そこで物理近似が保証されるわけではない。近接点は距離に応じた分割収束が必須。表面源の空洞内部は自由空間の数学的場として計算可能だが閉鎖筐体内部音場を意味しない。

## 励振と有限時間

tone：周波数・位相。order：始点/終点RPMと次数、線形RPMを積分。event：搬送周波数・中心時刻・sigma。noise：帯域・seed_key。全て0<f<0.44fsへ帯域制限しDC/Nyquistを除く。ガード込みのFFT周期計算後に中央区間を切り出す。急峻な帯域制限のリンギング、ガード外からの巻戻りは一般にゼロと保証しない。現在の収束試験は設定された定常音の条件であり全イベントの保証ではない。

`source_transfer`は単位励振の周波数応答、`response`は全音源のRMS強度を掛けたコヒーレントな応答を返す。時間的な独立励振の合成には`synthesize`を使用する。`response`だけで独立雑音の統計量を評価しない。

## 保存と追跡

独自結果schema=`distributed-acoustics-result/1.0`。

- observations.npz：time_s[N]、pressure_pa[N,R]、velocity_m_s[N,R,3]、axial_velocity_m_s[N,R]。受音点順はscene.receivers。
- generator_truth.npz：source_pressure_pa[S,N,R]、source_velocity_m_s[S,N,R,3]、source_drives[S,N]、source_iの配置・重み・位相・遅延。音源順はscene.sources。源別の励振単位を保持。
- scene.json：実行条件。観測時刻は0開始、sample i=i/fs、全体区間[0,N/fs)。
- metrics.json：各受音点のp/u RMSと平均p·u。異音検知スコアではない。
- provenance.json：設定hash、実装ファイルhash、Python/NumPy、軸定義。
- manifest.json：完了状態、全5成果物の容量とSHA-256。未知版、欠損、改変、配列軸不整合を拒否。
- viewer.html：保存配列から作る派生表示。表示用間引きと全点計算を区別する。原本manifestのメンバーではない。

モデル学習・推論は本PoCの責務外。将来接続する際はobservationsと正解を分離したまま、ID・由来・複数受音点の同一個体関係を維持する。
