'use strict';
const ResultLabels=(()=>{
 const names={rpm_start:'開始RPM',rpm_end:'終了RPM',variation:'ばらつき比率',ripple:'回転揺らぎ比率',ripple_hz:'回転揺らぎ Hz',noise_rms_rpm:'測定雑音 RMS [RPM]',gain_error_pct:'換算ゲイン誤差 [%]',offset_rpm:'オフセット [RPM]',delay_ms:'遅延 [ms]',smoothing_ms:'平滑時定数 [ms]',distance_m:'距離 [m]',axis_angle_deg:'軸角度 [°]',level_rms:'励振RMS [SI]',frequency_hz:'周波数設定 [Hz]',band_low_hz:'帯域下限 [Hz]',band_high_hz:'帯域上限 [Hz]',kind:'音種',model:'音場モデル',teeth:'歯数',harmonics:'倍音数',shaft_ratio:'回転比',p_gain_db:'pゲイン誤差 [dB]',u_gain_db:'uゲイン誤差 [dB]',p_noise_rms:'p測定雑音 [Pa]',u_noise_rms:'u測定雑音 [m/s]'};
 const fmt=v=>typeof v==='number'?Number(v.toPrecision(6)).toString():v===undefined?'未設定':String(v);
 function config(p,path){return p?.metadata?.[path]?.config;}
 function summary(c){if(!c)return '生成条件の記録なし';const r=c.rotation;const normal=(c.sources||[]).filter(s=>s.role==='normal'&&!s.background);return [r?`${fmt(r.rpm_start)}${r.rpm_start===r.rpm_end?'':'→'+fmt(r.rpm_end)} RPM`:'非回転',...normal.map(s=>`${s.name}／距離${fmt(s.distance_m)} m／励振${fmt(s.level_rms)} ${({piston:'m/s',monopole:'m³/s',plane:'Pa',rigid_wall:'Pa'})[s.model]||'SI'}`),`RPM測定雑音 ${fmt(c.rpm_sensor?.noise_rms_rpm??0)} RPM`,`fs ${c.fs} Hz・窓 ${c.window_samples}点`].join(' ｜ ');}
 function differences(base,target){if(!base||!target)return ['比較元または評価の生成設定が保存されていません'];const result=[];
  function walk(a,b,path=[]){if(JSON.stringify(a)===JSON.stringify(b))return;if(b&&typeof b==='object'&&a&&typeof a==='object'){for(const k of new Set([...Object.keys(a),...Object.keys(b)]))walk(a[k],b[k],[...path,k]);return;}if(['seed','level_reference','counts','schema_version','include_combined'].includes(path[0])||path.at(-1)==='include_combined')return;
   let label=path.map(k=>names[k]||k).join(' / ');if(path[0]==='sources'){const s=target.sources?.[Number(path[1])]||base.sources?.[Number(path[1])];label=(s?.name||'音源')+' / '+path.slice(2).map(k=>names[k]||k).join(' / ');if(path.at(-1)==='frequency_hz'&&['band_noise','white_noise','pink_noise','gear'].includes(s?.kind))label+='（この音種では未使用）';}else label=label.replace('rpm_sensor','RPM測定').replace('rotation','回転').replace('sensor','p/u測定');
   result.push(`${label}：${fmt(a)} → ${fmt(b)}`);
  }walk(base,target);return result;
 }
 function changes(p,path,train){const ds=differences(config(p,train||p?.training_datasets?.[0]),config(p,path));return ds.length?ds.join(' ／ '):'基準と同じ音場・音源・測定条件（別の評価収録）';}
 function evaluation(p,path,train){if(!config(p,path))return p?.labels?.[path]||'評価条件の記録なし（詳細でファイルを確認）';return changes(p,path,train);}
 function training(p,path){return '⓪ 正常のみ：'+summary(config(p,path||p?.training_datasets?.[0]));}
 return {config,summary,differences,changes,evaluation,training};
})();
if(typeof module!=='undefined')module.exports=ResultLabels;
