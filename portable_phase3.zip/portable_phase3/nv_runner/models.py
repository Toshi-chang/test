"""Replaceable fit/score models. Transforms are fit on fit inputs only."""
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.decomposition import PCA
from threadpoolctl import threadpool_limits


class NormalModel:
    @threadpool_limits.wrap(limits=1)
    def fit(self, values, config, seed):
        if len(values) < config.get("min_samples", 3):
            raise ValueError("insufficient_training_samples")
        self.kind = config["kind"]
        self.scaler = StandardScaler().fit(values)
        z = self.scaler.transform(values)
        if self.kind == "isolation_forest":
            self.estimator = IsolationForest(n_estimators=config.get("n_estimators", 64), random_state=seed, n_jobs=1).fit(z)
        elif self.kind == "pca":
            rank = min(config.get("components", 4), len(z) - 1, z.shape[1] - 1)
            self.estimator = PCA(n_components=max(1, rank), svd_solver="full").fit(z)
        else:
            raise ValueError(f"unknown model: {self.kind}")
        return self

    @threadpool_limits.wrap(limits=1)
    def score(self, values):
        z = self.scaler.transform(values)
        if self.kind == "isolation_forest":
            return -self.estimator.score_samples(z)
        restored = self.estimator.inverse_transform(self.estimator.transform(z))
        return np.mean((z - restored) ** 2, axis=1)

    def save(self, path):
        # Local model artifact only; Bundle reader never unpickles a model.
        joblib.dump(self, path, compress=0)
