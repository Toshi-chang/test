'use strict';
const planCard=document.createElement('div');planCard.className='card';planCard.id='plan-editor';
planCard.innerHTML=`<h2>検証計画を作る</h2><p class="muted">この01画面の音場・音源・収録設定を基準に、評価の変化点をまとめて指定します。⓪のみで学習・検証・閾値校正し、別収録の⓪〜③を評価します。保存時の設定を固定するため、その後01を編集しても保存済み計画は変わりません。</p>
<div class="toolbar"><label class="wide">実験名<input id="plan-name" placeholder="例：RPM測定誤差による異音検出への影響" maxlength="120"></label><label class="wide">確認したいこと<input id="plan-purpose" placeholder="例：RPM雑音5・20で検出率が低下するか"></label></div>
<div class="toolbar"><label>変化の組合せ<select id="plan-combination"><option value="one">1項目ずつ変更</option><option value="grid">指定項目の全組合せ</option></select></label><button id="plan-add">＋ 変化させる項目</button></div><div id="plan-axes"></div>
<p class="muted">候補値はカンマ区切り。未指定の項目は01と同じです。音量のdB増減は基準励振に対する倍率で、距離による減衰を打ち消しません。一定回転数は「開始・終了を同時変更」を選ぶと一括指定できます。</p>
<div class="toolbar" id="plan-variants"><label class="checkbox"><input type="checkbox" value="p">p</label><label class="checkbox"><input type="checkbox" value="u">u</label><label class="checkbox"><input type="checkbox" value="pu" checked>p＋u</label><label class="checkbox"><input type="checkbox" value="pu_rpm_std">p＋u＋RPM・標準偏差</label><label class="checkbox"><input type="checkbox" value="pu_rpm_fixed">p＋u＋RPM・固定幅</label></div>
<div class="toolbar"><label>最大エポック<input id="plan-epochs" type="number" min="1" max="500" value="80"></label><label>RPM固定幅<input id="plan-scale" type="number" min="1" value="10000"></label></div>
<p class="muted">正常の許容範囲は01の回転・音源ばらつきで設定します。閾値は独立した正常校正収録の99パーセンタイルで固定。候補の変化点は評価だけに適用します。</p>
<div class="toolbar"><button id="plan-preview">検証予定表を作成</button><button id="plan-save">計画を保存</button><button id="plan-launch" class="primary job-start">保存して一括実行 → 04</button></div><p id="plan-counts" role="status"></p><div id="plan-warnings"></div><div id="plan-preview-table" class="plan-scroll"></div>`;
$('config').children[0].after(planCard);
let approvedPlan=null,planParent=null,planFields=[],activePlan=null;
function planRequest(){return {name:$('plan-name').value,purpose:$('plan-purpose').value,config:clone(config),parent:planParent,combination:$('plan-combination').value,
 variants:Array.from(document.querySelectorAll('#plan-variants input:checked'),x=>x.value),epochs:Number($('plan-epochs').value),rpm_fixed_scale:Number($('plan-scale').value),
 axes:Array.from(document.querySelectorAll('.plan-axis'),row=>({path:row.querySelector('select').value,values:row.querySelector('input').value.split(/[,、\s]+/).filter(Boolean).map(Number)}))};}
async function addPlanAxis(axis){if(!config)throw Error('初期設定の読み込みを待ってください');const r=await api('plan-fields',{config});planFields=r.fields;
 const row=document.createElement('div');row.className='toolbar plan-axis';const select=document.createElement('select');select.setAttribute('aria-label','変化させる項目');for(const f of planFields)select.add(new Option(f.label,f.path));const input=document.createElement('input');input.placeholder='例：0, 5, 20';input.setAttribute('aria-label','候補値');const remove=document.createElement('button');remove.textContent='削除';remove.onclick=()=>row.remove();if(axis){select.value=axis.path;input.value=axis.values.join(', ');}row.append(select,input,remove);$('plan-axes').append(row);}
$('plan-add').onclick=()=>addPlanAxis().catch(showError);
function simpleTable(headers,rows){const t=document.createElement('table');const head=document.createElement('tr');for(const h of headers){const th=document.createElement('th');th.textContent=h;head.append(th);}t.append(head);for(const row of rows){const tr=document.createElement('tr');for(const v of row){const td=document.createElement('td');td.textContent=v;tr.append(td);}t.append(tr);}return t;}
$('plan-preview').onclick=async()=>{try{clearError();const request=planRequest();const p=await api('plan-preview',request);approvedPlan=JSON.stringify(request);
 $('plan-counts').textContent=`生成 ${p.counts.generation}件 → 学習 ${p.counts.training}件 → 評価 ${p.counts.evaluation}件。基準評価を含み、全評価で⓪〜③を確認します。`;
 $('plan-warnings').replaceChildren();for(const w of p.warnings){const el=document.createElement('p');el.textContent=w;$('plan-warnings').append(el);}
 $('plan-preview-table').replaceChildren(simpleTable(['用途','条件・変更点','使用する学習'],[['正常学習・検証・校正','01の基準条件／⓪のみ','—'],...p.rows.map(r=>['評価⓪〜③',r.name,'基準条件の正常モデル'])]));
 }catch(e){approvedPlan=null;showError(e);}};
async function savePlan(start){clearError();const request=planRequest();if(JSON.stringify(request)!==approvedPlan)throw Error('現在の01設定と候補値で「検証予定表を作成」を押してください。');const saved=await api('plan-save',request);activePlan=saved.folder;await refreshPlans();if(start)await api('plan-run',saved);tab('comparison');}
$('plan-save').onclick=()=>savePlan(false).catch(showError);$('plan-launch').onclick=()=>savePlan(true).catch(showError);

// Keep the file-based workflow available, but make named plans the main entry.
const legacyCard=comparisonPanel.firstElementChild;const legacyDetails=document.createElement('details');const legacySummary=document.createElement('summary');legacySummary.textContent='既存ファイルを指定する従来の一括比較';legacyDetails.append(legacySummary);legacyCard.before(legacyDetails);legacyDetails.append(legacyCard);
comparisonTab.textContent='04　計画・実行';
const planManager=document.createElement('div');planManager.className='card';planManager.innerHTML=`<h2>計画・実行</h2><p>01で作った検証計画を、生成 → 正常学習 → 評価へ順に進めます。</p><div class="toolbar"><label class="wide">実験計画<select id="plan-history"></select></label><button id="plan-refresh">更新</button><button id="plan-run" class="primary job-start">実行／未完了から再開</button><button id="plan-revise">01に呼び戻して改訂</button><button id="plan-results">05で結果を見る</button></div><p id="plan-status" role="status"></p><div id="plan-progress-table" class="plan-scroll"></div><div id="plan-files" class="download-row"></div>`;
comparisonPanel.prepend(planManager);
const statusNames={draft:'未実行',pending:'未実行',running:'処理中',generating:'生成中',training_evaluation:'学習・評価中',complete:'完了',partial:'一部失敗',paused:'停止中',failed:'失敗',blocked:'前工程待ち'};
let planList=[];const planStates=new Map();
async function refreshPlans(){const r=await api('plans');planList=r.plans;const selected=activePlan||$('plan-history').value;$('plan-history').replaceChildren();for(const p of planList)$('plan-history').add(new Option(`${p.plan.name} / ${statusNames[p.state.status]||p.state.status}`,p.folder));if(planList.some(p=>p.folder===selected))$('plan-history').value=selected;activePlan=$('plan-history').value;renderPlanProgress();const chosen=planList.find(p=>p.folder===activePlan);const before=planStates.get(activePlan);for(const item of planList)planStates.set(item.folder,item.state.status);if(chosen?.state.status==='complete'&&before&&before!=='complete'&&comparisonPanel.classList.contains('active'))$('plan-results').click();}
function renderPlanProgress(){const p=planList.find(p=>p.folder===$('plan-history').value);if(!p){$('plan-status').textContent='01で基準条件と検証予定を作成してください。';return;}
 $('plan-status').textContent=`${p.plan.name} — ${p.plan.purpose} / ${statusNames[p.state.status]||p.state.status}${p.state.error?' / '+p.state.error:''}`;
 $('plan-progress-table').replaceChildren(simpleTable(['用途・条件','生成状況'],p.state.rows.map(r=>[r.name,(statusNames[r.status]||r.status)+(r.error?' / '+r.error:'')])));
 $('plan-files').replaceChildren();link($('plan-files'),p.folder+'/plan.json','固定した検証計画');link($('plan-files'),p.folder+'/state.json','進捗');
 if(p.state.comparison&&$('cmp-history').value!==p.state.comparison){refreshComparisons().then(()=>{$('cmp-history').value=p.state.comparison;return loadComparison();}).catch(showError);}
}
$('plan-history').onchange=()=>{activePlan=$('plan-history').value;renderPlanProgress();const chosen=planList.find(p=>p.folder===activePlan);const before=planStates.get(activePlan);for(const item of planList)planStates.set(item.folder,item.state.status);if(chosen?.state.status==='complete'&&before&&before!=='complete'&&comparisonPanel.classList.contains('active'))$('plan-results').click();};$('plan-refresh').onclick=()=>refreshPlans().catch(showError);
$('plan-run').onclick=async()=>{try{if(!activePlan)throw Error('計画を選択してください');await api('plan-run',{folder:activePlan});await refreshPlans();}catch(e){showError(e);}};
$('plan-revise').onclick=async()=>{try{if(!activePlan)throw Error('計画を選択してください');const p=await api('plan-detail',{folder:activePlan});config=clone(p.plan.base);renderConfig();planParent=p.folder;$('plan-name').value=p.plan.name+'（改訂）';$('plan-purpose').value=p.plan.purpose;$('plan-combination').value=p.plan.combination;$('plan-epochs').value=p.plan.epochs;$('plan-scale').value=p.plan.rpm_fixed_scale;document.querySelectorAll('#plan-variants input').forEach(x=>x.checked=p.plan.variants.includes(x.value));$('plan-axes').replaceChildren();for(const a of p.plan.axes)await addPlanAxis(a);approvedPlan=null;tab('config');$('plan-counts').textContent='保存済み計画から呼び戻しました。元の計画・結果は保持して新しい改訂版を保存します。';}catch(e){showError(e);}};
$('plan-results').onclick=async()=>{try{const p=planList.find(p=>p.folder===activePlan);if(!p?.state.comparison)throw Error('まだ学習・評価の工程に進んでいません');await refreshComparisons();$('cmp-history').value=p.state.comparison;await loadComparison();tab('comparison-results');}catch(e){showError(e);}};

// A separate results workspace: selectors stay bounded; scores retain class colors.
const resultPanel=document.createElement('section');resultPanel.id='comparison-results';resultPanel.className='panel';
const resultTab=document.createElement('button');resultTab.className='tab';resultTab.dataset.tab=resultPanel.id;resultTab.textContent='05　結果比較';resultTab.onclick=()=>{tab(resultPanel.id);refreshComparisons().catch(showError);};document.querySelector('[data-tab="guide"]').before(resultTab);$('guide').before(resultPanel);
const resultHeader=document.createElement('div');resultHeader.className='card';resultHeader.innerHTML='<h2>結果比較</h2><p>評価条件で絞り込み、同じ条件に対するDL入力方式の違いを比較します。⓪正常・①外乱・②異音・③外乱＋異音の色は固定です。</p><div class="toolbar"><label class="wide">実験<select id="results-experiment"></select></label><label>検索<input id="results-search" placeholder="例：測定雑音、距離、RPM"></label></div><div id="results-context"></div>';
resultPanel.append(resultHeader);
const resultCard=$('cmp-table').closest('.card');resultPanel.append(resultCard);resultPanel.append($('cmp-chart').closest('.plot-card'));
resultCard.querySelector('p').textContent='①外乱の発報は機械異音の検出成功と区別します。各割合は独立収録単位。比較対象は最大4行まで選択できます。';
$('cmp-chart').closest('.plot-card').querySelector('p').textContent='各モデルを別のグラフで表示します。色は生成条件⓪〜③、縦軸はスコア÷閾値。破線1を超えると発報です。';
const scoreGrid=document.createElement('div');scoreGrid.id='score-grid';scoreGrid.className='plot-grid';$('cmp-chart').after(scoreGrid);$('cmp-chart').hidden=true;
const oldLoadComparison=loadComparison;
loadComparison=async function(){await oldLoadComparison();syncResults();};
function conditionName(path){return ResultLabels.evaluation(comparisonDetail?.plan,path);}
function syncResults(){const previous=$('results-experiment').value;$('results-experiment').replaceChildren();for(const o of $('cmp-history').options)$('results-experiment').add(new Option(o.text,o.value));$('results-experiment').value=$('cmp-history').value||previous;
 for(const o of $('cmp-filter').options)if(o.value)o.textContent=conditionName(o.value);
 const p=comparisonDetail?.plan;if(!p)return;$('results-context').replaceChildren();
 for(const text of [p.name||'保存済み条件比較',p.purpose||'',...((p.training_datasets||[]).map(path=>'学習：'+ResultLabels.training(p,path))),`DL入力：${(p.variants||[]).map(v=>comparisonLabels[v]||v).join(' ／ ')}。閾値は評価条件ごとに再調整しません。`]){if(text){const el=document.createElement('p');el.textContent=text;$('results-context').append(el);}}
 for(const id of ['cmp-history','results-experiment'])for(const o of $(id).options){if(o.value===comparisonDetail.folder){o.textContent=p.name||('既存比較：'+ResultLabels.summary(ResultLabels.config(p,p.training_datasets?.[0])));o.title=o.value;}}

}
$('results-experiment').onchange=async()=>{$('cmp-history').value=$('results-experiment').value;try{await loadComparison();}catch(e){showError(e);}};
const originalRenderComparison=renderComparisonTable;
renderComparisonTable=function(){originalRenderComparison();const search=$('results-search').value.toLowerCase();const rows=(comparisonDetail?.summary.rows||[]).filter(r=>!$('cmp-filter').value||r.dataset===$('cmp-filter').value);let index=0;
 for(const tr of $('cmp-table').querySelectorAll('tr')){if(!tr.querySelector('td'))continue;const row=rows[index++];const cells=tr.querySelectorAll('td');cells[1].textContent=(comparisonLabels[row.variant]||row.variant)+' ／ 学習：'+ResultLabels.training(comparisonDetail.plan,row.training_dataset);cells[2].textContent=ResultLabels.evaluation(comparisonDetail.plan,row.dataset,row.training_dataset);cells[1].title=row.training_dataset||'';cells[2].title=row.dataset;tr.hidden=!!search&&!tr.textContent.toLowerCase().includes(search);}
};
// Rebind the handler: the previous direct assignment retained the old filename renderer.
$('cmp-filter').onchange=()=>renderComparisonTable();
$('results-search').oninput=renderComparisonTable;
drawComparisonCurves=function(){
 $('cmp-legend').replaceChildren();['⓪ 正常','① 正常＋外乱','② 正常＋異音','③ 正常＋外乱＋異音'].forEach((s,k)=>{const el=document.createElement('span');el.style.color=colors[k];el.textContent='● '+s;$('cmp-legend').append(el);});
 scoreGrid.replaceChildren();for(const r of comparisonCurves){const wrap=document.createElement('div');wrap.className='plot-card';const title=document.createElement('h3');title.textContent=comparisonLabels[r.variant]||r.variant;const subtitle=document.createElement('p');subtitle.textContent='学習：'+ResultLabels.training(comparisonDetail.plan,r.training_dataset)+'\n評価での変更：'+ResultLabels.evaluation(comparisonDetail.plan,r.dataset,r.training_dataset);subtitle.style.whiteSpace='pre-wrap';const c=document.createElement('canvas');const detail=document.createElement('details');const detailTitle=document.createElement('summary');detailTitle.textContent='01の保存設定・元ファイルを確認';const pre=document.createElement('pre');pre.className='comparison-config';pre.textContent=JSON.stringify({学習設定:ResultLabels.config(comparisonDetail.plan,r.training_dataset||comparisonDetail.plan.training_datasets?.[0]),評価設定:ResultLabels.config(comparisonDetail.plan,r.dataset),学習ファイル:r.training_dataset,評価ファイル:r.dataset,モデル:r.model},null,2);detail.append(detailTitle,pre);wrap.append(title,subtitle,detail,c);scoreGrid.append(wrap);const series=[0,1,2,3].map(k=>{const records=r.records.map((a,i)=>({...a,index:i})).filter(a=>a.label===k);return {x:records.map(a=>a.index),y:records.map(a=>a.ratio),color:colors[k]};});chart(c,series,{scatter:true,logy:true,baseline:1,xlabel:'Recording',ylabel:'Score / threshold'});}
};
new MutationObserver(()=>{if(resultPanel.classList.contains('active'))requestAnimationFrame(drawComparisonCurves);}).observe(resultPanel,{attributes:true,attributeFilter:['class']});
window.addEventListener('resize',()=>{if(resultPanel.classList.contains('active'))drawComparisonCurves();});
setInterval(()=>{if(comparisonPanel.classList.contains('active'))refreshPlans().catch(showError);if(resultPanel.classList.contains('active'))refreshComparisons().catch(showError);},4000);
refreshPlans().catch(showError);

const trend=document.createElement('div');trend.className='plot-card';trend.innerHTML='<h3>条件の変化と発報率</h3><div class="toolbar"><label>横軸<select id="trend-axis"></select></label><label>他の変化点<select id="trend-other"></select></label><label>確認する割合<select id="trend-class"><option value="2">② 異音検出率</option><option value="0">⓪ 正常誤検知率</option><option value="1">① 外乱のみの発報率</option><option value="3">③ 外乱＋異音検出率</option></select></label></div><p>色はDL入力方式です。他の変化点を固定して比較します。収録スコアの色（⓪〜③）とは別の凡例です。</p><div id="trend-legend" class="result-legend"></div><canvas id="trend-chart"></canvas>';
resultHeader.after(trend);
function drawTrend(){
 const p=comparisonDetail?.plan;if(!p)return;const previous=$('trend-axis').value;const axes=new Map();for(const changes of Object.values(p.conditions||{}))for(const c of changes)axes.set(c.path,c.label);
 $('trend-axis').replaceChildren();for(const [path,label] of axes)$('trend-axis').add(new Option(label,path));if(axes.has(previous))$('trend-axis').value=previous;
 const axis=$('trend-axis').value;const canvas=$('trend-chart');$('trend-legend').replaceChildren();if(!axis){canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);const note=document.createElement('span');note.textContent='変化点の登録された計画を選ぶと表示します。従来の実験は下の結果表で確認できます。';$('trend-legend').append(note);return;}
 const selectedOther=$('trend-other').value;const otherValues=[...new Set(Object.values(p.conditions||{}).map(cs=>cs.filter(c=>c.path!==axis).map(c=>`${c.label}=${c.value}`).join(', ')))];$('trend-other').replaceChildren();for(const v of otherValues)$('trend-other').add(new Option(v||'その他は基準条件',v));if(otherValues.includes(selectedOther))$('trend-other').value=selectedOther;
 const groups=new Map(),palette={p:'#2780ce',u:'#e59927',pu:'#dd5262',pu_rpm_std:'#9263bd',pu_rpm_fixed:'#168e78'};
 for(const row of comparisonDetail.summary.rows){const changes=p.conditions?.[row.dataset]||[];const other=changes.filter(c=>c.path!==axis).map(c=>`${c.label}=${c.value}`).join(', ');if(other!==$('trend-other').value)continue;let value=changes.find(c=>c.path===axis)?.value;
 if(value===undefined){if(axis==='rotation.rpm'){const r=p.metadata?.[row.dataset]?.config?.rotation;value=r?.rpm_start===r?.rpm_end?r?.rpm_start:undefined;}else if(axis.endsWith('level_delta_db'))value=0;else{value=p.metadata?.[row.dataset]?.config;for(const key of axis.split('.'))value=value?.[key];}}
 const rate=row['class'+$('trend-class').value+'_rate'];if(!Number.isFinite(value)||rate==null)continue;const key=row.variant+'|'+other;
 if(!groups.has(key))groups.set(key,{points:[],color:palette[row.variant]||'#34495e',label:(comparisonLabels[row.variant]||row.variant)+(other?' / '+other:' / その他は基準条件')});groups.get(key).points.push([value,rate*100]);}
 const series=[];for(const g of groups.values()){g.points.sort((a,b)=>a[0]-b[0]);series.push({x:g.points.map(a=>a[0]),y:g.points.map(a=>a[1]),color:g.color});const label=document.createElement('span');label.textContent='● '+g.label;label.style.color=g.color;$('trend-legend').append(label);}
 if(series.length)chart(canvas,series,{scatter:true,xlabel:axes.get(axis),ylabel:'Rate [%]',yrange:[0,100]});
}
$('trend-other').onchange=drawTrend;$('trend-axis').onchange=drawTrend;$('trend-class').onchange=drawTrend;
const syncWithoutTrend=syncResults;syncResults=function(){syncWithoutTrend();drawTrend();};
window.addEventListener('resize',()=>{if(resultPanel.classList.contains('active'))drawTrend();});
new MutationObserver(()=>{if(resultPanel.classList.contains('active'))requestAnimationFrame(drawTrend);}).observe(resultPanel,{attributes:true,attributeFilter:['class']});

const comparisonNameCache=new Map();
const refreshWithPaths=refreshComparisons;
refreshComparisons=async function(newest=false){await refreshWithPaths(newest);await Promise.all(Array.from($('cmp-history').options,async o=>{const folder=o.value;if(!/^comparison_/.test(o.textContent))return;try{if(!comparisonNameCache.has(folder))comparisonNameCache.set(folder,api('comparison-detail',{folder}).then(d=>d.plan.name||('既存比較：'+ResultLabels.summary(ResultLabels.config(d.plan,d.plan.training_datasets?.[0])))));const name=await comparisonNameCache.get(folder);for(const id of ['cmp-history','results-experiment'])for(const entry of $(id).options)if(entry.value===folder){entry.textContent=name;entry.title=folder;}}catch(e){comparisonNameCache.delete(folder);}}));};
