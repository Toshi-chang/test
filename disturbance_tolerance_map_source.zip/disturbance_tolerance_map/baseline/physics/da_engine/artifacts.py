"""Local lab result format; deliberately NOT NV ResultBundle 1.0."""
import hashlib,html,json,platform,sys
from pathlib import Path
import numpy as np
from .engine import synthesize,SCHEMA,element_weights
from .geometry import quadrature

RESULT_SCHEMA='distributed-acoustics-result/1.0'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def run(config_path,output):
    config_path=Path(config_path).resolve();out=Path(output).resolve()
    if out.exists():raise ValueError('Use a new output folder; never overwrite results')
    scene=read(config_path);out.mkdir(parents=True)
    write(out/'scene.json',scene)
    try:
        result=synthesize(scene)
        np.savez_compressed(out/'observations.npz',**{k:result[k] for k in ['time_s','pressure_pa','velocity_m_s','axial_velocity_m_s']})
        truth={k:result[k] for k in ['source_pressure_pa','source_velocity_m_s','source_drives']}
        for i,s in enumerate(scene['sources']):
            q=quadrature(s['geometry']);w,phase,delay=element_weights(s,q)
            truth[f'source_{i}_points_m']=q['points_m'];truth[f'source_{i}_weights']=w
            truth[f'source_{i}_phase_rad']=phase;truth[f'source_{i}_delay_s']=delay
        np.savez_compressed(out/'generator_truth.npz',**truth)
        metrics={'schema_version':RESULT_SCHEMA,'receiver_results':[]}
        for i,r in enumerate(scene['receivers']):
            p=result['pressure_pa'][:,i];u=result['axial_velocity_m_s'][:,i]
            metrics['receiver_results'].append({'receiver_id':r['id'],'p_rms_pa':float(np.sqrt(np.mean(p*p))),
                'u_rms_m_s':float(np.sqrt(np.mean(u*u))),'mean_axial_intensity_w_m2':float(np.mean(p*u))})
        write(out/'metrics.json',metrics)
        code_root=Path(__file__).resolve().parent
        write(out/'provenance.json',{'engine':'distributed_acoustics_poc 0.1.0','input_config_sha256':sha(config_path),
            'code_sha256':{p.name:sha(p) for p in sorted(code_root.glob('*.py'))},
            'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),
            'phasor':'exp(+j omega t)','arrays':{'pressure_pa':'[time,receiver] Pa','velocity_m_s':'[time,receiver,xyz] m/s',
            'axial_velocity_m_s':'[time,receiver] m/s','source_pressure_pa':'[source,time,receiver] Pa',
            'source_velocity_m_s':'[source,time,receiver,xyz] m/s','source_drives':'[source,time], source-specific drive_unit'},
            'normalization':'source driver central RMS after envelope and spectral band limit; no p/u output normalization',
            'truth_policy':'generator_truth.npz is diagnostic ground truth, not observations',
            'limitation':'Equivalent source distribution; no solid-body scattering, wall transmission or structural coupling.'})
        write(out/'manifest.json',{'schema_version':RESULT_SCHEMA,'status':'complete',
            'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}})
        inspect(out)
        return out
    except Exception as e:
        write(out/'failure.json',{'status':'failed','reason':str(e)})
        raise

def inspect(folder):
    root=Path(folder).resolve();manifest=read(root/'manifest.json')
    if manifest.get('schema_version')!=RESULT_SCHEMA or manifest.get('status')!='complete':raise ValueError('unknown/incomplete result')
    required={'scene.json','observations.npz','generator_truth.npz','metrics.json','provenance.json'}
    if set(manifest['files'])!=required:raise ValueError('unexpected result member set')
    for name,desc in manifest['files'].items():
        p=(root/name).resolve()
        if p.parent!=root or not p.is_file() or sha(p)!=desc['sha256'] or p.stat().st_size!=desc['bytes']:
            raise ValueError('artifact integrity mismatch: '+name)
    scene=read(root/'scene.json')
    if scene['schema_version']!=SCHEMA:raise ValueError('unknown scene schema')
    count=len(scene['receivers']);n=round(scene['simulation']['duration_seconds']*scene['simulation']['sample_rate_hz'])
    with np.load(root/'observations.npz',allow_pickle=False) as arrays:
        for k,shape in {'time_s':(n,), 'pressure_pa':(n,count),'velocity_m_s':(n,count,3),'axial_velocity_m_s':(n,count)}.items():
            if arrays[k].shape!=shape or not np.isfinite(arrays[k]).all():raise ValueError('invalid observation array '+k)
    return {'status':'valid','schema_version':RESULT_SCHEMA,'receivers':count,'sources':len(scene['sources']),'samples':n}

def svg_plot(x,series,labels,ylabel,width=850,height=210):
    colors=['#007c91','#db6417','#7457ac','#269361'];left=75;top=20;pw=width-left-25;ph=height-65
    xx=np.asarray(x);data=np.asarray(series); ymax=max(float(np.max(abs(data))),1e-20)
    out=[f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{html.escape(ylabel)}">',
         f'<rect width="{width}" height="{height}" fill="white"/>',
         f'<path d="M {left} {top} V {top+ph} H {left+pw}" stroke="#aaa" fill="none"/>',
         f'<text x="4" y="15" font-size="12">{html.escape(ylabel)}</text>',
         f'<text x="4" y="40" font-size="11">±{ymax:.3g}</text>']
    ids=np.unique(np.linspace(0,len(xx)-1,min(800,len(xx))).astype(int))
    for i,(row,label) in enumerate(zip(data,labels)):
        pts=' '.join(f'{left+(xx[j]-xx[0])/max(xx[-1]-xx[0],1e-20)*pw:.2f},{top+ph/2-row[j]/ymax*ph/2:.2f}' for j in ids)
        color=colors[i%len(colors)]
        out.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="1.1"/>')
        out.append(f'<text x="{left+i*170}" y="{height-6}" font-size="12" fill="{color}">{html.escape(label)}</text>')
    out.append(f'<text x="{left+pw-100}" y="{top+ph+18}" font-size="11">time [s] {xx[-1]:.3g}</text></svg>')
    return ''.join(out)

def geometry_svg(scene):
    points=[];colors=[];palette=['#007c91','#db6417','#7457ac','#269361']
    for i,s in enumerate(scene['sources']):
        p=quadrature(s['geometry'])['points_m'];p=p[::max(1,len(p)//700)]
        points.extend(p);colors.extend([palette[i%len(palette)]]*len(p))
    source_count=len(points)
    points.extend([r['position_m'] for r in scene['receivers']]);colors.extend(['#b01d3a']*len(scene['receivers']))
    pts=np.asarray(points);out=['<svg viewBox="0 0 1000 320" role="img" aria-label="source and receiver positions">']
    for panel,(a,b,title) in enumerate([(0,1,'XY'),(0,2,'XZ'),(1,2,'YZ')]):
        low=pts[:,[a,b]].min(axis=0);high=pts[:,[a,b]].max(axis=0);span=max(float(max(high-low)),.01)*1.2
        center=(low+high)/2;xy=(pts[:,[a,b]]-center)/span*230
        out.append(f'<text x="{panel*333+10}" y="20" font-size="16">{title} projection [m]</text>')
        for i,((x,y),color) in enumerate(zip(xy,colors)):
            x+=panel*333+160;y=160-y
            out.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{4 if i>=source_count else 1.6}" fill="{color}"/>')
            if i>=source_count:out.append(f'<text x="{x+5:.2f}" y="{y:.2f}" font-size="11">{html.escape(scene["receivers"][i-source_count]["id"])}</text>')
        out.append(f'<text x="{panel*333+10}" y="305" font-size="12">display width: {span:.3g} m</text>')
    out.append('</svg>');return ''.join(out)

def view(folder,output):
    root=Path(folder);inspect(root);scene=read(root/'scene.json');metrics=read(root/'metrics.json')
    with np.load(root/'observations.npz',allow_pickle=False) as a:
        labels=[r['id'] for r in scene['receivers']]
        plots=svg_plot(a['time_s'],a['pressure_pa'].T,labels,'p [Pa]')+svg_plot(a['time_s'],a['axial_velocity_m_s'].T,labels,'u axis [m/s]')
    rows=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [r['receiver_id'],f"{r['p_rms_pa']:.6g}",f"{r['u_rms_m_s']:.6g}",f"{r['mean_axial_intensity_w_m2']:.6g}"])+'</tr>' for r in metrics['receiver_results'])
    body=f'''<!doctype html><html lang="ja"><meta charset="utf-8"><title>分布音源PoC</title>
    <style>body{{font:16px sans-serif;color:#193047;background:#eff3f6;max-width:1100px;margin:30px auto}}section{{background:white;padding:24px;margin:16px 0;border-radius:12px}}svg{{width:100%}}td,th{{padding:10px;border-bottom:1px solid #ddd}}pre{{white-space:pre-wrap;font-size:12px}}</style>
    <h1>分布音源：形状・観測p/u</h1><p>{html.escape(scene['propagation'])} / {html.escape(scene.get('interpretation',''))}</p>
    <section><b>生成器の配置情報（正解側）</b><p>赤点：受音点。その他：音源要素。立体形状は筐体境界を意味しません。配置図は表示用に間引いています。</p>{geometry_svg(scene)}</section>
    <section><b>観測信号</b><p>各受音点のpと軸方向u。波形表示は最大800点に間引き、計算と保存は全サンプルです。</p>{plots}</section>
    <section><table><tr><th>受音点</th><th>p RMS [Pa]</th><th>u RMS [m/s]</th><th>平均p·u [W/m²]</th></tr>{rows}</table></section>
    <section><b>条件</b><pre>{html.escape(json.dumps(scene,ensure_ascii=False,indent=2))}</pre></section>
    <p>線形音場の合成実験です。実測との一致、異音検知性能、筐体の遮音・透過は未検証。</p></html>'''
    Path(output).write_text(body,encoding='utf-8');return str(output)
