"""Phase 3 explicit registration, selection and preflight tests."""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

from nv_runner.plugin_catalog import BUILTIN_DESCRIPTORS
from nv_runner.plugin_descriptor import PluginDescriptor
from nv_runner.plugin_registry import PluginRegistry


def config():
    return {"key": "A", "plugin": "fixed_window", "window_seconds": 1,
            "hop_seconds": .5, "model": {"kind": "isolation_forest"}}


class PluginRegistryTests(unittest.TestCase):
    def setUp(self):
        self.registry = PluginRegistry(BUILTIN_DESCRIPTORS)
        self.descriptor = BUILTIN_DESCRIPTORS[0]

    def test_01_legacy_factory_and_input_unchanged(self):
        value = config()
        original = deepcopy(value)
        self.assertIsNone(self.registry.validate(value))
        instance = self.registry["fixed_window"](value)
        self.assertEqual(instance.key, "A")
        self.assertEqual(value, original)
        self.assertEqual(len(instance.feature_schema()), 8)

    def test_02_mapping_is_lazy_in_fresh_process(self):
        source = """import sys
from nv_runner.plugin_catalog import DEFAULT_REGISTRY as registry
assert 'fixed_window_candidate' in registry
assert len(list(registry)) == 5
factory = registry['fixed_window_candidate']
assert callable(factory)
assert 'nv_runner.route_a_candidate' not in sys.modules
assert 'nv_runner.routes' not in sys.modules
registry.validate({'enabled': False, 'plugin': 'missing'})
assert 'nv_runner.route_a_candidate' not in sys.modules
"""
        result = subprocess.run([sys.executable, "-c", source], cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_03_duplicate_missing_and_unregister(self):
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.registry.register(self.descriptor)
        self.registry.unregister("fixed_window_candidate")
        self.assertNotIn("fixed_window_candidate", self.registry)
        self.registry.validate(config())
        with self.assertRaises(ValueError):
            self.registry.validate({**config(), "plugin": "unknown"})
        with self.assertRaises(KeyError):
            self.registry["unknown"]

    def test_04_incompatible_versions_and_contracts(self):
        for changes in ({"api_version": "2.0"}, {"descriptor_version": "2.0"},
                        {"input_contracts": {"C01": "2.0", "C02": "1.0"}},
                        {"output_contracts": {"C03": "1.0"}}, {"model_contract": "C04@2.0"}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                PluginRegistry([replace(self.descriptor, **changes)])

    def test_05_optional_implementation_pin(self):
        value = {**config(), "implementation_version": "0.2.0"}
        self.registry.validate(value)
        with self.assertRaisesRegex(ValueError, "version mismatch"):
            self.registry.validate({**value, "implementation_version": "99"})

    def test_06_unavailable_unselected_plugin_is_isolated(self):
        self.registry.register(replace(self.descriptor, plugin_id="unavailable", factory="missing_phase3_dependency:Route"))
        self.registry.validate(config())
        self.registry.validate({"plugin": "unavailable", "enabled": False})
        with self.assertRaisesRegex(ValueError, "unavailable"):
            self.registry.validate({**config(), "plugin": "unavailable"})

    def test_07_malformed_entrypoint_and_noncallable(self):
        with self.assertRaisesRegex(ValueError, "type object"):
            PluginRegistry([replace(self.descriptor, config_schema={"type": "number"})])
        for endpoint in ("x.py", "x:y()", "x:y;bad"):
            with self.subTest(endpoint=endpoint), self.assertRaises(ValueError):
                PluginRegistry([replace(self.descriptor, factory=endpoint)])
        registry = PluginRegistry([replace(self.descriptor, factory="sys:version")])
        with self.assertRaisesRegex(ValueError, "not callable"):
            registry.validate(config())

    def test_08_actual_lifecycle_missing_or_wrong_signature(self):
        from nv_runner.routes import FixedWindow
        class Missing:
            def __init__(self, config):
                pass
        class WrongSignature(FixedWindow):
            def prepare(self):
                pass
        for factory in (Missing, WrongSignature):
            with self.subTest(factory=factory.__name__), patch("nv_runner.plugin_registry._resolve", return_value=factory):
                with self.assertRaisesRegex(ValueError, "lifecycle"):
                    self.registry.validate(config())

    def test_09_schema_validation_precedes_factory_import(self):
        with patch("nv_runner.plugin_registry._resolve", side_effect=AssertionError("must not import")):
            for value in (0, -1, "one"):
                with self.subTest(value=value), self.assertRaises(ValueError):
                    self.registry.validate({**config(), "window_seconds": value})

    def test_10_descriptor_dictionaries_are_snapshotted(self):
        declaration = replace(self.descriptor, config_schema=deepcopy(self.descriptor.config_schema))
        registry = PluginRegistry([declaration])
        declaration.config_schema["required"].append("mutated")
        exported = registry.get_descriptor("fixed_window")
        exported.config_schema["required"].append("also_mutated")
        registry.validate(config())

    def test_11_candidate_constraint_and_factory_identity(self):
        candidate = {**config(), "plugin": "fixed_window_candidate"}
        self.registry.validate(candidate)
        with self.assertRaises(ValueError):
            self.registry.validate({**candidate, "selection": {"enabled": True, "condition": {"field": "msc", "comparison": ">", "value": .5}}})
        with self.assertRaisesRegex(ValueError, "plugin mismatch"):
            self.registry["fixed_window"](candidate)

    def test_12_config_cannot_override_registered_entrypoint(self):
        value = {**config(), "factory": "missing_phase3_dependency:Route"}
        self.assertEqual(type(self.registry["fixed_window"](value)).__name__, "FixedWindow")


if __name__ == "__main__":
    unittest.main()
