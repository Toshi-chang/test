import copy
import shutil
import unittest
from contract_fixtures import pipeline, run_variant
from nv_runner.common import read_json, write_json
from nv_runner.runner import validate_config
from nv_runner.bundle import BundleReader

class C08(unittest.TestCase):
    def test_existing_registry_pipeline(self):
        _,_,bundle=pipeline(); reader=BundleReader(bundle).validate()
        self.assertEqual(reader.manifest['bundle_status'],'complete')
        self.assertEqual(len(reader.manifest['completed_routes']),5)
        self.assertEqual(len(reader.tables['route_case_results']),35)

    def test_bad_config_rejected_before_run(self):
        root,original,_=pipeline()
        for kind in ('version','plugin','model','duplicate','condition'):
            cfg=copy.deepcopy(original)
            if kind=='version': cfg['schema_version']='2.0'
            elif kind=='plugin': cfg['routes'][0]['plugin']='future_api'
            elif kind=='model': cfg['routes'][0]['model']['kind']='future_model'
            elif kind=='duplicate': cfg['routes'][1]['key']=cfg['routes'][0]['key']
            else: cfg['routes'][1]['selection']['condition']={'op':'xor','children':[]}
            path=root/('bad_'+kind+'.json'); write_json(path,cfg)
            with self.subTest(kind=kind), self.assertRaises(ValueError): validate_config(path)

    def test_partial_failure_nulls_and_reasons(self):
        root,cfg,_=pipeline(); cfg=copy.deepcopy(cfg)
        data=root/'edge_data'; shutil.copytree(root/'data',data)
        manifest=read_json(data/'eval_manifest.json')
        for entry in manifest['measurements']: entry['mapping']['rpm']=None
        write_json(data/'eval_manifest.json',manifest); cfg['eval_manifest']=str(data/'eval_manifest.json')
        cfg['routes'][1]['selection']['condition']={'field':'msc','comparison':'>','value':2}
        cfg['routes'][3]['threshold_pa']=100; cfg['routes'][4]['simulate_failure']=True
        reader=run_variant(cfg); self.assertEqual(reader.manifest['bundle_status'],'partial')
        for row in reader.tables['route_case_results']:
            key=row['route_key']
            if key=='A_full': self.assertIsNotNone(row['case_score']); continue
            self.assertIsNone(row['case_score']); self.assertEqual(row['decision'],'undetermined')
            if key=='B_order':
                self.assertEqual(row['execution_status'],'skipped'); self.assertEqual(row['coverage_status'],'not_applicable')
                self.assertIn('rotation_signal_missing',row['reason'])
            if key=='A_selected': self.assertIn('empty_selection',row['reason'])
            if key=='C_event': self.assertIn('no_events',row['reason'])
            if key=='D_patch': self.assertEqual(row['execution_status'],'failed')
