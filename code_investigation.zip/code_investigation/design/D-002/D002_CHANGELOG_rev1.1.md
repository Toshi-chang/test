# D-002 rev.1.1 変更記録・整合性レビュー

2026-10-20。設計文書のみ更新。**新機能実装、製品ソース改修、試験実行なし。** rev.1の3文書とevidence.json、round01/02を保持した。新たなコード調査根拠は増やしていないためevidence.jsonは変更しない。

成果物： [統合設計](D002_DESIGN_rev1.1.md)、[As-Is・判断台帳](D002_ASIS_DECISIONS_rev1.1.md)、[比較PoC](D002_COMPARISON_POC_rev1.1.md)、本変更記録。rev.1.1の統合設計は基礎項目も含み、旧版の差分読解を前提にしない。

## 1. 変更と非互換性

|箇所|変更理由・採用する案|影響・代替案|
|---|---|---|
|SourceBinding/Identity|CSV前提からraw/derived/synthetic unionへ。合成根はgeneration_refを持ち、架空CSVを要求しない|**rev.1案に対して形状変更**。raw欄だけの既存仮fixtureは変換必要。共通自由辞書/履歴だけ表現よりvariant検証を優先|
|Channel ID/表現|論理信号系列と表現を区別。表現は(root,定義revision,CH)で識別。多対一には新CH|**取得CHだけという意味を拡張**。派生信号を既存取得CHに偽装するfixtureは非適合。別UUID案はID増加のため非推奨|
|部分Revision|新manifestを作り未変更表現refを共有、旧View固定|意味はrev.1の不変性を強化。全複製も意味的には可能だが物理保存は比較対象。in-place更新は不採用|
|ConsumerProfile|role/required/advisory/禁止条件とpolicyを固定、ValidationReportへ参照|従来の抽象的用途判定を具体化。requiredをwarningで逃がす解釈は不可。任意コード検査/万能DSLを要求しない|
|AdapterReport|変換outcomeとfield disposition、適合scope、process/validation参照|新規意味契約。変換成功と科学的Readyを区別。boolや全文ログだけでは不足|
|Core|同一契約内の必須性/Unknown/capabilityで最小範囲を定義|巨大な用途別schema群を作らない。UnknownでもCH/time/unitの状態を省略しない|

文書改訂であり、PoC0.2.0、C01〜C08、ResultBundle1.0、Bridge/Observerの運用契約は変更していない。上記の非互換は**未実装D-002 rev.1案とrev.1.1案の間**のもの。文書番号1.1をpayload minor互換の根拠にしない。実装開始時に最初の正式schemaとfixture版を採択する必要がある。

## 2. 責務・重複・曖昧さの監査

|対象|検出した境界問題|rev.1.1での一意な定義/確認先|
|---|---|---|
|RecordingIdentity|合成に原CSVを強制する不整合|acquired source_refs / synthetic generation_ref、§4/15|
|SignalChannels|取得CHと多対一派生CHの混同|channel_kind、論理IDと表現、§6/16|
|SignalRevision|未変更CHの値と履歴を新規生成扱いにする懸念|全entry解決可能なmanifest、定義元表現ref共有、§16|
|SignalView|選択時の補間/校正が混入する懸念|選択のみ。処理は新Revision/Artifact、§10/16|
|DerivedArtifact|窓start不明でも転置で適合とする危険|source_support必須、診断assetと適合窓を分離、§11/18|
|ProcessingRecord|Bindingへ履歴を複製する重複|処理方法/実装/パラメータ/実行の正規所有者。Bindingは直接辺/port、§9/15|
|QualityFinding|異なるscopeや更新履歴のpass/failが衝突|scope/check/revision/evidenceで評価。supersedes証拠以外のlast-write-wins禁止、§17|
|CalibrationRecord|PU03の履歴を全CHへ付与する危険|入力表現と適用CH/区間を拘束、未変更CHは以前のref、§8/16|
|ValidationReport|consumer/profile/policyの判定が重複|eligibility[]が唯一の用途結果。各条件/理由/証拠/再評価条件を記録、§17|
|ConsumerProfile|計算API/アルゴリズム設定との混同|データ要求の宣言だけ。計算方式の具体条件を解決したprofileを使用、§17|
|AdapterReport|変換処理の成功を入力適格性と混同|outcomeとValidationReport参照を分離、§18|
|Core/拡張|必須由来を簡略化で捨てる懸念|raw/derived/synthetic該当欄は必須。未知を許す範囲と解析禁止を明記、§19|

同一意味の情報はref先を正とし、index/summaryを重複させる場合は値一致を検査する。Bindingのparent_edgesはProcessingRecord input portへの索引であり別の履歴ではない。source hashはAssetRefが正。CH単位/時間はSignalChannel/TimeBaseが正。profile/policyは参照snapshotが正。矛盾は片方を黙って採用せずINPUT_CONFLICT/EVIDENCE_CONFLICTにする。

## 3. INV-01〜12の照合

|INV|監査結果・影響|比較計画|
|---|---|---|
|01|合成根/混合親へ一般化。取得根の原本追跡は維持|T-01/06/08/09|
|02|quantity/unit/stageとmeasurement_roleを維持、Adapter補完禁止|T-01/05/08|
|03|表現ごとのTimeBase、片CH resample後に再評価|T-02/07/11|
|04|論理CH一意、定義元表現一意。aliasと新派生CHを区別|T-02/04/08|
|05|pair参照整合を維持、部分変更でも新表現の成立を確認|T-04/12|
|06|校正履歴は表現/CH/区間scopeに拘束|T-08/09|
|07|多親すべてのsample support。追跡不能は適合公開不可|T-07/09|
|08|同期不足の依存解析禁止をprofile条件に具体化|T-02/11/12|
|09|共有表現のimmutable保証、旧Viewは定義revision固定|T-06/08/09|
|10|missing/placeholder/実測0にexcludedも分離|T-02/03|
|11|親品質をsupportへ投影し継承。範囲不明なら合格化しない|T-08/12/13|
|12|契約/profile版・capabilityの未対応拒否を維持|T-09/13|

INV-13〜16はBinding/表現/用途判定/変換報告を追加したもの。旧INVを弱めるための例外ではない。J01〜19は新版判断台帳§6で全IDを照合し、既存の状態区分を保持した。J20〜25はEARLY中心、保存方式はSELECTのままでFIXを追加していない。

## 4. T-01〜13と引継ぎ

既存試験計画を本文ごと継承し、T-01〜10は各節内に補強条件、T-11〜13は追加条件欄を設けた。新試験IDなし。入力/変数/固定条件/期待・拒否/合格・判断IDを記載。すべて未実施。

- D-003：固定profileでViewを検査し、Adapter変換/入力不適格/実行失敗を別扱い。出力はDerivedArtifactまたは新SignalRevision。GUIから計算を複製しない。
- D-004：共有表現を旧Viewとともに保持。Binding/親support/AdapterReport/ValidationReport/AssetRef完全性を保存・移設できること。削除/GCで参照を破壊しない。
- D-005：profileと出力意味が同じかを交換条件として評価。実装IDが同じだけでは互換にしない。DAG/Registry採用は別工程。
- D-006：合成RNG/stream/順序/実装/設定、root/experiment/runの関係、truth隔離、旧revisionを変更しない比較を記録。

未確定は実機時間・位相/校正budget、外部metadata binding、表現共有の保存実装、Adapterが実成果物から復元できる範囲、generator再現水準。推奨案と検証方法は判断台帳J20〜25およびPoC計画§14へ記載した。これらの未確定は設計作業未完了ではなく、次の比較・実資料確認で決定する項目。

## 5. 保護対象・資料確認

rev.1.1作成前の保護対象SHA-256（終了時にも照合）：

|ファイル|SHA-256|
|---|---|
|D002_DESIGN.md|7705c8b7e9f5fe2f4fdbb2e49c0ba6f90445e667e3758c1fd9d80e2d196440f1|
|D002_ASIS_DECISIONS.md|37b545d2b31c2748174d09350f793c3202bd223d609b7b94f63e208e88a49608|
|D002_COMPARISON_POC.md|f9d7bbf48d3727c97bfb8e09121b0ba2ffaeacf27c03027529decbd7cb9caeef|
|evidence.json|47035fe5ca23377fa6085b92866c074cf1e0267f1e1f5e52bb4e01290eb52b10|

開始時に既存台帳の54ソースと4調査文書を照合し相違0件。ソース全文再読込・広域探索なし。文書生成・hash/参照確認のローカル操作は行ったが、製品module import・PoC/試験実行は行っていない。設計上の整合性レビューを科学的妥当性の実証に数えない。
