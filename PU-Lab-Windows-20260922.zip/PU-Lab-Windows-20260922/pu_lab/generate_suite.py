"""Reproducible A-I evaluation packs with shared normal learning partitions."""
from pathlib import Path
import argparse,copy,csv,json,time
import numpy as np
from physics import presets,synthesize
from dataset import make_dataset
from levels import reference_levels
from rpm_sensor import DEFAULT_SENSOR

def plan():
    base=presets()['評価基準：機械60 dB SPL・暗騒音25 dB SPL・1000 RPM']
    base.update(window_samples=2048,windows_per_record=4,duration_s=1.)
    base['counts']=dict(train=100,validation=40,calibration=100,test_per_class=100)
    jobs=[]
    def add(name,c,detail,own=False):jobs.append(dict(name=name,config=c,detail=detail,own_learning=own))
    for i in range(3):
        c=copy.deepcopy(base);c['seed']+=i
        add(f'A_seed_{i+1}',c,'Independent seed; own normal learning/calibration',True)
    for db in (-30,-20,-10,0):add(f'B_fault_{db:+d}dB',reference_levels(base,fault_relative_db=db),f'Inspect class 2; fault/p machine = {db} dB')
    for db in (-30,-20,-10,0,10):add(f'C_external_{db:+d}dB',reference_levels(base,external_relative_db=db),f'Inspect class 1; external/p machine = {db} dB')
    for fault in (-30,-20,-10,0):
        for ext in (-30,-20,-10,0,10):add(f'D_fault_{fault:+d}_external_{ext:+d}',reference_levels(base,fault_relative_db=fault,external_relative_db=ext),'Full grid; inspect class 3, no post-selection by test results')
    for rpm in (800,900,1000,1100,1200):
        c=copy.deepcopy(base);c['rotation'].update(rpm_start=rpm,rpm_end=rpm)
        add(f'E_rpm_{rpm}',c,'Learning at 1000 RPM; other RPMs are unseen. Drives fixed.')
    for start,end in ((800,1200),(1200,800)):
        c=copy.deepcopy(base);c['rotation'].update(rpm_start=start,rpm_end=end)
        add(f'F_ramp_{start}_{end}',c,'Normal speed change; fixed source drives')
    for ripple in (.01,.05):
        c=copy.deepcopy(base);c['rotation']['ripple']=ripple
        add(f'F_ripple_{int(ripple*100)}pct',c,'True speed fluctuation, not sensor noise')
    for kind in ('tone','bursts','multitone'):
        for db in (-10,0):
            c=copy.deepcopy(base);s=c['sources'][2];s.update(kind=kind,frequency_hz=1000 if kind!='multitone' else 750,harmonics=3)
            add(f'G_{kind}_{db:+d}dB',reference_levels(c,external_relative_db=db),'Independent external sound, matched received pressure level')
    for distance in (.1,.3):
        c=copy.deepcopy(base)
        for s in c['sources']:
            if s['kind'] in ('gear','rotation_fault'):s['distance_m']=distance
        add(f'H_target_{distance:g}m',c,'Source drives unchanged; receiver attenuation retained')
    for angle in (0,60,90):
        c=copy.deepcopy(base);c['sources'][2]['axis_angle_deg']=angle
        add(f'H_external_axis_{angle}',c,'External receiver projection changes; no p/u renormalization')
    sensor_cases={'gain_plus2pct':dict(gain_error_pct=2),'gain_minus2pct':dict(gain_error_pct=-2),
      'offset20rpm':dict(offset_rpm=20),'delay50ms':dict(delay_ms=50),
      'smooth100ms':dict(smoothing_ms=100),'noise5rpm':dict(noise_rms_rpm=5),
      'noise20rpm':dict(noise_rms_rpm=20),'quantize10rpm':dict(quantization_rpm=10),
      'interference20rpm':dict(interference_rpm=20,interference_hz=7),
      'dropout10pct':dict(dropout_probability=.1),'pulse60ppr':dict(pulses_per_rev=60),
      'combined':dict(delay_ms=50,smoothing_ms=50,gain_error_pct=1,noise_rms_rpm=5,quantization_rpm=5,dropout_probability=.05)}
    for name,errors in sensor_cases.items():
        c=copy.deepcopy(base);c['rotation'].update(rpm_start=800,rpm_end=1200)
        c['rpm_sensor']={**DEFAULT_SENSOR,**errors}
        add('I_sensor_'+name,c,'True ramp matches F_ramp_800_1200; only measured RPM changes. Ideal-RPM training.')
    return jobs

def describe(c):
    r=synthesize(c,3,c['seed'],components=True)
    sources=c['sources'];groups={k:np.zeros_like(r['observed']) for k in ('machine','background','external','abnormal')}
    for i,s in enumerate(sources):
        group=('background' if s.get('background') else 'machine') if s['role']=='normal' else s['role']
        groups[group]+=r['components'][i]
    rms={key:np.sqrt(np.mean(value**2,axis=1)) for key,value in groups.items()}
    info={key+'_spl_db':float(20*np.log10(max(value[0],1e-30)/20e-6)) for key,value in rms.items()}
    for key in ('external','abnormal'):
        for j,ch in enumerate(('p','u')):info[key+'_'+ch+'_relative_db']=float(20*np.log10(max(rms[key][j],1e-30)/rms['machine'][j]))
    info['rpm_error_rmse']=float(np.sqrt(np.mean((r['rpm']-r['rpm_true'])**2)))
    return info

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='outputs/evaluation_60dB');parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True);jobs=plan()
    (out/'plan.json').write_text(json.dumps(jobs,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(jobs)} packs; 100 independent one-second test recordings per class; 4 windows each',flush=True)
    if args.plan_only:return
    rows=[];common=out/'A_seed_1/dataset.npz'
    for i,job in enumerate(jobs):
        folder=out/job['name'];start=time.monotonic()
        if not (folder/'dataset.npz').exists():
            make_dataset(job['config'],folder,learning_dataset=None if job['own_learning'] else common)
        row=dict(name=job['name'],detail=job['detail'],**describe(job['config']))
        rows.append(row)
        (folder/'reference_levels.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
        print(f'{i+1}/{len(jobs)} {job["name"]} {time.monotonic()-start:.1f}s',flush=True)
    with (out/'catalog.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    (out/'README.txt').write_text('100 recordings = 100 independent 1-second records per class. 4 classes = 400 test records / 1600 windows. Each window is 2048/16384 = 0.125 s; four non-overlapping windows cover 0.5 s of each record. Full examples and regeneration seeds are saved.\nA seeds have independent normal training. B-I reuse the exact A_seed_1 training/validation/calibration arrays. E-I test distribution shifts, not trained robustness. For fixed-threshold comparison reuse the A model and record threshold via infer_windows. UI training creates separate models; do not retune thresholds on each test set.\n60 dB SPL machine / 25 dB SPL background are reference levels at 3 cm and 1000 RPM. H retains distance attenuation. RPM true is diagnostic only; DL uses measured RPM. Scenarios are not encoder specifications.\n',encoding='utf-8')
    print('COMPLETE',flush=True)

if __name__=='__main__':main()
