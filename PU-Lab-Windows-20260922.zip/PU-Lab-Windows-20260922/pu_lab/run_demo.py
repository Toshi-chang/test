"""Compatible DL entry point replacing the old arbitrary p/u generator."""
import argparse
from pathlib import Path
from physics import default_config
from dataset import make_dataset
from dl import train_model

def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset');p.add_argument('--out',default='outputs/dl_cli')
    p.add_argument('--epochs',type=int,default=80);p.add_argument('--channels',choices=['p','u','pu','pu_rpm'],default='pu')
    args=p.parse_args();path=args.dataset
    if path is None:
        folder=Path(args.out)/'input';make_dataset(default_config(),folder,progress=print);path=folder/'dataset.npz'
    result=train_model(path,args.out,args.epochs,args.channels,progress=print)
    print(result['metrics'])
if __name__=='__main__':main()
