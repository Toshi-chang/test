"""Deterministic midpoint/Gauss quadrature in SI units; shapes are not walls."""
import numpy as np

KINDS = {'point', 'rectangle', 'disk', 'box_surface', 'box_volume',
         'sphere_surface', 'sphere_volume', 'cylinder_surface', 'cylinder_volume'}

def vector(x, name):
    a = np.asarray(x, dtype=float)
    if a.shape != (3,) or not np.isfinite(a).all():
        raise ValueError(name + ': finite 3-vector required')
    return a

def positive(x, name):
    x = float(x)
    if not np.isfinite(x) or x <= 0:
        raise ValueError(name + ': positive finite value required')
    return x

def frame(g):
    origin = vector(g.get('center_m', [0, 0, 0]), 'center_m')
    rotation = np.asarray(g.get('rotation', np.eye(3)), dtype=float)
    if (rotation.shape != (3, 3) or not np.isfinite(rotation).all()
            or not np.allclose(rotation.T @ rotation, np.eye(3), rtol=0, atol=1e-10)
            or not np.isclose(np.linalg.det(rotation), 1, rtol=0, atol=1e-10)):
        raise ValueError('rotation: proper orthonormal local-to-world matrix required')
    return origin, rotation

def resolution(g):
    n = g.get('resolution', 6)
    if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 32:
        raise ValueError('resolution: integer 1..32 required')
    return n

def axis(length, n):
    return (np.arange(n) + .5) * length / n - length / 2

def polar(radius, n):
    # Integrate in s=r^2: r dr = ds/2. Weights sum to pi R^2.
    q, w = np.polynomial.legendre.leggauss(n)
    r = radius * np.sqrt((q + 1) / 2)
    phi = (np.arange(4*n) + .5) * 2*np.pi/(4*n)
    rr, pp = np.meshgrid(r, phi, indexing='ij')
    points = np.column_stack([rr.ravel()*np.cos(pp.ravel()), rr.ravel()*np.sin(pp.ravel()), np.zeros(rr.size)])
    weights = np.repeat(w * radius**2 / 4 * 2*np.pi/(4*n), 4*n)
    return points, weights

def directions(n):
    mu, w = np.polynomial.legendre.leggauss(n)
    phi = (np.arange(4*n) + .5) * 2*np.pi/(4*n)
    mm, pp = np.meshgrid(mu, phi, indexing='ij')
    dirs = np.column_stack([np.sqrt(1-mm.ravel()**2)*np.cos(pp.ravel()),
                            np.sqrt(1-mm.ravel()**2)*np.sin(pp.ravel()), mm.ravel()])
    return dirs, np.repeat(w*2*np.pi/(4*n), 4*n)

def quadrature(g):
    kind = g['kind']
    if kind not in KINDS: raise ValueError('unsupported geometry: '+kind)
    dimensions = {'point':set(),'rectangle':{'size_m'},'disk':{'radius_m'},
                  'box_surface':{'size_m'},'box_volume':{'size_m'},
                  'sphere_surface':{'radius_m'},'sphere_volume':{'radius_m'},
                  'cylinder_surface':{'radius_m','height_m'},'cylinder_volume':{'radius_m','height_m'}}
    if set(g)-({'kind','center_m','rotation','resolution'}|dimensions[kind]):
        raise ValueError('unsupported geometry property')
    origin, rotation = frame(g)
    n = resolution(g)
    dimension = 0 if kind == 'point' else (3 if kind.endswith('_volume') else 2)
    if kind == 'point':
        p, w = np.zeros((1,3)), np.ones(1)
    elif kind == 'rectangle':
        size = np.asarray(g['size_m'], dtype=float)
        if size.shape != (2,) or not np.isfinite(size).all() or np.any(size <= 0): raise ValueError('rectangle size_m needs two positive lengths')
        xx, yy = np.meshgrid(axis(size[0],n), axis(size[1],n), indexing='ij')
        p = np.column_stack([xx.ravel(), yy.ravel(), np.zeros(xx.size)])
        w = np.full(len(p), np.prod(size)/len(p))
    elif kind == 'disk':
        p, w = polar(positive(g['radius_m'],'radius'), n)
    elif kind.startswith('box_'):
        size = vector(g['size_m'], 'box size_m')
        if np.any(size <= 0): raise ValueError('box sizes must be positive')
        if kind == 'box_volume':
            grid = np.meshgrid(*(axis(s,n) for s in size), indexing='ij')
            p = np.column_stack([x.ravel() for x in grid])
            w = np.full(len(p), np.prod(size)/len(p))
        else:
            pts, weights = [], []
            for a in range(3):
                b,c = [i for i in range(3) if i != a]
                xx,yy = np.meshgrid(axis(size[b],n),axis(size[c],n),indexing='ij')
                for sign in [-1,1]:
                    face = np.zeros((n*n,3)); face[:,a] = sign*size[a]/2
                    face[:,b], face[:,c] = xx.ravel(), yy.ravel()
                    pts.append(face); weights.append(np.full(n*n,size[b]*size[c]/(n*n)))
            p,w = np.concatenate(pts),np.concatenate(weights)
    elif kind.startswith('sphere_'):
        radius = positive(g['radius_m'],'radius')
        d, dw = directions(n)
        if kind == 'sphere_surface': p,w = radius*d, radius**2*dw
        else:
            q, ww = np.polynomial.legendre.leggauss(max(n,2))
            r = (q+1)*radius/2
            p = (r[:,None,None]*d[None,:,:]).reshape(-1,3)
            w = ((ww*radius/2*r*r)[:,None]*dw[None,:]).ravel()
    else:
        radius = positive(g['radius_m'],'radius'); height = positive(g['height_m'],'height')
        disk, disk_w = polar(radius,n)
        if kind == 'cylinder_volume':
            p = np.tile(disk,(n,1)); p[:,2] = np.repeat(axis(height,n),len(disk))
            w = np.tile(disk_w*height/n,n)
        else:
            phi = (np.arange(4*n)+.5)*2*np.pi/(4*n)
            pp, zz = np.meshgrid(phi,axis(height,n),indexing='ij')
            side = np.column_stack([radius*np.cos(pp.ravel()),radius*np.sin(pp.ravel()),zz.ravel()])
            bottom, top = disk.copy(),disk.copy(); bottom[:,2] = -height/2; top[:,2] = height/2
            p = np.concatenate([side,bottom,top])
            w = np.concatenate([np.full(len(side),2*np.pi*radius*height/len(side)),disk_w,disk_w])
    return {'local_points_m':p, 'points_m':p@rotation.T+origin, 'weights':w,
            'measure_unit':{0:'1',2:'m^2',3:'m^3'}[dimension], 'dimension':dimension,
            'normal_world':rotation[:,2], 'center_m':origin}

def check_receiver(g, receiver, clearance):
    origin, rot = frame(g)
    p = (receiver-origin)@rot
    kind=g['kind']
    # Explicit exclusion of support and volume interiors: no singularity clipping.
    if kind in ('rectangle','disk'):
        within = np.all(abs(p[:2]) <= np.asarray(g['size_m'])/2+clearance) if kind=='rectangle' else np.linalg.norm(p[:2])<=g['radius_m']+clearance
        if within and abs(p[2])<=clearance: raise ValueError('receiver on source support')
    elif kind.startswith('box_'):
        d=abs(p)-np.asarray(g['size_m'])/2
        if np.all(d<=clearance) and (kind.endswith('volume') or np.any(abs(d)<=clearance)):
            raise ValueError('receiver in/on excluded source support')
    elif kind.startswith('sphere_'):
        d=np.linalg.norm(p)-g['radius_m']
        if (kind.endswith('volume') and d<=clearance) or abs(d)<=clearance:
            raise ValueError('receiver in/on excluded source support')
    elif kind.startswith('cylinder_'):
        dr=np.linalg.norm(p[:2])-g['radius_m']; dz=abs(p[2])-g['height_m']/2
        if dr<=clearance and dz<=clearance and (kind.endswith('volume') or abs(dr)<=clearance or abs(dz)<=clearance):
            raise ValueError('receiver in/on excluded source support')
