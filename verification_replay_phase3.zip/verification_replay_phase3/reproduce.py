"""Frozen-protocol launcher. No scientific calculations or automatic repairs."""
import argparse, hashlib, json, os, re, subprocess, sys, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ENGINE=ROOT/'engine'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    failures=[]
    for f in read(ROOT/'protocol_manifest.json')['files']:
        p=(ROOT/f['path']).resolve()
        if not p.is_relative_to(ROOT): raise ValueError('unsafe manifest path')
        if not p.is_file() or digest(p)!=f['sha256']: failures.append(f['path'])
    if failures: raise ValueError('Protocol changed/missing: '+', '.join(failures))
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('task',choices=['verify','quick','comparison','regression','contracts','physics','relocation'])
    ap.add_argument('--output',type=Path)
    ap.add_argument('--example',type=Path)
    a=ap.parse_args()
    verify()
    if a.task=='verify': print('Frozen files verified (not an execution test)'); return
    if not a.output: ap.error('--output is required')
    out=a.output.resolve()
    if out.exists(): raise ValueError('Output must be a new directory; never overwrite evidence')
    if out==ENGINE or out.is_relative_to(ENGINE): raise ValueError('Keep output outside engine')
    out.mkdir(parents=True)
    report={'protocol':'verification-replay-1','task':a.task,'status':'running','python':sys.version,
            'executable':sys.executable,'commands':[],'historical_equivalence':'not_checked'}
    env=os.environ.copy()
    for k in ['PYTHONPATH','PYTHONHOME']: env.pop(k,None)
    env['PYTHONNOUSERSITE']='1'; env['PYTHONDONTWRITEBYTECODE']='1'
    def run(name,args):
        command=[sys.executable,'-B',*map(str,args)]
        result=subprocess.run(command,cwd=ENGINE,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
        (out/(name+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        report['commands'].append({'name':name,'argv':command,'cwd':str(ENGINE),'returncode':result.returncode})
        save(out/'validation.json',report)
        if result.returncode: raise RuntimeError(name+' failed; inspect log; do not tune conditions')
        return result.stdout+'\n'+result.stderr
    try:
        run('imports',['-c',"from pathlib import Path; import nv_runner; p=Path(nv_runner.__file__).resolve(); assert p.is_relative_to(Path.cwd()); print(p)"])
        run('dependencies',['-m','pip','check'])
        run('freeze',['-m','pip','freeze'])
        if a.task in ('quick','comparison'):
            profile='acoustic_'+a.task
            settings=read(ENGINE/'configs'/f'{profile}_data.json')
            config=read(ENGINE/'configs'/f'{profile}.json')
            save(out/'generation_settings.json',settings)
            original=read(ENGINE/'configs'/f'{profile}.json')
            for key,filename in [('train_manifest','train_manifest.json'),('eval_manifest','eval_manifest.json'),('truth_path','truth.json')]:
                config[key]=str(out/'data'/filename)
            config['export']['output_dir']=str(out/'runs')
            save(out/'experiment.json',config)
            save(out/'path_changes.json',{'before':{k:original[k] for k in ['train_manifest','eval_manifest','truth_path','export']},
                                         'after':{k:config[k] for k in ['train_manifest','eval_manifest','truth_path','export']}})
            run('generate',['-m','nv_runner','generate','--settings',out/'generation_settings.json','--output',out/'data'])
            if read(out/'data/generation.json')!=settings: raise AssertionError('generation settings mismatch')
            run('validate',['-m','nv_runner','validate','--config',out/'experiment.json'])
            run('execute',['-m','nv_runner','execute','--config',out/'experiment.json'])
            bundles=list((out/'runs').glob('run_*/manifest.json'))
            if len(bundles)!=1: raise AssertionError('expected exactly one bundle')
            bundle=bundles[0].parent
            m=read(bundle/'manifest.json')
            expected=['A_full','A_selected','B_order','C_event','D_patch']
            if m['bundle_status']!='complete' or set(m['completed_routes'])!=set(expected): raise AssertionError('incomplete route execution')
            run('inspect',['-m','nv_runner','inspect','--bundle',bundle])
            run('view',['-m','nv_runner','view','--bundle',bundle,'--output',out/'viewer.html'])
            run('export',['-m','nv_runner','import','--bundle',bundle,'--output',out/'evaluation_inbox'])
            metrics=read(bundle/'metrics.json')
            history=read(ROOT/'historical_reference.json')[a.task]
            keys=['true_positive','false_positive','false_negative','true_negative','normal_total','abnormal_total','undetermined_normal','undetermined_abnormal']
            actual={r:{k:metrics['routes'][r][k] for k in keys} for r in expected}
            report['historical_equivalence']='counts_match' if actual==history['counts'] else 'counts_differ_investigate'
            save(out/'historical_comparison.json',{'actual':actual,'reference':history,'match':actual==history['counts'],
                'note':'Count equality does not establish waveform/model equality. A difference is not repaired automatically.'})
            save(out/'summary.json',{'bundle':str(bundle),'generator':'acoustic','profile':a.task,'metrics':metrics})
            report['bundle']=str(bundle)
        elif a.task in ('regression','contracts'):
            pattern='test_*.py' if a.task=='regression' else 'test_contract_c*.py'
            log=run('tests',['-m','unittest','discover','-s','tests','-p',pattern,'-v'])
            n=130 if a.task=='regression' else 22
            if not re.search(r'Ran '+str(n)+r' tests?\b',log) or not re.search(r'^OK\s*$',log,re.M): raise AssertionError('expected test count/OK missing')
            report['test_count']=n
        elif a.task=='physics': run('physics',['-m','nv_runner.verify_physics','--output',out/'physics'])
        else:
            if not a.example: raise ValueError('--example must reference a completed quick/comparison output')
            run('relocation',['tools/replay_saved_checks.py','--example',a.example.resolve(),'--output',out/'relocated'])
        verify()
        report['status']='passed_with_result_difference' if report['historical_equivalence']=='counts_differ_investigate' else 'passed'
    except Exception as e:
        report['status']='failed'; report['error']=str(e)
        (out/'error.log').write_text(traceback.format_exc(),encoding='utf-8')
        raise
    finally: save(out/'validation.json',report)
    print(json.dumps(report,ensure_ascii=False))
    if report['status']=='passed_with_result_difference': return 2
if __name__=='__main__': sys.exit(main())
