"""Only this adapter knows the on-disk input mapping. No truth is loaded here."""
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np
from .common import read_json, require_version, sha, identity


@dataclass
class MeasurementRecord:
    meta: dict
    signals: np.ndarray
    rpm: np.ndarray | None


class InputAdapter:
    def load(self, manifest_path):
        path = Path(manifest_path).resolve()
        manifest = read_json(path)
        require_version(manifest)
        records = []
        for item in manifest["measurements"]:
            meta = read_json(path.parent / item["metadata_path"])
            require_version(meta)
            required = ["specimen_id", "case_id", "measurement_id", "derived_group_id", "channels",
                        "timebase", "calibration", "operating_conditions", "validity", "protocol", "data_kind"]
            for key in required:
                if key not in meta:
                    raise ValueError(f"missing {key}")
            for key in ("specimen_id", "case_id", "measurement_id", "derived_group_id"):
                if not isinstance(meta[key], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", meta[key]):
                    raise ValueError(f"invalid {key}")
            source = (path.parent / item["source_path"]).resolve()
            digest = sha(source)
            if digest != item["source_sha256"]:
                raise ValueError("source hash mismatch")
            mapping = item["mapping"]
            if mapping.get("axes") != ["time", "channel"]:
                raise ValueError("explicit [time, channel] axes required")
            with np.load(source, allow_pickle=False) as data:
                signals = np.asarray(data[mapping["signals"]], dtype=float)
                rpm = np.asarray(data[mapping["rpm"]], dtype=float) if mapping.get("rpm") else None
            if signals.ndim != 2 or signals.shape[1] != 2 or len(signals) < 2:
                raise ValueError("v1 requires exactly two channels p and u")
            if not np.isfinite(signals).all() or (rpm is not None and not np.isfinite(rpm).all()):
                raise ValueError("non-finite input")
            channels = meta["channels"]
            if len(channels) != 2:
                raise ValueError("channel count mismatch")
            for ch, quantity, unit in zip(channels, ["pressure", "particle_velocity"], ["Pa", "m/s"]):
                if ch.get("quantity") != quantity or ch.get("unit") != unit:
                    raise ValueError("channel quantities/units must be pressure Pa, particle_velocity m/s")
                for key in ("name", "position_m", "direction", "pair_id"):
                    if key not in ch:
                        raise ValueError(f"missing channel {key}")
                if len(ch["position_m"]) != 3 or len(ch["direction"]) != 3:
                    raise ValueError("sensor vectors must have three coordinates")
                if not np.isfinite(ch["position_m"]).all() or not np.isfinite(ch["direction"]).all():
                    raise ValueError("sensor vectors must be finite")
            if channels[0]["pair_id"] != channels[1]["pair_id"]:
                raise ValueError("p/u pair mismatch")
            if not np.allclose(channels[0]["position_m"],channels[1]["position_m"],atol=1e-10,rtol=0):
                raise ValueError("local p-u intensity requires collocated channels; noncollocated adapter required")
            if not np.isclose(np.linalg.norm(channels[1]["direction"]),1.,atol=1e-10,rtol=0):
                raise ValueError("u direction must be unit vector")
            tb = meta["timebase"]
            if not isinstance(tb["sample_rate_hz"], (float, int)) or tb["sample_rate_hz"] <= 0:
                raise ValueError("invalid sample rate")
            if tb.get("signal_sync") != "shared_clock" or "start_seconds" not in tb:
                raise ValueError("explicit shared signal clock and start time required")
            if rpm is not None and (rpm.shape != (len(signals),) or tb.get("rpm_sync") != "shared_clock"):
                raise ValueError("rpm requires explicit synchronization and same time axis")
            if meta["calibration"].get("status") != "calibrated" or not meta["calibration"].get("reference"):
                raise ValueError("explicit calibrated inputs required; add calibration in an adapter")
            for span in meta["validity"]:
                if not (0 <= span["start_sample"] < span["end_sample"] <= len(signals)) or not span.get("reason"):
                    raise ValueError("invalid validity range")
            optional = ["acoustic_contract"] if "acoustic_contract" in meta else []
            if optional and meta["acoustic_contract"].get("version") != "1.0":
                raise ValueError("unsupported acoustic contract version")
            meta = {k: meta[k] for k in ["schema_version"] + required + optional}
            meta.update(source_path=str(source), source_sha256=digest, n_samples=len(signals),
                        mapping=mapping, metadata_sha256=identity(meta))
            records.append(MeasurementRecord(meta, signals, rpm))
        if not records:
            raise ValueError("empty manifest")
        return sorted(records, key=lambda r: r.meta["measurement_id"])


class DatasetPlanner:
    def plan(self, train, evaluation, config, seed):
        all_records = train + evaluation
        mids = [r.meta["measurement_id"] for r in all_records]
        if len(set(mids)) != len(mids):
            raise ValueError("duplicate measurement_id")
        case_owner = {}
        for r in all_records:
            m = r.meta
            if case_owner.setdefault(m["case_id"], m["specimen_id"]) != m["specimen_id"]:
                raise ValueError("case spans multiple specimens")
        for key in ("specimen_id", "case_id", "source_sha256", "derived_group_id"):
            if {r.meta[key] for r in train} & {r.meta[key] for r in evaluation}:
                raise ValueError(f"train/eval leakage: {key}")
        # Connected components: same specimen, shared source or declared derivation parent stay together.
        ids = sorted({r.meta["specimen_id"] for r in train})
        parent = {s: s for s in ids}
        def root(s):
            while parent[s] != s:
                s = parent[s]
            return s
        seen = {}
        for r in train:
            for key in ("source_sha256", "derived_group_id"):
                token = (key, r.meta[key])
                s = r.meta["specimen_id"]
                if token in seen:
                    parent[root(s)] = root(seen[token])
                seen[token] = s
        groups = {}
        for s in ids:
            groups.setdefault(root(s), []).append(s)
        groups = [groups[k] for k in sorted(groups)]
        np.random.default_rng(seed).shuffle(groups)
        minimum = config.get("min_calibration_groups", 2)
        ncal = max(minimum, int(np.ceil(len(groups) * config["calibration_fraction"])))
        available = len(groups) >= ncal + config.get("min_fit_groups", 3)
        cal_ids = {s for g in groups[:ncal] for s in g} if available else set()
        fit = [r for r in train if r.meta["specimen_id"] not in cal_ids]
        cal = [r for r in train if r.meta["specimen_id"] in cal_ids]
        return fit, cal, {"schema_version": "1.0", "seed": seed,
            "status": "available" if available else "calibration_unavailable",
            "grouping": ["specimen_id", "derived_group_id", "source_sha256"],
            "fit": [r.meta["measurement_id"] for r in fit],
            "calibration": [r.meta["measurement_id"] for r in cal],
            "evaluation": [r.meta["measurement_id"] for r in evaluation],
            "fit_specimens": sorted({r.meta["specimen_id"] for r in fit}), "calibration_specimens": sorted(cal_ids)}
