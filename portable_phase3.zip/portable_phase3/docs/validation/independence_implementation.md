# 既存機能独立化・契約試験 実施記録

対象: PoC 0.2.0 / ResultBundle schema 1.0。実施日: 2026-10-14〜15 JST。

今回指定された7設計資料を作業基準に採用。C01〜C08・既存32試験・科学計算・閾値・CLIを変更せず、実装と試験を追加した。Git初期化・設定・Worktree操作は行っていない。Plugin Labの将来APIは利用していない。

## 実装

唯一の既存本番コード変更は `nv_runner/signals.py`。`select_mask` の本体を新規 `nv_runner/selection.py` へ移し、signals側は同じ関数を再exportする。routes側の既存importは変更不要。依存はNumPyのみで、データ生成・モデル・実行管理をimportしない。関数のASTは変更前と厳密一致。

requested maskの計算だけを独立化した。validとのAND、窓の支持範囲、feature生成は既存FixedWindowに残る。選択しない設定は従来のselection.enabled=falseを利用できる。任意機能を自動登録・交換する基盤への全面移行ではない。

## 契約試験の対応

`tests/contract_fixtures.py` が設計時の `docs/parallel_contracts/fixtures.json` を実体化する。NPZの実hashを計算しInputAdapterを通す。完全Bundleはacoustic quick既定設定から新規生成する。生成物は `tests/_work/Q/<uuid>/` に隔離し、巨大なgoldenや過去モデルに依存しない。

|契約|専用試験|検査内容|
|---|---|---|
|C01|test_contract_c01.py / 3件|SI・shape・rpm任意、版/単位/非有限/非共置/軸長/hash拒否、fit/cal分離、eval漏洩拒否|
|C02|test_contract_c02.py / 3件|61×65 map、支持範囲、A consumer後のmap/観測不変、Parseval、Cpu符号、ゼロ/短入力、未知規約拒否|
|C03|test_contract_c03.py / 3件|実addのID・座標・feature幅、順序/batch対応、nullと理由、非有限feature/score・未学習|
|C04|test_contract_c04.py / 2件|実IF/PCA fit、fit-only scaler、同seed、score後のモデル不変、save、件数不足/幅/未知kind拒否|
|C05|test_contract_c05.py / 3件|設計fixture6ケース、higher閾値、cal不足、時間union、2経路×3判定の9通りfusion|
|C06|test_contract_c06.py / 3件|真値なしfresh Bundle、原本を隠した別プロセスviewer、hash/member/版/staging/ID/座標/ref破損拒否|
|C07|test_contract_c07.py / 2件|import再送、原本解決/未解決、manifest不変、同run衝突/破損拒否|
|C08|test_contract_c08.py / 3件|既存5経路完走、未知設定/重複key拒否、回転欠落/空選択/イベント0/部分失敗|

計22件。C05のfusion試験は判定だけをtest doubleで注入して集約境界の全真理値を試す。モデル自体は実学習するが、その試験の判定を検出性能として扱わない。C03の不正scoreも負例専用test double。通常pipelineは全て実モデル。

既存32件が担う評価/真値変更時のモデル・閾値不変、全経路のshuffle/batch、物理式、保存配列shape、ID逆引きもそのまま回帰実行する。新規契約試験だけで既存試験を置換しない。

## 実行条件・再実行

Windows / Python 3.12.14、NumPy 2.3.5、SciPy 1.16.3、scikit-learn 1.7.2、joblib 1.6.0。依存追加なし。requirements.txtも変更なし。

PoCルートで実行する。Windowsの実際の実行器は `.venv/Scripts/python.exe`。他環境はrequirements.txtから環境を作りpythonを置換する。

```powershell
python -m unittest discover -s tests -p 'test_contract_c*.py' -v
python -m unittest discover -s tests -p test_selection.py -v
python -m unittest discover -s tests -p test_independence_tools.py -v
python -m unittest discover -s tests -v
```

contractのみでも各ファイル単独でもfixtureを再生成する。プロセス内では完全Bundle fixtureを共有し、破損試験はコピーで実施する。中断時は新プロセスで再実行する。データ・モデル再利用による途中再開はしない。生成物は削除せず残すため、必要に応じ実行IDを確認して管理する。

比較用データはacoustic quick既定: seed42、学習正常12個体、評価7個体、各2測定、4秒、1024 Hz。学習fit/cal分割、実モデル/正規化/閾値は保存experiment.jsonに従い変更していない。モデルはIF64本、DはPCA。評価ケースは正常、band、order、event、relation、mixed、disturbance。

変更前版で次を実行してbaselineを保存し、変更後版で**同じ**experiment.jsonをexecuteする。後者は同じ入力ファイルを使うためsource/metadataに由来するIDも比較できる。

```powershell
python -m nv_runner demo --generator acoustic --profile quick --output reports/independence/baseline
python -m nv_runner execute --config reports/independence/baseline/experiment.json
python tools/compare_extraction.py --before <変更前Bundle> --after <変更後Bundle> --output reports/independence/comparison.json
```

baseline出力先は未存在が必要。再試験には別名を選び、その設定を両版で共用する。別環境へこの文書だけ移して過去との比較ができるわけではない。前版ソースがない場合は現版の再現性検査であり、今回の前後比較の再実施とは区別する。

比較は全9tableの値（ID/座標/状態/理由含む）、設定・分割・metrics・truthの値、モデル/閾値/全NPZのバイト一致。除外はrun_id、実行時間、時刻、environmentのコードhashおよびmanifestの実行由来の差。両Bundle自体はReaderで検証し、比較除外情報も保存する。異OS間のjoblibバイト一致は一般保証しない。

## 実測結果

全59試験が成功し、今回の実装・統合検証は完了した。失敗中・再開待ちの作業はない。下記の未実施事項は今回の完成条件外であり、自動継続で追加実装しない。

|検証|結果・証拠|
|---|---|
|変更前既存32件|32成功、43.720秒。reports/independence/before.log|
|切出し前追加C01〜08|22成功、119.977秒。reports/independence/contracts_before.log|
|切出し後全試験|59成功、162.267秒。既存32＋契約22＋selection3＋所有範囲2。reports/independence/after_all.log|
|CLI変更前後比較|成功。9,243入力、35個体×経路行。reports/independence/comparison.json|
|既存コードの差分範囲|既存pyはsignals.pyだけ。切出し関数AST同一。source_audit.json|
|既存32試験・設計資料|protected_before/after.jsonのSHA256比較で全て不変|

変更前run: `run_8643eddbc58642df9dfbc8e4d2f76428`。変更後run: `run_94df5597c63d49669d76c9bddcd728dc`。Bundleは `reports/independence/baseline/runs/`、変更前HTMLは同baseline/viewer.html。各runのenvironment.jsonにソースhash、manifest.jsonに完全性情報を保存。

## 独立開発領域・変更ファイル一覧

|区分|ファイル|
|---|---|
|既存変更|nv_runner/signals.pyのみ|
|新本番module|nv_runner/selection.py|
|契約fixture/test|tests/contract_fixtures.py、tests/test_contract_c01.py〜test_contract_c08.py|
|独立化/領域試験|tests/test_selection.py、tests/test_independence_tools.py|
|実行補助|tools/compare_extraction.py、tools/check_workstream_scope.py|
|所有範囲|development/ownership.json、development/README.md、configs/parallel/.gitkeep|
|担当別開始指示|docs/workstreams/{input,physics,route_a,route_b,route_c,route_d,model,viewer,output}.md|
|結果報告|docs/validation/independence_implementation.md（本書）|
|生成証拠|reports/independence/*、tests/_work/*。demoによるreports/latest_acoustic_quick.jsonも更新|

所有表はAGENT_TASKSの専用パスを具体化した。RAにselection.pyとtest_selection.pyを追加。共有本番ファイルはIのみ。QがC01〜08専用試験、各機能担当がcandidateと専用testを編集する。candidateは予約パスであり、空の実装を本番登録していない。I/Qの編集範囲もJSONに列挙し、担当横断の重複・共有ファイル越境・パス逸脱をtest_independence_toolsで検査する。OSによる強制隔離ではない。

## 切戻し

ローカル証拠 `reports/independence/signals_before.py` を `nv_runner/signals.py` に復元すれば既存経路は元の関数を利用する。selection.pyを残しても既存経路には影響しない。契約試験はそのまま利用できる。独立moduleへの配線自体を検査するtest_selectionのimport同一性試験は切戻し後に失敗するのが正しいため、旧版回帰は元の32試験を個別指定して実行する。復元後に追加のsignals変更がある場合はファイル全体を上書きせず、importと関数の移動部分だけ戻す。

## 残る制約・未実施

- 全面plugin化、Descriptor/Planner/Validator基盤、別エージェントによる同時実装、Git/Worktree分離は未実施。専用moduleの直接試験は今から着手可能。既存REGISTRY・validator・保存説明への接続だけIへ提出する。
- Record/mapはmutableである。CT02は今回のconsumerの非破壊性を監視するが、将来全consumerの変更を禁止するランタイム機構はない。SignalServiceはID-only cacheなので同ID別データの再利用は禁止、検出機構追加は別CR。
- NormalModelは数値行列だけを受けるため、同じ幅の列の意味・並び替えは検出できない。幅不正は拒否試験済み。feature_schemaの意味検査や一般的なPreparedSet validatorは未追加。現行readerが全不正座標意味を検出するとは主張しない。
- shared前処理、plugin constructor、truth読込、finalizeの例外は現行の経路内部分失敗保証の外。契約を拡大せず、既存の経路try内失敗を検証した。
- 任意診断artifactを省略した新規Bundleでのviewer互換は今回未追加。原本欠落とtruthなしは実行済み。全C02キーの物理的妥当性を新規3試験だけで網羅するものではなく既存15物理/音響試験と併用する。
- 実測データ・外部システム実接続・異OS移送試験は未実施。検出率改善や100%検出を今回の合格条件にしていない。
- 契約変更が必要な追加作業は既存INTEGRATION.mdのCRに分離し、境界変更だけを保留する。今回は契約変更なしで完了できる範囲を実装した。
