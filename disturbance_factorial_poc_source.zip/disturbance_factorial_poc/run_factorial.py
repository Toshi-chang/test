"""Paired target anomaly x disturbance study, no tuning of engine or model."""
import bootstrap_lab
from bootstrap_lab import ROOT,BASELINE,verify_baseline
from pathlib import Path
import argparse,copy,subprocess,sys,time,traceback
import numpy as np
from bridge.adapter import read,write,sha
from bridge.dataset import generate
from nv_runner.runner import ExperimentRunner,validate_config
from nv_runner.bundle import BundleReader
from diagnose import diagnose

ANOMALIES=['band','order','event','relation','mixed']
def variant_config(base,disturbed):
    cfg=copy.deepcopy(base)
    if disturbed:
        for kind in ANOMALIES:cfg['additions'][kind]+=copy.deepcopy(base['additions']['disturbance'])
    return cfg

def repair_truth(data,disturbed):
    # Original generator labels all additional sources by target scenario; explicitly separate nuisance truth.
    truth=read(data/'truth.json')
    for case in truth['cases']:
        target=case['scenario'];case['factor_target']=target if target in ANOMALIES else 'normal'
        case['factor_disturbance']=target=='disturbance' or disturbed and target in ANOMALIES
        for region in case['regions']:
            if region.get('source_id')=='external_extra':region.update(role='disturbance',kind='disturbance')
        if disturbed and target in ANOMALIES:case['scenario']=target+'_with_disturbance'
    write(data/'truth.json',truth)

def execute_one(base,branch,out):
    folder=out/branch;folder.mkdir();disturbed=branch=='disturbed'
    cfg=variant_config(base,disturbed);write(folder/'generation_settings.json',cfg)
    data=generate(folder/'generation_settings.json',folder/'dataset');repair_truth(data,disturbed)
    experiment=read(BASELINE/'configs/experiment.json')
    for key,name in [('train_manifest','train_manifest.json'),('eval_manifest','eval_manifest.json'),('truth_path','truth.json')]:experiment[key]=str(data/name)
    experiment['export']['output_dir']=str(folder/'runs');write(folder/'experiment.json',experiment)
    _,_,_,fit,cal,split=validate_config(folder/'experiment.json')
    if not fit or not cal:raise AssertionError('no fit/calibration')
    bundle=ExperimentRunner().execute(folder/'experiment.json');reader=BundleReader(bundle).validate()
    if reader.manifest['bundle_status']!='complete':raise AssertionError('partial experiment')
    for route in reader.manifest['completed_routes']:
        if read(bundle/'models'/f'{route}_threshold.json')['value'] is None:raise AssertionError('missing threshold')
    p=subprocess.run([sys.executable,'-B','-m','nv_runner','view','--bundle',str(bundle),'--output',str(folder/'viewer.html')],
                     cwd=BASELINE/'runtime',capture_output=True,text=True,encoding='utf-8',errors='replace')
    (folder/'viewer.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
    if p.returncode:raise RuntimeError('viewer failed')
    evidence=diagnose(bundle,folder/'evidence.json')
    return {'bundle':str(bundle),'dataset':str(folder/'dataset'),'split':split,'evidence':evidence}

def check_pairing(clean,disturbed):
    a=Path(clean['dataset']);b=Path(disturbed['dataset']);files=read(a/'canonical/train_manifest.json')['measurements']
    for f in files:
        for k in ['source_path','metadata_path']:
            if sha(a/'canonical'/f[k])!=sha(b/'canonical'/f[k]):raise AssertionError('training data changed')
    for p in (Path(clean['bundle'])/'models').iterdir():
        if sha(p)!=sha(Path(disturbed['bundle'])/'models'/p.name):raise AssertionError('model/threshold changed: '+p.name)
    if clean['split']!=disturbed['split']:raise AssertionError('split changed')
    cfg=read(a/'generation.json');normal_count=len(cfg['template_scene']['sources']);verified=0;max_error=0.
    truth=read(a/'canonical/truth.json')
    normal_case_by_family={c['independent_family_id']:c['case_id'] for c in truth['cases'] if c['scenario']=='normal'}
    for c in truth['cases']:
        for mi in range(len(cfg['modes'])):
            rel=f'raw/{c["case_id"]}_m{mi}'
            with np.load(a/rel/'generator_truth.npz') as x,np.load(b/rel/'generator_truth.npz') as y:
                for key in ['source_pressure_pa','source_velocity_m_s']:
                    if not np.array_equal(x[key][:normal_count],y[key][:normal_count]):raise AssertionError('normal base changed')
                    if c['scenario'] in ANOMALIES:
                        # Target contributions are unchanged; the last source alone is nuisance.
                        if not np.array_equal(x[key],y[key][:-1]):raise AssertionError('target changed when nuisance added')
            with np.load(a/rel/'observations.npz') as x,np.load(b/rel/'observations.npz') as y:
                if c['scenario'] in ANOMALIES:
                    with np.load(b/rel/'generator_truth.npz') as z:
                        for obs,part in [('pressure_pa','source_pressure_pa'),('velocity_m_s','source_velocity_m_s')]:
                            delta=y[obs]-x[obs];expected=z[part][-1]
                            np.testing.assert_allclose(delta,expected,rtol=1e-10,atol=1e-12)
                            max_error=max(max_error,float(np.max(abs(delta-expected))))
                else:
                    np.testing.assert_array_equal(x['pressure_pa'],y['pressure_pa'])
            verified+=1
    return {'status':'passed','training_files_identical':True,'models_thresholds_identical':True,'splits_identical':True,
            'verified_eval_captures':verified,'superposition_max_absolute_error':max_error}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['quick','comparison'],default='comparison');ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
    out=args.output.resolve()
    if out.exists():raise ValueError('new output folder required')
    out.mkdir(parents=True);start=time.perf_counter();status={'status':'running','profile':args.profile}
    write(out/'status.json',status)
    try:
        base=read(BASELINE/'configs'/f'dataset_{args.profile}.json');write(out/'base_protocol.json',base)
        clean=execute_one(base,'clean',out);disturbed=execute_one(base,'disturbed',out)
        pairing=check_pairing(clean,disturbed);write(out/'pairing.json',pairing)
        from summarize import summarize
        summarize(clean['evidence'],disturbed['evidence'],out)
        verify_baseline()
        status.update(status='passed',elapsed_seconds=time.perf_counter()-start,
            clean_bundle=clean['bundle'],disturbed_bundle=disturbed['bundle'],independent_eval_families=base['eval_families'],
            scope='identical deterministic re-fit verified by hashes; no existing frozen-model inference API claimed')
    except Exception as e:
        status.update(status='failed',error=str(e));(out/'error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:write(out/'status.json',status)
    print(status)
if __name__=='__main__':main()
