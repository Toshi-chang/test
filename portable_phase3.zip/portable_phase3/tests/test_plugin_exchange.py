"""Phase 3: settings-only exchange and independently registered route execution."""
import copy
from dataclasses import replace
import json
from pathlib import Path
import subprocess
import sys
import unittest
import uuid

import numpy as np

from nv_runner.acoustic_generator import acoustic_settings, generate_acoustic
from nv_runner.bundle import BundleReader
from nv_runner.common import read_json, sha, write_json
from nv_runner.input_adapter import InputAdapter
from nv_runner.plugin_catalog import DEFAULT_REGISTRY
from nv_runner.plugin_descriptor import PluginDescriptor
from nv_runner.profiles import acoustic_experiment
from nv_runner.runner import ExperimentRunner, validate_config
from nv_runner.signals import SignalService


def descriptor(plugin_id="phase3_extension"):
    return PluginDescriptor(
        plugin_id=plugin_id, implementation_version="0.1.0",
        factory="phase3_fixture_plugin:ExtensionWindow",
        config_schema={"type": "object", "required": ["window_seconds", "hop_seconds", "template_tag"],
                       "properties": {"window_seconds": {"type": "number", "exclusiveMinimum": 0},
                                      "hop_seconds": {"type": "number", "exclusiveMinimum": 0},
                                      "template_tag": {"type": "string", "enum": ["extension_v1"]}},
                       "additionalProperties": True})


class PluginExchange(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parent / "_work" / "P3T" / uuid.uuid4().hex
        cls.root.mkdir(parents=True)
        options = acoustic_settings("quick")
        options.update(train_specimens=6, duration_seconds=3)
        generate_acoustic(cls.root / "data", options)
        cls.config = acoustic_experiment("data", "runs")
        for route in cls.config["routes"]:
            if route["model"]["kind"] == "isolation_forest":
                route["model"]["n_estimators"] = 16
        cls.records = InputAdapter().load(cls.root / "data" / "eval_manifest.json")

    def setUp(self):
        self.registered = []

    def tearDown(self):
        for plugin_id in self.registered:
            if plugin_id in DEFAULT_REGISTRY:
                DEFAULT_REGISTRY.unregister(plugin_id)

    def register(self, desc):
        self.registered.append(desc.plugin_id)
        DEFAULT_REGISTRY.register(desc)

    def path(self, config):
        path = self.root / (uuid.uuid4().hex + ".json")
        write_json(path, config)
        return path

    def extension_config(self, plugin_id="phase3_extension"):
        config = copy.deepcopy(self.config)
        route = copy.deepcopy(config["routes"][0])
        route.update(key="Extension", plugin=plugin_id, template_tag="extension_v1")
        config["routes"] = [route]
        return config

    def test_settings_only_exchange_preserves_coordinates_schema_and_features(self):
        configs = Path(__file__).resolve().parents[1] / "configs" / "parallel"
        old_config = read_json(configs / "plugin_exchange_legacy.json")
        new_config = read_json(configs / "plugin_exchange_candidate.json")
        old = DEFAULT_REGISTRY[old_config["plugin"]](old_config)
        new = DEFAULT_REGISTRY[new_config["plugin"]](new_config)
        self.assertEqual(old.feature_schema(), new.feature_schema())
        service = SignalService(self.config["signal"])
        left, right = old.prepare(self.records, service), new.prepare(self.records, service)
        def coordinate(row):
            return row["measurement_id"], row["start_sample"], row["end_sample"]
        old_samples = {coordinate(s): s for s in left.samples}
        new_samples = {coordinate(s): s for s in right.samples}
        self.assertEqual(old_samples.keys(), new_samples.keys())
        self.assertTrue(old_samples)
        for coord, sample in old_samples.items():
            other = new_samples[coord]
            self.assertNotEqual(sample["sample_id"], other["sample_id"])
            for field in ("frequency_hz", "support_start_sample", "support_end_sample",
                          "display_center_seconds", "status", "reason", "specimen_id", "case_id"):
                self.assertEqual(sample[field], other[field])
            np.testing.assert_allclose(left.values[sample["sample_id"]], right.values[other["sample_id"]],
                                       rtol=1e-12, atol=1e-12)

    def test_registration_only_extension_runs_real_fit_cal_eval_without_central_edits(self):
        package = Path(__file__).resolve().parents[1] / "nv_runner"
        names = ("runner.py", "routes.py", "plugin_registry.py", "plugin_validation.py")
        before = {name: sha(package / name) for name in names}
        self.register(descriptor())
        path = self.path(self.extension_config())
        config, train, evaluation, fit, calibration, split = validate_config(path)
        self.assertTrue(fit and calibration and evaluation)
        self.assertFalse(set(split["fit"]) & set(split["evaluation"]))
        bundle = BundleReader(ExperimentRunner().execute(path)).validate()
        self.assertEqual(bundle.manifest["schema_version"], "1.0")
        self.assertEqual(bundle.manifest["completed_routes"], ["Extension"])
        results = bundle.tables["sample_results"]
        self.assertEqual({r["split"] for r in results}, {"fit", "calibration", "evaluation"})
        self.assertTrue(all(r["status"] == "scored" and np.isfinite(r["anomaly_score"]) for r in results))
        self.assertTrue((bundle.path / "models" / "Extension.joblib").is_file())
        self.assertEqual(before, {name: sha(package / name) for name in names})
        write_json(self.root / "central_unchanged_evidence.json", {
            "central_sha256_before_after": before, "bundle": str(bundle.path),
            "sample_results": len(results), "schema_version": "1.0"})

    def test_extension_owned_schema_rejects_before_any_run_directory(self):
        self.register(descriptor())
        for value in (None, 1, "unknown"):
            config = self.extension_config()
            config["routes"][0]["template_tag"] = value
            config["export"]["output_dir"] = uuid.uuid4().hex + "_must_not_exist"
            with self.subTest(value=value), self.assertRaises(ValueError):
                ExperimentRunner().execute(self.path(config))
            self.assertFalse((self.root / config["export"]["output_dir"]).exists())

    def test_bad_versions_and_contracts_rejected_before_execution(self):
        variants = ({"api_version": "99.0"}, {"descriptor_version": "99.0"},
                    {"input_contracts": {"C01": "99.0", "C02": "1.0"}},
                    {"output_contracts": {"C03": "1.0", "C05": "99.0"}},
                    {"model_contract": "C04@99.0"})
        for index, mutation in enumerate(variants):
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                candidate = replace(descriptor("phase3_bad_" + str(index)), **mutation)
                self.register(candidate)
                validate_config(self.path(self.extension_config(candidate.plugin_id)))

    def test_selected_unavailable_factory_rejected_before_output(self):
        desc = replace(descriptor("phase3_missing"), factory="phase3_intentionally_missing:Factory")
        self.register(desc)
        config = self.extension_config(desc.plugin_id)
        config["export"]["output_dir"] = uuid.uuid4().hex + "_must_not_exist"
        with self.assertRaises((ValueError, ImportError)):
            ExperimentRunner().execute(self.path(config))
        self.assertFalse((self.root / config["export"]["output_dir"]).exists())

    def test_removed_registration_does_not_affect_independent_existing_routes(self):
        self.register(descriptor())
        DEFAULT_REGISTRY.unregister("phase3_extension")
        self.assertNotIn("phase3_extension", DEFAULT_REGISTRY)
        validate_config(self.path(self.config))
        with self.assertRaises(ValueError):
            validate_config(self.path(self.extension_config()))

    def test_unselected_and_disabled_missing_plugin_remain_unimported_in_fresh_process(self):
        config = copy.deepcopy(self.config)
        disabled = copy.deepcopy(config["routes"][0])
        disabled.update(key="Disabled", plugin="phase3_unavailable", enabled=False)
        config["routes"].append(disabled)
        script = '''
import importlib.abc, json, sys
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in ('phase3_intentionally_missing', 'nv_runner.route_a_candidate'):
            raise AssertionError('unselected module was loaded: '+fullname)
sys.meta_path.insert(0, Block())
from nv_runner.plugin_descriptor import PluginDescriptor
from nv_runner.plugin_catalog import DEFAULT_REGISTRY
DEFAULT_REGISTRY.register(PluginDescriptor(plugin_id='phase3_unavailable', implementation_version='0.1.0', factory='phase3_intentionally_missing:Factory', config_schema={'type':'object'}))
from nv_runner.runner import ExperimentRunner
from nv_runner.bundle import BundleReader
b = BundleReader(ExperimentRunner().execute(sys.argv[1])).validate()
assert len(b.manifest['completed_routes']) == 5
assert 'Disabled' not in b.manifest['requested_routes']
assert not any(s['route_key']=='Disabled' for s in b.tables['samples'])
assert 'nv_runner.route_a_candidate' not in sys.modules
print(json.dumps({'bundle':str(b.path),'completed_routes':b.manifest['completed_routes']}))
'''
        result = subprocess.run([sys.executable, "-c", script, str(self.path(config))],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        evidence = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(len(evidence["completed_routes"]), 5)


if __name__ == "__main__":
    unittest.main()
