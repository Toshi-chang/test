// Optional browser QA: npm install playwright, then npx playwright install chromium.
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
(async () => {
  const browser = await chromium.launch({headless: true, ...(process.env.BROWSER_CHANNEL ? {channel: process.env.BROWSER_CHANNEL} : {})});
  const page = await browser.newPage({viewport: {width: 1440, height: 1100}});
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(pathToFileURL(path.resolve(process.argv[2] || 'reports/quick.html')).href);
  await page.waitForSelector('#cases tr');
  const cases = await page.locator('#cases tr').count();
  const checks = [];
  const outputPrefix = process.argv[3] || 'reports/viewer';
  for (const route of ['A_full', 'A_selected', 'B_order', 'C_event', 'D_patch']) {
    await page.locator('#cases tr').filter({has: page.getByText(route, {exact: true})}).first().click();
    const count = await page.locator('#sample option').count();
    if (!count) throw new Error(route + ' has no sample options');
    await page.locator('#sample').selectOption(String(count - 1));
    const evidence = JSON.parse(await page.locator('#evidence').textContent());
    if (evidence.sample.route_key !== route || evidence.sample.end_sample <= evidence.sample.start_sample)
      throw new Error('invalid drilldown ' + route);
    await page.locator('#timeline').click({position: {x: 200, y: 100}});
    await page.locator('#truthToggle').uncheck();
    await page.locator('#truthToggle').check();
    checks.push({route, options: count, drilldown: 'passed', timeline_click: 'passed', truth_toggle: 'passed'});
  }
  await page.locator('#cases tr').filter({has: page.getByText('A_selected', {exact: true})}).first().click();
  const physicalChecks = [];
  if (await page.locator('#puPanel').isVisible().catch(()=>false)) {
    for (const metric of ['z_abs','phase','msc','active','reactive']) {
      await page.locator('#puMetric').selectOption(metric);
      physicalChecks.push({metric,status:'passed'});
    }
    const sources = await page.locator('#puSource option').count();
    if (sources) {
      await page.locator('#puSource').selectOption(String(sources-1));
      const info = JSON.parse(await page.locator('#physicalInfo').textContent());
      if (!info.source || info.measured_contract.version !== '1.0') throw new Error('Missing physical contract/source');
      await page.locator('#truthToggle').uncheck();
      const hidden = JSON.parse(await page.locator('#physicalInfo').textContent());
      if (hidden.source) throw new Error('Source theory still exposed after truth off');
      await page.locator('#truthToggle').check();
      await page.locator('#puMetric').selectOption('phase');
    }
  }
  await page.screenshot({path: outputPrefix+'.png', fullPage: true});
  if (errors.length) throw new Error(errors.join('\n'));
  const result = {status: 'passed', case_route_rows: cases, browser_errors: errors, checks,physicalChecks};
  fs.writeFileSync(outputPrefix+'_test.json', JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
  await browser.close();
})().catch(error => { console.error(error); process.exitCode = 1; });
