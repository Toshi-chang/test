import copy,unittest
import numpy as np
from da_engine.geometry import quadrature
from da_engine.engine import validate_scene,source_transfer,response,synthesize
from make_examples import examples,source,base

class Geometry(unittest.TestCase):
    def test_01_measures(self):
        expected={'point':1,'rectangle':.12*.08,'disk':np.pi*.06**2,
            'box_surface':2*(.12*.08+.08*.06+.12*.06),'box_volume':.12*.08*.06,
            'sphere_surface':4*np.pi*.06**2,'sphere_volume':4*np.pi*.06**3/3,
            'cylinder_surface':2*np.pi*.04*.10+2*np.pi*.04**2,'cylinder_volume':np.pi*.04**2*.10}
        for name,value in expected.items():
            with self.subTest(name=name):
                q=quadrature(examples()[name]['sources'][0]['geometry'])
                self.assertAlmostEqual(q['weights'].sum(),value,places=12)
                self.assertTrue(np.all(q['weights']>0))

    def test_02_invalid_geometry(self):
        for g in [{'kind':'mesh'},{'kind':'disk','radius_m':-1},{'kind':'point','resolution':0},
                  {'kind':'point','rotation':[[2,0,0],[0,1,0],[0,0,1]]}]:
            with self.subTest(g=g),self.assertRaises(ValueError):quadrature(g)

class Physics(unittest.TestCase):
    def test_03_point_closed_form(self):
        s=examples()['point']; f=np.array([0,20,200,800]);p,u=response(s,f)
        r=.2; w=2*np.pi*f;k=w/343; q=1e-5
        ep=1j*w*1.2*q*np.exp(-1j*k*r)/(4*np.pi*r)
        eu=q*(1+1j*k*r)*np.exp(-1j*k*r)/(4*np.pi*r*r);eu[0]=0
        np.testing.assert_allclose(p[:,0],ep,rtol=1e-13,atol=1e-16)
        np.testing.assert_allclose(u[:,0,2],eu,rtol=1e-13,atol=1e-16)
        np.testing.assert_allclose(u[:,0,:2],0,atol=1e-16)

    def test_04_point_limit(self):
        point=examples()['point']; tiny=copy.deepcopy(point)
        tiny['sources'][0]['geometry']={'kind':'rectangle','size_m':[1e-6,1e-6],'resolution':4}
        p,u=response(point,[100,500]); pp,uu=response(tiny,[100,500])
        np.testing.assert_allclose(pp,p,rtol=1e-8,atol=1e-15)
        np.testing.assert_allclose(uu,u,rtol=1e-8,atol=1e-15)

    def test_05_symmetry_and_rotation(self):
        s=examples()['box_surface']; p,u=response(s,[100,400])
        np.testing.assert_allclose(u[:,0,:2],0,atol=1e-17)
        rot=np.array([[0,0,1],[0,1,0],[-1,0,0]])
        moved=copy.deepcopy(s);moved['sources'][0]['geometry']['rotation']=rot.tolist()
        for r in moved['receivers']:
            r['position_m']=(rot@r['position_m']).tolist();r['axis']=(rot@r['axis']).tolist()
        pp,uu=response(moved,[100,400])
        np.testing.assert_allclose(pp,p,rtol=1e-12,atol=1e-15)
        np.testing.assert_allclose(uu,u@rot.T,rtol=1e-12,atol=1e-15)

    def test_06_euler_gradient(self):
        s=examples()['box_surface_localized']; s['receivers']=s['receivers'][1:2]
        f=np.array([70.,300.]); _,u=response(s,f);grad=[];h=1e-6
        for ax in range(3):
            a,b=copy.deepcopy(s),copy.deepcopy(s)
            a['receivers'][0]['position_m'][ax]+=h;b['receivers'][0]['position_m'][ax]-=h
            grad.append((response(a,f)[0]-response(b,f)[0])/(2*h))
        calc=-np.stack(grad,axis=-1)/(1j*2*np.pi*f[:,None,None]*1.2)
        np.testing.assert_allclose(calc,u,rtol=2e-7,atol=1e-12)

    def test_07_baffled_disk_existing_piston_formula(self):
        s=examples()['baffled_disk'];s['receivers']=s['receivers'][:1]
        s['sources'][0]['geometry']['resolution']=12
        f=np.array([20,200,800.]);p,u=response(s,f)
        r=.2;a=.06;k=2*np.pi*f/343;R=np.hypot(r,a);v=.001
        # Same analytical on-axis piston equations as frozen NV baseline, independently evaluated.
        ep=1.2*343*v*(np.exp(-1j*k*r)-np.exp(-1j*k*R))
        eu=v*(np.exp(-1j*k*r)-r/R*np.exp(-1j*k*R))
        np.testing.assert_allclose(p[:,0],ep,rtol=1e-10,atol=1e-13)
        np.testing.assert_allclose(u[:,0,2],eu,rtol=1e-10,atol=1e-13)

    def test_08_baffle_boundary_tangent_velocity(self):
        s=examples()['baffled_disk'];s['receivers']=[{'id':'near_plane','position_m':[.2,0,2e-6],'axis':[0,0,1]}]
        _,u=response(s,[200]);self.assertLess(abs(u[0,0,2]),abs(u[0,0,0])*2e-5)

    def test_09_mesh_convergence(self):
        vals=[]
        for n in [2,4,8,16,32]:
            s=examples()['rectangle'];s['sources'][0]['geometry']['resolution']=n
            vals.append(response(s,[800])[0])
        errors=[np.linalg.norm(x-vals[-1]) for x in vals[:-1]]
        self.assertTrue(all(a>b for a,b in zip(errors,errors[1:])))
        self.assertLess(errors[-1]/np.linalg.norm(vals[-1]),.002)

    def test_10_phase_cancellation(self):
        s=examples()['rectangle'];s['receivers']=s['receivers'][:1]
        p,_=response(s,[200]);s['sources'][0]['phase']={'opposite_halves_axis':0}
        pp,u=response(s,[200]);self.assertLess(abs(pp[0,0]),abs(p[0,0])*1e-12)
        # Pressure cancellation need not cancel every vector velocity component.
        self.assertGreater(abs(u[0,0,0]),0)

    def test_11_domain_and_units_rejected(self):
        mutations=[('version',lambda s:s.update(schema_version='2')),
            ('propagation',lambda s:s.update(propagation='solid_enclosure')),
            ('unit',lambda s:s['sources'][0].update(drive_unit='Pa')),
            ('inside',lambda s:s['receivers'][0].update(position_m=[0,0,0])),
            ('axis',lambda s:s['receivers'][0].update(axis=[0,0,2]))]
        for name,fn in mutations:
            s=examples()['box_volume'];fn(s)
            with self.subTest(name=name),self.assertRaises(ValueError):validate_scene(s)
        s=examples()['baffled_disk'];s['receivers'][0]['position_m'][2]=-.2
        with self.assertRaises(ValueError):validate_scene(s)
        s=examples()['baffled_disk'];s['sources'].append(examples()['point']['sources'][0])
        s['sources'][1]['id']='other'
        with self.assertRaises(ValueError):validate_scene(s)

    def test_12_shared_plane(self):
        s=examples()['baffled_disk'];second=copy.deepcopy(s['sources'][0]);second['id']='patch2'
        second['geometry']['center_m']=[.15,0,.01];s['sources'].append(second)
        with self.assertRaises(ValueError):validate_scene(s)

    def test_13_density_vs_total_strength(self):
        s=examples()['rectangle'];a=copy.deepcopy(s)
        a['sources'][0].update(strength_mode='surface_density',drive_unit='m/s',drive_rms=1e-5/(.12*.08))
        np.testing.assert_allclose(response(s,[100])[0],response(a,[100])[0],rtol=1e-13)

    def test_14_superposition_projection_and_seed(self):
        s=examples()['internal_components'];s['simulation'].update(sample_rate_hz=1024)
        result=synthesize(s);repeat=synthesize(s)
        np.testing.assert_array_equal(result['pressure_pa'],repeat['pressure_pa'])
        np.testing.assert_allclose(result['pressure_pa'],result['source_pressure_pa'].sum(axis=0),atol=1e-12)
        np.testing.assert_allclose(result['velocity_m_s'],result['source_velocity_m_s'].sum(axis=0),atol=1e-12)
        np.testing.assert_allclose(result['axial_velocity_m_s'][:,0],result['velocity_m_s'][:,0,2],atol=1e-15)
        other=copy.deepcopy(s);other['simulation']['seed']=43
        changed=synthesize(other)
        self.assertFalse(np.allclose(result['source_pressure_pa'][1],changed['source_pressure_pa'][1]))
        np.testing.assert_allclose(result['source_pressure_pa'][0],changed['source_pressure_pa'][0],atol=1e-14)

    def test_15_time_frequency_intensity(self):
        s=examples()['point'];r=synthesize(s);p=r['pressure_pa'][:,0];u=r['axial_velocity_m_s'][:,0];n=len(p)
        cross=np.fft.rfft(p)*np.conj(np.fft.rfft(u));weights=np.full(len(cross),2.);weights[0]=weights[-1]=1
        self.assertAlmostEqual(np.mean(p*u),np.sum(weights*cross.real)/n**2,places=15)

    def test_16_spherical_distribution_analytic(self):
        f=np.array([100.,800.]);point=examples()['point'];p,u=response(point,f)
        ka=2*np.pi*f/343*.06
        for kind,factor in [('sphere_surface',np.sin(ka)/ka),('sphere_volume',3*(np.sin(ka)-ka*np.cos(ka))/ka**3)]:
            s=examples()[kind];s['sources'][0]['geometry']['resolution']=12
            pp,uu=response(s,f)
            np.testing.assert_allclose(pp,p*factor[:,None],rtol=1e-9,atol=1e-14)
            np.testing.assert_allclose(uu,u*factor[:,None,None],rtol=1e-8,atol=1e-14)

    def test_17_noise_groups(self):
        s=examples()['point'];s['sources'][0]['excitation']={'kind':'noise','band_hz':[100,400],'seed_key':10}
        second=copy.deepcopy(s['sources'][0]);second['id']='second';s['sources'].append(second)
        equal=synthesize(s)['source_drives'];np.testing.assert_array_equal(equal[0],equal[1])
        s['sources'][1]['excitation']['seed_key']=11
        independent=synthesize(s)['source_drives']
        self.assertFalse(np.array_equal(independent[0],independent[1]))

    def test_18_guard_tone_convergence(self):
        s=examples()['rectangle'];a=synthesize(s)
        s['simulation']['guard_seconds']=.5;b=synthesize(s)
        np.testing.assert_allclose(a['pressure_pa'],b['pressure_pa'],rtol=1e-9,atol=1e-12)
        np.testing.assert_allclose(a['velocity_m_s'],b['velocity_m_s'],rtol=1e-9,atol=1e-12)

if __name__=='__main__':unittest.main()
