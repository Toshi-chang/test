import unittest
import numpy as np
from contract_fixtures import SPEC, directory
from nv_runner.models import NormalModel
from nv_runner.common import sha

class C04(unittest.TestCase):
    def test_real_models_fit_only_and_save_compatibility(self):
        f=SPEC['feature_rows']; x=np.array(f['fit']); ev=np.array(f['evaluation'])
        for cfg in f['models']:
            with self.subTest(kind=cfg['kind']):
                model=NormalModel().fit(x,cfg,f['seed']); path=directory()/'model.joblib'
                model.save(path); digest=sha(path)
                np.testing.assert_allclose(model.scaler.mean_,x.mean(axis=0))
                scores=model.score(ev)
                self.assertEqual(scores.shape,(2,)); self.assertTrue(np.isfinite(scores).all())
                np.testing.assert_allclose(scores,NormalModel().fit(x,cfg,f['seed']).score(ev),rtol=1e-12,atol=1e-12)
                model.score(ev*100); model.save(path); self.assertEqual(digest,sha(path))

    def test_insufficient_and_wrong_width_rejected(self):
        f=SPEC['feature_rows']; x=np.array(f['fit'])
        for cfg in f['models']:
            with self.assertRaisesRegex(ValueError,'^insufficient_training_samples$'):
                NormalModel().fit(x[:1],cfg,42)
            model=NormalModel().fit(x,cfg,42)
            with self.assertRaises(ValueError): model.score(np.zeros((2,4)))
        with self.assertRaises(ValueError): NormalModel().fit(x,{'kind':'unknown'},42)
