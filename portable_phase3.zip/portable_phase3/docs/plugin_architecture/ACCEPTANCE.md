# 交換可能性の受入試験案

すべて**計画・未実行**。設計資料のJSON構造確認を、plugin実行試験の合格と混同しない。既存PoCの32試験は維持し、この試験群は別package/別testsで実施する。

## fixtureとoracle

- W1：float64波形[0,3,0,−3] Pa、fs1024 Hz、measurement_id=lab_m1、frame=measurement_sample_index、source_sample_count4、範囲[0,4)。RMS=√4.5、crest=√2。seed不要。
- W0：同座標で全0。A/BはRMS0を成功として返す。Cはrms_below_floorでskipped、output null。
- W2：float64[1,−1,1,−1] Pa。同じ単位・座標型でRMS1/crest1。W1とは別measurement_idにする。
- 数値同等性はA/B間および解析値でrtol=atol=1e−12、契約ID/版/単位/座標/状態は厳密一致。数値0/単位なし/座標省略を暗黙補正しない。
- examples.jsonはJSON表現。fixture loaderで一度だけndarrayへ構築。wrong dtype試験ではint64/objectのままvalidatorへ渡す。成功出力を固定値にするstubは禁止。negative試験だけ壊れた返値・例外を出すtest doubleを明示して使う。

## 受入試験一覧

|ID|問い・操作|期待結果/変更禁止範囲|段階・証拠|
|---|---|---|---|
|PT01|catalog=A、rms_main=AでW1実行|RMS√4.5、succeeded/completed、型/単位/座標が適合|初期基準。descriptor/plan/resultを保存|
|PT02 Task C-1|同nodeをA→Bへ選択変更|数値/出力契約同等。engine/validator/planner/contract定義/A/Cのhash不変|変更はcompositionとBの導入だけ。A/B oracle比較|
|PT03 Task C-2|初期catalog=A,BからC実装/descriptorを追加、CをAへbinding|crest√2。A/Bとengine/validator/planner/契約定義のhash不変|catalog/composition追加は許可。初期3契約を事前freeze|
|PT04|Cの上流を同じnode_idのB実装へ交換|Cのコード/descriptor/binding不変で同じ結果|A/Bの具体名への依存を検出|
|PT05 Task C-3|A,B,Cを選択、Cをdisabled|A/Bは動きCはdisabled/output null。C.run/factory呼出し0|call counterとresultの保存|
|PT06 Task C-3|Cと上流Aをdisabled、Bだけ有効。A/Cをcatalogからも除去|BがW1で完走。無効nodeの未登録pluginを理由に全体拒否しない|他nodeがA/Cを参照していないこと。B/engine hash不変|
|PT07 Task C-4|Cはenabled、rms bindingが欠落nodeまたはdisabled Aを指す|DEPENDENCY_UNAVAILABLE、plan拒否、全plugin run/factory呼出し0|欠落と無効化の2ケース|
|PT08|Aをcatalogから削除、Aのenabled nodeを残す|PLUGIN_NOT_FOUND、実行0、代替Bへ自動変更しない|実装削除とnode削除を区別|
|PT09|必須input port欠落/余分binding/存在しないexternal|MISSING_BINDINGまたはCONTRACT_MISMATCH等の事前診断、実行0|各エラーのnode/portが特定可能|
|PT10|同じcontractのtest-only identity descriptor2nodeで循環binding|DEPENDENCY_CYCLE、実行0|type mismatchが先に発生しないcycle専用fixtureを使用|
|PT11 Task C-5|W1のdtypeをint64/object、rankを2D、NaN/Infに変更|INPUT_CONTRACT_MISMATCH、実行0。coercionで通さない|各変異を別ケースで保存|
|PT12 Task C-5|W1のunit=kPa、quantity別値、axes=[time]へ変更|INPUT_CONTRACT_MISMATCH、実行0|単位換算やaxis名の推測をしない|
|PT13 Task C-5|負start、end超過、長さ不一致、fs≤0、frame別名、bool index|INPUT_CONTRACT_MISMATCH、実行0|半開範囲と型の負例|
|PT14 Task C-5|API2.0、descriptor2.0、contract2.0、存在しない実装pin|版別にVERSION_UNSUPPORTED/PLUGIN_NOT_FOUND、実行0|impl版は正確pin。minorの暗黙互換なし|
|PT15|Cのrms bindingにCrestFactor型nodeを接続|CONTRACT_MISMATCH、実行0|型ID/版をport接続時検査|
|PT16|Cへ異なるmeasurement/区間/fsのRMS Datumを外部入力として接続|INPUT_CONTRACT_MISMATCH。外部値ならpreflight、上流値ならC実行直前に拒否|宣言型一致だけでは同じ計測区間と保証できない|
|PT17|壊れたtest doubleが単位違い/型違い/座標違いの出力を返す|producer failed/OUTPUT_CONTRACT_MISMATCH、C skipped/UPSTREAM_UNAVAILABLE、独立B succeeded|不正な実出力の拒否は実行後であることを明示|
|PT18|producerが例外を投げる|failed/PLUGIN_FAILED、依存nodeはskipped、独立node継続、LabRunReport partial|既存Bundleのfailed enumと混ぜない|
|PT19|W0、またはmin_samplesをN超過に設定|min_samples不足はskipped。W0 RMS0成功/Cはskipped、output null|skipを0結果や成功へ変えない|
|PT20|min_samples=true/1/未知config key、C min_rms_pa<0|CONFIG_INVALID、実行0。disabled nodeのconfigは実行検査しない|bool/int混同、未知fieldの無視を防止|
|PT21|node重複/catalog key重複/全部disabled|それぞれ事前拒否。capability同一のA/B登録は許可|empty構成の完了を偽装しない|
|PT22|compositionのnode列順だけ反転|計画の実行順は同じtopological/node_id順、数値同じ|時刻/run_id/elapsedは一致対象外|
|PT23|plan後にdescriptor/catalogを変更|digest不一致で実行拒否、再計画が必要|実行中hot swapをしない|
|PT24 Task C-6|独立担当のB/Cを契約harnessへ提出|各単体適合が判定でき、engineコード編集不要。悪い実装は具体port/fieldで失敗|ソース内部の共有前提を要求しない。一次検証であり全性能保証ではない|
|PT25|plugin実行前後に外部input/configのsnapshotを比較|hash/配列内容/設定が不変|入力copy/readonlyの運用を検査。悪意sandboxとは呼ばない|
|PT26|engineに未選択pluginを登録しただけの状態|未選択factory/run呼出し0、既存結果不変|明示登録と実行選択を分離|

PT09など複数の不正を含めた場合、どの診断が先かは固定しない。単独変異で対象コードを確認する。runtimeのsame_coordinate違反はproducer不正がなければCのinput validation failedとし、C.runは呼ばない。

## 独立エージェント用契約harness案

予定コマンド（**まだ存在しない**）：

```text
python -m unittest discover -s tests -p test_plugin_a.py -v
python -m unittest discover -s tests -p test_plugin_b.py -v
python -m unittest discover -s tests -p test_plugin_c.py -v
python -m unittest discover -s tests -p test_composition_acceptance.py -v
```

cwdは将来のplugin_lab_poc。harnessの入力はdescriptor、factory、公開fixture、期待contract/semantic capabilityだけ。A/BにはW1/W2/W0と設定境界、Cには型適合RMS fixtureと区間不一致/ゼロを渡す。C担当はA/Bの実装をimportする必要がない。

一次合格：descriptor/config/Input/Output検査、known-input oracle、例外/skip、input不変、版拒否に成功。結合合格：PT01〜26でDAG実行とconsumer接続まで確認。将来の科学的同等性・実測性能は別評価。

## 互換性ゲート（既存側、別試験群）

|ID|条件|期待|
|---|---|---|
|BC01|既存0.2.0のコード/config/C01〜08 hashを実証前後比較|無変更。今回の設計段階でも照合可能|
|BC02|隔離PoCの実装後、旧PoCで32試験＋物理verify＋新規quickを実行|既存試験を削除/緩和せず成功。隔離packageの有無に依存しない|
|BC03|新規生成した旧ResultBundle1.0を隔離PoC読取adapterへ渡す|既存readerで検証、読取前後Bundleのhash不変、truthを機能入力へ渡さない|
|BC04|将来wrapperを作る際、旧configを旧CLIへそのまま渡す|既定経路が旧実装のまま。新基盤が無くても動く|
|BC05|将来新経路出力をBundleにする場合|既存BundleReader/viewer/outputが読み取れる。必須model/threshold/座標/状態の捏造なし|

BC03〜05のadapterは未実装。初回ダミーPoCの合格条件はPT群＋BC01/02まで。BC05に表現できない出力はLab形式に留め、既存schemaを変更して無理に通さない。

## 保存と再開

各ケースのdescriptor/composition/config、fixture生成条件、plan順序/digest、call counters、LabRunReportまたはPlanRejected、例外ログ、engine/plugin/validatorソースhash、依存環境を保存する。stateful modelや大容量データは本実証では生成しない。

RMS解析値などをtest oracleとして使うことと、pluginが固定値を返すことを区別する。run_idや時刻を除外した数値比較を行い、結果fixtureだけを差し替えて合格にしない。失敗後は新しいrunで同じ構成を再実行し、途中実行状態の自動再開は作らない。
