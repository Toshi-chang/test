"""Evaluate all packs with ONE existing model and its saved threshold."""
from pathlib import Path
import argparse,csv,json
import numpy as np
from threadpoolctl import threadpool_limits
from sklearn.metrics import roc_auc_score
from dataset import load_dataset
from dl import infer_windows,group_max

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',required=True)
    ap.add_argument('--suite',default='outputs/evaluation_60dB');ap.add_argument('--out',required=True)
    args=ap.parse_args();model=Path(args.model)
    with np.load(model,allow_pickle=False) as weights:
        threshold=float(weights['record_threshold']);use_rpm=bool(weights.get('rpm_conditioned',False))
    rows=[]
    for path in sorted(Path(args.suite).glob('*/dataset.npz')):
        d=load_dataset(path);scores=[]
        with threadpool_limits(limits=2):
            for start in range(0,len(d['test']),128):
                end=start+128
                scores.extend(infer_windows(model,d['test'][start:end],float(d['sampling_rate_hz']),
                    d['test_rpm'][start:end] if use_rpm and 'test_rpm' in d else None))
        ids,values=group_max(np.asarray(scores),d['test_record_ids'])
        labels=np.array([d['test_labels'][d['test_record_ids']==rid][0] for rid in ids])
        row=dict(dataset=path.parent.name,model=str(model),threshold=threshold,
                 auc_any_change=roc_auc_score(labels>0,values),
                 auc_machine_fault=roc_auc_score(labels>=2,values))
        for k in range(4):
            mask=labels==k;row[f'class{k}_flag_rate']=float((values[mask]>threshold).mean()) if mask.any() else None
        rows.append(row);print(json.dumps(row),flush=True)
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    if not rows:raise ValueError('No generated datasets found')
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)

if __name__=='__main__':main()
