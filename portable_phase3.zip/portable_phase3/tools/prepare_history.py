"""Create relocated configs and source mappings without modifying saved evidence."""
import argparse
import json
from pathlib import Path, PureWindowsPath


def prepare(archive, output):
    archive, output = Path(archive).resolve(), Path(output).resolve()
    if output.exists():
        raise ValueError("output must be a new directory")
    prepared = []
    for example in sorted((archive / "examples").iterdir()):
        if not example.is_dir():
            continue
        bundles = sorted((example / "runs").glob("run_*"))
        if len(bundles) != 1:
            raise ValueError(f"expected one preserved bundle: {example}")
        bundle = bundles[0]
        config = json.loads((example / "experiment.json").read_text(encoding="utf-8"))
        for key in ("train_manifest", "eval_manifest", "truth_path"):
            if config.get(key):
                config[key] = str((example / config[key]).resolve())
        config["export"]["output_dir"] = str(output / example.name / "runs")
        mapping = {}
        for line in (bundle / "measurements.jsonl").read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            source = row["source_path"]
            # Exact file mappings also work when moving Windows evidence to POSIX.
            local = example / "data" / PureWindowsPath(source).name
            if not local.is_file():
                raise ValueError(f"missing relocated source: {local}")
            mapping[source] = str(local)
        prepared.append((example.name, bundle, config, mapping))
    if not prepared:
        raise ValueError("no archived examples")
    output.mkdir(parents=True)
    index = []
    for name, bundle, config, mapping in prepared:
        target = output / name
        target.mkdir()
        for filename, value in (("experiment.json", config), ("path_mapping.json", mapping)):
            (target / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        index.append({"example": name, "bundle": str(bundle), "config": str(target / "experiment.json"),
                      "path_mapping": str(target / "path_mapping.json")})
    (output / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    return index


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.archive, args.output), ensure_ascii=False, indent=2))
