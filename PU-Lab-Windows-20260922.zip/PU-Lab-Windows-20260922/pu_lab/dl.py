"""Normal-only deep autoencoder; never uses test labels in model/threshold fitting."""
from pathlib import Path
import copy,csv,hashlib,json
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
from dataset import load_dataset
from physics import json_safe


def encode(model,x):
    return np.tanh(np.tanh(x@model.coefs_[0]+model.intercepts_[0])@model.coefs_[1]+model.intercepts_[1])


def group_max(scores,ids):
    groups=np.unique(ids)
    return groups,np.array([scores[ids==r].max() for r in groups])


def train_model(dataset_path,out,epochs=80,channels='pu',progress=lambda s:None,cancel=lambda:False,
                rpm_normalization='std',rpm_fixed_scale=10000.):
    if channels not in ['p','u','pu','pu_rpm']:raise ValueError('入力はp/u/pu/pu_rpmです')
    epochs=int(epochs)
    if not 1<=epochs<=500:raise ValueError('学習回数は1〜500です')
    d=load_dataset(dataset_path);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    indices={'p':[0],'u':[1],'pu':[0,1],'pu_rpm':[0,1]}[channels]
    waves=[d[s][:,indices,:].astype(np.float32) for s in ['train','validation','calibration','test']]
    mean=waves[0].mean(axis=(0,2),keepdims=True);scale=waves[0].std(axis=(0,2),keepdims=True)
    if np.any(scale<1e-15):raise ValueError('学習入力のチャンネルがゼロです。測定軸や音場設定を確認してください')
    norm=lambda a:((a-mean)/scale).reshape(len(a),-1)
    xt,xv,xc,xe=map(norm,waves)
    inputs=[xt,xv,xc,xe];rpm_mean=0.;rpm_scale=1.
    if channels=='pu_rpm':
        if 'train_rpm' not in d:raise ValueError('RPM履歴がありません。回転機械プリセットでデータを生成してください')
        if rpm_normalization not in ('std','fixed'):raise ValueError('RPM正規化はstd/fixedです')
        if not np.isfinite(rpm_fixed_scale) or rpm_fixed_scale<=0:raise ValueError('RPM固定幅は正の有限値です')
        rpm_mean=float(d['train_rpm'].mean())
        rpm_scale=max(float(d['train_rpm'].std()),1.) if rpm_normalization=='std' else float(rpm_fixed_scale)
        inputs=[np.concatenate([x,((d[split+'_rpm']-rpm_mean)/rpm_scale).astype(np.float32)],axis=1)
                for x,split in zip(inputs,['train','validation','calibration','test'])]
    it,iv,ic,ie=inputs
    model=MLPRegressor(hidden_layer_sizes=(128,16,128),activation='tanh',solver='adam',
           batch_size=min(64,len(xt)),learning_rate_init=.001,alpha=.0001,random_state=123,max_iter=1)
    history=[];best_loss=np.inf;best=None;best_epoch=0;stale=0
    with threadpool_limits(limits=2):
        for epoch in range(epochs):
            if cancel():raise InterruptedError('学習を停止しました')
            model.partial_fit(it,xt)
            tl=float(np.mean((model.predict(it)-xt)**2));vl=float(np.mean((model.predict(iv)-xv)**2))
            history.append(dict(epoch=epoch+1,train=tl,validation=vl))
            if vl<best_loss:
                best_loss=vl;best=copy.deepcopy(model);best_epoch=epoch+1;stale=0
            else:stale+=1
            if epoch==0 or (epoch+1)%5==0:progress(f'学習 {epoch+1}/{epochs}：正常検証誤差 {vl:.6g}')
            if stale>=25:progress('正常検証誤差の改善が止まったため早期終了');break
        model=best
        cal=np.mean((model.predict(ic)-xc)**2,axis=1)
        window_threshold=max(float(np.quantile(cal,.99)),1e-15)
        _,cal_max=group_max(cal,d['calibration_record_ids'])
        record_threshold=max(float(np.quantile(cal_max,.99)),1e-15)
        prediction=model.predict(ie);scores=np.mean((prediction-xe)**2,axis=1)
        ztrain,ztest=encode(model,it),encode(model,ie)
        pca=PCA(2).fit(ztrain);xy=pca.transform(ztest)
    ids,record_scores=group_max(scores,d['test_record_ids'])
    record_labels=np.array([d['test_labels'][d['test_record_ids']==r][0] for r in ids])
    flags=record_scores>record_threshold
    metrics=dict(channels=channels,best_epoch=best_epoch,epochs_run=len(history),
      architecture=[it.shape[1],128,16,128,xt.shape[1]],fs=float(d['sampling_rate_hz']),
      window_samples=d['train'].shape[-1],training_windows=len(xt),test_windows=len(xe),
      test_records=len(ids),window_threshold=window_threshold,record_threshold=record_threshold,
      record_aggregation='maximum window MSE; threshold fitted to calibration-record maxima',
      class_names=d['class_names'].tolist(),rates={},
      latent_pca_explained_variance=pca.explained_variance_ratio_.tolist())
    for k in range(len(d['class_names'])):
        m=record_labels==k
        metrics['rates'][str(k)]=dict(records=int(m.sum()),flagged=int(flags[m].sum()),
          rate=float(flags[m].mean()) if m.any() else None,
          meaning='false_positive' if k==0 else 'detection')
    if len(np.unique(record_labels>0))==2:metrics['record_roc_auc']=float(roc_auc_score(record_labels>0,record_scores))
    else:metrics['record_roc_auc']=None
    result=dict(metrics=metrics,history=history,
      records=[dict(id=int(r),label=int(l),score=float(s),ratio=float(s/record_threshold),flag=bool(s>record_threshold)) for r,l,s in zip(ids,record_labels,record_scores)],
      embedding=[dict(x=float(v[0]),y=float(v[1]),label=int(l),record_id=int(r)) for v,l,r in zip(xy,d['test_labels'],d['test_record_ids'])])
    (out/'result.json').write_text(json.dumps(json_safe(result),indent=2),encoding='utf-8')
    (out/'metrics.json').write_text(json.dumps(json_safe(metrics),indent=2),encoding='utf-8')
    with (out/'test_results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['window_id','record_id','true_label','score','window_flag','latent_PC1','latent_PC2'])
        for j in range(len(scores)):writer.writerow([j,int(d['test_record_ids'][j]),int(d['test_labels'][j]),scores[j],int(scores[j]>window_threshold),*xy[j]])
    with (out/'record_results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['record_id','true_label','max_score','ratio_to_record_threshold','flag'])
        for row in result['records']:writer.writerow([row[k] for k in ['id','label','score','ratio','flag']])
    weights={f'W{i}':w for i,w in enumerate(model.coefs_)}
    weights.update({f'b{i}':b for i,b in enumerate(model.intercepts_)})
    np.savez_compressed(out/'model_weights.npz',**weights,mean=mean,scale=scale,channel_indices=indices,
         fs=d['sampling_rate_hz'],window_samples=d['train'].shape[-1],window_threshold=window_threshold,
         record_threshold=record_threshold,pca_mean=pca.mean_,pca_components=pca.components_,
         rpm_conditioned=(channels=='pu_rpm'),rpm_mean=rpm_mean,rpm_scale=rpm_scale)
    run=dict(dataset_sha256=hashlib.sha256(Path(dataset_path).read_bytes()).hexdigest(),dataset_name=Path(dataset_path).name,dataset_path=str(Path(dataset_path).resolve()),
             model_seed=123,channels=channels,epochs_requested=epochs,score_target='normalized acoustic channels only',rpm_conditioned=(channels=='pu_rpm'),
             rpm_normalization=rpm_normalization if channels=='pu_rpm' else None,rpm_mean=rpm_mean,rpm_scale=rpm_scale)
    (out/'run_settings.json').write_text(json.dumps(run,indent=2),encoding='utf-8')
    # Stable publication image, labels are the simulation truth, not predicted classes.
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import pyplot as plt
    colors=['#2780ce','#e59927','#dd5262','#9263bd'];fig,ax=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    for k in range(len(d['class_names'])):
        m=d['test_labels']==k;ax[0].scatter(xy[m,0],xy[m,1],s=11,alpha=.65,color=colors[k],label=f'Class {k}')
        m=record_labels==k;ax[1].scatter(np.flatnonzero(m),record_scores[m]/record_threshold,s=20,color=colors[k])
    ax[0].set(xlabel='Latent PC1',ylabel='Latent PC2',title='Normal-trained representation / PCA');ax[0].legend()
    ax[1].axhline(1,color='#283244',ls='--');ax[1].set(xlabel='Independent test recording',ylabel='Max window score / record threshold',yscale='log',title='Normal / anomaly detection')
    fig.suptitle(f'PU Lab | Synthetic data | Input: {channels}')
    fig.savefig(out/'dl_result.png',dpi=150);plt.close(fig)
    progress('学習と評価が完了しました')
    return result


def infer_windows(weights_path,waves,fs,rpm=None):
    with np.load(weights_path,allow_pickle=False) as z:w={k:z[k] for k in z.files}
    if not np.isclose(fs,float(w['fs'])):raise ValueError('学習時とfsが異なります')
    waves=np.asarray(waves)
    if waves.ndim!=3 or waves.shape[1:]!=(2,int(w['window_samples'])):raise ValueError('窓データの形状が異なります')
    if not np.isfinite(waves).all():raise ValueError('非有限の入力です')
    x=((waves[:,w['channel_indices'],:]-w['mean'])/w['scale']).reshape(len(waves),-1)
    h=x
    if bool(w.get('rpm_conditioned',False)):
        rpm=np.asarray(rpm,dtype=np.float32) if rpm is not None else None
        if rpm is None or rpm.shape!=(len(waves),int(w['window_samples'])) or not np.isfinite(rpm).all() or np.any(rpm<0):
            raise ValueError('同期した非負のRPM履歴が必要です')
        h=np.concatenate([x,(rpm-w['rpm_mean'])/w['rpm_scale']],axis=1)
    for i in range(4):
        h=h@w[f'W{i}']+w[f'b{i}']
        if i<3:h=np.tanh(h)
    return np.mean((h-x)**2,axis=1)
