# 並列作業指示・Git調査・段階的統合方針

本書の実装指示は**今後実装が依頼された場合**の作業定義。今回はコード変更、Git初期化、エージェント起動、実証基盤の作成を行わない。

## Task A：Git管理範囲の読取調査

2026-10-14に確認：

|対象|コマンド/確認|結果|
|---|---|---|
|作業ルート|git -C . rev-parse --show-toplevel|not a git repository|
|nv_route_runner_poc|git -C nv_route_runner_poc rev-parse --show-toplevel|同上|
|09_DL-NPZ_Bridge|git -C 09_DL-NPZ_Bridge rev-parse --show-toplevel|同上|
|ソース領域内の.git file/directory|読取walk|検出なし|

walkは.venv/.venv_c/.phase_a_deps/node_modules/__pycache__、data/runs/demos/examples/reports/_work、inspection_runs/reference、transfer_*を除外した。マシン全体や除外フォルダ内にGitがないとは主張しない。追跡範囲・branch・remoteは不明で、git init/config/add/commitは未実施。

並列checkout運用前に実際の管理repo/基準commitを決める必要がある。ソース所有範囲と単独test設計はその前にも進められる。新基盤の構想や実証結果を待つ必要はない。

## 既存PoCで独立着手できる仕事

C01〜C08を変更しないことを条件に、../parallel_contracts/AGENT_TASKS.mdの担当をそのまま使う。下記は今回の優先指示であり、既存契約の変更ではない。

|担当|入力→出力と保証|将来の専用編集ファイル|共有編集待ちになる範囲|
|---|---|---|---|
|入力D|元測定fixture→C01 Record、単位/同期/祖先/真値隔離|nv_runner/input_candidate.py、tests/test_input_candidate.py、configs/parallel/input_*|InputAdapterの本番入口へ配線する部分だけ|
|物理P|音源条件→観測p/u＋別truth、C02の意味を維持|nv_runner/physics_candidate.py、tests/test_physics_candidate.py、configs/parallel/physics_*|共通SignalServiceのscale/key変更|
|RA/RB/RC/RD|C01/02→C03 PreparedSet→C05、既存基底を利用|route_a/b/c/d_candidate.py、担当別tests/configs|REGISTRY/validate_config/runner保存説明への登録|
|モデルM|fit特徴→model、特徴→score、fit-only前処理|model_candidate.py、tests/test_model_candidate.py|model kind whitelist、前処理/score説明の修正|
|閲覧V|既存Bundle1.0→表示、null/根拠/真値区別|将来のviewer変更はV専有、候補testはtests/test_viewer_candidate.py|新たな必須artifactをwriterへ要求するとき|
|出力O|検証済Bundle→ローカルreceipt、内容不変|output_candidate.py、tests/test_output_candidate.py|外部接続仕様と既存入口への接続|
|QA Q|C01〜08 fixture→CT結果|tests/test_contract_c01.py〜c08.py、contract_fixtures.py|契約自体の意味変更|

実測ファイル未入手でもDは標準入力fixtureで、外部API未確定でもOはローカルstubで進められる。契約CT実装を待つ間も候補class直接呼出しと既存テストで作業できる。共有ファイル変更が必要な箇所だけ統合担当IへCRを出す。

## 共通ファイルの衝突と所有者

|ファイル/結合点|競合しやすい担当|回避策|
|---|---|---|
|routes.py（基底・4経路・REGISTRY）|RA/RB/RC/RD/M|専用candidate moduleへ。共有編集はIのみ|
|runner.py（validator/実行/保存/fusion）|全担当|Iのみ配線。plugin固有条件を無断追加しない|
|bundle.py（Collector/Reader/Output）|I/V/O/Q|Oは外部module、V/Qはread-only利用。Iのみ共有変更|
|signals.py/cache/map|P/RA/RD/V|baseline固定。候補の局所計算は専用module|
|input_adapter.py（読取＋分割）|D/Q/I|分割をDがついでに変更しない。adapter候補を外に置く|
|models.py/requirements|M/各route|モデル候補で先行、依存版変更はCR|
|profiles/configs/CLI/__version__|全担当|担当config命名を分け、global default/版はIのみ|
|既存回帰tests/fixture|Q/全担当|既存を維持、新testファイルを担当別に追加|

既存runnerにはREGISTRY以外にplugin別必須parameter辞書、modelのkind制限、StandardScaler/IF/PCAに特化した保存説明がある。ここが現行結合の実装依存点。新基盤のdescriptorを作るだけで既存runnerへ自動接続できるとは扱わない。

## Task B/C：隔離PoCの並列作業単位

将来のrootを `plugin_lab_poc/` とする（未作成）。各担当はこの下以外を変更しない。旧nv_runner/tests/configs/C契約は全員read-only。最初はimport依存も置かず、旧reader adapterを試す段階だけ外側から依存を追加する。

|担当|所有する予定ファイル|依存と提出物|
|---|---|---|
|L1 契約/Validator|plugin_lab/contracts.py、descriptor.py、validator.py、tests/test_validator.py|DESIGNの3データ契約・限定config・interfaceを固定。公開fixtureと検査関数signatureをL2〜L5へ提供|
|L2 Planner/Engine|plugin_lab/planner.py、engine.py、report.py、tests/test_planner.py|L1の検証APIだけに依存、plugin具体名に依存しない。plan順序/digest、前後検査、失敗隔離を実装|
|L3 Plugin A|plugin_lab/plugins/rms_a.py、descriptors/rms_a.json、tests/test_plugin_a.py|公開contract/fixtureだけ参照。実際のNumPy RMS、skip、入力不変|
|L4 Plugin B|plugin_lab/plugins/rms_b.py、descriptors/rms_b.json、tests/test_plugin_b.py|A内部を参照しない、math.fsum RMS。Aと同じcapability/I/O/configで独立提出|
|L5 Plugin C|plugin_lab/plugins/crest.py、descriptors/crest.json、tests/test_plugin_c.py|A/Bに依存せず公開RMS fixtureを入力に一次検証。same_coordinateとゼロ扱いを守る|
|LQ 結合/試験|catalog.json、compositions/*、tests/fixtures.py、test_composition_acceptance.py、README、依存ファイル|catalogと構成の統合所有者。PT01〜26、hash比較、結果記録。engineを修正してpluginを無理に通さない|

小規模なので役割は兼務可能だが同一ファイル所有者は1名。4スロットならL1/L2/L3/LQで骨格を作り、L1の契約が固定したらL4/L5を独立に開始する。L2の完成を待たずにplugin単体harnessで一次検証する。既存PoCの担当群とこのLab群は別作業であり、一方の完了を他方の開始条件にしない。

### 割当時の短い指示

- L1：単位/座標/版の許容範囲を勝手に広げない。未知を拒否し、descriptorはデータ、実行コードはfactoryとして分ける。
- L2：A/B/C名によるif文を禁止。disabled、依存欠落、runtime不正出力の意味をDESIGNどおりに実装。依存自動追加はしない。
- L3/L4：W1だけの固定値実装は禁止。W2/ゼロ/長さ条件でも数式を計算。descriptorと出力の意味が同じか検証。
- L5：input.rmsを具体plugin名で探さない。portから受け取り、別測定/別区間を拒否。zero RMSはskip。
- LQ：初期engine/validator/3契約のhashを記録してから交換/追加試験を行う。数値同等性と「変更不要」を両方確認する。

エージェント提出物は所有ファイル差分、descriptor、単独コマンド、試験件数、合否、未実施、必要CR。実装内部を先に統一する要求を置かない。

## Task D：既存側の維持・adapter・置換候補

|既存領域|当面維持するもの|接続/将来候補|必要な合格ゲート|
|---|---|---|---|
|InputAdapter/分割 C01|正常表明、群分割、元hash、単位/同期/共置|外側のread-only adapterがp列だけをLab PressureWaveへ投影する診断用途|元record不変、座標変換明示、truth/IDを特徴に使わない|
|SignalService C02|物理量の意味、phase/valid/scale、既存cache運用|後から共有計算を明示port化する候補。初回は触らない|既存物理試験・consumer整合、数値許容差|
|RoutePlugin/NormalModel C03/04|prepare/fit/score/save、学習隔離、feature_schema|単経路または単変換を外側wrapperで試す。学習lifecycleは次段階の別契約|新旧同じ入力/分割/設定で比較、学習/評価漏洩なし|
|状態/閾値 C05|未評価null、coverage、case/個体、閾値意味|Lab statusを旧statusへ直接コピーしない。意味が揃ったものだけ明示mapper|モデル/threshold/根拠が揃うこと。単純RMSをanomaly_scoreへ偽装しない|
|ResultCollector/Reader C06|schema1.0・必須tables・hash・immutable保存|既存collector/readerを再利用するadapterが先。writer置換は最後の候補|旧reader/viewerで検証、artifact名/refs/形状/状態整合|
|EvaluationAdapter C07|ローカル取込・receipt・冪等性|transportだけを別moduleに。認証/APIは今回不要|既存receipt互換、実接続は別受入|
|runner登録/検証 C08|既存CLI/configを既定のまま残す|registry/config検証の置換が候補。ただしLab合格だけで変更しない|1候補opt-in経路、旧default回帰、rollback可能|
|viewer|保存Bundleからのみ閲覧|旧Bundleをそのまま読む。Lab専用結果の閲覧は別report|LabReportを旧Bundleと誤認しない|

## 段階移行（今は計画のみ）

1. **M0 既存並列開発**：C01〜08とファイル所有権で開始。現行32試験/quickのbaselineを記録。Labの完成を待たない。
2. **M1 ダミー隔離実証**：Lab packageは旧コードをimportしない。PT01〜26とBC01/02で交換性・独立性・旧側無影響を確認。
3. **M2 読取だけのadapter**：外部で旧CLIを実行して新規Bundle1.0を生成し、既存BundleReaderで検証した後、観測p snapshotだけをPressureWaveへコピー。測定start/end/sample_rateを保持。Lab reportはBundleの外へ保存する。immutable Bundleへ診断fileを後から足さない。真値は投影しない。
4. **M3 1つの実処理をwrapperで試験**：次の最小対象を決め、必要ならRecord/feature等の**Lab専用**contractを追加して別CRにする。旧経路のfit/cal/eval全体を単純run interfaceで既に表現できるとは主張しない。wrapperは旧側をread-only利用し、shadow比較する。モデル状態や校正閾値の交換はこの段階の設計課題。
5. **M4 既存への任意接続**：明示承認後、旧CLIとは別の入口/adapterで1経路だけ試す。既定経路は旧のまま。Bundle1.0へ正確に表現できる場合だけcollectorへ渡し、BC03〜05と全回帰を通す。表現できないならLab形式に留める。
6. **M5 選択的置換**：交換の利益が確認された登録/設定検証等から小単位で採用。旧runner/reader/モデル実装を一括削除しない。旧schemaを変える必要が生じたら本互換性維持タスクから分離する。

各段階でdescriptor/契約版、入力と出力hash、使用実装、設定、試験結果を固定する。機能削除は参照検索・plannerの依存確認・回帰の後で行う。エンジン差分を要した交換は「変更不要」の受入失敗として理由を残し、試験結果を成功に読み替えない。

## 変更承認と再開

旧C契約は../parallel_contracts/INTEGRATION.mdのCR手順を維持。Lab契約の変更はL1＋影響plugin担当＋L2＋LQで確認し、旧側への影響がある場合はIも承認する。無応答を承認にしない。境界待ち中も専用moduleで独立開発できる部分は進める。

失敗時は旧側defaultをそのまま使い、Labまたはadapterを選択しなければ元の機能が成立する構成とする。Lab実行はnew run全再実行、保存済み旧Bundleは変更しない。機能の選択・版pin・構成・成果物を記録し、未使用pluginを無断fallbackで使わない。
