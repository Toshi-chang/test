import bootstrap_lab
from bootstrap_lab import ROOT,BASELINE,verify_baseline
from pathlib import Path
import copy,tempfile,unittest,uuid
import numpy as np
from bridge.adapter import read,write
from bridge.dataset import realize
from run_factorial import variant_config,repair_truth
from summarize import summarize,ANOMALIES

class Protocol(unittest.TestCase):
    def test_01_changes_only_eval_additions(self):
        base=read(BASELINE/'configs/dataset_comparison.json');before=copy.deepcopy(base)
        changed=variant_config(base,True)
        self.assertEqual(base,before)
        for key in base:
            if key!='additions':self.assertEqual(base[key],changed[key])
        for kind in ANOMALIES:
            self.assertEqual(changed['additions'][kind][:-1],base['additions'][kind])
            self.assertEqual(changed['additions'][kind][-1],base['additions']['disturbance'][0])

    def test_02_normal_training_scene_exact(self):
        base=read(BASELINE/'configs/dataset_comparison.json');b=variant_config(base,True)
        for family in [0,1,19,100000]:
            for mode in [0,1]:self.assertEqual(realize(base,family,mode,'normal'),realize(b,family,mode,'normal'))

    def test_03_target_scene_preserved(self):
        base=read(BASELINE/'configs/dataset_comparison.json');b=variant_config(base,True)
        for scenario in ANOMALIES:
            a=realize(base,100001,1,scenario);c=realize(b,100001,1,scenario)
            self.assertEqual(a['sources'],c['sources'][:-1])
            self.assertEqual(a['simulation'],c['simulation'])

    def test_04_disturbance_truth_role_not_fault(self):
        root=ROOT/'tests/_work'/uuid.uuid4().hex;root.mkdir(parents=True)
        write(root/'truth.json',{'schema_version':'1.0','cases':[{'scenario':'band','label':'abnormal','regions':[
            {'source_id':'band_extra','role':'target_anomaly','kind':'band'},
            {'source_id':'external_extra','role':'target_anomaly','kind':'band'}]}]})
        repair_truth(root,True);t=read(root/'truth.json')['cases'][0]
        self.assertEqual(t['label'],'abnormal');self.assertEqual(t['regions'][0]['role'],'target_anomaly')
        self.assertEqual(t['regions'][1]['role'],'disturbance');self.assertEqual(t['scenario'],'band_with_disturbance')

    def test_05_controls_deduplicated_undetermined_kept(self):
        def row(kind,decision,score):return {'route':'A','family':'f','scenario':kind,'decision':decision,'score':score,'threshold':.5,'top_inputs':[]}
        clean={'cases':[row('normal','within',.1),row('disturbance','outside',.7)]+[row(k,'undetermined',None) for k in ANOMALIES]}
        disturbed={'cases':[row(k+'_with_disturbance','outside',.8) for k in ANOMALIES]}
        root=ROOT/'tests/_work'/uuid.uuid4().hex;root.mkdir(parents=True)
        r=summarize(clean,disturbed,root)
        self.assertEqual(r['unique_eval_variants'],12)
        self.assertEqual(r['routes']['A']['normal_disturbed']['n'],1)
        self.assertEqual(r['routes']['A']['abnormal_clean']['undetermined'],5)
        self.assertTrue(all(p['score_change'] is None for p in r['paired_transitions']))

    def test_06_baseline_preserved(self):self.assertEqual(verify_baseline(),164)

if __name__=='__main__':unittest.main()
