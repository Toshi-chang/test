# 隔離Plugin基盤：最小実証設計

設計案0.1。以下の型・validator・plannerは未実装。ResultBundle schema1.0やC01〜C08の改訂ではない。

## 1. ダミー機能と最小の契約集合

|実装|semantic capability|入力→出力|計算|依存|
|---|---|---|---|---|
|A / lab.rms.numpy|lab.pressure_rms@1.0|PressureWave@1.0 → PressureRms@1.0|sqrt(mean(x²))、NumPy|外部waveのみ|
|B / lab.rms.fsum|同じlab.pressure_rms@1.0|Aと完全に同じ|sqrt(math.fsum(float(x)²)/N)|外部waveのみ|
|C / lab.crest|lab.pressure_crest@1.0|PressureWave@1.0 ＋ PressureRms@1.0 → CrestFactor@1.0|max(abs(x))/rms|rms入力portへ接続したnode|

A/Bは同等機能の別実装。Cは追加機能で、Aという具体名には依存せずrms port契約に依存する。A/Bを同時に別nodeで選ぶ構成も可能。Cを無効化してA/Bを動かす、Cとその依存Aを無効化して独立Bだけ動かすことで削除時の独立性を実証する。

### 契約定義（実証時の初期固定レジストリ）

`PressureWave@1.0`：

```text
contract_id = "lab.pressure_wave"; contract_version = "1.0"
quantity = "sound_pressure"; unit = "Pa"
values: NumPy ndarray, dtype == float64, shape == [N], N >= 2, finite
axes == ["sample"]
measurement_id: nonempty string
coordinate:
  frame == "measurement_sample_index"
  source_sample_count: int > 0 (bool不可)
  sample_start, sample_end: int, 0 <= start < end <= source_sample_count
  sample_end - sample_start == N
  sample_rate_hz: finite number > 0 (bool不可)
```

`PressureRms@1.0`：contract_id="lab.pressure_rms"、quantity="rms_sound_pressure"、unit="Pa"、valuesはfloat64 ndarray shape[1]、finiteかつ>=0、axes=["metric"]。measurement_idとcoordinateは対応waveと完全一致。契約上はwave全切出し範囲のRMSを表す。

`CrestFactor@1.0`：contract_id="lab.pressure_crest"、quantity="pressure_crest_factor"、unit="1"、valuesはfloat64 ndarray shape[1]、finiteかつ>=0、axes=["metric"]。measurement_id/coordinateは入力waveと同じ。

共通して座標frameと単位文字列を完全一致で確認し、start/endは半開。metricのvalues長1を切出し長と比較しない。Cの2入力はmeasurement_id、sample_rate、source_sample_count、start/endが同じでなければ拒否する。この相互制約はCのport間条件としてdescriptorに宣言する（後述）。異なる位置のRMSを同じ型として接続する誤りを防ぐ。

JSON例のvaluesは配列リテラルでありruntimeではfixture loaderが**初回のみ**float64 ndarrayへ明示構築する。plugin出力をvalidatorが自動castして救済しない。実証入力は小さな値に限定し、任意の巨大値に対するoverflow安定性は将来課題。overflow/NaN/Infは明示的に拒否する。

## 2. 最小Plugin Descriptor

Descriptorの目的は登録・選択・検証に必要な情報だけを宣言すること。依存はport bindingから決まるため、別のrequiresリストを二重管理しない。

```json
{
  "descriptor_version": "1.0",
  "plugin_id": "lab.rms.numpy",
  "implementation_version": "0.1.0",
  "api_version": "1.0",
  "capability": {"id": "lab.pressure_rms", "version": "1.0"},
  "entrypoint": "plugin_lab.plugins.rms_a:create",
  "inputs": {"wave": {"contract_id": "lab.pressure_wave", "contract_version": "1.0"}},
  "output": {"contract_id": "lab.pressure_rms", "contract_version": "1.0"},
  "config": {"min_samples": {"type": "integer", "minimum": 2, "default": 2}},
  "constraints": [{"kind": "preserve_coordinate", "input": "wave"}]
}
```

- 全項目必須、未知descriptor keyは拒否する。config={}は許可。実証用typeはinteger/number/boolean/stringだけ、optional keywordはminimum/maximum/enum/defaultだけ。未対応keywordは無視せず拒否。全config keyは必須扱いでdefaultがあると補完、未定義keyは拒否。boolをnumber/integerとして受けない。非有限numberも拒否。
- Bはplugin_id/entrypointのみ別、Aと同じcapability・port契約・config・constraints。実装版は最初0.1.0。
- Cはwaveとrmsの2入力、output=lab.pressure_crest@1.0、config.min_rms_pa={type:number,minimum:0,default:0}。constraintsはpreserve_coordinate(wave)とsame_coordinate(inputs=[wave,rms])。
- engineはcapability名で分岐しない。semantic capabilityは「交換候補として同じ目的」の宣言、port契約はデータ形と意味の接続条件。名前一致だけで数値同等と認定せず受入oracleも必要。
- registry keyは(plugin_id,implementation_version)。重複keyは衝突エラー。capabilityが同じ複数実装は正常。catalogは明示したdescriptorファイルのリスト、entrypointはその一覧内のローカル信頼済みmoduleだけ。directory自動探索はしない。
- 新plugin追加は新descriptor/実装とcatalogの1項目、compositionの選択で足りることを試す。**catalog/compositionの更新は許可するがengine/validator/既存pluginの変更は許可しない**。

### 版の扱い

descriptor_version/API/contract/implementationは別の軸。初版はすべて完全一致比較とし、semver範囲や「minorだから互換」の推測はしない。API1.0対応engineはapi_version2.0を拒否。契約はIDとversionの組が一致したときだけ接続。implementation_versionはcompositionが正確にpinする。同じcontract名で単位/座標意味を変更しない。

Cの初回追加で新output契約lab.pressure_crestが必要になるので、**3契約を最初からfixture/validator registryへ定義**してengineをfreezeする。これでC追加がengine不要であることを限定的に検証できる。未知の将来契約を一切のvalidator拡張なく理解できるという主張はしない。

## 3. 共通実行interface（擬似定義）

```python
# 設計上の署名。まだコードとして存在しない。
create(config: dict) -> Plugin
Plugin.run(inputs: Mapping[str, Datum], context: RunContext) -> PluginReturn

RunContext = {run_id: str, node_id: str}  # seed/state/global registryは初版で不要
PluginReturn = Success(output: Datum) | Skip(reason_code: str, message: str)
```

純粋な同期数値処理1回を1nodeとする。初版はrunだけで、fit/calibrate/load/save lifecycleは設けない。A/B/Cは実際に上表の数値計算を行い、成功値を固定値・乱数・正解参照で代用しない。

configは起動前にdefault補完・型検査し固定、入力は検証後の専用コピー/readonly viewとして渡す。Pluginは他node・registry・ファイル出力を直接操作せず、payloadを返す。実証pluginは信頼済みコードとし、readonlyや契約検査を悪意あるコードへのsandboxとは呼ばない。独立プロセス隔離は範囲外。

A/BでN<min_samplesならSkip('insufficient_samples',...)。Cでrms<=min_rms_paならSkip('rms_below_floor',...)。ゼロRMSのcrestを0や正常判定に置き換えない。Unexpected exceptionはengineがfailedへ変換。不正出力はvalidatorがfailed/OUTPUT_CONTRACT_MISMATCHへ変換し、下流へ値を公開しない。

### 共通結果への変換

engineが `LabRunReport` を生成する。pluginにrun結果全体を組み立てさせない。

```text
lab_result_version: "1.0"                 # Bundleのschema_versionとは異なる名前空間
run_id, plan_digest, registry_digest
status: completed | partial              # 実行前拒否ではこのReportを作らない
nodes: [{node_id, plugin_id, implementation_version,
         status: succeeded | skipped | failed | disabled,
         output: Datum | null,
         reason_code: string | null, message: string | null,
         input_refs, elapsed_seconds}]
```

全enabled node succeededならcompleted、それ以外はpartial。disabledは完了判定の母数外。入力が必要な上流がfailed/skippedなら下流skipped/UPSTREAM_UNAVAILABLE。独立した他nodeは継続。disabledはoutput=null/FEATURE_DISABLED、未選択catalog項目はnodesに載せない。

成功だけにoutputを持たせる。ここにsample anomaly_score、threshold、within等は作らない。LabRunReportを既存BundleReaderに渡すことは対応外で、相手のschema1.0を偽装しない。preflight拒否は `PlanRejected{code,node_id,port,message}` を別の診断として保存し、plugin実行件数0を確認する。

## 4. Contract Validator

構造と数値/座標を二段階で検証する。最初から一般JSON Schema実装を導入せず、上記限定構造に対する純粋関数で実証できる。

1. descriptor検証：required/unknown key、IDと版、portとcontract registry存在、config定義、対応constraintsだけを受理。
2. config検証：unknown key拒否、default補完、strict型、finite/range/enum。各pluginが独自に曖昧なcoercionをしない。
3. 宣言の接続検証：producer.outputとconsumer.inputのcontract ID/版一致。API/実装pin一致。capability一致は交換試験時に確認し、plannerが代替実装を勝手に選ばない。
4. runtime Datum検証：dtype、rank、shape、finite、quantity/unit/axes、座標範囲、長さ、measurement_id、contract版。
5. node実行直前：複数portのsame_coordinate制約。実行後：出力Datumとpreserve_coordinate制約。返値tag/必須reasonも検査。

不正の扱いを段階で区別する：外部入力の型/単位/座標/版の誤りはpreflightで拒否し実行0件。上流が将来生成する**実際の値**まではpreflightでは検証できず、実行後に拒否し依存nodeを停止する。宣言の不一致と実データの不一致を同じ「すべて実行前保証」としない。

エラーコードの最小集合：DESCRIPTOR_INVALID、VERSION_UNSUPPORTED、PLUGIN_NOT_FOUND、CONFIG_INVALID、CONTRACT_MISMATCH、INPUT_CONTRACT_MISMATCH、MISSING_BINDING、DEPENDENCY_UNAVAILABLE、DEPENDENCY_CYCLE、NO_ENABLED_NODES、OUTPUT_CONTRACT_MISMATCH、PLUGIN_FAILED、UPSTREAM_UNAVAILABLE。これらはLab専用でC05の既存reason/enumを書き換えない。

## 5. Composition Planner

compositionは `composition_version:'1.0'`、external_inputsの名前→Datum、nodes配列を持つ。nodeはnode_id/enabled/plugin_id/implementation_version/config/bindings。bindingsは各入力portを `{external:'wave0'}` または `{node:'rms_main'}` へ明示対応。単一outputなのでoutput port名は初版不要。

```json
{
  "composition_version": "1.0",
  "nodes": [
    {"node_id": "rms_main", "enabled": true, "plugin_id": "lab.rms.numpy", "implementation_version": "0.1.0", "config": {}, "bindings": {"wave": {"external": "wave0"}}},
    {"node_id": "crest", "enabled": true, "plugin_id": "lab.crest", "implementation_version": "0.1.0", "config": {}, "bindings": {"wave": {"external": "wave0"}, "rms": {"node": "rms_main"}}}
  ]
}
```

例ではexternal_inputsの具体値を省略した。examples.jsonにfixtureがある。

### 起動前の決定手順

1. composition版とnode_id重複を検査。catalog descriptorの構造・重複keyを検証するが、この段階でentrypoint moduleをimport/instantiateしない。
2. enabled=falseはnode_id/enabled以外を実行検証しない。無効nodeはdescriptor存在/設定検証も不要で、catalogから削除した実装の履歴を無効nodeとして残せる。enabledはbool厳密。誰かが無効nodeへ依存すれば拒否。
3. enabled nodeだけplugin実装版/API、config、必須portのbinding有無、余分bindingを確認。依存を自動追加しない。
4. external参照は外部Datumを検証し型を確認。node参照は存在/enabled/宣言output型を確認。前方参照は許可。same_coordinate等の制約は全対象portがexternalで既知ならこの段階でも検査し、上流の実出力を待つ場合はnode実行直前に再検査する。
5. edgeをproducer→consumerとしてDAG検査。循環なら構成全体を拒否。enabled nodeが0ならNO_ENABLED_NODES。
6. topological sort、同順位はnode_id昇順で固定。未使用catalogは実行しない。planに正確なdescriptor/config/binding/順序をfreezeしてdigestを保存。
7. 計画が成功した後だけfactoryを解決してrunする。計画に使ったdescriptorと実行時descriptorのdigestが変わっていれば拒否して再計画。途中のregistry更新を反映しない。

「登録」は利用可能候補、「選択」はcompositionへのenabled node採用、「依存」はbindingである。この3つを混同しない。選択されていない依存先を勝手に実行しない。エンジンが理解するのはport/contract/graphであり、A/B/C名のif文は禁止。

## 6. 交換・追加・廃止の許容変更範囲

- A→B：rms_mainのplugin_idと実装pinだけ変更。node_id、binding、C、engine、validator、contract定義は不変。configは同じなので変更不要。
- C追加：C実装/descriptor、catalog項目、composition node追加を許す。A/B/engine/validatorのコードは不変。Cが使う3契約は先に定義済み。
- 無効化：enabledだけ変更。C無効ならA/B独立継続。Aを無効にしてCを有効にしたままなら明示的な依存エラー。
- 廃止/削除：catalogとcompositionから削除/無効化。削除した実装へのenabled参照が残ればPLUGIN_NOT_FOUND。消えた依存nodeを参照すればDEPENDENCY_UNAVAILABLE。silent fallback禁止。
- 新契約種別：contract registryへの承認済み追加が必要。validator engine自体の変更不要を目指せるが、初版の実証対象は上記3契約まで。任意型や任意座標を無改修で扱えるとは保証しない。
