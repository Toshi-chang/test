# D-002 PhysicalRecording v1：意味的共通データ契約案

2026-10-20 / 設計草案 rev.1.1。**未実装・未採用。PoC・製品試験は実行していない。** PhysicalRecordingは意味的な境界の名称であり、Pythonクラス、保存形式、既存schemaの改版を意味しない。

読む順序：本書 → [As-Is・判断台帳](D002_ASIS_DECISIONS_rev1.1.md) → [比較PoC計画](D002_COMPARISON_POC_rev1.1.md)。根拠の全パス・SHA-256・照合結果は[evidence.json](evidence.json)。round01/round02およびソースは変更しない。旧rev.1を保存したまま、本書に全基本定義と補強定義を統合した。[変更・整合性監査](D002_CHANGELOG_rev1.1.md)は履歴用であり、本書の理解に旧版との差分読解は不要。

文書rev.1.1は実装契約のminor版を意味しない。後述の1.0.0は初版実装の仮称であり、rev.1と本案を同一payload版で混用してよいという意味ではない。検証fixtureには文書revisionも明記する。

## 1. 設計結論と確定状態

D-002の課題は、収録値にCH、単位、時計、校正、センサー、由来を結び付け、独立PoCが**同じ意味の入力**を比較できるようにすることである。データを一つの配列へ揃えるだけでは解決しない。

- **F（静的事実）**：Observer開発版とBridge既定referenceは異なる。電圧波形、校正TF、周期AC校正波形、DL窓、NV入力は別契約。ゼロplaceholder、CH最初一致、任意由来欄などがあり、名前や拡張子から意味を確定できない。
- **F（第2回の追加事実）**：strict経路にはraw/probe/config捕捉・hash結合・親品質継承がある。計算成功、成果物公開、実機適合、用途別利用許可は同じではない。通常exportには同じ保証がない。
- **I（要求からの推論）**：全CHを同時計・常時校正済みに強制すると、欠損CHや別時計RPMなど研究上必要な入力を失う。逆に不足を既定値で埋めると位相・方向を使う比較の根拠を失う。
- **P（推奨）**：不変の収録根を持つPhysicalRecording、変更ごとのSignalRevision、選択だけを行うSignalView、変換結果のDerivedArtifactを分離する。値・構造の妥当性と用途別利用可否を分離する。
- **FIX**：Windows、外部ファイル受領、DAQ制御対象外、原本保護、追跡性、独立検証、GUI分離はユーザー指定。48 kHz/120秒/12 PUは固定上限にしない。
- **EARLY**：IDスコープ、半開区間、CH状態、校正領域、品質と利用可否の分離を下記案で早期合意する。今回の文書作成を承認済み契約への昇格としない。
- **SELECT**：NumPy＋型付き構造を暫定第一候補とするが、A/B/C比較と部分読込性能で選ぶ。保存形式は別判断。
- **U**：実CSV第1列の意味・列配置、メタデータ照合キー、実機時計精度、配線・方向・係数適用帯域は未確認。これらを仮の物理事実として埋めない。

本書の設計規定は、特記がない限りすべて**P/EARLY**である。F/I/P/U/VとFIX/EARLY/SELECT/DEFERは別軸。Vは実行証拠を伴う場合だけ使用し、本件の機能・科学的Vは0件。ファイルhash照合は資料の完全性確認である。

## 2. 責務と最小構造

```mermaid
flowchart LR
  S[SourceAsset 原本bytesとhash] --> R[PhysicalRecording 不変manifest]
  M[外部測定メタデータ snapshot] --> R
  R --> I[Identity / TimeBases / Channels]
  R --> P[SensorMapping / Context / Quality]
  R --> V[SignalView 選択参照]
  V --> C[独立した校正・解析]
  C --> D[DerivedArtifact + Provenance]
  D --> SR[時間波形ならSignalRevision]
  SR --> V2[別のSignalView]
```

|要素|所有する意味|外部に置ける実体・責務外|
|---|---|---|
|PhysicalRecording|一つの収録または合成生成根の解釈revision、CH/時間/センサー/条件の参照と状態|信号大容量bytes、原本、証明書、処理実装の保存場所。実行エンジンは持たない|
|SignalRevision|処理後の時間波形・時間軸・状態と親への対応。所属rootは維持しrevisionを新規発行、他の寄与根も追跡|FFT等を無理に時間CHへ戻さない|
|SignalView|revisionを固定したCH/ペア/区間の読み取り選択|校正、補間、resampling、欠損補完はしない|
|DerivedArtifact|TF、PSD、窓列、次数、特徴量等の型別結果と元SignalView参照|個別数式・正規化の詳細はD-003。保存配置はD-004|
|CalibrationRecord / QualityFinding / ProcessingRecord|校正適用と証拠、品質所見、変換の意味|大きい係数表・環境lock等はhash付き外部asset参照|

暫定6要素にTimeBase複数化、Calibration/Quality、SignalRevisionを追加する。理由は、別時計と校正領域の差を一つのstage文字列へ押し込めないため。代替の「すべてをPhysicalRecordingの可変辞書へ格納」は簡単だが同一IDの意味が実行中に変わる。採用を推奨しない。全成果物を巨大DAGとして常駐させる必要もない。親refと必要な対応情報を辿れればよい。

## 3. 共通記法・参照・バージョン

表のM=必須、O=任意、C=条件付き必須。Mは不明を捏造して埋める意味ではない。状態付き値 `Known(value,evidence_ref)` / `Unknown(reason)` / `NotApplicable(reason)` を用いる項目では状態自体が必須。空文字、NaN、ゼロをUnknownの代用にしない。

`EntityRef={entity_id, revision_id}` は不変の版を指定する。外部実体を参照するときは `AssetRef={asset_id, sha256, byte_length, media_type, locator}`。locatorは移設可能な解決先でありIDではない。sha256は64桁16進、lengthは非負整数。リモート/ローカルの可用性とhash一致は別所見。外部の任意実行コードを参照から起動しない。

|フィールド|必須性・型|意味・制約|
|---|---|---|
|contract_name, contract_version|M string|提案値 PhysicalRecording / 1.0.0。実装済み版ではない|
|required_capabilities|M list[string]|解釈必須の追加意味。未知なら拒否|
|identity|M RecordingIdentity|次節|
|timebases|M map[id,TimeBase]|最低1個。未確定時間はstate unresolvedで表す|
|channels|M map[id,SignalChannel]|最低1個の登録CH。取得不能CHも登録できる|
|sensor_mapping|M object|sensors/frames/pairs。情報未登録は空集合＋理由|
|context_ref|M 状態付きEntityRef|条件不明を既定正常条件と解釈しない|
|provenance_ref|M EntityRef|原本→読込の変換を含む|
|quality_refs|M list[EntityRef]|空なら未評価。全項目合格ではない|
|extensions|O map[namespace,object]|既存意味の上書き禁止。意味必須ならcapabilityへ登録|

版は文字列major.minor.patch。未知major、未対応minor、未知required capabilityは消費前に拒否する。minorの自動前方互換は認めず、対応表に明記された組合せのみ許可。意味・必須性・単位変更は非互換、任意拡張のみ互換候補、patchは意味を変えない修正。旧Observer/Bridge/NV schemaを版番号だけで受け入れない。明示Adapterが損失と不足を出力する。既存ResultBundle 1.0/C01〜C08は変更しない。

## 4. RecordingIdentity

|フィールド|必須性・型|意味・発行・不変条件|
|---|---|---|
|recording_id|M opaque string|収録/合成生成根のID。登録主体がnamespace付きUUID等で発行。ファイル名から生成しない|
|revision_id|M opaque string|読込解釈/metadata snapshotを含む不変revision。変更時は新規発行|
|root_kind|M enum|acquired / synthetic。収録根の出自。派生処理を示すoriginとは別|
|source_refs / source_id|C AssetRef列|acquired根は原本bytesの非空参照列。synthetic根は空列でよくgeneration_ref必須。source_idはasset_idの別称で二重保存不要|
|generation_ref|C ProcessingRecord参照|synthetic根で必須。生成仕様snapshot、実装、生成出力hashを結合。架空CSVを原本として作らない|
|source_hash|C source_refs内|参照原本がある場合のSHA-256。合成値の出力hashと区別|
|measurement_id|M 状態付き外部ID|測定行為・実施記録との関係。未登録はUnknown。recording_idと同一視しない|
|context_ref|M 状態付きref|トップレベルと同一参照。実装では一箇所だけ保持|
|derived_id / parent_refs|C ID / 非空ref列|派生では親ref必須。derived_idは§16のrevision正規refを用いてよく、別UUIDは必須でない。元Recordingはderived_idなし|
|issuer / registered_at|M string / timestamp|ID発行主体・登録時刻。registered_atを収録開始時刻にしない|

**同じCSV再読込**：hash一致だけで同じ測定と断定しない。既存登録のsourceと明示measurement紐付けが一致し、parser設定・context snapshotも同じなら既存revisionを再利用可能。紐付けが不明なら同じsource assetへの別registrationを保持し、重複候補を通知する。ID発行の完全な冪等化・登録DBはD-006。別名コピーもsource bytes同一候補になる。

**同じCSVに別校正**：root recordingとraw revisionを維持し、異なるderived_id/revision_id、CalibrationRecord、ProcessingRecordを作る。出力が偶然同じでも処理履歴を統合しない。ファイル改変は同じpathでも新source assetとし、既存参照のhash不一致は拒否する。

measurementは測定行為、experimentは比較計画、runは一度の処理実行、specimenは対象個体、caseは評価条件/ケース。Bridge record/window番号は局所IDとしてnamespaceとsourceを添えて保持する。Observer UUIDやNV measurement IDを検証なしに新IDへ昇格させない。正解ラベルと学習分割はRecording必須属性にせず、D-006の別参照として入力特徴量から隔離する。

## 5. TimeBase

|フィールド|必須性・型/単位|意味・条件|
|---|---|---|
|timebase_id / revision_id|M ID|一つの時刻解釈を固定|
|sample_count|M int ≥0|0なら空取得、数値解析不可|
|grid_kind|M enum|uniform / explicit / unresolved|
|interval_s, sampling_frequency_hz|C 正有限数|uniformでは片方を正とするauthoritative_fieldが必須。両方記載時は相互整合を検証|
|relative_origin_s|C finite|uniformの最初のsample時刻。原点の由来をorigin_definitionで明記|
|time_values_ref|C AssetRef・実数[N], s|explicitでは必須。原CSV列そのものとは限らない|
|origin_definition|M enum＋理由|acquisition_start / first_sample / external_event / unknown。first_sample=0は局所座標であり機器の開始時刻ではない|
|original_time_column_ref / interpretation|C ref / enum|入力に時刻関連列がある場合。timestamp / interval / other / unresolved。原値を保存|
|absolute_origin|M 状態付き値|既知ならtimezone付き時刻、時系、精度/出典。登録時刻と分離|
|clock_ref|M 状態付きID|同一fs・同じNは同一時計の証拠にしない|
|sync_relations|M list|他timebaseへのoffset/drift/uncertainty、有効区間、証拠、補正済みか。未知は明記|
|tolerance_policy|M object|測定丸め/時計/数値誤差を区別、policy IDと根拠。未設定なら等間隔認定不可|
|parent_timebase_ref, transform_ref|C refs|再構成・補間・再標本化した場合必須|

uniformの定義は `t(i)=origin+i*dt, 0≤i<N`。explicitは有限で厳密単調増加。逆転/重複がある原本は保護して残すが、その時間軸に従う解析をUnavailableとする。欠落sampleを黙って詰めない。非等間隔も保持できるがFFT等のconsumerがuniformを要求するときはUnavailable。時間解釈不明ならsample単位の診断表示のみ可能で、秒範囲選択・周波数解析は禁止。

p/uとRPMは別TimeBaseを許可する。時計関係不明でも各CHの単独表示はできるが、回転同期/PU位相解析は不可。補間はSignalViewで自動実行せず、方式・境界・遅延・誤差を持つ派生操作とする。丸め時刻の正規格子化も派生であり原列を置き換えない。

秒区間[a,b)は実sample時刻が `a≤t(i)<b` のsampleを選ぶ。uniformでも境界丸めを無条件epsilonで動かさず、要求範囲・決定した[start,stop)・実時刻を併記する。explicitでは順序探索相当。最終sampleの後端時刻を非等間隔軸から推測しない。index範囲は常に0≤start<stop≤N、stop=Nを終端sentinelとして表す。同期や格子許容差は計測精度・解析周波数帯の要求に基づき決め、既存16epsや1e-6を新標準へコピーしない。

## 6. SignalChannels

|フィールド|必須性・型|意味・許容値|
|---|---|---|
|channel_id|M string|Recording根内の論理信号ID。取得CHの系列と派生論理CHを区別し、詳細は§16。表示名は別|
|channel_kind|M enum|acquired / synthetic / derived_logical。channelの系列種別であり表現ごとのoriginと別|
|source_binding|M 判別可能な参照型|raw / derived / syntheticのいずれか。各必須欄は§15。CSV列を全種類へ強制しない|
|physical_quantity / unit|M enum/string|voltage V、pressure Pa、particle_velocity m/s、rotation_speed rpm。未解釈はunknownで物理解析不可|
|measurement_role|M 状態付きenum|pressure_sensor_output / velocity_sensor_output / rotation / other。raw Vの取得役割を示し、physical_quantityを上書きしない|
|signal_ref|C array ref|presentのとき必須。arrayのdtype、shape、axes、hash、対象member/sliceを指定|
|timebase_ref|M EntityRef|信号長とsample_count一致|
|sensor_id|M 状態付きID|既知ならsensor表へ解決。raw電圧だけならUnknownを許す|
|calibration_ref|C EntityRef|校正を適用した物理値で必須。合成物理値はorigin syntheticと生成由来を必須化し、実機校正済みとはしない|
|value_stage|M enum|raw_voltage / physical_waveform / unknown。TF補正はこのstageを変更しない|
|availability|M enum|present / missing / unavailable / unknown。値と別管理|
|validity|M enum|unchecked / valid / invalid / partial。validは明示policy範囲でのデータ検査合格|
|origin|M enum|measured / synthetic / derived / legacy_placeholder / unknown|
|valid_regions / quality_refs|C index区間 / refs|partialなら有効区間必須。invalid/missing等は理由必須|

意味的標準はCHごとの実数1D `[sample]`。共通格子のCHを物理格納で `[sample,channel]` にまとめてもよいがcolumn→channel_idの一対一対応が必須。CH順は意味を持たず、名前による選択で取り出す。TF複素値は別DerivedArtifact。変換時のdtype縮小・量子化は処理履歴へ記録する。

presentかつvalidな領域ではfiniteを要求する。非有限/クリップ等の領域は明示invalid/partialで保持できるが、消費側へ通常値として流さない。missingのsignal_refはなし。旧placeholderを監査用に残す場合はそのassetを診断参照に置き、present信号として公開しない。実測の全ゼロはmissingとはしない（定値品質検査は別）。p-only/u-onlyを構造違反にしない。最大24CHをschema制約にしない。

## 7. SensorMapping

|フィールド|必須性・型|意味・整合性|
|---|---|---|
|sensors[id]|M map（空可）|sensor ID、種類、serial/probe IDの状態付き値、証拠。probe係数キーと実体IDを区別|
|frames[id]|M map（空可）|軸名、handedness、原点、長さ単位m、親frameとtransform/証拠。未確認なら座標変換不可|
|pairs[pair_id]|M map（空可）|pair IDはRecording内で一意|
|pressure_channel_id / velocity_channel_id|M 状態付きCH ID|既知なら役割・unit整合、別CH。欠損側はUnknown/missing理由を明示|
|pressure_sensor_id / velocity_sensor_id / probe_id|M 状態付きID|同じprobeと仮定しない。別probeでも構造拒否しない|
|position / frame_ref|M 状態付き[m,m,m] / ref|p/u別位置を保持。pair中心の一座標で共置性を偽装しない|
|velocity_positive_direction|M 状態付き3-vector|既知ならframe内の単位方向。符号/極性/証拠も保持。未知を[1,0,0]にしない|
|sync_ref / calibration_refs|M 状態付きref / list|CH/timebaseにある情報を参照して重複値を持たない|
|mapping_evidence / pair_quality_refs|M refs（空可）|未取得なら未確認。配線宣言と物理照合を別所見とする|

raw V段階のpairはmeasurement_roleとsensor bindingを照合し、Pa/m/sを要求しない。物理波形段階では加えてphysical_quantity/unitを照合する。役割未確認はUnknownであり矛盾とは別に扱う。既知参照のCH不在、役割逆転、同一CHをp/uに指定、pair_id/CH ID重複は意味検証エラー。異なるpairが同じCHを共有する場合は、明示aliasと用途があるときだけ許す案とし、デフォルトは曖昧な共有を拒否する。多方向プローブで一つのpを複数uと組にする用途はaliasで表現できる。装置上の可否は別確認。

ペア宣言の整合性とIntensity可否は別。位置・方向・位相補正・相対同期・適用帯域などconsumerの必要条件が不足すれば、その解析だけUnavailable。非共置測定を全体拒否せず、距離/方法の適用条件を確認するまで局所Intensityとして扱わない。方向不明でも単独pressure解析は継続できる。

## 8. Calibration / Quality

|CalibrationRecord項目|必須性|意味|
|---|---|---|
|calibration_id / revision_id|M|不変適用記録。モデルthreshold calibrationと無関係|
|input_refs / output_refs / channel_sensor_binding|M|どの値にどのsensor係数を使ったか。output側はこの記録を参照|
|method_id / implementation_ref / parameters_ref|M|感度、周波数依存、位相等の方式、版とコードhash、正規化/境界条件|
|coefficient_asset_refs / coefficient_units|M|使用した係数snapshotとhash、対応sensor/probe、証明書は状態付き参照|
|domain / corrections|M|time_waveform / spectrum / time_frequency、およびsensitivity/frequency_response/phase等の集合|
|applicability|M 状態付き構造|帯域、期間、温湿度、gain、方向、対象sample/CH、境界、除去DC/Nyquist、前提|
|execution_state / execution_ref|M|not_run / succeeded / failed / unsupported、実行証跡/理由。succeededは数値出力の成立|
|physical_validation / evidence_refs|M|not_assessed / supported / failed / inconclusive、検証範囲と証拠|
|uncertainty / warnings|M 状態付き値 / list|不明はUnknown。係数・結果の不確かさをゼロとしない|

TF上だけの補正で時間波形をphysical_waveformへ昇格させない。単一感度の適用は位相補正済みを意味しない。校正宣言だけの旧データは `declared_only` の品質所見を持ち、履歴がないまま校正recordを捏造しない。これを受領する場合、calibration_refは状態付きUnknownとして限定受領し、上表の完全なCalibrationRecord適合とは区別する。時間波形の申告物理値として保持できても、証跡を要求する解析にはUnavailableとする。

QualityFindingは `finding_id, scope(recording/channel/pair/view/process + revision/range), check_id, check_version, outcome(pass/fail/inconclusive/not_assessed/unsupported), reason_code, evidence_refs, assessed_at` を必須とする。severityと用途ごとのrequiredはpolicyが決める。親所見を消さず継承し、修復した場合は対象領域・新証拠を付けた解決関係で記録する。単一「calibrated」「valid」で全範囲の物理保証をしない。

## 9. ProcessingProvenance / Context

|ProcessingRecord項目|必須性|意味|
|---|---|---|
|process_id / run_id / method_id|M|操作の識別・実行識別・方式。experiment IDと別|
|implementation_ref / environment_ref|M 状態付きref|実装版/hashと選択root、依存版、環境。unknownなら再現性制限|
|input_refs / output_refs|M|実際に読んだimmutable asset/revisionをhashで拘束|
|parameters / calibration_refs|M object/ref|デフォルト展開済み値、単位、seedを使う場合はseed/RNG方式も記録|
|coordinate_mapping|M object|identity_slice / index_map / resampled_support / aggregate_support。元CH/sample区間へ到達|
|execution_state / quality_refs / duration|M|成功/失敗/未実行を別記。途中成果物は完了として消費しない|
|intermediate_refs|O|観察・再開に必要な中間成果物。保存政策はD-004|

provenanceは有向非循環の親参照。raw parse操作も含める。raw→校正→resample→windowで直接元sampleへ一対一に戻れない場合、実際に寄与した区間・kernel support・遅延/境界処理を返す。表示上の中心時刻と計算supportを別記する。パスがあるだけ/64桁hashがあるだけを完全性確認としない。再現可否はinputs_available、integrity_verified、implementation_available、environment_resolvedを別所見とする。

原本を上書きせず、処理対象の捕捉bytesとhashを一致させることを推奨する。原本同梱と外部immutable store参照はD-004で選択。原pathが消えても検証済みsnapshotがあるなら再現可能、hashだけで実体がないなら追跡参照は残るが再実行不可。処理前後の検証/公開手順はD-004/D-006へ要求として渡す。

MeasurementContextは `context_id, revision_id, measurement_id, binding_evidence, planned_ref, actual_record_ref, fields` を持つ。fieldsには運転回転数/負荷（値・単位）、温度/湿度、センサー配置ref、測定イベント、外乱、装置状態を状態付きで記載する。条件が変化する場合はtimebaseに結び付いた区間/系列を用い、設定RPMと実測RPMを区別する。必須なのは項目状態と出典であり、温湿度の未測定を全Recording拒否にしない。用途policyが必要条件を選ぶ。

外部metadataとの照合キーはU。推奨は収録source hashを含む明示bindingと測定実施IDの照合。hashは測定意味の証明ではない。ファイル名近似だけで自動結合しない。未登録はUnknownとして診断可能、不一致はcontext結合を拒否し、値だけを流用しない。実CSV先頭5行/第6行以降/第1列の情報はユーザー提供D-001条件であり、この調査で実ファイルを実証したものではない。

## 10. SignalView

|項目|必須性・意味|
|---|---|
|view_id / contract_version|M 不変選択ID/対応版|
|recording_ref / signal_revision_ref|M rootと具体的なrevision。最新版への可変参照禁止|
|selection|M ordered channel IDs、任意pair ID、timebase別[start,stop)または秒要求。両指定なら一致を検証|
|resolved_ranges|M 各CH/timebaseのsample範囲、実時刻、元source対応|
|units / stages / calibration_refs / sync_refs|M 親の情報を保持する読取結果。GUI側で再推測しない|
|quality_refs / eligibility|M 対象範囲の所見と用途別結果|
|read_contract|M 軸・dtype・shape・chunk条件。値を返すとき選択との対応を維持|

区間は半開。負index、逆順、空区間、範囲外、未知CHは明示拒否し、自動clipしない。秒範囲内にsampleがない場合はEMPTY_SELECTIONとしてUnavailable。p/u/RPMが別時計なら別範囲を返し、同長matrixへ暗黙結合しない。同期を必要とするconsumerは共通軸または証明済み変換を要求する。

SignalViewは読み取り専用という**意味契約**を持つ。NumPy writeable=Falseだけでは外部aliasによる改変を防げない。メモリviewは高速だがowner管理が必要、コピーは隔離が強いが大容量、遅延providerは部分読込に向くが寿命/失敗/原本差替えを扱う必要がある。推奨はimmutable snapshotを指す選択descriptor＋read-only providerで、小規模PoCではコピーを基準に比較する（SELECT）。同一snapshot・選択・校正状態を複数PoCへ渡し、片方の処理が他方の入力を変えないことをT-06で検証する。

## 11. 派生データとの境界

全DerivedArtifactに `artifact_id, type/version, input_view_refs, axes(name/unit/coordinates), values_ref, processing_ref, source_support, quality_refs` を要求する案とする。特徴量のIDと値は同じ行対応で保持し、シャッフル後も一致すること。具体的な数式と実行APIはD-003。

|処理|D-002で要求する追跡・意味|D-003以降で決める項目|
|---|---|---|
|固定時間窓|窓ID、start/stop、元timebase/CH、表示中心と計算区間|窓長/overlap、端部/padding|
|回転同期窓・次数|角度/回転軸と元時刻対応、RPM参照、補間support|角度再標本化法、次数分解能、低速/逆転条件|
|FFT/STFT/PSD|周波数Hz、時間座標、元窓、複素/実数、正規化ID、単位、片側/両側、DC/Nyquist|窓関数、FFT長、振幅/パワー/PSD換算の数式と検証|
|cross/MSC/位相差|CH順序、共役規約、正規化/平均区間、Hz、rad/deg等、同期・校正証拠|推定量、平均法、信頼性/成立条件|
|Active/Reactive Intensity|p/uの組・方向/符号・cross規約、単位W/m²の解釈、計算support|推定式、スペクトル密度なら単位/Hz、適用物理条件|
|特徴量/ML入力|feature schema、軸順序、単位/変換、元区間群、処理履歴|特徴定義、標準化のfit対象、モデル/分割/閾値|

例えば未正規化abs(FFT)²をPSDと呼ぶことは拒否できるが、D-002で唯一のPSDアルゴリズムを強制しない。選択mask、切出し矩形、表示範囲、実計算supportは別欄。混合窓/複数元区間を一つの連続区間へ偽装しない。

## 12. 不変条件・Validator

|ID|推奨不変条件|違反時の最小範囲|
|---|---|---|
|INV-01|acquired根→原本hash/取込解釈、synthetic根→生成仕様/実装/出力hash、混合派生→すべての親根への到達|根参照矛盾は拒否。実体可用性不足は別所見。§15参照|
|INV-02|quantity/unit/stage/origin整合|既知の矛盾はCH受領拒否。不明は該当物理解析不可|
|INV-03|CH長とtimebase一致、選択範囲一致|当該CH解析不可。構造のshape虚偽は受領拒否|
|INV-04|root内CH ID一意、参照先一意|Recording拒否。後勝ち/最初一致禁止|
|INV-05|pair参照/役割整合、重複共有明示|pair拒否。独立CHは利用可|
|INV-06|適用校正の入力/出力/係数/方法/範囲追跡|証跡必要解析不可。校正済み状態への無証拠昇格禁止|
|INV-07|派生から元区間supportへの到達|当該成果物の研究比較利用不可|
|INV-08|要求された同期/方向/位相条件を明示検証|依存する解析のみUnavailable|
|INV-09|原本・revision・View意味の不変性、hash一致|改変したasset/revisionを拒否。既存値に黙って更新しない|
|INV-10|missing/unsupported/invalidと実測ゼロを分離|違反CH拒否、0補完禁止|
|INV-11|品質/校正の領域限定と親所見維持|該当派生利用拒否、品質消去不可|
|INV-12|契約版・必須capability認識|不対応オブジェクトを実行前拒否|

Validatorは入力を書き換えず、次の4層の結果を返す案とする。

1. **構造**：型、必須欄、enum、配列記述。報告 `accepted/rejected`。未知版、重複ID、参照の曖昧さ、実体hash不一致などは拒否。
2. **意味/参照**：単位、段階、CH/time/pair、原本連鎖。範囲別findingを生成。未知と矛盾を区別。
3. **処理実行可能性**：consumerのrequirements＋対象View＋policyで `Ready / Ready with warning / Unavailable`。requiredにunknown/fail/unsupportedがあればUnavailable。warningでrequiredを迂回しない。
4. **科学的妥当性**：物理証拠の評価結果・適用範囲を保持。汎用schema検査だけでPASSを付けない。独立した試験/証明がない場合not_assessed/inconclusive。

戻り値の提案：`ValidationReport(contract_version, object_ref, structural_status, findings[], eligibility[{consumer_profile, target_ref, state, reasons, policy_ref}], checked_assets[])`。単一boolは禁止。構造拒否したデータは診断用隔離対象であり通常consumerへ渡さない。部分利用の場合は、合格したCH/Viewだけを明示して渡す。

|reason code案|種別・挙動|
|---|---|
|UNSUPPORTED_VERSION / UNKNOWN_CAPABILITY|契約拒否。unsupportedを正常としない|
|HASH_MISMATCH / AMBIGUOUS_CHANNEL_ID|全体または該当asset受領拒否|
|PAIR_ROLE_MISMATCH / DANGLING_REFERENCE|pair/派生の意味拒否、非依存CHは利用可|
|TIME_UNRESOLVED / SYNC_UNKNOWN / DIRECTION_UNKNOWN|依存解析Unavailable、単独sample表示などは残す|
|CHANNEL_MISSING / EMPTY_SELECTION|データ無し・選択無し。計算失敗と分離|
|CALIBRATION_DECLARED_ONLY / PHYSICAL_NOT_ASSESSED|policy次第でwarningまたはUnavailable。科学的合格にはしない|
|ASSET_UNAVAILABLE|一時I/O/未移送。実体改変と区別、再取得で再評価可能|
|COMPUTATION_FAILED|処理例外。入力invalidと断定せずエラー参照を保存|

例外は読込/処理の機械的失敗、警告は利用条件付きの所見、missingは未取得、unsupportedは能力/表現の未対応である。いずれもスコア0/正常へ変換しない。

## 13. 擬似データ例（提案・非実行fixture）

次は説明用抜粋であり完全な適合JSONではない。`Hraw`等は実hashではない。実fixtureはPoCで生成する。

```yaml
identity: {recording_id: org:R1, revision_id: rev:raw1, source_refs: [asset:csv1]}
timebases:
  tb: {grid_kind: uniform, sample_count: 30000, interval_s: 0.001,
       relative_origin_s: 0, origin_definition: first_sample, clock_ref: Unknown}
channels:
  ch01: {physical_quantity: voltage, unit: V, timebase_ref: tb,
         availability: present, origin: measured, value_stage: raw_voltage}
  ch02: {physical_quantity: voltage, unit: V, timebase_ref: tb,
         availability: present, origin: measured, value_stage: raw_voltage}
```

取込metadataでch01がpressureセンサー、ch02がvelocityセンサーに対応すると宣言されても、このraw値のquantityはvoltageのまま。校正process K1後にderived:D1/rev:physical1を作り、同じ取得CHの派生表現をPa/m/sにする。pair03はそのrevisionのCHを参照する。

SignalView V1はrev:physical1/pair03/10≤t<20 sを選び `[10000,20000)` を解決する。親rawにも同じindexが対応するのはK1が時間格子を変えない場合だけ。方向・相対同期がUnknownならpの単独波形解析はpolicy条件次第で可能だが、PU IntensityはUnavailable。別校正K2はderived:D2を生成しV1を変更しない。

## 14. D-003以降への引継ぎ

|工程|D-002から渡す要求|ここで確定しないもの|
|---|---|---|
|D-001 外部入力|原CSV保存、列/時間解釈/配線/metadata bindingの根拠、Unknown保持|実列配置・第1列の意味・外部ツールの照合方式|
|D-003 独立PoC|View/DerivedArtifact参照、requirementsと利用可否、単位/軸/正規化宣言|実行API、数式、モデル、例外ラッパーの実装|
|D-004 保存|immutable revision/asset、hash検証、部分読込、親解決、途中成果物識別|NPZ/HDF5/ディレクトリ/commit方式|
|D-005 組合せ|能力/契約版不一致を実行前拒否、方式変更で履歴を分離|Registry/DAG/Plugin基盤の採用|
|D-006 再現|run/experimentとrecording分離、snapshot/seed/実装環境/比較入力固定|登録DB、実験UI、完全再現環境の配布|
|D-007 GUI|読み取りモデル、状態/理由/元範囲表示、値・校正のGUI内複製禁止|画面構成、非同期/キャンセルAPI|

実装前に決める最小事項は判断台帳J03〜J10。実ファイルが未入手でもT-01〜09の合成契約比較は可能だが、それをD-001や実機校正の実証にしてはならない。追加調査はround02 U1〜U8の必要分に限定し、全体再読込しない。

## 15. SourceBinding：信号表現の直接の由来

**P/EARLY、J20**。SourceBindingは「この信号表現をどこから得たか」という直接辺だけを持つ。ProcessingRecordは処理方法/パラメータ/実装/実行証跡の唯一の所有者、CalibrationRecordは校正適用の所有者、originは直接生成過程の要約である。履歴全文をSourceBindingへ複製しない。各refは不変revisionへ解決する。

推奨は `kind` で判別するraw/derived/syntheticの意味的union。共通辞書＋自由拡張は相互排他欄を検証しにくく、Provenanceだけで統一する方式は単純な列位置の解決にも履歴探索が必要になる。型付きunion＋ProcessingRecord参照なら直接取得と複雑な処理を分離できる。Pythonクラス階層を必須化しない。

|種類/フィールド|必須性|意味・検査|
|---|---|---|
|共通 kind|M enum|raw / derived / synthetic。未知は対応capabilityがなければ拒否|
|raw.source_asset_ref|M AssetRef|実際にparseしたbytesのhash/sizeを結合。source_hashの別コピーは禁止|
|raw.locator|M tagged object|CSVなら列index規約（0始まり）、元header、数値開始行（1始まり）、行範囲。datasetならdataset path/軸/slice。適用しない欄は持たない|
|raw.parse_record_ref|M ProcessingRecord ref|parser ID/版/実装hash/読込設定/時刻解釈がここへ解決。未知実装はUnknown証跡として再現性制限|
|raw.acquisition_channel_key|M 状態付きstring|機器のCH名/番号。D-002 channel_idと別。Unknownでも列locatorが一意なら診断取込可|
|raw.raw_unit / time_interpretation_ref|M unit / ref|V等の原値unit、TimeBase解釈への参照。未知をSIにしない|
|derived.process_ref|M ProcessingRecord ref|校正/フィルタ/resample/合成重畳/混合等はmethod_idで区別|
|derived.output_port|M string|処理のどの出力がこの表現か。一意であること|
|derived.parent_edges|M 非空列|各要素はinput_port、parent representation ref、source_support参照。ProcessingRecord input_refsの該当要素と一致|
|synthetic.generation_ref|M ProcessingRecord ref|generator ID/実装版/hash、パラメータasset、RNG方式/seed、時間定義、出力意味、合成前提に解決|
|synthetic.output_port|M string|生成器のどのCH出力か。時間/quantity/unitはCHとTimeBaseが正、生成仕様と一致|
|synthetic.reproducibility_requirement|M enum|exact_bytes / numerical_budget / statistical_only / unresolved。実現済み保証ではなく目標。budget/ref不足なら未検証|

生成時にRNGを使わなければProcessingRecordに `randomness=not_used`、使う場合は `rng_id/version, seed, stream/substream, generation_order` を記録する。seedだけでは多CH・並列生成の再現条件として不十分。パラメータ・異常区間/帯域/センサー設定はhash付き生成仕様に保存し、正解ラベルは別truth assetに置く。通常consumerへ供給するViewは値/単位/品質/由来参照を含むが、truthや異常設定を特徴量へ渡さない。完全監査用の解決と科学計算用読取を分離する。アクセス制御の実装はD-003/006。

|具体例（P）|Bindingと追跡|誤解を防ぐ条件|
|---|---|---|
|実測CSV CH03 V|raw→CSV asset/列2/parse P1→TimeBase|pという列名でもVをPaへ変更しない|
|同CHの校正p|derived→calibration process K1→raw representation、CalibrationRecord|単位変更と適用領域を出力で検査|
|正常/異常合成p,u|synthetic→generator G1→仕様asset/実装/出力hash|sensor校正実行済みとは宣言しない。generatorの物理モデル前提を保存|
|実測p＋合成異常s|derived→mix M1、親edges=[実測p表現, synthetic s表現]|実測根は維持しsynthetic親根も列挙、origin=derived。純実測/純合成と誤表示しない|
|複数CHの和/差|derived→multi-input process、各parent/区間/係数参照|別時計・unitが整合しないまま演算不可。新論理CHを作る|

rawのoriginはmeasuredを基本とし、原本自体が合成出力であればsynthetic由来を別途明示しrawファイル包装だけでmeasuredへ昇格させない。由来を証明できない旧ファイルはorigin unknownとして限定受領する。derivedのoriginはderived、syntheticのoriginはsynthetic。channel_kindは取得系列を示すため、acquired CHの校正表現がorigin derivedであって矛盾しない。

Validatorはkindごとの必須欄、port一意性、親ref一致、単位/時間、循環、hashを検査する。親実体が一時不在はASSET_UNAVAILABLE、存在しない参照やhash不一致は拒否。不明parser/生成実装の版はUnknownの証跡で保持できるが、再生成可能とは判定しない。親sample対応がない派生を正確な追跡付きデータとして受領しない。診断隔離は§18の限定用途報告へ分ける。

## 16. Revision・CH・表現の識別と部分変更

**P/EARLY、J21/J22**。SignalRevisionはその時点のCH表現選択・pair/context/quality参照の不変manifestである。値配列の全部コピーではない。

|識別子/参照|意味・必要性|
|---|---|
|Recording ID|取得/生成根のnamespace。混合出力は所属根を一つ指定するが、他の寄与根はparent_refsから必ず辿る|
|Revision ID|根内で一意なmanifest版。親revisionを固定。部分変更でも新manifestを発行|
|Channel ID|根内の論理信号系列。校正/同一CHフィルタ/resampleでは維持。多CH合成や異なる意味の信号には新規ID|
|Signal representation ref|推奨は `(recording_id, defining_revision_id, channel_id)`。別UUIDを増やさず、定義元revisionの実体を指す|
|Derived ID|独立した派生Artifactの識別。時間波形Revision全体が成果物ならそのrevision refを正規IDとして用い、別IDはaliasに留める|
|SignalView ID|具体revisionと選択を固定した読取要求のID。値の生成IDではない|

|SignalRevisionフィールド|必須性・意味|
|---|---|
|recording_id / revision_id / parent_revision_refs|M。初期版は親空、更新版は親非空。多親は明示|
|channel_entries|M map[channel_id,representation_ref]。全有効entryを一意に解決する意味を持つ。保存時差分化はD-004|
|representation_definitions|M map（空可）。当revisionで新規生成した表現のみ。外部root表現の再利用はnamespace付きref|
|excluded_channels|M list（空可）。意図的に今回のmanifest対象外にしたCHと理由。未取得missingと別|
|mapping_ref / context_ref / quality_refs|M。旧版の参照再利用可。参照先も不変|
|process_refs|M list。新生成/選択変更の履歴。親証跡の複製は不要|

変更しないCHは元のrepresentation_refを共有する。新しいR1のentriesがR0定義を指すのは正当だが、未変更CHを新値として再定義したことにはしない。共有値/metadataの上書き禁止。GC/削除は参照される資産を破棄しない（D-004）。意味的manifestは完全解決可能でなければならず、保存差分の欠落は受領失敗。

### B1：PU03だけ別校正

入力R0はPU01〜12のraw表現、R1は校正K1による物理表現とする。R2を作り、PU03のp03/u03だけをR0のrawからK2で再校正する。K1出力へ黙ってK2を二重適用しない。

|対象|R1 entry|R2 entry|履歴・比較|
|---|---|---|---|
|p03/u03|R1定義p03/u03|R2定義p03/u03|両者の親はR0 raw、K1/K2の適用scopeは当2CH。値/単位/元sampleで比較|
|他22CH|R1定義各CH|同じR1 representation ref|配列・校正・qualityは同一。K2を全CHへ付けない|
|Vold/Vnew|revision R1/pair03|revision R2/pair03|Voldは変更されない。別ID比較でも元CHとsupportを対応付ける|

K2が一部区間だけなら出力representationは処理範囲と未処理範囲を明示し、CalibrationRecord applicabilityとQualityFinding scopeをその区間に限定する。単一calibration_refが必要なら区間別適用記録へ解決するrefを用い、全長を校正済みと偽装しない。厳密な最小PoCはまず2CH全長再校正とし、部分sample校正は条件付き追加とする。

### B2〜B4

|ケース|状態遷移|ID/時間/品質の扱い|
|---|---|---|
|B2 CH03だけフィルタ|R2→R3、同channel_id、新representation|method/遅延/境界/source_support必須。同じtimebase値でも相対位相条件を再評価。数値変更なしとしない|
|B2 CH03だけresample|R3→R4、新representation/TimeBase|他CHは旧格子。pairの再利用可能性を再評価し、同期・補間証拠なしに共通matrix化しない|
|B3 p01−p02|R4→R5、新channel_id d01、channel_kind derived_logical|parentsに両CH、各support、符号/係数。Paの差として宣言できても実在sensor p01と同一ではない。sensor_idはNotApplicableまたは明示仮想定義|
|B4 取得CH追加|新revisionで新channel_id|取得実体/原本を追加参照し、収録セッションが別なら別rootとして結合。後から収録したものを元収録と偽装しない|
|B4 欠損|entry内availability missing、signal_refなし|予定CHの存在と値なしを維持。0配列を発行しない|
|B4 利用対象外/削除|新revisionのexcluded_channels、旧entryは旧版に残る|物理的未取得を意味しない。古いViewは解決可能。新Viewで選択すればCHANNEL_EXCLUDED|

同一CHの複数表現を同一manifestの一entryへ曖昧に登録しない。比較には複数Viewを使う。同じsampleを2回選ぶ窓は別selection IDを持てるが、元sampleが異なるとは主張しない。

## 17. ConsumerProfileと用途別ValidationReport

**P/EARLY、J23**。ConsumerProfileはデータの必要条件を宣言し、計算手順・ジョブ起動・モデル設定を持たない。条件はD-003のアルゴリズム設定から必要部分を解決した具体profileとして固定できる。任意コード/式のevalをValidatorへ渡さない。

|フィールド|必須性|意味|
|---|---|---|
|consumer_id / profile_version / profile_ref|M|不変要求集合。consumer実装版とは別。profile内容hashで固定|
|accepted_contracts / required_capabilities|M|対応版と必須意味。未知なら事前拒否|
|purpose / policy_ref|M|diagnostic / exploratory / scientific等の目的と不変policy。語だけで条件を緩めない|
|input_roles|M 非空列|role ID、quantity/unit、CH個数(min/max)、pair関係。role→View CH対応を明示|
|requirements|M 条件列|condition_id、対象role/scope、predicate名、parameter/ref、requiredかadvisoryか、証拠要求。型定義済みpredicateのみ|
|prohibited_conditions|M 列（空可）|placeholder利用、非有限対象領域、無断補間など。成立時Unavailable|
|allowed_warning_codes|M 集合|advisoryで残せる理由code。required不成立をここで許可できない|

predicate群はquantity/unit、count/pair、finite/valid_regions、grid_kind/count/coverage、synchronization、calibration domain/帯域/証跡、phase、position/frame/direction、provenance completenessで足りる。要求なしは「評価不要」であって「条件が真」ではない。数値閾値はprofileの根拠refが必要。profile間で条件を一律に揃えない。

### 最小要求の比較（P：具体方式でさらに限定する）

|consumer案|信号/時間の必須条件|校正/空間/品質の条件|不足時の例|
|---|---|---|---|
|p時間波形表示 diagnostic|1 pressure Pa、解釈済み時間。sample表示別profileなら秒軸不要|declared_onlyを明示表示するprofileは可、方向不要。missingと有効範囲表示|p値がVならp表示profile不可、電圧表示へ明示変更|
|RMS（pの離散sample RMS）|1 p Pa、非空finite有効sample範囲|方向/他CH不要。証跡要求は用途別。時間平均RMSは重み/時間解釈の追加条件|pだけでReadyになり得る。RMSの数値定義はD-003|
|FFT（通常等間隔方式）|1対象quantity/unit、uniform、方式の必要N/有効区間|方向不要。物理振幅比較では校正帯域/前処理を要求|grid unresolvedはUnavailable。非等間隔専用方式とは別profile|
|MSC|2 role、共通時間対応/相対同期証拠、方式が要求する区間長/平均集合|方向は必須にしない。校正要求は方式/用途で宣言、単位の整合した意味が必要|p/u同期UnknownならUnavailable。方向だけUnknownでは止めない|
|p/u位相差|p/u、相対同期と位相規約、対象帯域|測定系相対位相の補正/既知性が必須。方向は符号解釈に必要なとき要求|校正phase宣言だけで物理補正確認済みにしない|
|Active/Reactive Intensity|p Pa/u m/s、時間対応、共役/符号規約へ解決|方向/frame、配置適用条件、相対位相/校正帯域/物理条件を要求|方向UnknownはUnavailable。局所Intensity適用条件は方法依存|
|回転同期解析|対象CH＋RPM等の回転role、カバレッジ、既知の時計対応|補間/回転方向/低速処理など方式条件へ解決|別時計自体は不正でない。関係不明ならUnavailable|
|ML特徴量生成|宣言feature schemaに必要なrole/時間/区間/由来|構成特徴のrequired条件の和集合、単位/正規化/品質を維持。truthアクセス禁止|特徴ごとの未評価を0補完せず、明示対応するモデルだけ部分特徴を利用|

校正Unknownのp表示がwarningで許されるのは、そのprofileが「申告単位の診断表示」を対象とし物理証明をrequiredにしていない場合だけ。科学的振幅比較profileのrequired校正不足はUnavailable。実行成功はこれらの判断と別である。

### 判定規則とreport

1. 不正構造・参照/単位矛盾は該当object/scopeをrejectedとし、当該Viewのeligibility=Unavailable。曖昧なID等は全manifest拒否。独立CHの欠損だけでは全体拒否しない。
2. 固定View/Revision、profile、policy、証拠snapshotに対し各条件を `satisfied / failed / unknown / unsupported / not_applicable` で評価する。requiredのnot_applicableはprofileが明示許可した場合だけ成立扱い。
3. requiredが1件でも非成立、禁止条件成立、証拠矛盾未解決ならUnavailable。requiredをadvisoryへ実行中に格下げしない。
4. required成立かつ未解決advisoryがある場合、そのcodeが許可済みならReady with warning、許可外ならUnavailable。すべて成立ならReady。空の証拠を科学的PASSとしない。
5. QualityFindingが矛盾する場合、check/scope/revision/evidenceを照合する。明示supersedesとその根拠があるもののみ更新扱い。それ以外はEVIDENCE_CONFLICT。最後の行優先は禁止。用途が違う判定は矛盾ではない。

ValidationReportの唯一の用途判定欄を `eligibility[]` とする。各要素は `consumer/profile_ref, policy_ref, view_ref, revision_ref, resolved_roles/ranges, state, condition_results, reason_codes, explanations, quality_refs, evidence_refs, unresolved_conditions, recheck_triggers` をMとする。最上位はstructural_status、checked_assets、report ID/版/作成時刻。profile/policy値や元quality全文は参照し、説明文と機械codeを分離する。

再評価条件は入力revision/asset完全性、profile/policy版、校正/同期証拠snapshot、適用時間/帯域の変更。古いreportは古いsnapshotへの記録として保持し、新入力に流用しない。判定時刻だけを変えて同じ条件を異なる状態にしない。有効期限判定が必要なら評価時点もpolicy入力として固定する。

処理中のI/O/計算例外はProcessingRecordのfailedであり、事前Readyを「入力が実はinvalidだった」と書き換えない。後に新しい入力不良証拠が得られれば別reportを発行する。

## 18. Adapter変換契約・AdapterReport

**P/EARLY、J24**。Adapterはsource contractの意味を解釈し、target contractへ明示写像する境界。校正やresampleを内部で行う場合もProcessingRecordを作り、単なる配列変換に隠さない。Validatorは意味の検査、Adapterは変換、ConsumerProfileは用途条件である。

|Adapter宣言項目|必須性・意味|
|---|---|
|adapter_id/version、implementation_ref|M。どの変換実装か|
|source_contracts / target_contract|M。名前/版/対応variant。Observer等の無版型は実装snapshot hashとvariantを固定して受領|
|input_requirements / auxiliary_metadata|M。値/軸/単位/CH/時間/状態と追加metadata要件、不明許容範囲|
|mapping_spec_ref|M。値の変換、軸転置、ID表、時間/元区間、校正/品質/由来の写像と損失規則|
|output_capabilities / exclusions|M。提供可能な意味と対応しない用途。consumerのReadyを代行しない|

AdapterReportは `report_id/version, adapter_ref, source_contract_ref, target_contract_ref, process_ref, input_refs, output_refs, mapping_summary_ref, field_dispositions[], outcome, reason_codes, explanations, validation_report_refs, eligible_scope_candidates` を必須とする。output_refsは失敗/保留なら空。実処理のパラメータやエラー実体はProcessingRecord、検証結果はValidationReportを参照する。

field_dispositionは `source_field, target_field, status, evidence_ref, reason`。statusはpreserved / transformed / generated / unresolved / lost。generatedには正当なID発行・hash計算・記録からの導出の根拠を含み、方向/時計を推測生成しない。mapping表はsource旧IDとtarget IDの対応を保存し、ID文字列の一致を強制しない。

|outcome|意味と公開条件|
|---|---|
|conformant|target構造/意味契約へ変換済み。物理検証/consumer Readyを意味しない|
|limited|限定scopeのtargetだけ適合、または隔離診断表現のみ。範囲/禁止用途を必須表示|
|pending|必須入力/metadata/assetが不足、追加取得で再判定可能。通常consumerへ公開しない|
|rejected|矛盾/非対応契約等で変換不可。warningへ降格しない|
|failed|変換実行自体の例外。入力が不正とは限らない。部分生成物を成功出力に含めない|

limitedはCoreの不変条件を免除しない。正確な元sampleが不明な窓は適合DerivedArtifactとして公開不可。元NPZを診断assetとして保存してlimitedと報告できるが、target outputに「追跡可能な窓」を偽装して載せない。一部CHだけ適合する場合はそのCH scopeのみ出力する。

|欠落分類code|意味・扱い|
|---|---|
|MAPPING_UNSUPPORTED|入力に存在するがAdapter未対応。元assetは保持。必要欄ならpending/拒否、任意なら明示限定|
|NOT_RECORDED|入力自体にない。Unknownとして許容される欄のみ保持可|
|REFERENCE_UNAVAILABLE|参照はあるが実体を取得できない。pendingまたは用途制限。hash不一致とは別|
|TRANSFORMATION_LOSS|変換前にあった意味/精度が失われた。損失範囲/理由を記録、Core必須意味ならtarget拒否|
|INPUT_CONFLICT|入力同士の矛盾。拒否。値を勝手に選ばない|

### 具体的Adapterの成立条件（I/P、実装未実施）

|変換|成立条件・必要処理|不足/損失/不能時|
|---|---|---|
|Observer raw V→PhysicalRecording|実装variantと原asset、列/CH/時刻/単位を固定しraw binding化。開発版CH状態を保存|placeholderはmissing、原本hash不明はpending。位置不明はUnknown。旧metadataだけで取得実態を証明しない|
|Bridge校正波形→SignalRevision|raw根と校正入力/係数/実装/区間を解決。DC/Nyquist除去/周期仮定を保持|通常exportとstrictの保証差を記録。校正履歴欠如はdeclared_only限定、未確認を物理PASSにしない|
|Bridge TF→DerivedArtifact|[F,T]、複素/abs²、窓時刻/support、正規化/単位と校正domainを明示|abs²をPSDへ名前だけ変更しない。元波形の校正済み化不可。元窓不明は診断限定|
|Bridge window NPZ→窓Artifact|[W,2,L]とrecord IDs/start/元時間/単位/source bindingを解決|start欠落はNOT_RECORDED。転置だけで追跡適合としない。float32化が既存ならその精度を維持/記録|
|SignalView→NV InputAdapter入力|既存2CH Pa/m/s、共置/方向/共有clock/校正宣言、ID/metadata/hash要求を満たすViewだけ射影|不足方向を既定値で補完しない。多CH/別時計を勝手に縮約しない。provenance等がNV形式に入らなければsidecar保持とreport必須|
|外部CSV→raw PhysicalRecording|D-001列/時刻意味の確認、raw locator/parser/source hash、metadata binding|第1列未確定はunresolved時間。物理/秒解析不可。実CSV照合前にconformantな物理波形としない|
|合成→PhysicalRecording/Revision|synthetic rootまたはderived混合、generator仕様/実装/RNG/時間/単位/出力hash|実機校正済みとはしない。元実測へ追加する場合は実測親も保持。生成設定をモデル入力へ漏らさない|

sidecarを使う場合、target asset hashと対応IDを結合し、その消費側が参照しなければ由来保証が伝播しないことをreportへ明記する。既存NVコードを変更せず、外側で追加意味を管理できる範囲を別途検証する。

## 19. Core・条件付き情報・追加不変条件

**P/EARLY、J25**。巨大な別schema群に分割せず、同じ契約の必須欄＋状態＋capabilityで表す案を推奨する。Coreは最小受領条件であり科学用途Readyの保証ではない。

|区分|最低限必要な情報|Unknownの許容範囲・禁止される用途|
|---|---|---|
|Core|版/root/revision、CH ID/kind、quantity/unit/stage/origin、availability、信号ref/軸/長さ、TimeBase状態、SourceBinding、hash参照|quantity/time解釈Unknownは診断限定。ID曖昧/実体hash矛盾は不可|
|解析条件付き|pair、同期、座標、方向、必要N/帯域、校正/品質証拠、ConsumerProfile|Unknownは対応するrequired解析Unavailable。無関係CHの表示は許可可能|
|外部metadata|測定ID/運転条件/配線/環境/予定と実施の区別|未登録を正常条件にしない。要求する比較には利用不可|
|処理に伴う必須|derived parent edges/process/support、synthetic generator仕様、CalibrationRecord、quality継承|該当処理を行ってから必須。親追跡をUnknownで免除しない|
|保存・再現|全参照の解決/完全性、共有表現保護、実装/環境/係数/生成仕様asset|履歴が読めることと再実行可能は別。実装環境Unknownなら再現Ready不可|

追加INV-13：Binding kindごとの必須参照が解決し、複数親・合成の由来を隠さない。

追加INV-14：revision entryは一意のrepresentationを指す。未変更表現の共有は不変、派生論理CHを取得CHと同一視しない。

追加INV-15：eligibilityはView/profile/policy/証拠snapshotへ拘束され、required不成立をwarningで回避しない。

追加INV-16：Adapterの成功状態とtargetの適合scope/用途可否は別。情報欠落・損失と復元不能を機械可読で保持する。

INV-01〜12は§12の定義を維持し、INV-01だけ合成根/複数親へ一般化した。INV-04は論理CH一意性、INV-06/11はrepresentationと区間scopeへ適用する。親のqualityは変換supportへ投影して継承する。座標の写像が未確定なら影響を消さず、該当利用をUnknown/Unavailableにする。

最小PoCはCore＋raw/synthetic/derived Binding、immutable revisionの参照共有、4条件型（unit/grid/required evidence/provenance）、p表示/RMS/MSC/Intensity/回転の条件判定、明示AdapterReportから始める。数値MSC/Intensityの実装や汎用rule言語は含めない。T-08部分校正は既知感度fixtureで比較し、実機適合は別工程。D-003へはprofile検査後のView受領/失敗区分、D-004へは共有参照・report・asset保持、D-005へは同じprofile/出力意味による交換条件、D-006へは合成再現条件/truth隔離/不変比較を渡す。実行エンジン・保存形式は選ばない。
