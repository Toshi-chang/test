"""Named, frozen experiment plans: generation -> training -> evaluation."""
import copy
import itertools
import math
from pathlib import Path
import experiments as ex
from dataset import make_dataset, load_dataset
from physics import validate_config, case_names
from rpm_sensor import DEFAULT_SENSOR


def fields(config):
    result=[]
    if config.get('rotation'):
        result.append(dict(path='rotation.rpm',label='回転 / 一定回転数 [RPM]（開始・終了を同時変更）'))
    names={'rpm_start':'開始RPM','rpm_end':'終了RPM','variation':'ばらつき比率','ripple':'RPM揺らぎ比率',
           'distance_m':'距離 [m]','axis_angle_deg':'測定軸角度 [°]','level_rms':'励振RMS（SI）',
           'frequency_hz':'周波数 [Hz]','teeth':'歯数','shaft_ratio':'回転比','harmonics':'倍音数',
           'noise_rms_rpm':'測定雑音RMS [RPM]','delay_ms':'測定遅延 [ms]','smoothing_ms':'平滑時定数 [ms]',
           'gain_error_pct':'換算ゲイン誤差 [%]','offset_rpm':'オフセット [RPM]','update_hz':'更新周波数 [Hz]',
           'pulses_per_rev':'パルス数/回転','quantization_rpm':'量子化 [RPM]','dropout_probability':'欠測率'}
    for group in ('rotation','rpm_sensor','sensor'):
        values=(DEFAULT_SENSOR if group=='rpm_sensor' and config.get('rotation') else config.get(group,{})) or {}
        for key,value in values.items():
            if isinstance(value,(int,float)) and not isinstance(value,bool):
                result.append(dict(path=group+'.'+key,label={'rotation':'回転','rpm_sensor':'RPM測定','sensor':'p/u測定'}[group]+' / '+names.get(key,key)))
    for i,source in enumerate(config['sources']):
        for key,value in source.items():
            if isinstance(value,(int,float)) and not isinstance(value,bool):
                result.append(dict(path=f'sources.{i}.{key}',label=source['name']+' / '+names.get(key,key)))
        result.append(dict(path=f'sources.{i}.level_delta_db',label=source['name']+' / 基準励振からの増減 [dB]'))
    return result


def assign(config,path,value):
    if path=='rotation.rpm':
        config['rotation'].update(rpm_start=value,rpm_end=value)
        return
    parts=path.split('.');obj=config
    if parts[0]=='rpm_sensor':config.setdefault('rpm_sensor',copy.deepcopy(DEFAULT_SENSOR))
    for part in parts[:-1]:obj=obj[int(part)] if isinstance(obj,list) else obj[part]
    if parts[-1]=='level_delta_db':obj['level_rms']*=10**(value/20)
    else:obj[parts[-1]]=value


def build(data):
    name=str(data.get('name','')).strip()
    if not name or len(name)>120:raise ValueError('実験名を1〜120文字で入力してください')
    base=validate_config(data['config']);base['include_combined']=True
    if base.get('rotation'):base['rpm_sensor']={**DEFAULT_SENSOR,**(base.get('rpm_sensor') or {})}
    base=validate_config(base)
    variants=list(dict.fromkeys(data.get('variants',['pu'])))
    if not variants or any(v not in ('p','u','pu','pu_rpm_std','pu_rpm_fixed') for v in variants):raise ValueError('DL入力を選択してください')
    if any(v.startswith('pu_rpm') for v in variants) and not base.get('rotation'):raise ValueError('RPM入力には回転機械の基準条件が必要です')
    epochs=int(data.get('epochs',80));scale=float(data.get('rpm_fixed_scale',10000))
    if not 1<=epochs<=500 or not math.isfinite(scale) or scale<=0:raise ValueError('学習回数またはRPM固定幅が不正です')
    mode=data.get('combination','one')
    if mode not in ('one','grid'):raise ValueError('組合せ方法が不正です')
    labels={f['path']:f['label'] for f in fields(base)};axes=[];seen=set()
    for axis in data.get('axes',[]):
        path=axis['path']
        if path not in labels or path in seen:raise ValueError('変化項目が不正または重複しています')
        seen.add(path);values=list(dict.fromkeys(float(v) for v in axis['values']))
        if not values or len(values)>30 or not all(math.isfinite(v) for v in values):raise ValueError('各変化項目は有限な数値を1〜30個指定してください')
        axes.append(dict(path=path,label=labels[path],values=values))
    for path in seen:
        if path.endswith('level_delta_db') and path.replace('level_delta_db','level_rms') in seen:
            raise ValueError('同じ音源の励振RMSとdB増減は同時指定できません')
    if 'rotation.rpm' in seen and seen.intersection({'rotation.rpm_start','rotation.rpm_end'}):
        raise ValueError('一定回転数と開始・終了RPMは同時指定できません')
    n=math.prod(len(a['values']) for a in axes) if mode=='grid' else sum(len(a['values']) for a in axes)
    if n>200:raise ValueError('評価条件は最大200件です。候補値を絞ってください')
    combinations=(itertools.product(*[[(a,v) for v in a['values']] for a in axes]) if mode=='grid' else
                  ([ (a,v) ] for a in axes for v in a['values']))
    rows=[dict(id='base',name='基準評価（変更なし）',changes=[],config=copy.deepcopy(base))]
    import json
    signatures={json.dumps(base,sort_keys=True)};duplicates=0
    for combination in combinations if axes else []:
        cfg=copy.deepcopy(base);changes=[]
        for axis,value in combination:
            assign(cfg,axis['path'],value);changes.append(dict(path=axis['path'],label=axis['label'],value=value))
        cfg=validate_config(cfg);sig=json.dumps(cfg,sort_keys=True)
        if sig in signatures:duplicates+=1;continue
        signatures.add(sig)
        rows.append(dict(id=f'condition_{len(rows):03d}',name=' / '.join(f'{c["label"]} = {c["value"]:g}' for c in changes),changes=changes,config=cfg))
    if len(rows)*len(variants)+len(variants)>2000:raise ValueError('処理数が上限を超えています')
    warnings=[]
    roles={s['role'] for s in base['sources'] if s['level_rms']>0}
    for role,title in [('external','外乱'),('abnormal','異音')]:
        if role not in roles:warnings.append(f'{title}の有効な音源がありません。該当評価クラスは正常と同じ音になります。')
    if duplicates:warnings.append(f'基準と同一または重複する条件 {duplicates}件を統合しました。')
    if mode=='grid' and len(axes)>1:warnings.append('複数項目を同時に変更する計画です。単独要因の効果とは区別してください。')
    return dict(schema=1,name=name,purpose=str(data.get('purpose',''))[:2000],base=base,axes=axes,
                combination=mode,variants=variants,epochs=epochs,rpm_fixed_scale=scale,rows=rows,warnings=warnings,
                counts=dict(generation=len(rows)+1,training=len(variants),evaluation=len(rows)*len(variants)),
                parent=data.get('parent'),threshold='独立した正常校正収録の最大窓MSEの99パーセンタイル')


def locate(state,name):
    folder=state.path(name)
    if folder.parent!=state.outputs.resolve() or not folder.name.startswith('plan_'):raise ValueError('実験計画を選択してください')
    return folder


def create(state,proposal):
    folder=state.new_folder('plan')
    ex.save(folder/'plan.json',proposal)
    ex.save(folder/'state.json',dict(status='draft',comparison=None,rows=[dict(id='learning',name='⓪ 正常学習・検証・閾値校正',status='pending')]+
             [dict(id=r['id'],name=r['name'],status='pending') for r in proposal['rows']]))
    return folder.relative_to(state.outputs).as_posix()


def detail(state,name):
    folder=locate(state,name)
    return dict(folder=name,plan=ex.read(folder/'plan.json'),state=ex.read(folder/'state.json'))


def run(state,name):
    folder=locate(state,name);proposal=ex.read(folder/'plan.json');status=ex.read(folder/'state.json')
    status['status']='generating';status.pop('error',None);ex.save(folder/'state.json',status)
    reference=folder/'data/learning/dataset.npz'
    try:
        for i,task in enumerate(status['rows']):
            out=folder/'data'/task['id']
            if task['status']=='complete':
                if ex.digest(out/'dataset.npz')!=task['sha256']:raise ValueError('生成済みデータが変更されています。改訂版を作成してください')
                continue
            if state.stop.is_set():raise InterruptedError()
            task['status']='running';task.pop('error',None);ex.save(folder/'state.json',status)
            cfg=copy.deepcopy(proposal['base'] if i==0 else proposal['rows'][i-1]['config'])
            # Evaluation uses a separate seed namespace and copies only normal learning partitions.
            state.log(f'{proposal["name"]} / 生成 {i+1}/{len(status["rows"])}: {task["name"]}')
            make_dataset(cfg,out,state.log,state.stop.is_set,learning_dataset=reference if i else None)
            task.update(status='complete',sha256=ex.digest(out/'dataset.npz'))
            ex.save(out/'label.json',dict(experiment=proposal['name'],name=task['name'],role='normal_learning' if i==0 else 'evaluation',plan=name))
            ex.save(folder/'state.json',status)
        if state.stop.is_set():raise InterruptedError()
        if not status['comparison']:
            datasets=[(folder/'data'/r['id']/'dataset.npz').relative_to(state.outputs).as_posix() for r in proposal['rows']]
            request=dict(mode='fixed',training_datasets=[reference.relative_to(state.outputs).as_posix()],datasets=datasets,
                         variants=proposal['variants'],epochs=proposal['epochs'],rpm_fixed_scale=proposal['rpm_fixed_scale'])
            comparison=ex.plan(state,request)
            comparison.update(name=proposal['name'],purpose=proposal['purpose'],source_plan=name,
                              labels={p:r['name'] for p,r in zip(datasets,proposal['rows'])},
                              conditions={p:r['changes'] for p,r in zip(datasets,proposal['rows'])})
            output=ex.create(state,comparison);status['comparison']=output.relative_to(state.outputs).as_posix()
        status['status']='training_evaluation';ex.save(folder/'state.json',status)
        result=ex.run(state,state.path(status['comparison']));status['status']=result['status']
    except InterruptedError:
        status['status']='paused'
        for task in status['rows']:
            if task['status']=='running':task['status']='pending'
    except Exception as exc:
        status['status']='failed';status['error']=str(exc);state.log(str(exc))
        for task in status['rows']:
            if task['status']=='running':task.update(status='failed',error=str(exc))
    finally:ex.save(folder/'state.json',status)
    return dict(folder=name,status=status['status'],comparison=status['comparison'])
