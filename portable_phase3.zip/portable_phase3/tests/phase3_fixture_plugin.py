"""Test-only trusted extension: real fixed-window features and real NormalModel.

This module is deliberately outside nv_runner. Explicit registration is the only
way the execution engine discovers it; no test scores or labels enter inference.
"""
from nv_runner.routes import FixedWindow


class ExtensionWindow(FixedWindow):
    """Reuse the established numerical method under a separately owned entrypoint."""

    def prepare(self, records, service):
        return super().prepare(records, service)
