# 最小共通契約案

読み方：**採用候補**は現行をそのまま固定する案であり、全APIを新設する提案ではない。[確定済み]/[実装依存]/[仮契約]はREADMEの定義による。C01〜C08以外の内部データ型を全員共通にする必要はない。境界変更だけINTEGRATIONのCR対象。

## C01 観測入力・データ分割（入力 → 経路/実行）

- Producer：InputAdapter.load(manifest_path)。Consumer：DatasetPlanner/runner/各route/SignalService。
- [確定済み] `MeasurementRecord(meta: dict, signals: ndarray[N,2], rpm: ndarray[N] | None)`。pはch0 Pa、uはch1 m/s。N≥2・finite数値、同時計・等間隔、rpm rev/min。同じpairの同位置、u軸は長さ1。原点/座標系はmetadata記載、推測しない。
- manifest.schema_version=1.0、measurements要素はsource_path/source_sha256/metadata_path/mapping。mapping.axes=[time,channel]、signalsのNPZ key、rpmのkeyまたはNone。trainの正常表明はvalidate_configがnormal_only_attested=trueを要求。
- 必須meta：schema_version、specimen_id/case_id/measurement_id/derived_group_id、channels、timebase、calibration、operating_conditions、validity、protocol、data_kind。channelsはname/quantity/unit/position_m[3]/direction[3]/pair_id、timebaseはsample_rate_hz/start_seconds/signal_syncとrpm時rpm_sync、calibrationはstatus=calibrated/reference/units。validityは半開start_sample/end_sample/reasonの配列。load後source_path/source_sha256/metadata_sha256/n_samples/mappingが付く。任意acoustic_contract.versionも1.0のみ。
- [確定済み] train/evalの個体/case/hash/派生元を重複させない。fit/calは同一個体・元データ・祖先を共有する群を分けない。分割結果を保存。真値、scenario、IDを数値特徴へ入れない。
- 保証：[仮契約] consumerはRecord/配列/metaをin-place変更しない。現classはmutableなので「変更不能」とは主張せず契約試験で監視。producerは同IDへ別波形を再利用しない。
- 自由：実測フォーマット、校正手順の内部、圧縮方式、計測機固有ログ。未対応の校正/同期を仮定で埋めず失敗させる。
- 拡張：追加測定情報はadapter固有sidecar、record必須化はCR。非共置/複数pairはv1に混ぜない。
- ダミー/試験：fixtures.record_minimal、wave_recipe、CT01。

## C02 共有信号map・物理量（signals → routes/保存/表示）

- interface：[実装依存] `SignalService(config).maps(record) -> dict[str, ndarray]`、`pu_diagnostics(record) -> dict`。
- mapsの2D配列[frame,frequency_bin]：p_power/u_power、intensity/reactive_intensity、phase(rad)、msc[0,1]、valid(bool)、p_log_power/u_log_power。1D：frequency_hz[F]、frame_start/frame_end/support_start/support_end/display_center_seconds[T]。
- frame/bin区間終端は除外。displayは表示中心で、演算支持範囲を代用しない。timebase.start_secondsと既存sample-relative座標の整合を今後変えるならCR（現在の各表示はsample/fs基準）。
- [確定済み] v2のbin量とPSDの混同禁止。Cpu=Pconj(U)、p−u位相、signed axial active=Re(Cpu)、reactive=Im(Cpu)。legacyとv2はconfigで明示、未知規約拒否。無効binを信頼できる0として消費しない。
- Welch配列はfrequency/p_psd/u_psd/active_intensity_psd/reactive_intensity_psd/phase_p_minus_u_radians/msc/impedance_real/impedance_imag/valid。単位Pa²/Hz、(m/s)²/Hz、W/m²/Hz、rad、Pa·s/m。Zは混合場推定、特定音源の真値ではない。
- [仮契約] 共有mapも読取専用。cacheの実装や計算法は自由だが、同じconfig/recordでkey・座標・量の意味と許容差を維持。独自特徴は新keyをshared mapに直接追加せずroute内で計算できる。
- 未決定：将来の多sensor軸、別の物理field追加。既存mapを固定したまま別artifactで試作可。
- ダミー/試験：fixtures.wave_recipe（2048点→61frame×65bin）、CT02。STFT端のvalid、低energy、Parsevalを独立検証。

## C03 経路準備・入力/score対応（route → runner/model）

- [実装依存] `RoutePlugin(config)`、`capabilities()`、`feature_schema()`、`prepare(records,service)`、`fit(prepared,model_config,seed)`、`score(model,prepared,batch_size)`、`aggregate(prepared,results,records)`、`calibrate(cases,policy)`、`decide(rows,threshold)`を現行signatureで維持。capabilitiesの情報だけでrunnerが自動配線するわけではない。
- `PreparedSet(samples:list[dict], values:dict[sample_id,1D numeric vector], assets:dict[measurement_id,dict[array_key,ndarray]], coverage:dict[measurement_id,dict])`。feature_schemaは[(name,unit),…]。feature幅・順番・単位は同じmodelのfit/cal/evalで一致。
- sample最低項目：sample_id/route_key/specimen_id/case_id/measurement_id、start_sample/end_sample/support_start_sample/support_end_sample、frequency_hz=[lo,hi]、display_center_seconds、status=prepared|unscored、reason、parent_refs、operation、config_ref、software_version。空選択はsampleを残してvalues無し。Bのrpm欠落はsample0件とcoverage理由。既存RoutePlugin.addでID/座標を作ることを推奨。
- IDsはopaqueとして扱い、consumerが再計算・順序推測しない。runnerがinput_ref/input_row/run_id/splitを追加する。route担当はその保存用参照を勝手に生成しない。sample→values→scoredの対応はID基準。
- scoreの生出力：sample_id/route_key/case_id/status/scoredならfinite anomaly_score、unscoredならnull/reason、model_ref、score_definition_ref、evidence_ref=sample_id。score結果はsamplesと同じID集合・重複なし。model無しを正常へ置換しない。
- assetsはfinite numeric/bool、object不可。selection_mask/requested_mask等既存keyは意味を維持。独自assetは独自名。coverageはreason、incomplete、not_applicable（必要時）に加えroute固有の除外範囲等。全recordのledgerを用意。
- 自由：特徴アルゴリズム、切出し/探索/モデル内部。ただしfeature_schema/保存configに意味を残す。異なる幅を1モデルへ混ぜない。他経路を直接呼ばない。
- ダミー/試験：fixtures.prepared_recipeとfeature_rows、CT03。ダミーscoreは契約テスト専用で本番推論代用は禁止。

## C04 モデル（route → model）

- [実装依存] 現行NormalModel.fit(values[N,D],config,seed)→self、score(values[M,D])→finite float[M]、save(path)→joblib成果物。route.fitの返すmodelもscore/saveを備える必要がある。
- [確定済み] Scaler等の学習はfitのみ。cal/evalにfitしない。scoreは大きいほど異常、方向と定義を記録。閾値をscore関数が勝手に更新しない。batch/順序が変わってもID対応後の値を維持。
- 現行min_samples不足はValueError('insufficient_training_samples')をrunnerが特別扱いする。文字列を気軽に変更しない。新しいtyped error APIは未実装。未知のmodel kindはvalidate_configが拒否。
- 自由：既存境界に合わせる候補モデル、内部前処理。ただしrunnerは現状、前処理をStandardScalerとハードコードしscore説明もIF/PCAに固定。異なる前処理/score/modelの**本番結合にはmetadataとvalidatorのCRが必須**。候補の直接テストは先行可。
- modelロードAPI、推論-only CLI、ONNX等は未決定で今回の前提にしない。serialize formatを変えるときはartifact/reader契約も審査。
- ダミー/試験：fixtures.feature_rows、CT04。IFとPCAを別々に実学習しfinite/不変/不足を確認。

## C05 case結果・状態・根拠（route/runner → collector/viewer）

- [確定済み] execution=completed|failed|skipped、coverage=sufficient|insufficient|not_applicable、decision=within|outside|undetermined、sample status=scored|unscored。これらを1つのstatusに統合しない。未知enumは拒否。
- RouteCaseResult：route_key/case_id/specimen_id/execution_status/coverage_status/decision/case_score/threshold_ref/aggregation_ref/n_created/n_scored/reason/evidence_refs。runnerがrun_id/route_elapsed_secondsを追加。通常はobserved_seconds/scored_union_seconds/score_p95/events_per_secondも存在。failed fallbackには時間/分布値がない場合があるのでconsumerは欠落許容。
- [実装依存] max集約、cal95% higher・最低2個体、score>thresholdでoutside、同値を含む以下でwithinにするにはsufficient必要。閾値nullは未確定。有効な超過があればinsufficientでもoutside可。sufficientは全観測時間の100%評価保証ではない。
- 半開sample/support範囲は原本長内、supportがsample包含。frequency_hzはHz範囲（bin_range終端除外と混同しない）。選択格子と切出し・表示座標を分ける。
- 正常・異常未確定を混同行列の母数から消さない。未ラベルは別集計。個体判定はany outside / all within / other undetermined。異経路生score平均なし、fusion既定off。
- [仮契約] reasonは人可読の診断文字列として維持し、既存テストが使う理由token以外を外部ロジックの厳密enumにしない。任意の新理由を正常扱いしない。
- ダミー/試験：fixtures.decision_cases、CT05。threshold=.5、score=.5/.7/null、coverage違いを含む。

## C06 不変Bundleと保存読出し（runner/collector → viewer/output）

- [確定済み] schema_version='1.0'。writerはResultCollector.finalize(staging,manifest,destination)、readerはBundleReader(path).validate()→self.tables/self.manifest/self.path。collect APIは未実装。
- manifestはrun_id/requested_routes/completed_routes/bundle_status=complete|partial/members[path]={bytes,sha256}/completed_at/schema_version。JSON UTF-8・finite、NPZ allow_pickle=False。membersはmanifest自身を除く全ファイル、余分なファイルも拒否。未完stagingは通常readerで拒否。成功後はimmutable。
- 必須tables：specimens/cases/measurements/artifacts/samples/sample_results/route_case_results/case_results/errorsの各jsonl、experiment/dataset_split/environment/metricsのjson。models/arrays/logsは現行writer生成、truthは任意。
- 保存artifactはartifact_id/schema_version/operation/parent_refs/software_versionに、必要ならarray_file={path,sha256,arrays:{key:{shape,dtype}}}等。model artifactはpath/sha256/feature_schema/fit_sample_ids。ID参照、配列形状、sample/input行、件数が整合。
- [実装依存] viewer必須：signal:{mid}のwaveform/frequency_hz/p_log_power/frame_start/frame_end/display_center_seconds（rpm任意）、thresholdを持つartifact、sample/results/cases。選択用prepared:{route}:{mid}のselection_maskがあれば表示。pu_diagnostics:{mid}、truth:{mid}は任意だがある場合は既存配列keyを守る。writerとviewerの暗黙命名をここで固定する。
- 自由：保存内部の組立方式、UI描画。新情報は任意の固有artifact_id/operationで追加可。ただし同一schemaで既存必須fieldを削除/意味変更しない。新variantの拒否/無視方針はreader試験で確認。
- ダミー/試験：fixtures.bundle_recipeから新規quick生成。手書きの断片を完全Bundleとして渡さない。CT06で破損/参照不整合/余分なfile/任意truthなしを試す。

## C07 出力adapter（不変Bundle → 受領記録）

- [確定済み] `EvaluationAdapter.import_bundle(bundle_path,destination,path_mapping=None) -> receipt dict`。ローカルではrun_id＋manifest SHA同一ならalready_imported、同ID別内容はconflict。
- receipt：schema_version1.0/run_id/manifest_sha256/status=imported|already_imported/bundle_path/unresolved_sources。原本参照不明は[{measurement_id,reason:'source_unavailable'}]、Bundleを読めたことと原本確認済みを区別。
- [仮契約] 新transportは専用module/classへ。現行receiptを包むtransport固有記録は別ファイル、必須receipt enumへ未合意の'queued'/'sent'を混入しない。ローカル用receiptでremote完了を装わない。
- 未決定：ネットワークAPI、認証、再送時間、相手ID。ローカルfake destinationで開発可能。新remote protocolは実接続前に別CR。
- ダミー/試験：fixtures.receipt_recipe、CT07。X01再生成Bundleも使える。

## C08 実行設定・登録・真値境界（統合責務）

- [確定済み] validate_config(path)は(config,train,evaluation,fit,calibration,split)を返す。execute(config_path)→完成Bundle Path。config相対パスはconfigファイルの親基準。schema、model種別、経路パラメータ、train表明、分割を検証。
- route設定はkey（run内一意）/plugin/enabled/model＋固有parameter。共有signal/split/calibration/aggregation/fusion/exportは既存構造。defaultsはprofiles.py、configsファイルとdemoの生成設定は別なので勝手に同一視しない。
- [仮契約] 候補pluginの登録申請はkey候補・class import path・必要config・feature_schema・必要artifact・単独test結果を統合担当へ渡す。エージェントがREGISTRY/runner/CLIを同時編集しない。
- [確定済み] truthは全経路推論後に開く。generator/評価担当がtruthを変更しても観測Record/学習特徴に流さない。data/setting/modelをrun間で暗黙共有しない。
- [実装依存] 共有前処理・truth・finalizeの失敗は経路例外隔離の外。現在はnew run全再実行、完了段階の再利用なし。この制約を越える保証追加は新CR。
- ダミー/試験：fixtures.run_recipeと欠落rpm/空選択/no_events/route failureの変異。CT08。

## 最小の凍結宣言案

「C01〜C08の現行shape/意味/enum/参照をbaselineとし、所有者以外の共有ファイル編集をしない。追加の内部実装・担当専用config/testは自由。新しい必須field、単位、score方向、artifact名、登録方式はCRで共同確認する。」

この宣言に担当者名と基準commit（またはsnapshot hash）が入れば並列開発を開始できる。新規JSON Schemaライブラリ、サービス間RPC、全ファイルの分割完了は開始条件にしない。
