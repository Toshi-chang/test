import argparse
from pathlib import Path
from .common import read_json, write_json


def main():
    parser = argparse.ArgumentParser(prog="python -m nv_runner")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("demo")
    p.add_argument("--profile", choices=["quick", "comparison"], default="quick")
    p.add_argument("--output")
    p.add_argument("--generator",choices=["acoustic","legacy"],default="acoustic")
    p = sub.add_parser("generate")
    p.add_argument("--settings", required=True)
    p.add_argument("--output", required=True)
    for name in ("validate", "execute"):
        p = sub.add_parser(name)
        p.add_argument("--config", required=True)
    for name in ("inspect", "view", "import"):
        p = sub.add_parser(name)
        p.add_argument("--bundle", required=True)
        if name in ("view", "import"):
            p.add_argument("--output", required=True)
        if name == "import":
            p.add_argument("--path-mapping")
    args = parser.parse_args()
    if args.command == "demo":
        from .demo import demo
        demo(args.profile, args.output,args.generator)
    elif args.command == "generate":
        from .synthetic import generate
        settings = read_json(args.settings)
        if settings.get("generator")=="acoustic":
            from .acoustic_generator import generate_acoustic
            print(generate_acoustic(args.output,settings))
        elif settings.get("generator","legacy")=="legacy":
            print(generate(args.output,settings))
        else:
            raise ValueError("unknown generator")
    elif args.command in ("execute", "validate"):
        from .runner import ExperimentRunner, validate_config
        if args.command == "execute":
            print(ExperimentRunner().execute(args.config))
        else:
            config, train, evaluation, _, _, split = validate_config(args.config)
            print({"status": "valid", "train_measurements": len(train), "eval_measurements": len(evaluation), "split": split})
    elif args.command == "inspect":
        from .bundle import BundleReader
        reader = BundleReader(args.bundle).validate()
        print({"status": "valid", "manifest": reader.manifest["bundle_status"], "routes": reader.manifest["completed_routes"],
               "samples": len(reader.tables["samples"]), "metrics": read_json(reader.path / "metrics.json")})
    elif args.command == "import":
        from .bundle import EvaluationAdapter
        print(EvaluationAdapter().import_bundle(args.bundle, args.output, read_json(args.path_mapping) if args.path_mapping else None))
    elif args.command == "view":
        from .viewer import render
        print(render(args.bundle, args.output))


if __name__ == "__main__":
    main()
