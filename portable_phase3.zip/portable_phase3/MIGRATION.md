# Phase 3 移植・再検証手順

最初に [開発アーキテクチャ](docs/DEVELOPMENT_ARCHITECTURE.md) を読む。対象は2026-10-15完了版 PoC 0.2.0 / ResultBundle 1.0 / C01〜C08 / Python 130試験。新機能や契約変更を含めない。

## パッケージと根拠

`nv_runner/`, `tests/`, `tools/`, `configs/`, `development/`, `docs/`, `README.md`, `requirements.txt` の110ファイルは履歴ハッシュで確認したbaselineをバイト一致で複製した。Phase 3開始時ハッシュに完了時監査の変更後ハッシュを適用し、Phase 3記録対象外の上位文書・README・requirementsは前段の記録で照合した。各ファイルの由来は `manifest.json` に記録する。移植手順・本アーキテクチャ文書・移植検証スクリプト・ignore・検証結果は追加資産として区別する。

AGENTS.md、pyproject.toml、setup.py、setup.cfgは元プロジェクトに存在せず追加していない。`run_demo.ps1` は履歴ハッシュによるbaseline確認ができなかった任意ラッパーのため含めない。README内の同ラッパーの代わりに下記CLIを使う。重複した `development/docs/`, `development/development/` とZIPは除外した。正本は `docs/` と `development/`。

過去のデータ・モデル・Bundle・大量ログ・仮想環境は移送しない。テストに必要な `docs/parallel_contracts/fixtures.json`、設定断片、`tests/phase3_fixture_plugin.py`、viewerテンプレートは含む。`manifest.json` 自身は自己ハッシュの対象外。ファイル検証は次を実行する。

```powershell
python verify_migration.py
```

この検証はコピー完全性の確認であり、署名や信頼できないコードの安全性検査ではない。

## Windows環境

検証環境は64bit Windows / CPython 3.12.14。まずPython 3.12の64bit版を用意する。他のPython版・OSは今回未検証。パッケージ全体を任意の作業フォルダへコピーし、そのルートで実行する。

```powershell
py -3.12 -m venv .venv
& ./.venv/Scripts/python.exe -m pip install -r requirements.txt
& ./.venv/Scripts/python.exe -m pip check
$env:PYTHONNOUSERSITE = '1'
$python = (Resolve-Path ./.venv/Scripts/python.exe).Path
& $python verify_migration.py
```

依存はnumpy 2.3.5 / scipy 1.16.3 / scikit-learn 1.7.2 / joblib 1.6.0 / threadpoolctl 3.7.0 / cloudpickle 3.1.2。GPU・DL環境・HTTPサーバーは不要。オフライン先では別途同Python/OS/architecture対応wheelを準備し、`pip install --no-index --find-links <wheel-directory> -r requirements.txt` を使う。wheelやライブラリ本体は本パッケージに含まない。

今回の移植検証ではpipのネットワーク取得がWinError 10013で失敗した。代わりに独立venvへ元環境の上記6依存のインストール済みファイルのみを複製し、pip checkとバージョンを確認した。元プロジェクトや元venvを実行時参照する構成ではない。ただし新規オンラインインストール成功を実証したものではない。

## 試験と実行順序

以下はすべてコピー先ルートから実行する。外部のPYTHONPATH/PYTHONHOMEや元プロジェクトのeditable installを混ぜない。

```powershell
New-Item -ItemType Directory -Force reports/migration | Out-Null
& $python -c "import nv_runner; print(nv_runner.__file__)"
& $python -m unittest discover -s tests -p 'test_contract_c*.py' -v *> reports/migration/contracts.log
if ($LASTEXITCODE -ne 0) { throw 'contract tests failed' }
& $python -m unittest discover -s tests -v *> reports/migration/all_tests.log
if ($LASTEXITCODE -ne 0) { throw 'regression failed' }
```

契約試験22件、全体130件が `OK` となること。130には従来97件、Registry12件、Validator12件、交換7件、互換性2件を含む。テスト自体を変更して成功扱いにしない。テストは `tests/_work/` にデータ・モデル・Bundleを再生成する。新プラグイン明示登録、設定選択・交換・無効化、遅延import、未知契約版、不正schema、依存欠落、中央コード不変も既存試験が検査する。

```powershell
& $python -m nv_runner generate --settings configs/acoustic_quick_data.json --output data/acoustic_quick
& $python -m nv_runner validate --config configs/acoustic_quick.json
$bundleOutput = & $python -m nv_runner execute --config configs/acoustic_quick.json
if ($LASTEXITCODE -ne 0) { throw 'execute failed' }
$bundle = ($bundleOutput | Select-Object -Last 1).Trim()
& $python -m nv_runner inspect --bundle $bundle
& $python -m nv_runner view --bundle $bundle --output reports/migration/viewer.html
& $python -m nv_runner import --bundle $bundle --output evaluation_inbox
Start-Process (Resolve-Path reports/migration/viewer.html).Path
```

各コマンドの終了コード0、inspectのvalid/schema 1.0、5経路の結果、viewerの個体×経路一覧と波形・領域への逆引きを確認する。正常/異常の検出率100%は合格条件ではない。正解とモデル根拠を区別する。単一コマンドでも再生成可能：

```powershell
& $python -m nv_runner demo --profile quick --generator acoustic --output demos/quick_new
```

seed・測定条件はコピーした `configs/acoustic_quick_data.json`、分割・前処理・モデル・閾値は `configs/acoustic_quick.json` が正本。比較規模は `acoustic_comparison*.json` を使う。設定の相対パスは設定ファイル基準。変更時は元設定を残して別名で作成し、条件を結果と保存する。生成・学習は新しい空の出力先を使い、失敗Bundleを上書きして合格扱いにしない。途中学習のcheckpoint再開APIはないため該当実行を最初からやり直す。成功済みBundleの閲覧は学習不要。

Browserの自動QAはPython130試験とは別。Node.js・Playwright・Chromiumを別途導入すれば `node tests/viewer_smoke.cjs reports/migration/viewer.html reports/migration/viewer` が使える。追加依存はrequirements.txtに含まない。

## プラグイン追加と並列開発

[Phase 3実装記録](docs/validation/phase3_registry.md) と [所有表](development/ownership.json) を先に読む。

1. 専用moduleで現行RoutePluginとPreparedSet/NormalModel契約を満たす実装を作成する。
2. 統合担当が `nv_runner/plugin_catalog.py` に信頼済みDescriptorを明示追加する。Runner/共通Validatorに名前分岐を追加しない。単一プロセスの試験ではRegistry.registerを利用できる。
3. config_schemaと必要な固有validatorを宣言し、専用試験を追加する。未知契約版を使って既存契約を迂回しない。
4. 構成のpluginで選択する。既存fixed_window / fixed_window_candidateの交換例は `configs/parallel/plugin_exchange_*.json`。これはroutesへ組み込む断片で、単独の完全configではない。
5. enabled=falseで無効化。撤去は使用構成を除去してから登録を削除する。実装ファイルだけ削除して選択状態を残せば依存不在として失敗する。

並列開始時は [AGENT_TASKS](docs/parallel_contracts/AGENT_TASKS.md)、[INTEGRATION](docs/parallel_contracts/INTEGRATION.md)、[development README](development/README.md) に従い専用ファイルを割り当て、共通ファイルは統合担当だけが編集する。新しい担当/範囲は統合担当が所有表へ割り当てる。既存C01〜C08の変更が必要なら実装と分離して承認を受ける。Git/worktreeの自動設定は行わない。

## 実データ・別システムとの接続

InputAdapterを交換する場合はC01/C02、SI単位、時間・周波数軸、センサー位置/方向、RPM同期、個体/測定/派生元ID、校正情報、欠損状態を確認する。真値やIDをモデル特徴量に混入させず、fit/cal/evalの個体・派生元分離を保つ。合成音場の検証は実機精度や外乱分離の実証ではない。

ResultBundle 1.0のBundleReader/EvaluationAdapterを境界に使う。Bundleは元測定への参照を含み、Bundleだけの移送では元波形の逆引きが成立しないことがある。元測定も移送するかpath mappingを明示する。HTMLは生成時に埋め込まれた表示用データの閲覧用であり、モデル・元測定・再学習資産の代わりにはならない。モデルpickle/joblibは信頼済み成果物だけを読み込む。外部システムへの実接続は今回未実施。

元環境の絶対パスは実行コード/設定に必要ない。既存の履歴文書の絶対パスや `tests/test_independence_tools.py` の `C:/outside` はそれぞれ過去証拠・拒否試験であり、アクセス先として用意する必要はない。

## 過去成果物を必要とする保存済みツール

|ツール|移植後の条件|
|---|---|
|tools/verify_phase3.py|過去のreports/phase3/Iのbaseline Bundle・ログ・スナップショットが必要。未同梱のため歴史的な移行前後比較をそのまま再実行できない。今回の新規130試験・CLI再実行とは区別する。|
|tools/run_parallel_verification.py|比較対象baseline生成物を別途用意する。過去の両実装がない場合は過去比較を再現したとしない。|
|tools/replay_saved_checks.py / prepare_history.py|指定された過去Bundle / archive/examplesが必要。今回は未同梱。|
|tools/verify_transfer.py / build_transfer.py|旧01/02/03移送方式とTRANSFER_MANIFEST.json用。本パッケージのmanifest.jsonにはverify_migration.pyを使う。|

履歴の32/59/97試験などの記載を130に書き換えていない。実施当時の文書である。今回の実測結果・制約は `migration_validation.json` を参照する。

## Gitへ持ち込むとき

フォルダ全体のソース・契約・設定・tests・文書・manifestを管理対象とし、`.gitignore` 対象の生成物/環境/秘密情報を含めない。必須fixtureを拡張子だけで除外しない。今回はgit init/commit/push/remote設定を一切実行していない。後でコードを変更すれば移植時manifestの不一致は正常な変更検出となるため、元manifestをbaseline証跡として残して新開発の変更監査を別に行う。
