# 並列開発タスク分割とエージェント指示

以下は割当テンプレート。担当エージェントは未起動。パスはすべて独立PoCルートからの相対。参照プロジェクト・生成済みBundle・過去結果は全員read-only。依存ライブラリ追加は共有環境へ勝手にinstallせずCRにrequirements差分を添える。

## 所有範囲を先に分ける

各担当の専用**新規ファイル**を初期の書込範囲とする。下表の候補ファイルはまだ作成していない。既存のコードをその場所へ移動済みとも解釈しない。物理的な単一ファイルの領域分割（routes.pyの何行目から、等）では競合を防げないので採用しない。

|担当ID|作業単位/入力→出力|書込許可（初期）|着手条件と結合先|
|---|---|---|---|
|I 統合|共有境界・登録・実行/保存の結合|nv_runner/runner.py、routes.py、bundle.py、common.py、input_adapter.py、signals.py、models.py、profiles.py、__main__.py、__init__.py、demo.py、requirements.txt、既存configs、共有test、必要な新registry module|C01〜08凍結、各CR反映。初期は変更を最小化。他担当の専用ファイルを勝手に変更しない|
|D 入力|測定形式→観測Record|nv_runner/input_candidate.py、tests/test_input_candidate.py、configs/parallel/input_*.json、docs/workstreams/input.md|C01 baselineで即着手。実測未入手はdummyで開発、実機受入は保留|
|P 物理|音源/センサー条件→観測p/uと分離真値|nv_runner/physics_candidate.py、tests/test_physics_candidate.py、configs/parallel/physics_*.json、docs/workstreams/physics.md|C01/C02を変えず現acousticsを利用・比較。既存acoustics/acoustic_generator/verify_physicsの本変更はPへ専有割当後に限る|
|RA A|Record/map→A候補PreparedSet|nv_runner/route_a_candidate.py、tests/test_route_a_candidate.py、configs/parallel/route_a_*.json、docs/workstreams/route_a.md|C03/C05 baseline、既存FixedWindow/RoutePluginを読み込み直接試験|
|RB B|Record/rpm→B候補PreparedSet|nv_runner/route_b_candidate.py、tests/test_route_b_candidate.py、configs/parallel/route_b_*.json、docs/workstreams/route_b.md|C01/C03/C05で即着手。パルス変換そのものはDに要求|
|RC C|Record→イベント/PreparedSet|nv_runner/route_c_candidate.py、tests/test_route_c_candidate.py、configs/parallel/route_c_*.json、docs/workstreams/route_c.md|C03/C05で正常イベント/no_eventsを先に契約試験|
|RD D|map→パッチ/PreparedSet|nv_runner/route_d_candidate.py、tests/test_route_d_candidate.py、configs/parallel/route_d_*.json、docs/workstreams/route_d.md|C02/C03/C05で即着手。GPU/DLは現時点の必須条件にしない|
|M モデル|fit特徴→model、eval特徴→score|nv_runner/model_candidate.py、tests/test_model_candidate.py、configs/parallel/model_*.json、docs/workstreams/model.md|C04固定で直接fit/score/save可。kind追加と保存説明はIとの結合待ち|
|V 閲覧|保存Bundle→根拠表示|nv_runner/viewer.py、nv_runner/viewer.html、tests/viewer_candidate_smoke.cjs、tests/test_viewer_candidate.py、docs/workstreams/viewer.md|C06の新規生成golden Bundleで即着手。shared bundle.py変更は禁止|
|O 出力|検証済Bundle→receipt|nv_runner/output_candidate.py、tests/test_output_candidate.py、configs/parallel/output_*.json、docs/workstreams/output.md|C06/C07ローカルstubで即着手。相手APIは保留|
|Q 契約QA|fixture/全担当出力→適合報告|tests/test_contract_c01.py〜test_contract_c08.py、tests/contract_fixtures.py、docs/parallel_contractsの承認済み改訂、docs/validation/parallel_*.md|Iと契約採択。テスト閾値を実装に合わせ勝手に緩めない|

Iの一覧は「触ってよい候補」であり一括変更を要求しない。acoustics.py等の専有割当変更は所有表へ記録する。全担当の新規test内で生成する出力はtests/_work/<担当ID>/<uuid>/、固定フォルダの同時上書き禁止。新moduleは既存package直下に置く案なので共有__init__.pyを各人が編集する必要はない。

## 全員への共通指示（割当時にそのまま渡す）

1. 本設計README、担当するC契約、既存コードと該当testsを読む。確定済み/実装依存/仮契約を区別する。
2. 指定ファイルだけ編集する。共有ファイルの変更が必要ならCRを提出し、その箇所に依存しない実装/testを先に進める。他担当のファイルを修正して進めない。
3. 観測Recordとmapはread-only。正解やIDを特徴へ混ぜない。run内で入力・前処理・閾値を暗黙更新しない。
4. 小さなdummyで境界を試験し、次に新規生成acousticデータで実学習/評価する。stub scoreを本番成果として報告しない。
5. 出力にfeature_schema、config、元座標、未評価理由を残す。性能改善と契約適合を別々に報告する。
6. 完了時に変更ファイル、単独コマンド、契約ID、実施/未実施試験、失敗例、必要CR、統合順を返す。自動的に他担当へ依頼送信する前提は置かない。

## 担当別の受入指示

### D：入力adapter

- まず既存InputAdapterで受けられる有限SIペアへ変換する候補を作る。実形式不明ならreaderの入口だけを仮定し、変換後Recordを実契約に合わせる。
- calibration/reference/共置/方向/同期の欠落を推測で補完しない。C01負例とtrain/eval祖先漏洩の確認を提出。
- 必須成果：変換仕様、dummy→標準入力の例、単位/shape/欠落拒否テスト。分割方針を独自変更しない。

### P：物理・共通信号

- 既存の場の前提・位相規約を維持した候補を専用moduleで作る。新場が他の場と境界条件矛盾しないかを明示。
- CT02と既存物理試験を使う。SignalServiceのkey追加/scale変更はCR。最初は新artifactに診断を出す方式で進められる。
- 必須成果：数式/単位/適用範囲/seed、解析式との比較、真値を入力へ渡していない証拠。

### RA/RB/RC/RD：経路（4名に分割可能）

- 既存RoutePluginまたは当該pluginを継承/利用し、prepareと必要な経路内部を担当専用moduleで実装する。既存REGISTRYを編集しない。
- constructorへ既存形式configを渡し、prepare→fit→score→aggregate→calibrate→decideを直接呼んだ単独testを提出。接続前にfeature_schemaとID対応を検証。
- Aはrequested_mask/valid反映maskを分離、Bはrpm不成立と元時間対応、Cは0件/通常イベント不足を未確定、Dはlog powerの意味とパッチ計算範囲を保存。
- 候補名はintegration前にIから一意key/pluginを割り当てる。実験設定の数値は契約ではなく担当configに保存し、比較前に固定する。

### M：モデル

- 入力はID/ラベルなしの同幅数値行。fitに渡したデータだけで前処理を学習する。score方向を大きいほど異常へ揃える。
- 新モデルの直接testは既存validatorを経由しなくてよい。既存runnerのIF/PCA説明をそのまま新モデルへ流用しない。統合時に説明/前処理metadataの変更案を出す。
- 保存後ロードによる運用推論は新APIとして別CR。既存のsave成功だけで固定モデル運用が完成したとはしない。

### V：閲覧

- 計算中オブジェクトや生成器を読まず、BundleReader経由だけで構築する。古い任意artifactなしBundle、partial、nullを表示できるようにする。
- 凡例、軸、元範囲、真値/モデル出力の分離を優先する。表示追加のためrunnerの必須fieldを独自追加しない。
- 必須成果：fixture Bundleのスクリーン/操作記録。モデルjoblibを読み込まない。

### O：出力adapter

- 完成Bundleを検証後に渡す。ローカルfake destinationで重複・競合・欠損参照・部分失敗を試す。
- remote未接続を明示。受領完了やキュー状態を既存statusへ意味を変えて埋め込まない。

### Q/I：契約と統合

- Qはproducer単体だけでなくconsumerが読めることを検証する。テスト用断片と完全Bundleを区別する。
- Iは候補コードをコピーしてroutes.pyへ再埋込みする前に、既存基底を参照する専用moduleを直接呼ぶ最小配線を検討する。
- 例：将来route_registry.pyで現行REGISTRYと候補classを合成しrunnerのimportを変更する案。ただし新registry APIは未実装/未承認。循環import、validate_configの辞書、model metadata、software版を同じCRで確認する。

## 実行スロットが4つの場合の波分け例

全員を同時に走らせる必要はない。I＋Q＋担当2名を基本とする。

1. 波1：I（採択/接続準備）、Q（CT01〜08 fixture）、D（adapter）、V（viewer）。全体設計を待たない。
2. 波2：I、Q、P、M。共有map/モデルを変更しない経路案ならこの波を経路担当に入替可。
3. 波3：I、Q、RA、RB。波4：I、Q、RC、RD。各経路は直接testで開始し、Iが逐次結合。
4. 波5：I、Q、O、必要な修正担当。統合fixtureと全回帰を実行。

これは実行順の案であり、全タスクの要件確定を待つ直列ウォーターフォールではない。課題が軽ければ同一担当が役割を兼務するが、同じファイルの所有者は1名に保つ。
