# 外乱耐性マップ結果

正常対象のみ。改善・異常検出力の再評価は次段階。周波数100/220/350 Hz、3位置、12音圧、6正常群。旧3群は継続比較、新3群は追加評価。学習正常20群（fit16/cal4）は固定。

|経路|外乱なし 正常/群数|誤判定|判定不可|
|---|---:|---:|---:|
|A_full|2/6|4|0|
|A_selected|6/6|0|0|
|B_order|4/6|2|0|
|C_event|6/6|0|0|
|D_patch|6/6|0|0|

|経路|音源位置|Hz|外乱なし全群正常|連続正常の最終試験点 dB|最初の失敗試験点 dB|
|---|---|---:|---|---|---|
|A_full|original|100|False|None|None|
|A_full|original|220|False|None|None|
|A_full|original|350|False|None|None|
|A_full|front|100|False|None|None|
|A_full|front|220|False|None|None|
|A_full|front|350|False|None|None|
|A_full|side|100|False|None|None|
|A_full|side|220|False|None|None|
|A_full|side|350|False|None|None|
|A_selected|original|100|True|None|5|
|A_selected|original|220|True|10|15|
|A_selected|original|350|True|5|10|
|A_selected|front|100|True|None|5|
|A_selected|front|220|True|20|25|
|A_selected|front|350|True|20|25|
|A_selected|side|100|True|30|40|
|A_selected|side|220|True|60|None|
|A_selected|side|350|True|5|10|
|B_order|original|100|False|None|None|
|B_order|original|220|False|None|None|
|B_order|original|350|False|None|None|
|B_order|front|100|False|None|None|
|B_order|front|220|False|None|None|
|B_order|front|350|False|None|None|
|B_order|side|100|False|None|None|
|B_order|side|220|False|None|None|
|B_order|side|350|False|None|None|
|C_event|original|100|True|30|40|
|C_event|original|220|True|None|5|
|C_event|original|350|True|40|45|
|C_event|front|100|True|30|40|
|C_event|front|220|True|None|5|
|C_event|front|350|True|40|45|
|C_event|side|100|True|27.5|30|
|C_event|side|220|True|15|20|
|C_event|side|350|True|40|45|
|D_patch|original|100|True|60|None|
|D_patch|original|220|True|45|47.5|
|D_patch|original|350|True|30|40|
|D_patch|front|100|True|60|None|
|D_patch|front|220|True|50|60|
|D_patch|front|350|True|30|40|
|D_patch|side|100|True|60|None|
|D_patch|side|220|True|40|45|
|D_patch|side|350|True|30|40|

## 制約・解釈

- Noneは許容音圧0 dBという意味ではない。外乱なしで成立しない経路には上限を定義しない。最初の試験点5 dBで崩れた場合、0–5 dBを補間しない。
- 全群正常という厳しい指標のほか、セルで正常・誤判定・判定不可、旧群・追加群を保存。6群で一般母集団の限界は保証できない。
- 同じ正面音圧でも他受音点の音圧とu方向は変わる。距離を正面受音点から揃えた3位置であり、平面波の方向だけを変えた試験ではない。
- 周波数・位置・phase=1.1固定の条件網羅で、位相や広帯域外乱の頑健性は未検証。
- A全領域の外乱なし誤判定は各baselineケースの最大入力・特徴量偏差から調べる。偏差は因果説明ではない。
- 専用実験Adapterは固定モデルを読み、既存Pluginのprepare/score/aggregate/decideを呼ぶ。既存Runner全105評価との一致をcompatibility.jsonに記録。元の共通基盤は変更しない。
- training_runsはResultBundle 1.0。掃引結果は別形式でありBundle 1.0と偽らない。cases内の全入力ID・スコア・特徴量・選択マスク・元波形・取得ハッシュで追跡可能。
- 改善候補の学習や閾値調整はしていない。次は弱点の説明を確認し、別評価条件で異常＋外乱の見逃しを含めて改善を比較する。
