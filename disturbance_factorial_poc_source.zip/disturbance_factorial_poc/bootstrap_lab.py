from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
BASELINE=ROOT/'baseline'
def verify_baseline():
    m=json.loads((BASELINE/'release_manifest.json').read_text(encoding='utf-8'))
    for e in m['files']:
        p=(BASELINE/e['path']).resolve()
        if not p.is_relative_to(BASELINE) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:raise ValueError('baseline changed: '+e['path'])
    return len(m['files'])
verify_baseline()
sys.path.insert(0,str(BASELINE))
import bootstrap
if bootstrap.ROOT!=BASELINE:raise ValueError('wrong baseline imported')
