"""Validate saved experiment and package source plus compact evidence."""
import bootstrap_sweep
from bootstrap_sweep import ROOT,BASELINE,verify_baseline
from pathlib import Path
import sys,subprocess,zipfile,platform
from bridge.adapter import read,write,sha
from nv_runner.bundle import BundleReader

def main():
    out=Path(sys.argv[1]).resolve();status=read(out/'status.json')
    if status['status']!='passed':raise ValueError('experiment has not passed')
    reader=BundleReader(status['bundle']).validate()
    for key in reader.manifest['completed_routes']:
        if read(reader.path/'models'/f'{key}_threshold.json')['value'] is None:raise AssertionError('no threshold')
    rows=read(out/'cases.json');assert len(rows)==210
    for key in reader.manifest['completed_routes']:
        rr=[r for r in rows if r['route']==key]
        assert len({r['threshold'] for r in rr})==1
        assert len({r['family'] for r in rr})==3
        assert len({r['level_index'] for r in rr})==14
    training=read(out/'dataset/canonical/train_manifest.json')
    for item in training['measurements']:
        for k in ['source_path','metadata_path']:
            assert sha(out/'dataset/canonical'/item[k])==sha(out/'reference/canonical'/item[k])
    reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    proc=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(ROOT),'-p','test_sweep.py','-v'],capture_output=True,text=True)
    (reports/'tests.log').write_text(proc.stdout+proc.stderr,encoding='utf-8')
    if proc.returncode:raise AssertionError('unit tests failed')
    for name in ['REPORT.md','summary.json','cases.json','model_hashes.json','status.json']:
        (reports/name).write_bytes((out/name).read_bytes())
    # Standalone compact result, without a broken link to omitted full viewer.
    page=(out/'index.html').read_text(encoding='utf-8').replace('<a href="viewer.html">元波形・判定根拠を開く</a>','<p>詳細Viewerと波形は再実行で生成します。</p>')
    (reports/'index.html').write_text(page,encoding='utf-8')
    gen=read(out/'dataset/generation_validation.json');write(reports/'generation_validation.json',gen)
    result={'status':'passed','new_unit_tests':7,'evaluation_rows':len(rows),'bundle_validated':True,'training_bytes_unchanged':True,'baseline_hash_verified_files':verify_baseline(),'python':platform.python_version(),'viewer_separate_process':True,'all_levels_share_one_training_per_route':True,'baseline130_rerun':False,'baseline130_reason':'frozen code unchanged; this task validates added sweep and integration','browser_visual_inspection':False}
    write(reports/'validation.json',result)
    files=[]
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if not p.is_file() or any(x in rel.parts for x in ['outputs','__pycache__','.venv']) or p.name=='package_manifest.json':continue
        files.append({'path':rel.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    write(ROOT/'package_manifest.json',{'schema_version':'sweep-package/1.0','files':files})
    target=ROOT.parent/'disturbance_level_sweep_source.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for e in files:z.write(ROOT/e['path'],'disturbance_level_sweep/'+e['path'])
        z.write(ROOT/'package_manifest.json','disturbance_level_sweep/package_manifest.json')
    print(result);print(target,target.stat().st_size)
if __name__=='__main__':main()
