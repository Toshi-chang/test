"""Persisted local experiments. Test data never fit normalization or thresholds."""
import csv
import hashlib
import json
import time
import zipfile
from pathlib import Path

import numpy as np
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
from dataset import load_dataset
from dl import train_model, infer_windows, group_max
from physics import VERSION, json_safe


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(json_safe(value), ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temp.replace(path)


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def metadata(path):
    # Inspect shapes without decompressing all acoustic arrays for the plan preview.
    with zipfile.ZipFile(path) as z:
        shapes = {}
        for name in ('train','validation','calibration','test','train_rpm','test_rpm'):
            if name+'.npy' in z.namelist():
                with z.open(name+'.npy') as f:
                    version = np.lib.format.read_magic(f)
                    header = (np.lib.format.read_array_header_1_0(f) if version==(1,0)
                              else np.lib.format.read_array_header_2_0(f))
                    shapes[name] = header[0]
    with np.load(path, allow_pickle=False) as d:
        fs = float(d['sampling_rate_hz']) if 'sampling_rate_hz' in d else float(1/np.diff(d['time_s'][:2])[0])
    for split in ('train','validation','calibration','test'):
        if split not in shapes or len(shapes[split])!=3 or shapes[split][1]!=2 or not shapes[split][0]:
            raise ValueError(f'{path.name}: 不正な波形形状 {split}')
    config_path=Path(path).parent/'config.json'
    config=json.loads(config_path.read_text(encoding='utf-8-sig')) if config_path.exists() else None
    return dict(fs=fs, samples=shapes['test'][-1], rpm='test_rpm' in shapes and 'train_rpm' in shapes,
                config=config)


def plan(state, data):
    mode = data.get('mode','fixed')
    if mode not in ('fixed','retrain','existing'):raise ValueError('比較モードが不正です')
    tests = list(dict.fromkeys(data.get('datasets',[])))
    trains = list(dict.fromkeys(data.get('training_datasets',[])))
    variants = list(dict.fromkeys(data.get('variants',['pu'])))
    epochs = int(data.get('epochs',80))
    scale = float(data.get('rpm_fixed_scale',10000))
    if not tests:raise ValueError('評価データを選択してください')
    if not 1<=epochs<=500 or not np.isfinite(scale) or scale<=0:raise ValueError('エポック数またはRPM固定幅が不正です')
    if not variants or any(v not in ('p','u','pu','pu_rpm_std','pu_rpm_fixed') for v in variants):raise ValueError('比較する入力が不正です')
    if mode!='existing' and (not trains or (mode=='fixed' and len(trains)!=1)):
        raise ValueError('固定モデルでは学習データを1件、学習比較では1件以上選択してください')
    if mode=='existing':trains=[]
    paths = {p:state.path(p) for p in set(tests+trains)}
    for p in paths.values():
        if not p.is_file():raise ValueError(f'データがありません: {p.name}')
    meta = {p:metadata(path) for p,path in paths.items()}
    tasks=[]
    if mode=='existing':
        model = state.path(data.get('model',''))
        with np.load(model, allow_pickle=False) as w:
            expected = (float(w['fs']),int(w['window_samples']))
            rpm = bool(w.get('rpm_conditioned',False))
            if not float(w['record_threshold'])>0:raise ValueError('モデルの閾値が不正です')
        models=[dict(id='existing',model=model.relative_to(state.outputs).as_posix(),variant='既存モデル',training_dataset=None)]
    else:
        expected = (meta[trains[0]]['fs'],meta[trains[0]]['samples'])
        rpm=any(v.startswith('pu_rpm') for v in variants)
        models=[]
        for train in trains:
            for v in variants:
                key=f'train_{len(models)+1:03d}'
                item=dict(id=key,kind='train',training_dataset=train,variant=v,model=f'models/{key}/model_weights.npz')
                models.append(item);tasks.append(item.copy())
    for p,m in meta.items():
        if (m['fs'],m['samples'])!=expected:raise ValueError(f'fsまたは窓長が一致しません: {p}')
        if rpm and not m['rpm']:raise ValueError(f'RPMがありません: {p}')
    for model in models:
        for test in tests:
            tasks.append(dict(id=f'eval_{sum(t["kind"]=="evaluate" for t in tasks)+1:04d}',kind='evaluate',
                              dataset=test,model=model['model'],dependency=model['id'] if mode!='existing' else None,
                              variant=model['variant'],training_dataset=model['training_dataset']))
    if len(tasks)>2000:raise ValueError('1実験の上限は2000処理です。評価データを絞ってください')
    return dict(schema=1,version=VERSION,mode=mode,epochs=epochs,rpm_fixed_scale=scale,tasks=tasks,
                datasets=tests,training_datasets=trains,variants=variants,metadata=meta,
                training_count=len(models) if mode!='existing' else 0,evaluation_count=len(models)*len(tests),
                note='同じ評価データ群を全モデルに適用。評価データで閾値・正規化を調整しない。')


def create(state, proposal):
    folder=state.new_folder('comparison')
    save(folder/'plan.json',proposal)
    save(folder/'state.json',dict(status='pending',tasks=[dict(**t,status='pending') for t in proposal['tasks']],fingerprints={}))
    return folder


def evaluate(model, dataset, cancel):
    d=load_dataset(dataset)
    with np.load(model,allow_pickle=False) as w:
        threshold=float(w['record_threshold']);rpm=bool(w.get('rpm_conditioned',False))
    scores=[]
    with threadpool_limits(limits=2):
        for start in range(0,len(d['test']),128):
            if cancel():raise InterruptedError('比較を停止しました')
            scores.extend(infer_windows(model,d['test'][start:start+128],float(d['sampling_rate_hz']),
                         d['test_rpm'][start:start+128] if rpm and 'test_rpm' in d else None))
    ids,values=group_max(np.asarray(scores),d['test_record_ids'])
    labels=np.array([d['test_labels'][d['test_record_ids']==rid][0] for rid in ids])
    rates={}
    for k in range(len(d['class_names'])):
        mask=labels==k;n=int(mask.sum());hits=int(np.sum(values[mask]>threshold))
        # Wilson 95% interval for independent recording-level proportions.
        p=hits/n if n else 0;den=1+3.8416/n if n else 1
        center=(p+1.9208/n)/den if n else 0
        half=1.96*np.sqrt(p*(1-p)/n+3.8416/(4*n*n))/den if n else 0
        rates[str(k)]=dict(records=n,flagged=hits,rate=p if n else None,
                          low=max(0,center-half) if n else None,high=min(1,center+half) if n else None)
    auc=lambda truth:float(roc_auc_score(truth,values)) if len(np.unique(truth))==2 else None
    return dict(threshold=threshold,rates=rates,class_names=d['class_names'].tolist(),
                auc_any_change=auc(labels>0),auc_machine_fault=auc(labels>=2),
                records=[dict(id=int(i),label=int(l),score=float(s),ratio=float(s/threshold)) for i,l,s in zip(ids,labels,values)])


def reports(folder, status):
    proposal=read(folder/'plan.json')
    rows=[]
    for t in status['tasks']:
        if t['kind']!='evaluate' or t['status']!='complete':continue
        r=read(folder/(t['id']+'.json'))
        row={k:r.get(k) for k in ('id','dataset','training_dataset','variant','model','model_sha256','dataset_sha256','threshold','seconds','training_seconds','best_epoch','rpm_scale','auc_any_change','auc_machine_fault')}
        for k in range(4):
            for key in ('rate','records','flagged','low','high'):row[f'class{k}_{key}']=r['rates'].get(str(k),{}).get(key)
        row['condition_name']=proposal.get('labels',{}).get(row['dataset'],row['dataset'])
        rows.append(row)
    save(folder/'summary.json',dict(status=status['status'],rows=rows,tasks=status['tasks']))
    if rows:
        with (folder/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    lines=['# '+proposal.get('name','PU Lab 実験比較'),proposal.get('purpose',''),f'状態: {status["status"]} / 評価完了: {len(rows)}',
           '正常の誤検知、外乱のみの発報、異音の検出、外乱＋異音の検出を別々に評価します。',
           '外乱のみの発報は、機械故障の検出成功を意味しません。',
           '割合の95%区間は独立収録単位のWilson区間です。同じ収録からの窓を独立件数として数えません。',
           '評価データから閾値は選びません。探索に使った評価セットでの最良値は、別の未使用セットで再確認してください。',
           '合成データの結果であり、実機性能や原因を確定するものではありません。',
           '数値と保存設定の自動集計です。AIによる診断・外部API呼び出しは実行していません。',
           '\n|入力|評価データ|正常誤検知|外乱発報|異音検出|外乱＋異音|', '|---|---|---:|---:|---:|---:|']
    for row in rows:
        pct=lambda k:'—' if row[f'class{k}_rate'] is None else f'{100*row[f"class{k}_rate"]:.1f}%'
        lines.append('|'+ '|'.join([row['variant'],row['condition_name'],*[pct(k) for k in range(4)]])+'|')
    lines+=['\n## 次に確認する点','- 同じ評価データ行を使い、正常誤検知と異音検出を一緒に比較する。',
            '- RPM誤差条件を変えた際、固定幅と標準偏差の差が再現するか確認する。',
            '- 外乱ありで異音検出が落ちる条件、外乱だけで発報する条件を抽出する。',
            '- 学習seedは123固定。ばらつき評価には独立した収録seedの学習データで再試行する。',
            '\n## 未完了・失敗']
    lines += [f'- {t["id"]}: {t["status"]} {t.get("error","")}' for t in status['tasks'] if t['status']!='complete']
    (folder/'report.md').write_text('\n'.join(lines),encoding='utf-8')
    return rows


def run(state,folder):
    proposal=read(folder/'plan.json');status=read(folder/'state.json')
    # Failed/interrupted tasks are retried; completed tasks are immutable.
    for t in status['tasks']:
        if t['status']!='complete':t.update(status='pending',error=None)
    status['status']='running';save(folder/'state.json',status)
    try:
        for task in status['tasks']:
            if task['status']=='complete':continue
            if state.stop.is_set():raise InterruptedError()
            dep=task.get('dependency')
            if dep and next(t for t in status['tasks'] if t['id']==dep)['status']!='complete':
                task.update(status='blocked',error='学習が未完了');continue
            task.update(status='running',error=None);save(folder/'state.json',status)
            start=time.perf_counter();state.log(f'{task["id"]}: {task["variant"]} / {task.get("dataset",task.get("training_dataset"))}')
            try:
                path=state.path(task.get('dataset') or task['training_dataset'])
                sha=digest(path);key=path.relative_to(state.outputs).as_posix()
                old=status['fingerprints'].get(key)
                if old and old!=sha:raise ValueError('開始後にデータが変更されています。新しい比較を作成してください')
                status['fingerprints'][key]=sha
                if task['kind']=='train':
                    v=task['variant'];normalization='fixed' if v.endswith('_fixed') else 'std'
                    train_model(path,(folder/task['model']).parent,proposal['epochs'],
                                'pu_rpm' if v.startswith('pu_rpm') else v,state.log,state.stop.is_set,
                                rpm_normalization=normalization,rpm_fixed_scale=proposal['rpm_fixed_scale'])
                    task['model_sha256']=digest(folder/task['model'])
                    status['fingerprints'][str((folder/task['model']).relative_to(state.outputs))]=task['model_sha256']
                else:
                    model=state.path(task['model']) if proposal['mode']=='existing' else folder/task['model']
                    msha=digest(model);mkey=str(model.relative_to(state.outputs))
                    old=status['fingerprints'].get(mkey)
                    if old and old!=msha:raise ValueError('開始後にモデルが変更されています')
                    status['fingerprints'][mkey]=msha
                    result=evaluate(model,path,state.stop.is_set)
                    settings=read(model.parent/'run_settings.json') if (model.parent/'run_settings.json').exists() else {}
                    metrics=read(model.parent/'metrics.json') if (model.parent/'metrics.json').exists() else {}
                    training=next((t for t in status['tasks'] if t['id']==dep),{})
                    result.update(**{k:task[k] for k in ('id','dataset','training_dataset','variant')},
                                  model=model.relative_to(state.outputs).as_posix(),dataset_sha256=sha,model_sha256=msha,
                                  seconds=time.perf_counter()-start,training_seconds=training.get('seconds'),
                                  best_epoch=metrics.get('best_epoch'),rpm_scale=settings.get('rpm_scale'),settings=settings)
                    save(folder/(task['id']+'.json'),result)
                task.update(status='complete',seconds=time.perf_counter()-start)
            except InterruptedError:
                task['status']='pending';raise
            except Exception as exc:
                task.update(status='failed',error=str(exc),seconds=time.perf_counter()-start)
                state.log(f'{task["id"]}: 失敗 {exc}')
            save(folder/'state.json',status);reports(folder,status)
        status['status']='complete' if all(t['status']=='complete' for t in status['tasks']) else 'partial'
    except InterruptedError:
        status['status']='paused';state.log('比較を停止しました。完了済み処理を保持し、未完了から再開できます。')
    finally:
        save(folder/'state.json',status);reports(folder,status)
    return dict(folder=folder.relative_to(state.outputs).as_posix(),status=status['status'])
