import bootstrap_map
from bootstrap_map import ROOT,BASELINE,verify_baseline
import argparse,copy,shutil,time,traceback,sys
from pathlib import Path
import numpy as np
import joblib
from bridge.adapter import read,write,sha,DistributedAdapter
from bridge.dataset import generate,realize
from da_engine.engine import synthesize
from nv_runner.runner import ExperimentRunner,validate_config
from nv_runner.bundle import BundleReader
from nv_runner.input_adapter import InputAdapter
from evaluate import evaluate
from report import render,case_page

def validate_protocol(p):
    if p.get('schema_version')!='disturbance-tolerance-map/1.0':raise ValueError('unknown protocol')
    for field in ['families','frequencies_hz','levels_db_spl']:
        x=p[field]
        if not x or len(x)!=len(set(x)) or not all(np.isfinite(v) for v in x):raise ValueError(field)
    if p['levels_db_spl']!=sorted(p['levels_db_spl']):raise ValueError('levels not ascending')
    if any(f<100000 or int(f)!=f for f in p['families']):raise ValueError('evaluation family overlap')
    if any(not 0<f<.44*1024 for f in p['frequencies_hz']):raise ValueError('outside passband')
    if p['reference_pressure_pa']!=2e-5 or p['reference_receiver']!='front':raise ValueError('unsupported reference')
    for x in p['positions_m'].values():
        if np.shape(x)!=(3,) or not np.isfinite(x).all():raise ValueError('position')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--resume',action='store_true');a=ap.parse_args();out=a.output.resolve()
    protocol=read(ROOT/'map_config.json');validate_protocol(protocol);cfg=read(BASELINE/'configs/dataset_comparison.json')
    if out.exists() and not a.resume:raise ValueError('fresh directory or --resume required')
    out.mkdir(exist_ok=True,parents=True);start=time.perf_counter();status={'status':'running'}
    source_hashes={p.name:sha(p) for p in ROOT.glob('*.py')}
    if a.resume:
        if read(out/'protocol.json')!=protocol or read(out/'source_hashes.json')!=source_hashes:raise ValueError('resume code/protocol changed')
    else:write(out/'protocol.json',protocol);write(out/'source_hashes.json',source_hashes)
    write(out/'status.json',status)
    try:
        if not (out/'training.json').exists():
            data=generate(BASELINE/'configs/dataset_comparison.json',out/'reference')
            experiment=read(BASELINE/'configs/experiment.json')
            for k,f in [('train_manifest','train_manifest.json'),('eval_manifest','eval_manifest.json'),('truth_path','truth.json')]:experiment[k]=str(data/f)
            experiment['export']['output_dir']=str(out/'training_runs');write(out/'experiment.json',experiment)
            bundle=ExperimentRunner().execute(out/'experiment.json');BundleReader(bundle).validate()
            write(out/'training.json',{'bundle':str(bundle),'hashes':{f.name:sha(f) for f in (bundle/'models').iterdir()}})
        training=read(out/'training.json');bundle=Path(training['bundle']);reader=BundleReader(bundle).validate()
        if reader.manifest['bundle_status']!='complete':raise ValueError('partial training')
        if training['hashes']!={f.name:sha(f) for f in (bundle/'models').iterdir()}:raise ValueError('model changed')
        experiment,_,evaluation,_,_,_=validate_config(out/'experiment.json')
        models={r['key']:joblib.load(bundle/'models'/f'{r["key"]}.joblib') for r in experiment['routes']}
        thresholds={k:read(bundle/'models'/f'{k}_threshold.json') for k in models}
        # Validate the dedicated frozen-model path against all original Runner case decisions.
        reference_rows=evaluate(evaluation,experiment,models,thresholds)
        expected={(r['route_key'],r['case_id']):r for r in reader.tables['route_case_results']}
        for r in reference_rows:
            e=expected[r['route_key'],r['case_id']]
            for k in ['decision','coverage_status','reason','n_scored','n_created']:assert r[k]==e[k],k
            np.testing.assert_allclose(r['case_score'],e['case_score'],rtol=1e-12,atol=1e-12)
        write(out/'compatibility.json',{'status':'passed','cases_compared':len(reference_rows),'states_reasons_counts':'exact equality','scores':'rtol=atol=1e-12; same numerical operations, floating batch roundoff only','training_calls_during_sweep':0})
        jobs=[(None,None,None)]+[(d,f,l) for d in protocol['positions_m'] for f in protocol['frequencies_hz'] for l in protocol['levels_db_spl']]
        allrows=[];acoustic=[];cases=out/'cases';cases.mkdir(exist_ok=True)
        for family in protocol['families']:
            normal=[synthesize(realize(cfg,family,mi,'normal')) for mi in range(len(cfg['modes']))]
            for ji,(direction,freq,level) in enumerate(jobs):
                cid=f'f{family}_j{ji:03d}';dest=cases/cid
                if (dest/'complete.json').exists():
                    completed=read(dest/'complete.json')
                    for rel,h in completed['hashes'].items():
                        if sha(dest/rel)!=h:raise ValueError('resume artifact corrupted: '+str(dest/rel))
                    allrows+=read(dest/'results.json');acoustic+=read(dest/'acoustic.json');continue
                dest.mkdir(exist_ok=True);canonical=dest/'canonical';canonical.mkdir(exist_ok=True);items=[];origins=[];case_acoustic=[]
                for mi,base in enumerate(normal):
                    scene=realize(cfg,family,mi,'normal');scene['sources']=copy.deepcopy(cfg['additions']['disturbance'])
                    if direction is not None:
                        scene['sources'][0]['geometry']['center_m']=protocol['positions_m'][direction];scene['sources'][0]['excitation']['frequency_hz']=freq
                    ext=synthesize(scene);ri=next(i for i,r in enumerate(scene['receivers']) if r['id']=='front')
                    target=0 if level is None else 2e-5*10**(level/20);gain=target/np.sqrt(np.mean(ext['pressure_pa'][:,ri]**2))
                    p=base['pressure_pa']+gain*ext['pressure_pa'];u=base['velocity_m_s']+gain*ext['velocity_m_s'];axes=np.asarray([r['axis'] for r in scene['receivers']]);axial=np.einsum('nri,ri->nr',u,axes)
                    np.testing.assert_allclose(np.sqrt(np.mean((gain*ext['pressure_pa'][:,ri])**2)),target,rtol=1e-12,atol=1e-15)
                    if level is None:np.testing.assert_array_equal(axial,base['axial_velocity_m_s'])
                    raw=dest/f'm{mi}';raw.mkdir(exist_ok=True);np.savez_compressed(raw/'observations.npz',time_s=base['time_s'],pressure_pa=p,velocity_m_s=u,axial_velocity_m_s=axial)
                    mode=cfg['modes'][mi];t=base['time_s'];rpm=mode['start_rpm']+(mode['end_rpm']-mode['start_rpm'])*t/scene['simulation']['duration_seconds'];np.savez_compressed(raw/'rpm_observation.npz',rpm=rpm)
                    acq=read(out/'reference/raw'/f'c00020_m{mi}'/'acquisition.json');acq['observations']['sha256']=sha(raw/'observations.npz');acq['rpm']['sha256']=sha(raw/'rpm_observation.npz');write(raw/'acquisition.json',acq)
                    converted,refs=DistributedAdapter().convert(raw/'acquisition.json',canonical,{'specimen_id':cid,'case_id':cid,'derived_group_id':f'family_{family:06d}','capture_id':f'{cid}_m{mi}'});items+=converted;origins+=refs
                    for i,r in enumerate(scene['receivers']):
                        ep=float(np.sqrt(np.mean((gain*ext['pressure_pa'][:,i])**2)))
                        case_acoustic.append({'measurement_id':refs[i]['measurement_id'],'receiver':r['id'],'external_p_rms_pa':ep,'external_db_spl':None if ep==0 else float(20*np.log10(ep/2e-5)),'gain':float(gain),'normal_p_rms_pa':float(np.sqrt(np.mean(base['pressure_pa'][:,i]**2)))})
                    write(raw/'generation.json',{'normal_scene':realize(cfg,family,mi,'normal'),'external_scene':scene,'gain':float(gain),'truth_use':'generation only; not model input'})
                write(canonical/'eval_manifest.json',{'schema_version':'1.0','role':'eval','normal_only_attested':False,'measurements':items});write(dest/'origins.json',origins)
                records=InputAdapter().load(canonical/'eval_manifest.json');rows=evaluate(records,experiment,models,thresholds,dest)
                for r in rows:r.update(family=family,direction=direction,frequency_hz=freq,db_spl=level,truth='normal',detail=f'cases/{cid}/index.html')
                write(dest/'results.json',rows);write(dest/'acoustic.json',case_acoustic);case_page(rows,records,dest)
                write(dest/'complete.json',{'hashes':{f.relative_to(dest).as_posix():sha(f) for f in dest.rglob('*') if f.is_file() and f.name!='complete.json'}})
                allrows+=rows;acoustic+=case_acoustic
                if ji%12==0:
                    write(out/'progress.json',{'family':family,'condition':ji,'completed_route_rows':len(allrows),'total_cases':len(jobs)*len(protocol['families'])});print(f'{family} {ji}/{len(jobs)}',flush=True)
            render(allrows,protocol,out)
        write(out/'acoustic.json',acoustic);render(allrows,protocol,out)
        if training['hashes']!={f.name:sha(f) for f in (bundle/'models').iterdir()}:raise ValueError('model changed')
        status.update(status='passed',cases=len(allrows)//5,route_rows=len(allrows),frozen_source_files=verify_baseline(),elapsed_seconds=time.perf_counter()-start)
    except BaseException as e:
        status.update(status='failed',error=str(e));(out/'error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:write(out/'status.json',status)
if __name__=='__main__':main()
