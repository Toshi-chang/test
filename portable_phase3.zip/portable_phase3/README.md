# NV route runner PoC

Claude Codeで過去検証を再実行する場合の一冊の要件書： [CLAUDE_CODE_VALIDATION_REQUIREMENTS.md](docs/CLAUDE_CODE_VALIDATION_REQUIREMENTS.md)。各試験の条件・コマンド・合否・保存物と追加スクリプト全文を含みます。

**01だけをGitで移植する場合は [継続検証方針書](docs/REVALIDATION_POLICY.md) から開始してください。** 合成データ・結果は新環境で再生成します。実データ接続後の検証項目も同書にまとめています。

合成測定の生成 → 登録 → 個体分割 → A〜Dの実学習 → calibration閾値 → 評価 → Bundle → オフライン閲覧まで実行できます。

## 作業方針

- このPoCで新規作成するコード、設定、テスト、合成データ、実行結果、ログ、環境は、このフォルダ内に格納します。
- 親ディレクトリ内の既存ファイル群は参照資料として扱い、変更しません。
- 同一機能が必要な場合も、このPoC内で独立して実装します。既存PoCのコードをimportしたり、実行時に読み込んだりしません。
- 既存PoCの仮想環境や内部モジュールに依存せず、必要な依存ライブラリと環境構築手順をこのPoC内で管理します。
- 実測データの対応・単位・校正状態など、未確認の情報を推測で補いません。

## 設計資料

`docs/NV_route_runner_implementation_spec_v0_1.md` は提供された仕様書の原文コピーです。
資料内の指示とユーザーからの作業依頼を区別し、実装範囲はユーザーの依頼に従います。

## p–u物理モデル（0.2.0）

同一音源の圧力伝達関数と速度伝達関数からp/uを同時生成します。exp(+jωt)、U=−∇P/(jωρ)、u=e·Uを採用。平面波・単極子近接場・バッフル付き円形ピストン軸上・剛壁反射場を実装し、適用範囲外の組合せを拒否します。既定は単極子の対象音＋平面波背景です。数式、位相、単位、境界条件、センサー誤差は `docs/ACOUSTIC_DESIGN.md`、検証・比較結果は `reports/ACOUSTIC_DELIVERY.md` に記載しています。

旧 `examples/quick` / `examples/comparison` は物理関係更新前の保存結果です。今回の確認には下記acoustic版を使用してください。

## すぐ確認する

- `examples/acoustic_quick/viewer.html` / `examples/acoustic_comparison/viewer.html` をブラウザーで開きます。サーバー・外部CDN・ネットワークは不要です。
- 数値結果と制約：`reports/ACOUSTIC_DELIVERY.md`（旧版は `reports/DELIVERY.md`）
- 試験ログ：`reports/acoustic_regression_tests.txt`、物理検証：`reports/acoustic/PHYSICAL_VALIDATION.md`、画面操作：`reports/acoustic/comparison_viewer_test.json`
- Bundleの場所と集計：`examples/acoustic_quick/summary.json` / `examples/acoustic_comparison/summary.json`

このディレクトリでPowerShellを開いて実行します。専用 `.venv` は構築済みです。

```powershell
.\run_demo.ps1 -Profile quick
.\run_demo.ps1 -Profile comparison
```

実行ごとに `demos/<generator>_<profile>_<UTC日時>_<id>/` を新規作成します。生成データ、設定、Bundle、ローカル受渡し先、viewer.html、summary.jsonが入ります。直近の場所は `reports/latest_acoustic_quick.json` または `reports/latest_acoustic_comparison.json` で確認できます。

別環境ではPython 3.12で専用環境を構築します。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m nv_runner demo --profile quick
```

## 個別コマンド

初回のみデータ生成します。提供済み `data/acoustic_quick` を使う場合は生成を省略してください。生成先が既に存在すると拒否します。

```powershell
.\.venv\Scripts\python.exe -m nv_runner generate --settings configs/acoustic_quick_data.json --output data/acoustic_quick
.\.venv\Scripts\python.exe -m nv_runner validate --config configs/acoustic_quick.json
.\.venv\Scripts\python.exe -m nv_runner execute --config configs/acoustic_quick.json
```

executeが表示したBundleパスを指定します。

```powershell
.\.venv\Scripts\python.exe -m nv_runner inspect --bundle "<Bundleのパス>"
.\.venv\Scripts\python.exe -m nv_runner view --bundle "<Bundleのパス>" --output reports/my_viewer.html
.\.venv\Scripts\python.exe -m nv_runner import --bundle "<Bundleのパス>" --output evaluation_inbox
```

viewは別プロセスで保存済みBundleだけを読みます。元ファイルがなくても保存した解析用波形・STFTで閲覧できます。importは原本の存在とハッシュを確認し、未解決参照をreceiptへ出します。移設時は `--path-mapping mapping.json`（旧パス接頭辞→新パス接頭辞のJSONオブジェクト）を指定できます。

## 設定と閲覧

`configs/acoustic_quick_data.json` / `acoustic_comparison_data.json` の個体数、評価繰返し数、測定数、秒数、サンプル周波数、seedを変更できます。生成器v1は800 Hz以上・2秒以上です。quickは正常学習12個体＋評価7個体、comparisonは40＋28個体。各個体に定常・回転数変化の2測定を持たせます。評価の7シナリオは同じ正常実現を共有する対比較で、quickは1、comparisonは4の独立したベース個体群です。28独立実現の性能試験とは扱いません。

別データの登録はtrain/evalの2つのmanifestに元ファイル、SHA256、metadata、キーmappingを指定します。設定内の相対パスは設定ファイル基準です。`configs/acoustic_quick.json` / `acoustic_comparison.json` で窓長・hop・AND/OR選択・次数・イベント・パッチ・モデル・閾値・fusionを設定します。`a_first.json` は共通基盤を最初に確認したAのみの設定です。

画面の個体×経路行を選び、点または入力ドロップダウンを選択します。波形の切出し・計算支持範囲、周波数帯・選択mask、sensor位置・方向、rpm範囲、元サンプル番号を確認できます。橙色の正解は生成器情報でありモデル推定ではありません。外乱のみの個体は正常ラベル、scenario=disturbanceで区別します。

## 実装構成

|nv_runner内のファイル|責務|
|---|---|
|input_adapter.py|NPZ/JSON入力、単位・同期・ハッシュ、個体/派生元分割|
|signals.py|共通STFT、MSC・位相・符号付きインテンシティ、座標|
|routes.py|A全領域/選択、B次数、Cイベント、Dパッチの共通契約|
|models.py|fit限定StandardScaler＋Isolation Forest / PCA|
|runner.py|逐次実行、経路例外隔離、状態、fusion、実行後指標|
|bundle.py|完全性・参照検証、原子的完了、ローカル受渡し・冪等取込|
|viewer.py / viewer.html|BundleだけからオフラインHTML生成|
|acoustics.py / acoustic_generator.py|物理伝達、音源励振、観測誤差、正解隔離、合成データ登録|
|verify_physics.py|解析式・Euler式・インテンシティ整合の数値レポート|
|synthetic.py|旧簡易生成器（明示的なlegacy実験用）|

単位、形状、版、必須項目、状態、仮設定は `docs/CONTRACTS.md` に記載しています。

## 試験

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

試験用データは `tests/_work/<id>/` に残ります。任意の画面試験はNode.jsとPlaywrightがある環境で `node tests/viewer_smoke.cjs examples/acoustic_quick/viewer.html`。インストール済みEdgeを使う場合は `$env:BROWSER_CHANNEL='msedge'` を設定します。Python実行とHTML閲覧にNode.jsは不要です。

物理検証レポートの再生成：`python -m nv_runner.verify_physics --output reports/acoustic`。旧生成器は `run_demo.ps1 -Generator legacy` で明示選択できます。既存設定 `configs/quick.json` / `configs/comparison.json` は旧規約の再現用です。

## 制約と接続箇所

- 簡易合成信号です。実音場、外乱分離、故障部位、現場検出性能を実証しません。少数calibrationの95%経験分位点は誤検出率保証ではありません。
- 入力v1は校正済みp [Pa] / u [m/s] の1ペア、共通時計・等間隔系列です。Bは同期rpmを使用。パルスデコード、非同期系列、校正係数適用、多センサー、単位変換は入力アダプタ拡張点です。
- Cは固定条件の高域RMS検出です。イベント0件は未確定、頻度異常モデルは未実装（イベント数/秒は診断値）。DはPCAで、DL/GPUやピクセル局所化はありません。
- 逐次実行で、再実行は新runです。途中成果は再利用しません。経路実行中のCtrl+Cはpartial/cancelledを保存。強制終了・初期処理中の中断ではstagingが残る場合がありreaderは拒否します。
- joblibモデルはローカル専用です。reader/viewerはモデルをデシリアライズしません。
- 実測接続時はキー/shape/dtype、ch、単位、校正、同期、個体/case/派生元ID、回転軸、運転条件、正常データ分布が必要です。`InputAdapter.load()`を交換・拡張します。
- 外部接続時は先方の版付き受入契約・ID競合・参照先解決を確認し、`EvaluationAdapter.import_bundle()`を交換します。今回はローカル受渡しのみ実行済みで、外部システムへの実接続は未実施です。

## 別環境への移植

`transfer_20261012/START_HERE.md`に移植手順をまとめ、同フォルダに実行用・閲覧用・元データ/全結果保管用の3つのZIPを収録しています。実データ接続・外部受渡しの交換箇所は `docs/TRANSFER_GUIDE.md` を参照してください。
