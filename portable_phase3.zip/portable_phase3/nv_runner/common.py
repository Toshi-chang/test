"""Versioned JSON, stable identities and numeric array descriptors."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from . import SCHEMA_VERSION


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def identity(obj):
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"non-finite JSON: {x}")))


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")


def write_lines(path, rows):
    Path(path).write_text("".join(canonical(row) + "\n" for row in rows), encoding="utf-8")


def read_lines(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8").splitlines() if s.strip()]


def require_version(obj):
    if obj.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"unsupported schema_version: {obj.get('schema_version')!r}")


def utc():
    return datetime.now(timezone.utc).isoformat()


def inside(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"path outside bundle: {relative}")
    return path


def array_file(root, relative, **arrays):
    path = Path(root) / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    for value in arrays.values():
        if np.asarray(value).dtype.hasobject or not np.isfinite(value).all():
            raise ValueError("arrays must be finite numeric values")
    np.savez_compressed(path, **arrays)
    return {"path": relative, "sha256": sha(path), "arrays": {
        k: {"shape": list(np.asarray(v).shape), "dtype": str(np.asarray(v).dtype)} for k, v in arrays.items()}}


def union_length(ranges):
    total, end = 0, 0
    for a, b in sorted(ranges):
        total += max(0, b - max(end, a))
        end = max(end, b)
    return total
