# Phase 3 Agent P: Descriptor / Registry

担当範囲は `nv_runner/plugin_descriptor.py`、`plugin_registry.py`、`plugin_catalog.py`、`tests/test_plugin_registry.py`。既存共有コード、契約、既存試験は変更していない。

## 実装

- `PluginDescriptor` は現行 RoutePlugin の API 1.0、C01/C02 入力、C03/C05 出力、C04@1.0 モデルを宣言する frozen dataclass。未知版・契約組合せを登録時に拒否する。
- `PluginRegistry` は Mapping。`REGISTRY[id](config)` を維持し、`register`、`unregister`、`get_descriptor`、`validate` を提供する。
- `plugin_catalog.DEFAULT_REGISTRY` は 5 実装を明示登録する。実装クラスは文字列 factory で宣言し、登録・一覧・存在確認・factory 取得時には import しない。選択時だけ依存を解決する。
- 共通 schema 検証は Agent V の `plugin_validation` に委譲する。candidate 固有制約は既存関数を entrypoint で呼ぶ。設定を変更せず、既定値を注入しない。
- 登録時と descriptor 取得時に辞書をコピーし、呼出側の辞書変更で登録済み契約を変えられない構成にした。

## 追加・交換

1. 現行の constructor(config)、capabilities/feature_schema/prepare/fit/score/aggregate/calibrate/decide を備えた実装を専用 Python ファイルに作成する。
2. `plugin_catalog.py` の明示登録定義に `PluginDescriptor` を追加する。factory は信頼済み Python コード側でのみ決定する。設定ファイル内の factory 値は解決しない。
3. 専用契約試験を追加し、構成の `plugin` を登録 ID に設定する。任意の `implementation_version` を指定すると完全一致を検証する。
4. `enabled: false` の未登録・未インストール実装は実行も import もしない。登録削除後も依存しない経路を利用できる。

Runner・共通 Validator へのプラグイン名分岐追加は不要。実装クラス間の物理的・数値的同等性は descriptor だけでは証明されず、専用交換試験で検証する。

## 検証と制約

実行: `.venv/Scripts/python.exe -m unittest discover -s tests -p test_plugin_registry.py -v`

12 試験成功。fresh process の import 遅延、宣言版・契約、schema 事前拒否、factory 欠落・非 callable、実 method signature、辞書 snapshot、実装 pin、無効化・削除を確認。記録: `reports/phase3/P/registry_tests.log` / `state.json`（開始終了 UTC・対象 hash）。結合回帰は統合担当が実施する。

事前検証では constructor を呼び、method の呼出形を確認する。prepare/fit/score は呼ばない。実行時にも constructor が呼ばれるため、新プラグインの constructor は観測を加工したり外部書込みをせず設定保持に限定する。既存 constructor はこの条件を満たす。method の戻り値・科学的意味・PreparedSet 内容の正しさまでは事前 signature 検査では保証しない。

任意 Python の sandbox ではない。register に渡す entrypoint はレビュー済み信頼コードであることが前提。任意ディレクトリ探索・設定からのコード実行・将来の run API は導入していない。
