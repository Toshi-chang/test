"""C01-C08 executable fixtures; no generated assets are required for checkout."""
import copy
from functools import lru_cache
from pathlib import Path
import shutil
import uuid
import numpy as np
from nv_runner.common import read_json, write_json, sha
from nv_runner.input_adapter import InputAdapter
from nv_runner.acoustic_generator import generate_acoustic, acoustic_settings
from nv_runner.profiles import acoustic_experiment
from nv_runner.runner import ExperimentRunner
from nv_runner.bundle import BundleReader

ROOT = Path(__file__).resolve().parents[1]
SPEC = read_json(ROOT / 'docs/parallel_contracts/fixtures.json')

def directory(owner='Q'):
    path = ROOT / 'tests/_work' / owner / uuid.uuid4().hex
    path.mkdir(parents=True)
    return path

def record_fixture(wave=False, mutate=None):
    root = directory()
    recipe = SPEC['record_minimal']
    meta = copy.deepcopy(recipe['metadata'])
    signals = np.array(recipe['waveform'])
    rpm = np.full(len(signals), 1200.)
    if wave:
        w = SPEC['wave_recipe']
        p = np.sqrt(2)*.2*np.sin(2*np.pi*128*np.arange(w['N'])/w['fs_hz'])
        signals = np.column_stack([p, p/(1.2*343)])
        rpm = np.full(w['N'], w['rpm'])
    arrays = {'waveform': signals, 'shaft_rpm': rpm}
    if mutate:
        mutate(meta, arrays)
    np.savez_compressed(root/'signal.npz', **arrays)
    write_json(root/'meta.json', meta)
    manifest = {'schema_version':'1.0', 'measurements':[{
        'metadata_path':'meta.json', 'source_path':'signal.npz',
        'source_sha256':sha(root/'signal.npz'), 'mapping':copy.deepcopy(recipe['mapping'])}]}
    write_json(root/'manifest.json', manifest)
    return root/'manifest.json'

def record(wave=False):
    return InputAdapter().load(record_fixture(wave))[0]

@lru_cache(maxsize=1)
def pipeline():
    root = directory()
    generate_acoustic(root/'data', acoustic_settings('quick'))
    config = acoustic_experiment('data', 'runs')
    write_json(root/'experiment.json', config)
    bundle = ExperimentRunner().execute(root/'experiment.json')
    return root, config, bundle

def run_variant(config):
    root, _, _ = pipeline()
    path = root/(uuid.uuid4().hex+'.json')
    write_json(path, config)
    return BundleReader(ExperimentRunner().execute(path)).validate()

def bundle_copy():
    target = directory()/'bundle'
    shutil.copytree(pipeline()[2], target)
    return target

def refresh_member(bundle, name):
    manifest = read_json(bundle/'manifest.json')
    path = bundle/name
    manifest['members'][name] = {'bytes':path.stat().st_size, 'sha256':sha(path)}
    write_json(bundle/'manifest.json', manifest)
