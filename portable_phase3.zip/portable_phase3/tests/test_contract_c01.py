import copy
import unittest
import numpy as np
from contract_fixtures import record_fixture, pipeline
from nv_runner.common import read_json, write_json
from nv_runner.input_adapter import InputAdapter, DatasetPlanner
from nv_runner.runner import validate_config

class C01(unittest.TestCase):
    def test_record_compatibility_and_optional_rotation(self):
        path = record_fixture()
        r = InputAdapter().load(path)[0]
        self.assertEqual(r.signals.shape, (8,2))
        self.assertEqual([c['unit'] for c in r.meta['channels']], ['Pa','m/s'])
        m = read_json(path); m['measurements'][0]['mapping']['rpm'] = None
        write_json(path,m)
        self.assertIsNone(InputAdapter().load(path)[0].rpm)

    def test_invalid_input_rejected(self):
        mutations = [
            lambda m,a: m.update(schema_version='2.0'),
            lambda m,a: m['channels'][0].update(unit='kPa'),
            lambda m,a: m['channels'][1].update(position_m=[1,0,0]),
            lambda m,a: a['waveform'].__setitem__((0,0), np.nan),
            lambda m,a: a.update(shaft_rpm=np.zeros(2))]
        for mutation in mutations:
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                InputAdapter().load(record_fixture(mutate=mutation))
        path = record_fixture(); m = read_json(path)
        m['measurements'][0]['source_sha256'] = '0'*64; write_json(path,m)
        with self.assertRaisesRegex(ValueError,'hash'):
            InputAdapter().load(path)

    def test_split_and_leakage(self):
        root, config, _ = pipeline()
        _, train, ev, fit, cal, _ = validate_config(root/'experiment.json')
        for key in ('specimen_id','source_sha256','derived_group_id'):
            self.assertFalse({r.meta[key] for r in fit}&{r.meta[key] for r in cal})
            altered = copy.deepcopy(ev); altered[0].meta[key] = train[0].meta[key]
            with self.assertRaises(ValueError):
                DatasetPlanner().plan(train, altered, config['split'],42)
