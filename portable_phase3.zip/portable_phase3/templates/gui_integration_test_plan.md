# 別GUI統合試験計画

2026-10-16。**GUI/Serviceは未実装のため、下記アプリ試験はすべて未実施**。core移植時の130 PASSは既存baseline証拠であり、GUI接続成功を意味しない。参照：[規則](../docs/APPLICATION_INTEGRATION_RULES.md)、[Service提案](../docs/APPLICATION_SERVICE_CONTRACT.md)、[移植記録](../migration_validation.json)。

## 前提と実行順

1. 固定したcore/extension/アプリのハッシュ、Python/依存版、所有範囲とService DTOを記録する。
2. core単独130件→Service単体→実core接続→GUI mock→GUI実接続→交換/互換更新→変更監査の順。GUI mockとService/Plugin直接開発は並列でよい。
3. 共通fixtureは `core/configs/acoustic_quick_data.json` と `acoustic_quick.json`。seed等を変更せずコピーし、出力/manifest参照だけ各試験先に解決する。設定digest・解決前後の差分を保存する。科学条件は設定の値を正本とし、手順書へ別の数値を転記しない。
4. 失敗例はbaseline設定/Bundleのコピーにだけ適用し、core原本・既存テストを変更しない。学習/評価/真値の境界を保持する。

## 受入表

|ID・担当|入力/実施方法|合格条件・保存証拠|
|---|---|---|
|G01 QA core独立|アプリ/extensionをimportできない環境でcore130件。アプリディレクトリを配置しない別コピーでCLI実行|130 PASS、5経路Bundle valid。ログ、環境、hash。GUI削除がcore実行を壊さない。|
|G02 SERVICE 入力/設定|相対パス付きrequestをジョブ先へ変換。unknown版/重複key/不正schema/学習宣誓不足/混合派生元も与える|正常入力はcoreの分割/条件を維持。不正はrun開始前failed、診断あり。request/解決config/分割/Validatorログ。|
|G03 SERVICE 実解析|submit_runで正常ダミーfit/cal/evalを実行|worker完了後Reader valid、モデル/閾値/5経路結果が存在。job_idとrun_id対応を保存。score固定値による代用不可。|
|G04 GUI+QA 保存結果|別プロセスでsubmit_open、一覧→sample→EvidenceViewを選択|個体/ケース/測定/入力ID対応、時間/周波数/位置/運転条件、support/切出し/mask/表示座標が保存値と一致。真値表示と推論を区別。スクリーンショットとDTO照合。|
|G05 CORE+SERVICE Plugin交換|既存exchangeテストと新Serviceでfixed_window/candidate構成選択、新Descriptorのbootstrap登録|中央Runner/Validator不変。交換は元測定範囲とfeature schemaで対応し特徴/結果を比較。ID相違は許容根拠を記録。|
|G06 CORE+QA 遅延/廃止|candidate/テスト専用拡張のimportを禁止するfresh workerで未選択/無効/削除。別workerで不足実装を選択|独立経路は完走、選択した不足実装はpreflightで拒否。catalog一覧はfactoryをimportしない。legacy routes.py一括importを誤って失敗条件にしない。|
|G07 GUI+QA 表示変更の計算不変|同じcore/環境/seed/設定/測定でCLIとGUI実行。GUIの並べ替え/色/間引き/画面状態を変更して再実行|モデル数値、features、閾値、scores、状態/理由、ID/座標が同一。run UUID/経過時間/絶対出力pathは比較から分離。Bundle全体hashの一致を要求しない。差分と除外項目を保存。|
|G08 QA 互換更新|旧/新core候補と同一アプリで130件＋G02〜G07を再実行、互換表更新前後も確認|更新前は未検証hash拒否、成功後に承認した互換表だけで実行可。版文字列だけで通さない。承認と試験結果を保存。数値変更は別性能評価へ分離。|
|G09 QA 非互換|未知Service版/Bundle版/API/C契約/実装版、不一致core hash、壊れたBundleを与える|起動/検証/読込の該当境界で明示拒否、未知データを正常表示しない。core実行前拒否可能なものは実行しない。|
|G10 GUI+SERVICE 応答性|比較規模データで学習・読込・検証中に画面移動/ログ閲覧を操作。stdout大量出力も試す|GUIスレッドで重い処理なし、pipe deadlockなし。暫定アプリ目標：操作ack 500ms以内、イベントループ停止1秒未満（テスト機を記録）。core性能SLAではない。計測ログを保存。|
|G11 QA 状態の区別|simulate_failureによる経路失敗、空選択、rpm欠落、イベント0、モデル不足、真値破損、書込失敗|partial/failed/undetermined/unscoredを正常へ変換しない。completeでも未評価数を表示。null維持、理由保持。Bundle未確定時はstagingを開かない。|
|G12 SERVICE 中断/再起動|workerを検証中/学習中/保存中に強制終了。応答ファイル欠落/途中書込も作る|interruptedまたはprotocol failedで診断。キャンセル成功と称さない。中間成果再利用なし、新jobで再試行。確定Bundleがあれば別openで検証。|
|G13 SERVICE 読取/受渡し|真値なし、原本なしの確定Bundle、任意artifact不足、output adapterの再送/競合|保存snapshotがある領域は閲覧可、不足は明示。モデルunpickleなし。imported/already_imported/conflict/unresolved_sourcesの区別。BundleへのGUI設定追記なし。|
|G14 QA 方向/所有監査|import構造と変更hash一覧を検査、アプリなし試験、Service mockでGUI試験|GUI→core直接import、core→app import、GUI依存のcore混入、未承認共有編集が0。新ownershipを採択し専用パスを記録。|

## 比較基準

G07の目的はGUIが科学計算を変えないこと。同一実装・同一環境では保存数値配列は原則完全一致を確認し、既存比較ツールが数値許容差を使う場合はその値と理由を記録する。差が出た後に都合のよい許容差へ広げない。異OS/依存版間では先に許容差/対象を承認し、科学的互換性を別途評価する。検出率100%は要求しない。誤判定・見逃し・判定不可の母数と結果を保持する。

## 現在実行可能なコマンド

coreディレクトリで（Python環境構築はMIGRATION.md）：

```powershell
python -m unittest discover -s tests -v
python -m unittest discover -s tests -p 'test_contract_c*.py' -v
python -m unittest discover -s tests -p 'test_plugin_*.py' -v
python -m nv_runner demo --profile quick --generator acoustic --output ../artifacts/qa/core_reference
```

出力先は未使用ディレクトリを指定する。アプリ用の実行コマンドはまだ存在しない。SERVICE担当がFacade/workerと専用試験を、GUI担当がmock/実GUI試験を実装し、QAが正確な実行コマンドをこの計画に追記する。既存 `tests/viewer_smoke.cjs` は旧HTML専用であり、新GUI試験の代用品ではない。

## 成果物・再試験・承認

各担当のartifacts配下に実行設定、入力生成条件、環境/ハッシュ、モデル/閾値/Bundle、DTO、stdout/stderr、試験結果、画面証拠を保存する。大容量生成物はGitへ入れず再生成手順を残す。途中失敗は原因を保存し、新runで再試験する。過去成功ログの流用は禁止。

初回のGUI実装完了にはG01〜G14を必要とする。受渡しUIを含めない場合でもG13のReader境界は必須、任意export操作部分は未実装として明記する。C変更は既存INTEGRATION.mdのproducer/consumer/I/Q承認を先行させる。破壊的変更をGUI側の例外握りつぶしで吸収しない。
