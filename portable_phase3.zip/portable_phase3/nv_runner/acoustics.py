"""Independent linear acoustic fields, exp(+j omega t), peak phasor transfers.

Gp and vector Gu act on ONE source drive. Projection happens after propagation.
No pressure/velocity output normalization is performed.
"""
import copy
import numpy as np
from scipy.signal import lfilter

ACOUSTIC_VERSION = "1.0"
DRIVE_UNITS = {"plane": "Pa", "monopole": "m^3/s", "piston": "m/s", "rigid_wall": "Pa"}


def vector(value, name, unit=False):
    v = np.asarray(value, dtype=float)
    if v.shape != (3,) or not np.isfinite(v).all():
        raise ValueError(f"{name}: finite 3-vector required")
    if unit and not np.isclose(np.linalg.norm(v), 1., atol=1e-10, rtol=0):
        raise ValueError(f"{name}: unit vector required, not automatically normalized")
    return v


def field_transfer(frequency_hz, source, receiver, medium):
    f = np.asarray(frequency_hz, dtype=float)
    rho, c = float(medium["density_kg_m3"]), float(medium["sound_speed_m_s"])
    if f.ndim != 1 or not np.isfinite(f).all() or np.any(f < 0) or not np.isfinite([rho,c]).all() or min(rho,c) <= 0:
        raise ValueError("invalid acoustic frequencies/medium")
    x = vector(receiver["position_m"], "receiver position")
    model = source["field"]
    if model not in DRIVE_UNITS or source["drive_unit"] != DRIVE_UNITS[model]:
        raise ValueError("field/drive unit mismatch")
    origin = vector(source["position_m"], "source/reference position")
    k = 2*np.pi*f/c
    delta = x-origin
    if model == "plane":
        direction = vector(source["direction"], "plane propagation", True)
        gp = np.exp(-1j*k*np.dot(direction, delta))
        gu = gp[:, None]*direction[None, :]/(rho*c)
    elif model == "monopole":
        r = np.linalg.norm(delta)
        if r <= 1e-6:
            raise ValueError("receiver at monopole singularity")
        phase = np.exp(-1j*k*r)
        gp = 1j*2*np.pi*f*rho*phase/(4*np.pi*r)
        gu = ((1+1j*k*r)*phase/(4*np.pi*r*r))[:, None]*(delta/r)[None, :]
    elif model == "piston":
        normal = vector(source["normal"], "piston normal", True)
        r = float(np.dot(delta, normal))
        radius = float(source["radius_m"])
        if not np.isfinite(radius) or radius <= 0 or r <= 0 or np.linalg.norm(delta-r*normal) > 1e-9:
            raise ValueError("piston requires positive radius and receiver on positive axis")
        edge_distance = np.hypot(r, radius)
        phase = np.exp(-1j*k*r)
        change = np.expm1(-1j*k*(edge_distance-r))
        gp = -rho*c*phase*change
        gu = (phase*((1-r/edge_distance)-(r/edge_distance)*change))[:, None]*normal[None, :]
    else:
        normal = vector(source["normal"], "wall outward normal", True)
        incident = vector(source["incident_direction"], "wall incident propagation", True)
        if np.dot(delta, normal) < -1e-10 or np.dot(incident, normal) >= 0:
            raise ValueError("wall: receiver in fluid and wave incident toward wall required")
        reflected = incident-2*np.dot(incident,normal)*normal
        incoming = np.exp(-1j*k*np.dot(incident,delta))
        outgoing = np.exp(-1j*k*np.dot(reflected,delta))
        gp = incoming+outgoing
        gu = (incoming[:,None]*incident[None,:]+outgoing[:,None]*reflected[None,:])/(rho*c)
    # This engine is acoustic AC only; steady flows/static displacement are not modeled.
    gp[f == 0] = 0
    gu[f == 0] = 0
    return gp, gu


def axial_transfer(f, source, receiver, medium):
    gp, gu = field_transfer(f, source, receiver, medium)
    return gp, gu @ vector(receiver["axis"], "receiver axis", True)


def rotation_trace(t, duration, config):
    start, end = config["start_rpm"], config["end_rpm"]
    rpm = start+(end-start)*np.clip(t/duration, 0, 1)
    rpm *= 1+config.get("ripple_fraction", 0)*np.sin(2*np.pi*config.get("ripple_hz", 2)*t)
    if not np.isfinite(rpm).all() or rpm.min() <= 0:
        raise ValueError("synthetic rotation must remain positive")
    cycles = np.r_[0., np.cumsum((rpm[:-1]+rpm[1:])*np.diff(t)/120)]
    cycles -= np.interp(0, t, cycles)
    return rpm, cycles


def measured_rpm(t, rpm, cycles, config, seed):
    if not config or not config.get("enabled", False):
        return rpm.copy()
    rate = float(config.get("update_hz",100))
    if rate <= 0 or config.get("smoothing_seconds", 0) < 0 or not 0 <= config.get("dropout_fraction",0) < 1:
        raise ValueError("invalid rpm sensor configuration")
    period = 1/rate
    times = np.arange(t[0], t[-1]+period, period)
    delayed = times-config.get("delay_seconds",0)
    value = np.interp(delayed,t,rpm)
    ppr = config.get("pulses_per_revolution",0)
    if ppr:
        if ppr < 1 or int(ppr) != ppr:
            raise ValueError("pulses_per_revolution must be positive integer")
        phase = np.interp(delayed,t,cycles)*ppr
        previous = np.interp(delayed-period,t,cycles)*ppr
        value = (np.floor(phase)-np.floor(previous))*60/(ppr*period)
    value = value*(1+config.get("gain_error_fraction",0))+config.get("offset_rpm",0)
    smooth = config.get("smoothing_seconds",0)
    if smooth:
        a = np.exp(-period/smooth)
        value, _ = lfilter([1-a],[1,-a],value,zi=[a*value[0]])
    rng = np.random.default_rng(seed)
    value += rng.normal(0,config.get("noise_std_rpm",0),len(value))
    quantum = config.get("quantization_rpm",0)
    if quantum:
        if quantum < 0:
            raise ValueError("negative rpm quantum")
        value = np.round(value/quantum)*quantum
    missing = rng.random(len(value)) < config.get("dropout_fraction",0)
    missing[0] = False
    indices = np.maximum.accumulate(np.where(missing,0,np.arange(len(value))))
    value = np.maximum(0,value[indices])
    return value[np.clip(np.searchsorted(times,t,side="right")-1,0,len(value)-1)]


def band_filter(f, fs, config):
    low = config["highpass_hz"]
    transition = config["transition_hz"]
    high = config["lowpass_fraction"]*fs
    if not (0 < low and 0 < transition < high-low and high+transition < fs/2):
        raise ValueError("invalid synthesis band")
    return np.clip((f-low)/transition,0,1)*np.clip((high+transition-f)/transition,0,1)


def drive_spectrum(t, cycles, fs, duration, source, numerics, seed):
    excitation = source["excitation"]
    rng = np.random.default_rng(seed)
    phase = excitation.get("phase_radians",float(rng.uniform(-np.pi,np.pi)))
    kind = excitation["kind"]
    if kind == "order":
        carrier = np.sin(2*np.pi*excitation["order"]*cycles+phase)
        instantaneous = excitation["order"]*np.gradient(cycles,t)
        if instantaneous.max() > numerics["lowpass_fraction"]*fs:
            raise ValueError("order excitation exceeds synthesis passband")
    elif kind in ("tone","events"):
        frequency = excitation["frequency_hz"]
        if not numerics["highpass_hz"]+numerics["transition_hz"] <= frequency <= numerics["lowpass_fraction"]*fs:
            raise ValueError("carrier outside synthesis passband")
        carrier = np.sin(2*np.pi*frequency*t+phase)
    elif kind == "noise":
        carrier = rng.normal(size=len(t))
    else:
        raise ValueError("unknown excitation")
    envelope = np.ones(len(t))
    if kind == "events":
        envelope = sum(np.exp(-.5*((t-duration*center)/excitation["sigma_seconds"])**2)
                       for center in excitation["center_fractions"])
    if "gate_fraction" in excitation:
        a,b = np.asarray(excitation["gate_fraction"])*duration
        ramp = excitation.get("ramp_seconds",.02)
        if not 0 <= a < b <= duration or not 0 < ramp <= (b-a)/2:
            raise ValueError("invalid excitation gate")
        q = np.clip((t-a)/ramp,0,1)*np.clip((b-t)/ramp,0,1)
        envelope *= .5-.5*np.cos(np.pi*q)
    amplitude = float(source["drive_rms"])
    if not np.isfinite(amplitude) or amplitude < 0:
        raise ValueError("invalid source drive RMS")
    guard = -t[0]
    taper = np.ones(len(t))
    left,right = t < 0,t >= duration
    taper[left] = np.sin(np.pi/2*np.clip((t[left]+guard)/guard,0,1))**2
    taper[right] = np.cos(np.pi/2*np.clip((t[right]-duration)/guard,0,1))**2
    f = np.fft.rfftfreq(len(t),1/fs)
    filt = band_filter(f,fs,numerics)
    if kind == "noise":
        low,high = excitation["band_hz"]
        if not 0 < low < high < fs/2:
            raise ValueError("invalid noise band")
        filt *= (f >= low) & (f <= high)
        base = np.fft.irfft(np.fft.rfft(carrier*taper)*filt,n=len(t))
        center = (t>=0) & (t<duration)
        rms = np.sqrt(np.mean(base[center]**2))
        if rms == 0:
            raise ValueError("noise passband empty")
        drive = base*(amplitude/rms)*envelope
        spectrum = np.fft.rfft(drive)*filt
    else:
        spectrum = np.fft.rfft(np.sqrt(2)*amplitude*carrier*envelope*taper)*filt
    spectrum[0] = 0
    if len(t)%2 == 0:
        spectrum[-1] = 0
    return spectrum


def sensor_response(f, config):
    gains = np.asarray(config["gain_db"],float)
    phases = np.asarray(config["phase_degrees"],float)
    delays = np.asarray(config["delay_seconds"],float)
    if any(v.shape != (2,) or not np.isfinite(v).all() for v in (gains,phases,delays)):
        raise ValueError("sensor gain/phase/delay require two finite values")
    return 10**(gains[None,:]/20)*np.exp(1j*np.deg2rad(phases[None,:])-2j*np.pi*f[:,None]*delays[None,:])


def synthesize(config, sources, seed, rotation=None):
    """Return observed inputs and a separate diagnostic payload. Caller controls isolation."""
    if config["acoustic_schema_version"] != ACOUSTIC_VERSION:
        raise ValueError("unsupported acoustic schema version")
    fs,duration = config["sample_rate_hz"],config["duration_seconds"]
    numerics = config["numerics"]
    n = round(fs*duration)
    guard = round(fs*numerics["guard_seconds"])
    if n < 32 or guard < 16:
        raise ValueError("insufficient recording/guard")
    t = (np.arange(n+2*guard)-guard)/fs
    f = np.fft.rfftfreq(len(t),1/fs)
    rotation = rotation or config["rotation"]
    true_rpm, cycles = rotation_trace(t,duration,rotation)
    measured = measured_rpm(t,true_rpm,cycles,config["rpm_sensor"],np.random.SeedSequence([seed,987]))
    axis = vector(config["receiver"]["axis"],"receiver axis",True)
    pair_spectrum = np.zeros((len(f),2),complex)
    parts, drives, transfers = [], [], []
    # Globally contradictory boundaries are rejected rather than silently superposed.
    fields = {source["field"] for source in sources}
    if "rigid_wall" in fields and fields != {"rigid_wall"}:
        raise ValueError("rigid-wall scene must use wall-consistent sources only")
    if "piston" in fields and fields != {"piston"}:
        raise ValueError("piston scene must use same baffled geometry sources only")
    if fields == {"piston"}:
        signatures = {(tuple(s["position_m"]),tuple(s["normal"]),s["radius_m"]) for s in sources}
        if len(signatures) != 1:
            raise ValueError("piston sources must share the same baffled piston geometry")
    if fields == {"rigid_wall"}:
        if len({(tuple(s["position_m"]),tuple(s["normal"])) for s in sources}) != 1:
            raise ValueError("wall sources must share boundary")
    for source in sources:
        gp,gu = axial_transfer(f,source,config["receiver"],config["medium"])
        drive = drive_spectrum(t,cycles,fs,duration,source,numerics,np.random.SeedSequence([seed,source["seed_key"]]))
        pair = drive[:,None]*np.column_stack([gp,gu])
        pair_spectrum += pair
        parts.append(np.fft.irfft(pair,n=len(t),axis=0)[guard:guard+n])
        drives.append(np.fft.irfft(drive,n=len(t))[guard:guard+n])
        # Full complex transfer values are stored numerically in truth, not used by inference.
        transfers.append(np.column_stack([gp.real,gp.imag,gu.real,gu.imag]))
    acoustic = np.fft.irfft(pair_spectrum,n=len(t),axis=0)[guard:guard+n]
    sensor = config["sensor"]
    observed = np.fft.irfft(pair_spectrum*sensor_response(f,sensor),n=len(t),axis=0)[guard:guard+n]
    noise_std = np.asarray(sensor["noise_std_si"],float)
    if noise_std.shape != (2,) or np.any(noise_std < 0) or not np.isfinite(noise_std).all():
        raise ValueError("invalid sensor noise")
    observed += np.random.default_rng(np.random.SeedSequence([seed,876])).normal(size=observed.shape)*noise_std
    if not np.isfinite(observed).all():
        raise ValueError("nonfinite acoustic signal")
    return {"waveform": observed, "rpm_measured": measured[guard:guard+n],
        "truth": {"acoustic_waveform": acoustic,"source_waveforms": np.asarray(parts), "source_drives": np.asarray(drives),
                  "sensor_residual": observed-acoustic,"rpm_true": true_rpm[guard:guard+n],
                  "transfer_frequency_hz": f,"transfers_re_im": np.asarray(transfers)},
        "sources": copy.deepcopy(sources)}
