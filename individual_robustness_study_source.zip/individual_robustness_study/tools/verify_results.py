from pathlib import Path
import sys,subprocess,zipfile,copy,platform,shutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import bootstrap_study
from bridge.adapter import read,write,sha
from nv_runner.input_adapter import InputAdapter
from experiment import prepare,score
from register_pool import register
import numpy as np,joblib,scipy,sklearn

out=ROOT/'outputs/comparison_v1';reports=ROOT/'reports';reports.mkdir(exist_ok=True)
assert read(out/'status.json')['status']=='passed'
assert register(out)==360
protocol=read(out/'protocol.json');rows=read(out/'map_rows.json');stability=read(out/'stability_rows.json');cells=read(out/'map_summary.json');stats=read(out/'stability_summary.json')
assert len(rows)==5040 and len(stability)==1620 and len(cells)==140 and len(stats)==45
assert all(c['normal_n']==6 and c['abnormal_n']==30 and c['paired_n']==30 for c in cells)
assert len(list((out/'cases').glob('*/complete.json')))==1008
hashes=read(out/'model_hashes.json');assert hashes=={p.relative_to(out/'models').as_posix():sha(p) for p in (out/'models').rglob('*') if p.is_file()}
for seed in protocol['partition_seeds']:
    for key in {r['route_key'] for r in rows}:
        a=next(s for s in stats if s['variant']==f's{seed}_fit16_cal4' and s['route']==key);b=next(s for s in stats if s['variant']==f's{seed}_fit16_cal8' and s['route']==key)
        assert b['threshold']>=a['threshold'];assert b['normal_correct']>=a['normal_correct'];assert b['detected']<=a['detected']
# Check target additions remain identical across nuisance levels/directions.
max_error=0.;pairs=0
for family in protocol['evaluation_families']:
    for mi in range(2):
        path=out/'cases'/f'f{family}_j00_normal'/f'm{mi}'/'observations.npz'
        with np.load(path,allow_pickle=False) as z:clean={k:z[k].copy() for k in ['pressure_pa','velocity_m_s']}
        target_deltas={}
        for kind in protocol['scenarios'][1:]:
            with np.load(out/'cases'/f'f{family}_j00_{kind}'/f'm{mi}'/'observations.npz',allow_pickle=False) as z:target_deltas[kind]={k:z[k]-clean[k] for k in clean}
        for ji in range(1,28):
            with np.load(out/'cases'/f'f{family}_j{ji:02d}_normal'/f'm{mi}'/'observations.npz',allow_pickle=False) as z:normal={k:z[k].copy() for k in clean}
            for kind in protocol['scenarios'][1:]:
                with np.load(out/'cases'/f'f{family}_j{ji:02d}_{kind}'/f'm{mi}'/'observations.npz',allow_pickle=False) as z:
                    for k in clean:
                        actual=z[k]-normal[k];expected=target_deltas[kind][k];np.testing.assert_allclose(actual,expected,rtol=1e-10,atol=1e-12);max_error=max(max_error,float(np.max(abs(actual-expected))))
                pairs+=1
cfg=read(out/'experiment.json');primary=protocol['primary'];models={r['key']:joblib.load(out/'models'/primary/f'{r["key"]}.joblib') for r in cfg['routes']};thresholds={k:read(out/'models'/primary/f'{k}_threshold.json') for k in models}
records=InputAdapter().load(out/'cases/f200000_j00_normal/canonical/manifest.json');p=prepare(records,cfg);a=score(records,p,cfg,models,thresholds)
changed=copy.deepcopy(cfg);changed['batch_size']=1;b=score(list(reversed(records)),prepare(list(reversed(records)),changed),changed,models,thresholds)
for x,y in zip(a,b):
    assert (x['case_id'],x['decision'],x['n_scored'])==(y['case_id'],y['decision'],y['n_scored']);np.testing.assert_allclose(x['case_score'],y['case_score'],rtol=1e-12,atol=1e-12)
    assert [t['sample']['sample_id'] for t in x['top_inputs']]==[t['sample']['sample_id'] for t in y['top_inputs']]
proc=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(ROOT),'-p','test_study.py','-v'],capture_output=True,text=True);(reports/'tests.log').write_text(proc.stdout+proc.stderr,encoding='utf-8');assert proc.returncode==0
validation={'status':'passed','unit_tests':5,'prepared_subset_routes':read(out/'training_validation.json')['prepared_subset_equivalence'],'same_fit_calibration_change_model_byte_pairs':15,'target_superposition_pairs':pairs,'target_superposition_max_absolute_error':max_error,'model_files_unchanged':True,'shuffled_records_batch1_verified':True,'normal_train_eval_disjoint_checks':'specimen, case, parent, source hash for every evaluation case','baseline_files':bootstrap_study.verify_baseline(),'baseline130_rerun':False,'browser_visual_inspection':False}
write(reports/'validation.json',validation);write(reports/'environment.json',{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'platform':platform.platform()})
for name in ['REPORT.md','stability_summary.json','map_summary.json','protocol.json','splits.json','source_hashes.json','status.json','training_validation.json','model_hashes.json']:(reports/name).write_bytes((out/name).read_bytes())
lines=['# 追加検証の観察結果','', '同じ新規6群を使った今回の内部比較。前回の6群とは異なるため、前回との差を改善効果と解釈しない。分割3回の最小～最大を示し、信頼区間としない。','', '|経路|fit16/cal4 正常・異常|fit16/cal8 正常・異常|fit32/cal8 正常・異常|','|---|---|---|---|']
for key in models:
    cells_text=[]
    for name in protocol['variants']:
        ss=[s for s in stats if s['route']==key and s['variant'].endswith(name)]
        cells_text.append(f'{min(s["normal_correct"] for s in ss)}–{max(s["normal_correct"] for s in ss)}/6 ・ {min(s["detected"] for s in ss)}–{max(s["detected"] for s in ss)}/30')
    lines.append('|'+key+'|'+'|'.join(cells_text)+'|')
lines+=['','## 事前選択構成の外乱なし評価','', '|経路|正常正解|異常検出|両方正解|','|---|---:|---:|---:|']
for c in cells:
    if c['direction'] is None:lines.append(f'|{c["route"]}|{c["normal_correct"]}/6|{c["detected"]}/30|{c["both_correct"]}/30|')
lines+=['','## 外乱下27条件での両方正解数の範囲','', '|経路|最小～最大（各条件30対）|全対で両方正解した条件数|外乱下の異常検出数の範囲|','|---|---:|---:|---:|']
for key in models:
    cs=[c for c in cells if c['route']==key and c['direction'] is not None]
    lines.append(f'|{key}|{min(c["both_correct"] for c in cs)}–{max(c["both_correct"] for c in cs)}/30|{sum(c["both_correct"]==30 for c in cs)}/27|{min(c["detected"] for c in cs)}–{max(c["detected"] for c in cs)}/30|')
lines+=['','合成ばらつきの幅は固定したまま個体数・組合せを検証。閾値設定用4/8群の95%higher分位点はいずれも最大値（センサー校正とは別）。外乱下の異常検出率が高くても、正常もoutsideなら識別成功の証拠にしない。新しい最適構成は選定していない。']
(reports/'OBSERVATIONS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(ROOT/'WORK_STATUS.md').write_text('# 完了記録\n\noutputs/comparison_v1: 正常候補60群、9構成、未使用6群、1008条件の評価完了。reports/validation.jsonとOBSERVATIONS.md参照。\n既存基盤164ファイル不変。モデル・閾値の評価中変更なし。全27外乱条件で正常/異常の対比較を保存。既存130試験、実測、分布幅変更、測定時間/受音点数変更の試験は今回未実施。\n',encoding='utf-8')
files=[]
for p in sorted(ROOT.rglob('*')):
    rel=p.relative_to(ROOT)
    if not p.is_file() or any(x in rel.parts for x in ['outputs','__pycache__','.venv']) or p.name=='package_manifest.json':continue
    files.append({'path':rel.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
write(ROOT/'package_manifest.json',{'schema_version':'individual-study-package/1.0','files':files})
target=ROOT.parent/'individual_robustness_study_source.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for e in files:z.write(ROOT/e['path'],'individual_robustness_study/'+e['path'])
    z.write(ROOT/'package_manifest.json','individual_robustness_study/package_manifest.json')
print(validation);print(target,target.stat().st_size)
