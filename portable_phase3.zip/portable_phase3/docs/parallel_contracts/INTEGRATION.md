# 契約変更と統合手順

## 1. 決定権と開始条件

契約keeperは統合担当I。各境界のproducer/consumer責任者はAGENT_TASKSの担当、契約試験責任者はQ。初回に、C01〜08の既存互換部分、担当ファイル、基準commit/hashを短い採択記録へ残す。実情報不足のU項目は仮置きのまま開始し、採択のために全体設計の完成を待たない。

今回の調査は設計のみで採択/コード変更は未実施。Git管理が確認できないので、実開発前にユーザーの管理対象を確認し、01相当のコード・設定・docs・testsだけをGitに置く。旧PoC/参照群や生成データを一括importしない。既存リポジトリが別の場所にある場合はそれを選び、推測でremoteを作らない。

## 2. 変更申請（CR）

担当はdocs/parallel_contracts/changes/CR-<ID>.mdへ下記を提出する案。まだchangesファイルは作っていない。

```text
契約ID / 提案者 / producer owner / consumer owner:
現在の署名・field・意味:
提案する署名・field・意味:
変更理由と、既存契約内で解決できない理由:
影響ファイル / 影響するconsumer:
互換性: 内部のみ / 任意追加 / 意味変更・破壊的
ダミー入力と期待出力（変更前/後）:
必要なCTと既存回帰:
版・旧データ・旧モデルの扱い:
移行・切戻し手順:
開発を継続できる独立部分:
承認: producer / consumer / I / Q
状態: proposed / accepted / implemented / verified / rejected / superseded
```

CR状態は**開発管理用**であり、ResultBundleのenumへ混ぜない。

### 承認の最小ルール

- 内部アルゴリズムのみで契約/依存版/共有ファイルを変えない：担当内レビューと既存CTでよい、全体承認待ちにしない。
- 任意field/artifact追加：producerと実際のconsumer、Iが互換性確認、Qが後方読込テスト案を確認。既存readerが未知keyを本当に許容するかコードで確認する。
- 必須field、単位、座標、状態、score方向、ID、登録signature、共有前処理、truth境界、serialize/モデル説明、依存版の変更：影響するproducer/consumer＋I＋Qが承認。非互換ならversionと旧データ拒否/移行を同時に決める。
- 実測の校正条件・正常の定義・性能採否、外部接続先との契約はユーザー/測定または接続先責任者の判断が必要。コード担当だけで実測値を決めない。
- 無応答を承認にしない。承認待ちは当該boundaryのmergeだけ保留し、担当専用module内の独立開発/直接testは続ける。全タスクを止めない。

## 3. 最小接続パッチの方針

routeは当初既存基底/クラスをimportして担当moduleで直接試験する。本番接続時にIだけが既存REGISTRY/runner validatorを更新する。必要ならroute_registry.pyへ組立を分けるが、全routes.pyクラス移動を並列着手の前提にしない。基底をimportする候補とregistryの循環依存を確認する。

モデル追加はkind whitelistだけでなく、runnerのscore_definition/preprocessingの固定文言を点検する。内部がScaler以外なのにStandardScaler fit onlyと保存される結合を許可しない。input adapter/出力adapterも同様に既存入口へIが配線する。

各接続PRは1候補または1境界までとし、format-onlyの全体変更や無関係リファクタを同時に入れない。共通__version__はIが統合単位で変更し、sample_idへの波及を明記する。

## 4. 段階別の実行計画

|段階|実施|完了ゲート|待たずに進められる作業|
|---|---|---|---|
|G0 baseline|対象repo/commit確認、hash記録、32既存試験とquickの基準採取、所有権/契約の短い採択|基準結果/既知失敗が可視化される。既存失敗を新担当の責任にしない|専用候補module、fixture設計、実測仕様の調査|
|G1 contract-first|QがCT01〜08を小さく実装、最小Record/PreparedSet/Bundle生成fixture提供|CT件数>0、producer/consumerが同じfixtureを扱える|UI/adapter/route/modelを直接呼出しで開発|
|G2 縦切りA|IがA候補だけ配線し観測→fit/cal→score→Bundle→viewerを接続|単体CTとA両版、元範囲逆引き、正解隔離|B/C/D、入力、出力候補の独立test|
|G3 経路追加|B/C/Dを1候補ずつ結合。各merge前に最新baselineへ追従|全5経路、欠落rpm/空選択/イベント0件/部分失敗の状態が適合|次候補やモデル内部の改良|
|G4 consumer結合|新Bundleをviewer/出力adapterが別プロセスで読込、破損/再送/原本参照試験|CT06/07、null/partial/任意artifact欠落で正しく表示・通知|実接続未定ならremote stubを維持|
|G5 回帰/比較|全既存32＋追加CT、物理verify、quick/comparison、UI操作|機能回帰成功。検出差と母数を保存。過去件数の強制一致/100%検出は求めない|性能改善案は次runとして比較|
|G6 引渡し|小さいレポート、契約版、hash、設定、未決定事項、再実行コマンド|01だけで生成から再実行でき、Gitに大容量生成物なし|実測/外部接続は別受入ゲート|

G0〜G1の完全終了まで全員停止させない。C01〜08の採用と担当ファイルが決まった時点で候補内作業は開始できる。G2以降の**mergeと結合**は直列化して原因を切り分ける。ランタイムの逐次実行は維持する。

## 5. ブランチ・共有資産・統合チェックリスト

- 確認済みrepoの基準commitから担当ごとのbranch/worktreeを用意する案。共有同一checkoutを使う場合でも所有範囲を守り、他担当の未commitを取り込まない。Git未設定のまま存在しないbranch名を既成事実にしない。
- generation/inputs/models/output先は各担当固有。fixture生成seed/configは共通だが、書込先・一時ファイル・cacheは共有しない。
- merge前：担当の変更file listがallowlist内、未承認CRなし、全schema/単位/参照説明が正、必要なCTと既存関連test成功。
- merge後：Iがwriter→reader→viewer/outputを確認。依存版を変えた場合は全試験。失敗したら新境界を覆う最小修正または該当commitをrevertし、他担当の機能をまとめて巻戻さない。
- 固定seedのモデル/閾値不変テストは**同じコード/環境でeval/truthだけを変えた場合**の検証。コード変更前後のモデルhash一致を無条件に要求しない。
- stagingを完成物へ改名して救済しない。再実行は新runで全工程、view失敗だけなら完成Bundleから再生成可能。途中学習を再利用するcheckpointは未実装。

## 6. 最終受入報告の形式

```text
基準commit / 統合commit / schema / 契約提案版:
採用CR / 保留CR:
担当と変更ファイル:
CT01..CT08: pass/fail/not_run + 試験数:
既存回帰/物理/quick/comparison/UI/受渡し:
個体TP/FP/FN/TN/判定不可、独立個体群数:
生成config/seed/分割、Bundle manifest hash、成果物保存先:
既知制約・未決定U項目、次の担当:
```

実測・外部APIの未接続を隠さない。共通契約の設計完成ではなく、**各担当が専用ファイルで開発でき、境界で結合できること**をこの計画の完了条件とする。
