"""Small, explicit route configuration schema validator (not full JSON Schema).

Validation never supplies defaults or mutates configuration. Legacy numeric
declarations can opt into Python bool-as-number and non-finite acceptance;
new declarations reject both by default. File JSON validation remains upstream.
"""
import math


_TYPES = {"object", "array", "number", "integer", "string", "boolean", "null"}
_COMMON = {"type", "enum"}
_KEYWORDS = {
    "object": {"properties", "required", "additionalProperties"},
    "array": {"items", "minItems", "maxItems"},
    "number": {"minimum", "exclusiveMinimum", "maximum", "exclusiveMaximum", "allow_bool", "finite"},
    "integer": {"minimum", "exclusiveMinimum", "maximum", "exclusiveMaximum", "allow_bool", "finite"},
    "string": set(), "boolean": set(), "null": set(),
}


def validate_schema(schema):
    """Reject unknown/ill-formed declarations before a plugin can be selected."""
    if not isinstance(schema, dict) or not isinstance(schema.get("type"), str) or schema["type"] not in _TYPES:
        raise ValueError("schema requires a supported type")
    kind = schema["type"]
    unknown = set(schema) - _COMMON - _KEYWORDS[kind]
    if unknown:
        raise ValueError(f"unsupported schema keywords: {sorted(unknown)}")
    if "enum" in schema and (not isinstance(schema["enum"], list) or not schema["enum"]):
        raise ValueError("schema enum must be a nonempty list")
    if kind == "object":
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        if not isinstance(properties, dict) or any(not isinstance(key, str) for key in properties):
            raise ValueError("schema properties must be a string-keyed object")
        if not isinstance(required, list) or any(not isinstance(key, str) for key in required):
            raise ValueError("schema required must be a list of strings")
        if len(required) != len(set(required)) or not set(required) <= set(properties):
            raise ValueError("schema required must name unique declared properties")
        if not isinstance(schema.get("additionalProperties", True), bool):
            raise ValueError("schema additionalProperties must be boolean")
        for child in properties.values():
            validate_schema(child)
    if kind == "array":
        if "items" in schema:
            validate_schema(schema["items"])
        for key in ("minItems", "maxItems"):
            if key in schema and (type(schema[key]) is not int or schema[key] < 0):
                raise ValueError(f"schema {key} must be a nonnegative integer")
        if schema.get("minItems", 0) > schema.get("maxItems", math.inf):
            raise ValueError("schema minItems exceeds maxItems")
    if kind in ("number", "integer"):
        for key in ("allow_bool", "finite"):
            if key in schema and not isinstance(schema[key], bool):
                raise ValueError(f"schema {key} must be boolean")
        for key in ("minimum", "exclusiveMinimum", "maximum", "exclusiveMaximum"):
            if key in schema and (type(schema[key]) not in (int, float) or not math.isfinite(schema[key])):
                raise ValueError(f"schema {key} must be finite numeric")


def _validate(value, schema, path):
    kind = schema["type"]
    types = {"object": dict, "array": list, "number": (int, float),
             "integer": int, "string": str, "boolean": bool, "null": type(None)}
    accepted = isinstance(value, types[kind])
    if kind in ("number", "integer") and isinstance(value, bool) and not schema.get("allow_bool", False):
        accepted = False
    if not accepted:
        raise ValueError(f"invalid/missing {path}: expected {kind}")
    if "enum" in schema and not any(type(value) is type(item) and value == item for item in schema["enum"]):
        raise ValueError(f"invalid {path}: not in enum")
    if kind in ("number", "integer"):
        if schema.get("finite", True) and not math.isfinite(value):
            raise ValueError(f"invalid {path}: non-finite number")
        # Keep the old <= comparison for legacy NaN acceptance when finite=False.
        for key, violates in (("minimum", lambda a, b: a < b),
                              ("exclusiveMinimum", lambda a, b: a <= b),
                              ("maximum", lambda a, b: a > b),
                              ("exclusiveMaximum", lambda a, b: a >= b)):
            if key in schema and violates(value, schema[key]):
                raise ValueError(f"invalid/missing {path}: {key}")
    elif kind == "object":
        properties = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                raise ValueError(f"invalid/missing {key}")
        if not schema.get("additionalProperties", True) and set(value) - set(properties):
            raise ValueError(f"unknown configuration properties at {path}: {sorted(set(value) - set(properties))}")
        for key, child in properties.items():
            if key in value:
                _validate(value[key], child, key if path == "route" else f"{path}.{key}")
    elif kind == "array":
        if len(value) < schema.get("minItems", 0) or len(value) > schema.get("maxItems", math.inf):
            raise ValueError(f"invalid {path}: array length")
        if "items" in schema:
            for index, item in enumerate(value):
                _validate(item, schema["items"], f"{path}[{index}]")


def _check_selection(node):
    # Deliberately retains the existing validator's operators and error behavior.
    if "op" in node:
        if node["op"] not in ("and", "or") or len(node["children"]) < 2:
            raise ValueError("selection requires AND/OR with >=2 children")
        for child in node["children"]:
            _check_selection(child)
    elif node["field"] not in ("frequency_hz", "msc", "intensity", "reactive_intensity", "phase", "p_power", "u_power") or node["comparison"] not in (">", ">=", "<", "<=") or not isinstance(node["value"], (int, float)):
        raise ValueError("invalid selection predicate")


def validate_route_config(config, schema):
    """Validate current C03/C04 route config plus its declared local schema."""
    validate_schema(schema)
    if schema["type"] != "object":
        raise ValueError("route schema must be object")
    if not isinstance(config, dict):
        raise ValueError("route configuration must be object")
    if config["model"]["kind"] not in ("isolation_forest", "pca"):
        raise ValueError("unknown model")
    if config.get("selection", {}).get("enabled"):
        _check_selection(config["selection"]["condition"])
    _validate(config, schema, "route")
