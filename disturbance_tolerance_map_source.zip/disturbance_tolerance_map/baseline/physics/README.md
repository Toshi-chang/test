# 分布音源p–uエンジン：独立PoC 0.1.0

2026-11-06。既存NV Runner 0.2.0／Phase3／ResultBundle 1.0を変更せず、音源を面・表面・体積・部品位置へ分布させる実証を追加した。既存コードをimportせず、NumPyのみで動作する。実測データは不要。

## 今回できること

- 点、長方形、円板、箱・球・円柱の表面と内部体積に等価単極子を配置。
- 独立した部品音源を、位置と異なる励振で合成。箱の内部3部品の例を用意。
- 一様／Gaussian集中分布、同相／逆相の半面、空間的位相勾配／遅延勾配。
- 定常音、回転次数（一定または線形RPM変化）、Gaussianイベント、帯域雑音。雑音の同じseed_keyは共有励振、異なるseed_keyは独立した乱数系列。部分相関の任意行列は未実装。
- バッフル付き円板・長方形の面法線速度からRayleigh積分を計算。軸外の受音点も計算可能。
- 複数受音位置で音圧pと3成分速度Uを計算し、それぞれの測定軸eへu=e·Uとして投影。
- 観測配列と音源別の生成器正解を別ファイル保存。保存済み結果からオフラインHTMLを生成。

**形状は基本的に「音源の分布場所」であり、音を遮る固体ではない。** 箱の内部配置は壁を透過する物理を計算していない。バッフルだけは明示的な境界モデルを持ち、他の自由空間音源と混ぜない。表面の等価単極子を、そのまま実際の筐体法線振動速度と解釈しない。

## 最初に見るもの

- `outputs/demo_final/index.html`：13種類の配置・波形・観測値の一覧（ローカル生成物）。
- `CONTRACT.md`：定義・単位・軸・正規化・適用外条件。
- `reports/VALIDATION.md`：試験と限界。`reports/tests.log`が試験ログ。
- `configs/*.json`：明示された再実行条件。generator既定値の切替はない。

## Windowsでの実行

本フォルダを作業ディレクトリにする。Python 3.12 64bit／NumPy 2.3.5で確認。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -B -m da_engine run --config configs/internal_components.json --output outputs/internal_new
.\.venv\Scripts\python.exe -B -m da_engine inspect --result outputs/internal_new
.\.venv\Scripts\python.exe -B -m da_engine view --result outputs/internal_new --output outputs/internal_new/viewer.html
.\.venv\Scripts\python.exe -B run_examples.py --output outputs/all_new
```

出力先は未作成のフォルダを指定する。失敗成果物は上書きせず、failure.jsonを保存して別の出力先へ再実行する。viewer生成は学習・再生成を伴わない。全シナリオ再実行は十数MB程度の出力になるが条件により変わる。試験用データはtests/_workへ残す。

`make_examples.py`は設定を作り直す開発用スクリプトで、通常の再実行には不要。条件を変更する場合は既存JSONを別名で複製し、結果と一緒に保存する。今回のソースと設定のSHAはreports/source_manifest.jsonに保存。

## 比較時の注意

free_space例の全体体積速度RMSは1e-5 m³/s、baffle例の面法線速度RMSは0.001 m/s。両者は同じ音源強さの比較ではない。既存acoustic生成器はイベント包絡前のRMSを定義していたが、本PoCは**包絡・帯域制限後の中央記録区間RMS**を励振強さに採用した。既存値をそのまま移植して同じイベント強度と扱わない。

各要素の位相や遅延を変えると相殺が起きる。全体体積速度は位相付与前の重み総量であり、位相付与後の正味体積速度や放射パワーを一定にするものではない。p/u出力は個別に正規化しない。

## 既存基盤との関係

このPoCの出力は独自の`distributed-acoustics-result/1.0`でありNV ResultBundle 1.0ではない。既存の5経路、InputAdapter、130試験には組み込んでいない。観測p/uを各受音点の測定へ変換するAdapter、RPM観測系列、fit/cal/eval登録、検出性能比較は次段階。複数受音点を独立個体として数えることはしない。

D-002の正式採用、筐体透過・散乱、構造振動連成、実測校正、任意CADメッシュ、GUI編集、NV側のセンサー誤差モデルの移植は未実装。必要な条件を未対応のまま黙って近似しない。

## 理論参照

- 自由空間単極子と軸上ピストンの規約は既存`nv_route_runner_poc/docs/ACOUSTIC_DESIGN.md`と整合させた（実行時依存なし）。
- [COMSOL Baffled Piston Radiation](https://doc.comsol.com/6.3/doc/com.comsol.help.models.aco.baffled_piston_radiation/baffled_piston_radiation.html)：バッフル付き面放射と解析解比較。
- [局所音源と構造物の境界要素法](https://arxiv.org/abs/2104.13137)：将来の境界を含む拡張との区別。今回はBEM/FEMを実装していない。
