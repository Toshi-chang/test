"""Reproducible full example run, physical error report, saved offline viewers."""
from pathlib import Path
import argparse,json,time,copy
import numpy as np
from da_engine.artifacts import run,inspect,view,write
from da_engine.engine import response
from make_examples import examples

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
    root=a.output.resolve()
    if root.exists():raise ValueError('fresh output required')
    root.mkdir(parents=True);cases=[]
    configs=Path(__file__).resolve().parent/'configs'
    for path in sorted(configs.glob('*.json')):
        start=time.perf_counter();target=run(path,root/path.stem)
        info=inspect(target);view(target,target/'viewer.html')
        cases.append({'scenario':path.stem,'status':'passed','seconds':time.perf_counter()-start,**info})
    convergence=[]
    for n in [2,4,8,16,32]:
        s=examples()['rectangle'];s['sources'][0]['geometry']['resolution']=n
        p,u=response(s,[800]);convergence.append((n,p,u))
    refp,refu=convergence[-1][1:]
    numerical={'rectangle_800Hz_reference':'resolution32 numerical reference, not exact truth',
        'rectangle_convergence':[{'resolution':n,'pressure_relative_l2':float(np.linalg.norm(p-refp)/np.linalg.norm(refp)),
                                    'velocity_relative_l2':float(np.linalg.norm(u-refu)/np.linalg.norm(refu))} for n,p,u in convergence]}
    s=examples()['baffled_disk'];s['sources'][0]['geometry']['resolution']=12;s['receivers']=s['receivers'][:1]
    f=np.array([20.,200.,800.]);p,u=response(s,f);k=2*np.pi*f/343;r=.2;R=np.hypot(r,.06)
    ep=1.2*343*.001*(np.exp(-1j*k*r)-np.exp(-1j*k*R));eu=.001*(np.exp(-1j*k*r)-r/R*np.exp(-1j*k*R))
    numerical['baffled_disk_vs_analytic']={'frequency_hz':f.tolist(),'pressure_max_relative_error':float(np.max(abs(p[:,0]-ep)/abs(ep))),
        'axial_velocity_max_relative_error':float(np.max(abs(u[:,0,2]-eu)/abs(eu)))}
    write(root/'validation.json',{'status':'passed','cases':cases,'numerical':numerical,
          'limits':'mathematical consistency and artifact integrity, no measured validation, no detection evaluation'})
    links=''.join(f'<li><a href="{x["scenario"]}/viewer.html">{x["scenario"]}</a></li>' for x in cases)
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>分布音源PoC</title><h1>分布音源の比較例</h1><p>形状は音源の分布。バッフル以外に筐体境界はありません。</p><ul>'+links+'</ul>',encoding='utf-8')
    print(json.dumps({'cases':len(cases),'status':'passed','numerical':numerical},ensure_ascii=False))
if __name__=='__main__':main()
