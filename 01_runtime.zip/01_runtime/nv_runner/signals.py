"""Shared, explicitly indexed STFT and physical maps."""
import numpy as np
from scipy.ndimage import uniform_filter1d


def mean_square_spectrum(values):
    """Hann-windowed one-sided bin contributions; sum equals window-weighted mean square."""
    values = np.asarray(values)
    n = len(values)
    window = np.hanning(n)
    if n < 3:
        raise ValueError("at least three samples required for Hann power")
    spectrum = np.fft.rfft(values*window.reshape((-1,)+(1,)*(values.ndim-1)),axis=0)
    factors = np.full(len(spectrum),2.)
    factors[0] = 1
    if n%2 == 0:
        factors[-1] = 1
    return abs(spectrum)**2*(factors/(n*np.sum(window**2))).reshape((-1,)+(1,)*(values.ndim-1))


class SignalService:
    def __init__(self, config):
        self.config = config
        self.cache = {}

    def maps(self, record):
        key = record.meta["measurement_id"]
        if key in self.cache:
            return self.cache[key]
        x, fs = record.signals, record.meta["timebase"]["sample_rate_hz"]
        nfft, hop, avg = self.config["nfft"], self.config["hop_samples"], self.config["average_frames"]
        if len(x) < nfft:
            raise ValueError("measurement shorter than STFT support")
        starts = np.arange(0, len(x) - nfft + 1, hop)
        window = np.hanning(nfft)
        frames = np.stack([x[a:a+nfft] for a in starts])
        convention = self.config.get("spectral_convention", "legacy_amplitude_squared")
        spectrum = np.fft.rfft(frames * window[None, :, None], axis=1)
        if convention == "mean_square_bin_v2":
            factor = np.full(spectrum.shape[1],2.)
            factor[0] = 1
            if nfft%2 == 0:
                factor[-1] = 1
            spectrum *= np.sqrt(factor/(nfft*np.sum(window**2)))[None,:,None]
        elif convention == "legacy_amplitude_squared":
            spectrum /= window.sum()
        else:
            raise ValueError("unknown spectral convention")
        pp, uu = abs(spectrum[:, :, 0]) ** 2, abs(spectrum[:, :, 1]) ** 2
        cross = spectrum[:, :, 0] * spectrum[:, :, 1].conj()
        smooth = lambda v: uniform_filter1d(v, avg, axis=0, mode="nearest")
        sp, su = smooth(pp), smooth(uu)
        sc = smooth(cross.real) + 1j * smooth(cross.imag)
        msc = np.clip(abs(sc) ** 2 / np.maximum(sp * su, 1e-30), 0, 1)
        valid = np.ones_like(pp, dtype=bool)
        half = avg // 2
        valid[:half] = False
        valid[-half:] = False
        if convention == "mean_square_bin_v2":
            relative_floor = self.config.get("relative_power_floor",1e-8)
            valid &= (sp > max(float(sp.max())*relative_floor,1e-24)) & (su > max(float(su.max())*relative_floor,1e-30))
        support_start = starts[np.maximum(np.arange(len(starts)) - half, 0)]
        support_end = starts[np.minimum(np.arange(len(starts)) + half, len(starts) - 1)] + nfft
        for span in record.meta["validity"]:
            valid[(support_start < span["end_sample"]) & (support_end > span["start_sample"])] = False
        result = {"p_power": pp, "u_power": uu, "intensity": sc.real, "reactive_intensity":sc.imag, "phase": np.angle(sc), "msc": msc,
            "frequency_hz": np.fft.rfftfreq(nfft, 1/fs), "frame_start": starts, "frame_end": starts + nfft,
            "support_start": support_start, "support_end": support_end, "valid": valid,
            "display_center_seconds": (starts + nfft / 2) / fs,
            "p_log_power": np.log10(np.maximum(pp, 1e-12)), "u_log_power": np.log10(np.maximum(uu, 1e-18))}
        self.cache[key] = result
        return result


def pu_diagnostics(record):
    """Welch one-sided densities; diagnostics of the measured mixture, not source truth."""
    from scipy.signal import welch, csd
    x,fs = record.signals,record.meta["timebase"]["sample_rate_hz"]
    nperseg = min(512,2**int(np.floor(np.log2(max(8,len(x)//4)))))
    opts = dict(fs=fs,nperseg=nperseg,noverlap=nperseg//2,window="hann",detrend=False,scaling="density")
    f,pp = welch(x[:,0],**opts)
    _,uu = welch(x[:,1],**opts)
    _,pu = csd(x[:,1],x[:,0],**opts)  # scipy conjugates first argument: P conj(U)
    valid = (pp > max(float(pp.max())*1e-8,1e-24)) & (uu > max(float(uu.max())*1e-8,1e-30))
    if record.meta["validity"]:
        valid[:] = False  # do not present a full-record relation across declared invalid data
    impedance = np.divide(pu,uu,out=np.zeros_like(pu),where=valid)
    return {"frequency_hz":f,"p_psd":pp,"u_psd":uu,"active_intensity_psd":pu.real,"reactive_intensity_psd":pu.imag,
            "phase_p_minus_u_radians":np.angle(pu),"msc":np.clip(abs(pu)**2/np.maximum(pp*uu,1e-50),0,1),
            "impedance_real":impedance.real,"impedance_imag":impedance.imag,"valid":valid}


def select_mask(node, maps):
    if "op" in node:
        children = [select_mask(child, maps) for child in node["children"]]
        if node["op"] == "and":
            return np.logical_and.reduce(children)
        if node["op"] == "or":
            return np.logical_or.reduce(children)
        raise ValueError("selection op must be and/or")
    field = node["field"]
    values = maps[field]
    if field == "frequency_hz":
        values = np.broadcast_to(values, maps["msc"].shape)
    operation = {">": np.greater, ">=": np.greater_equal, "<": np.less, "<=": np.less_equal}[node["comparison"]]
    return operation(values, node["value"])


def valid_interval(record, start, end):
    return not any(start < r["end_sample"] and end > r["start_sample"] for r in record.meta["validity"])
