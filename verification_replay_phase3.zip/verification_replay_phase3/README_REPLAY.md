# 検証再実行パッケージ：最初に読む

2026-11-06。Phase3の機関部と、検証条件・実行入口を一緒に移送する。別環境のデータを元環境へ送る必要はない。生成器・モデル・既存試験・共通契約は変更していない。新規reproduce.pyは固定設定を既存CLIへ渡す実行管理のみ。

## AI／実行者の規則

- 本書を入口とする。engine/docs/CLAUDE_CODE_VALIDATION_REQUIREMENTS.mdは条件の詳細、engine/MIGRATION.mdはPhase3範囲の説明。旧01_runtime用verify_transferを本パッケージに使わない。
- 設定不一致・試験失敗を、閾値調整、seed変更、正常波形の再生成方法変更、テスト修正で通してはならない。不明は不明として記録する。
- ハッシュ不一致なら基準版を復元するか、別条件の実験へ分離する。監査用manifestを作り直して基準版扱いしない。ハッシュは改変検出であり電子署名ではない。
- データや結果は移植先に保管。比較結果を外へ送信する機能はない。

## 内容と範囲

engine/はportable_phase3のmanifest列挙ファイルを検証して複製したもの。大容量データ・モデル・過去Bundleは同梱しない。historical_reference.jsonは過去summaryの個体別集計件数から転記した比較参照で、原本hashと出典を保持。期待スコアの代用品でも合格へ誘導する目標値でもない。

AUDIT.mdのV01〜V13が検証台帳。今回は物理quick/comparison、130回帰、22契約、物理レポート、移設再学習の入口を固定した。legacyはengineの既存コードと詳細要件書を保持するが新入口で暗黙選択しない。ブラウザー操作は別依存で、viewer生成成功と混同しない。D-002は別基盤で非同梱。Phase3導入前後の歴史的比較は過去baseline不足のため再現対象外。未実施の実測検証を今回の成功に含めない。

## Windowsでの実行

このREADMEがあるルートでPython 3.12 64bitを使用する。依存の取得方法・制約はengine/MIGRATION.md参照。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r engine/requirements.txt
.\.venv\Scripts\python.exe reproduce.py verify
.\.venv\Scripts\python.exe reproduce.py quick --output results/quick_01
.\.venv\Scripts\python.exe reproduce.py contracts --output results/contracts_01
.\.venv\Scripts\python.exe reproduce.py regression --output results/regression_01
.\.venv\Scripts\python.exe reproduce.py physics --output results/physics_01
.\.venv\Scripts\python.exe reproduce.py comparison --output results/comparison_01
.\.venv\Scripts\python.exe reproduce.py relocation --example results/quick_01 --output results/relocation_01
```

各コマンドの終了コードを確認してから次へ進む。終了0は指定範囲の成功、2は処理成功だが過去件数との差があり要調査、それ以外は失敗。出力先は毎回未作成の場所を指定する。失敗時はvalidation.jsonと*.logを残し、同じ場所に上書き再開しない。途中学習再開はない。

既存のtestsはengine/tests/_workへfixtureを生成する。その他は指定outputへ保存する。配布する際は元のクリーンなZIPを使い、試験後フォルダの生成物を一緒に再配布しない。

## 固定条件

|実験|生成設定|解析設定|学習個体／評価シナリオ|時間・fs・seed|
|quick|engine/configs/acoustic_quick_data.json|engine/configs/acoustic_quick.json|12／7（独立正常実現1群）|4秒・1024Hz・42|
|comparison|engine/configs/acoustic_comparison_data.json|engine/configs/acoustic_comparison.json|40／28（独立正常実現4群）|6秒・1024Hz・42|

両方とも各個体2測定、正常・外乱のみ・band/order/event/relation/mixed。fit/cal分離、モデル、選択条件等は上記JSONと固定コードが正本。詳細の意味は要件書DATA-A/SPLIT/PROC-MODEL参照。生成と解析の両方をacousticに固定し、demoの既定やコード内profilesには依存しない。実行時に変えるのは入力・出力の格納先だけでpath_changes.jsonへ記録する。

## 成功の読み方

- verify成功：固定ファイル一致のみ。解析試験成功ではない。
- regression成功：130試験OK、contracts成功：22試験OK。比較実験とは異なる縮小fixtureを使用する。
- quick/comparison成功：generation.jsonの条件一致、入力validate、5経路complete、BundleReader inspect、viewer生成、ローカルimport成功。実ブラウザー描画は含まない。
- historical_comparison.json：TP/FP/FN/TN・母数・判定不可の過去件数と今回を比較。件数一致でも波形・モデルの一致を証明しない。差が出ても設定を調整しない。
- physics：既存verify_physicsの判定と物理レポートを見る。実音場での妥当性を保証しない。
- relocation：新規quickを移設し、元参照・再学習の一致を既存スクリプトで確認。過去Bundleは不要（MIGRATIONのこの点の記述より実装と要件書X01を優先）。

保存対象：generation_settings.json、data/generation.json、NPZ/metadata/manifests/truth、experiment.json、Bundle内dataset_split/environment/models/metrics、コマンドログ、pip freeze、validation.json。日時・パス・UUID等を含むファイルを無条件にバイト比較しない。波形の数値比較は次の調査段階であり本ランチャーでは未実装。

## 移植先だけでの診断順序

1. verify失敗→資産差。設定を調整せず基準コピーを確認。
2. generation設定不一致→入口・設定差。legacyとacousticを確認。
3. input validate失敗→データ・metadata・hashをログから確認。
4. regression失敗→該当assertとfixtureを確認。試験数だけ合わせない。
5. 処理成功・過去件数差→freeze、分割、スコア・閾値の順で確認。実測性能の問題と混同しない。

## ローカル検証記録

配布ZIPと同じ場所に置くLOCAL_VALIDATION.jsonを参照。未実施のタスクは未実施とする。こちらでの再実行成功は別PCでの成功保証ではない。
