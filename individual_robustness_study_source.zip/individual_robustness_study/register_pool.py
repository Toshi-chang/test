"""Export the attested normal pool as a standard training manifest; no signal/model edits."""
import bootstrap_study
from pathlib import Path
import sys
from bridge.adapter import read,write
from nv_runner.input_adapter import InputAdapter

def register(out):
    out=Path(out).resolve();att=read(out/'pool_attestation.json')
    if att['normal_only_attested'] is not True:raise ValueError('normal attestation missing')
    items=[]
    for family in att['families']:
        folder=out/'pool'/f'f{family}';manifest=read(folder/'canonical/manifest.json')
        for mode in range(2):
            provenance=read(folder/f'm{mode}/generation.json')
            if provenance['addition'] is not None or provenance['external'] is not None:raise ValueError('non-normal pool generation')
        for item in manifest['measurements']:
            item=dict(item)
            for k in ['metadata_path','source_path']:item[k]=f'f{family}/canonical/'+item[k]
            items.append(item)
    destination=out/'pool/train_manifest.json'
    write(destination,{'schema_version':'1.0','role':'train','normal_only_attested':True,'measurements':items})
    loaded=InputAdapter().load(destination)
    if sorted(r.meta['measurement_id'] for r in loaded)!=sorted(att['measurement_ids']):raise ValueError('pool registration differs')
    return len(loaded)
if __name__=='__main__':print(register(sys.argv[1]))
