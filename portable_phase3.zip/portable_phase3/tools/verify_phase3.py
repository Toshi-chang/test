"""Verify Phase 3 captured runs, unchanged protected sources, and Bundle consumers.

Run after the commands in docs/validation/phase3_registry.md. This does not train
or regenerate the baseline, and never alters a completed Bundle.
"""
import argparse
import ast
from datetime import datetime, timezone
import importlib.util
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nv_runner.common import read_json, write_json, sha
from compare_extraction import compare


def log(path):
    raw=path.read_bytes()
    return raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')


def verify(evidence):
    text=log(evidence/'final_tests.log')
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
    if not match or int(match[1])<97 or not text.rstrip().endswith('OK'):
        raise ValueError('full regression has not passed')
    for name in ('test_plugin_registry','test_plugin_validation','test_plugin_exchange','test_plugin_compatibility'):
        if name not in text: raise ValueError('new tests missing: '+name)
    pairs={
        'default':(read_json(evidence/'baseline_demo/summary.json')['bundle'],log(evidence/'after_default.log').strip().splitlines()[-1]),
        'candidate':(log(evidence/'baseline_candidate.log').strip().splitlines()[-1],log(evidence/'after_candidate.log').strip().splitlines()[-1])}
    for name,(before,after) in pairs.items():
        write_json(evidence/(name+'_comparison.json'),compare(before,after))
    snapshot=read_json(evidence/'baseline_hashes.json')
    protected=[p for p in snapshot if p.startswith(('tests/','docs/parallel_contracts/','docs/plugin_architecture/'))]
    for path in protected:
        if sha(ROOT/path)!=snapshot[path]: raise ValueError('protected file changed: '+path)
    old=ast.parse((evidence/'routes_before.py').read_text(encoding='utf-8-sig'))
    new=ast.parse((ROOT/'nv_runner/routes.py').read_text(encoding='utf-8-sig'))
    definitions=lambda tree:{n.name:ast.dump(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    a,b=definitions(old),definitions(new)
    preserved={k:v for k,v in a.items() if k!='_fixed_window_candidate'}
    if any(b.get(k)!=v for k,v in preserved.items()): raise ValueError('legacy route calculation changed')
    immutable=('nv_runner/models.py','nv_runner/signals.py','nv_runner/input_adapter.py','nv_runner/profiles.py',
               'nv_runner/__main__.py','nv_runner/__init__.py','nv_runner/bundle.py','nv_runner/route_a_candidate.py')
    for path in immutable:
        if sha(ROOT/path)!=snapshot[path]: raise ValueError('baseline implementation changed: '+path)
    bundle=pairs['candidate'][1]
    for name,args in [('viewer',['view','--bundle',bundle,'--output',str(evidence/'viewer.html')]),
                      ('import',['import','--bundle',bundle,'--output',str(evidence/'evaluation_inbox')])]:
        process=subprocess.run([sys.executable,'-m','nv_runner',*args],cwd=ROOT,capture_output=True,text=True)
        (evidence/(name+'.log')).write_text(process.stdout+'\n'+process.stderr,encoding='utf-8')
        if process.returncode: raise ValueError(name+' failed: '+process.stderr)
    state={'status':'complete','finished_utc':datetime.now(timezone.utc).isoformat(),
           'tests':int(match[1]),'test_seconds':float(match[2]),'baseline_tests':97,
           'default_comparison':'passed','candidate_comparison':'passed',
           'protected_files_unchanged':len(protected),'legacy_route_definitions_unchanged':sorted(preserved),
           'candidate_bundle':bundle,'bundle_schema':'1.0','separate_process_viewer':'passed',
           'local_import':'passed','report':'docs/validation/phase3_registry.md','pending_work':[]}
    write_json(evidence/'completion.json',state)
    write_json(evidence/'state.json',state)
    return state


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence',type=Path,default=ROOT/'reports/phase3/I')
    args=parser.parse_args()
    try:
        print(verify(args.evidence.resolve()))
    except Exception as exc:
        write_json(args.evidence/'verification_failure.json',{'status':'failed','error':str(exc),'next':'Inspect logs, correct cause, rerun verification; never mark incomplete tests passed.'})
        raise
