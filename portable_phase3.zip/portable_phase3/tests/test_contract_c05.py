import copy
import itertools
import unittest
from unittest.mock import patch
from contract_fixtures import SPEC, pipeline, run_variant
from nv_runner.routes import RoutePlugin
from nv_runner.common import union_length

class C05(unittest.TestCase):
    def test_decision_cases(self):
        plugin=RoutePlugin({'key':'test','plugin':'fixed_window'})
        for c in SPEC['decision_cases']:
            row={'case_score':c['score'],'coverage_status':c['coverage'],'decision':'undetermined','reason':None}
            actual=plugin.decide([row],{'value':c['threshold']})[0]
            self.assertEqual(actual['decision'],c['decision'])
            self.assertEqual(actual['case_score'],c['score'])
        self.assertEqual(union_length([(0,10),(5,20),(30,40)]),30)

    def test_calibration_higher_and_insufficient(self):
        plugin=RoutePlugin({'key':'test'})
        rows=[{'specimen_id':str(i),'case_id':str(i),'case_score':v,'coverage_status':'sufficient'} for i,v in enumerate([.1,.2,.4])]
        policy={'quantile':.95,'min_specimens':2}
        self.assertEqual(plugin.calibrate(rows,policy)['value'],.4)
        self.assertIsNone(plugin.calibrate(rows[:1],policy)['value'])

    def test_multiroute_fusion_truth_table_in_runner(self):
        # Inject decisions ONLY at the fusion boundary; all generation/fit/save still use real code.
        _,cfg,_=pipeline(); cfg=copy.deepcopy(cfg); cfg['routes']=cfg['routes'][:2]
        cfg['fusion']['enabled']=True
        for pair in itertools.product(('within','outside','undetermined'),repeat=2):
            decisions=dict(zip([r['key'] for r in cfg['routes']],pair))
            def decide(plugin,rows,threshold):
                for row in rows:
                    row.update(decision=decisions[plugin.key],threshold_ref='threshold:'+plugin.key)
                return rows
            with self.subTest(pair=pair), patch.object(RoutePlugin,'decide',decide):
                reader=run_variant(cfg)
                expected='outside' if 'outside' in pair else ('within' if pair==('within','within') else 'undetermined')
                self.assertTrue(all(r['decision']==expected for r in reader.tables['case_results']))
