# 既存コード調査 第1回：収録入力・CH・校正・解析受渡し

調査日：2026-10-19。目的は新しい共通データ契約のための事実収集。以下はAs-Isであり、既存設計を採用する提案ではない。ソース・設定・既存テストを変更していない。新しい実装・新しい試験も作成していない。

## 読み方と調査境界

- **[F] 確認事実**：実装またはテストの該当箇所を静的に確認した。実機動作・テスト成功を意味しない。
- **[I] 推論**：確認した境界から導く再利用上の判断。設計採択や実証結果ではない。
- **[U] 未確認**：今回の限定調査では根拠が不足。未実装と断定しない。

ワークスペース相対パスを根拠表に記載する。`Sxx:Lnn–mm` は当該ファイルの1始まり行番号。`source_inventory.json` に対象ファイルのSHA-256・行数・ASTシンボル・import一覧を保存した。引継ぎ先でhashが違う場合は行番号を再確認する。ソース全文・測定データ・モデル・ログは本フォルダに複製していない。

対象は3系統：`09_DL-NPZ_Bridge/observer_dev/Tool_A`（観測ツール開発側）、Bridge `src` と実際の参照先 `reference/observer/Tool_A`、`nv_route_runner_poc/nv_runner`。移植コピー・仮想環境・生成物は同じ実装として重複調査しない。GUI全体、DL本体、計測器ドライバーは対象外。

## 1. 絞込み手順・追加読込の理由

最初にGet-ChildItemと`rg --files`で名前を抽出し、次に`rg -n`でclass/def/importと呼出箇所を検索、最後に必要範囲だけ行番号付きで読んだ。初回ファイル名検索は仮想環境・生成物を含み出力が切れたため、その結果を完全な台帳とはせず、以降は明示したsrc/data_io/services/domain/testsだけを対象とした。リポジトリ全ソースの一括読込はしていない。

再調査用の検索例（workspaceルート）：

```powershell
rg --files 09_DL-NPZ_Bridge/observer_dev/Tool_A/data_io 09_DL-NPZ_Bridge/observer_dev/Tool_A/services -g '*.py'
rg --files 09_DL-NPZ_Bridge/src -g '*.py'
rg -n '^class |^def |^    def |^from |^import ' 09_DL-NPZ_Bridge/src/observer_exporter/instrument_csv_adapter.py
rg -n 'load_signal_|load_channel_mapping|load_probe_master' 09_DL-NPZ_Bridge/observer_dev/Tool_A/ui/controllers.py
rg -n '^def test_|^    def test_' 09_DL-NPZ_Bridge/tests/test_record_fft_calibration.py nv_route_runner_poc/tests/test_contract_c01.py
```

|追加した対象|必要性・確認結果|
|---|---|
|domain/models, semantics|loaderが返す実型とCH状態の意味を確認するため。p/u配列とCH availabilityは別契約。|
|calibration_loaders, calibrated_tf|CH→probe→係数の解決と、校正される領域を確認するため。|
|analysis_context|解析側が生TF/校正TFのどちらを受けるか、変更検出を確認するため。|
|reference_connectionとreference側6ファイル|Bridge import先がobserver_devと異なると判明したため。6対のhash比較でcalibration.py/calibration_loaders.pyだけ一致、models/loaders/calibrated_tf/tf_transformは不一致。|
|shared_contract/validation, loader_adapter, traceability|exportの形だけで受渡し契約を断定しないため。受信側の拒否条件と追跡能力を確認。|
|offline_evaluator/calibration|校正評価入口も同じ参照境界かを確認するため。限定範囲のみ、全評価処理は未調査。|
|NV input_candidate/InputAdapter/Planner|新規PoC側が電圧校正を行うか、Bridgeと同形式かを比較するため。|

## 2. 関連ファイル・主要シンボル索引

以下でD=`09_DL-NPZ_Bridge/observer_dev/Tool_A`、R=`09_DL-NPZ_Bridge/reference/observer/Tool_A`、B=`09_DL-NPZ_Bridge/src`、N=`nv_route_runner_poc/nv_runner`。JSON台帳には省略しないworkspace相対パスを記載する。

|ID|ファイル|責務・主要シンボル・根拠行|
|---|---|---|
|S01|D/data_io/loaders.py|load_signal_csv 40、UFF pair 122 / multi_pair 397、instrument voltage CSV 558、_loaded_signal 10、_estimate_fs 213|
|S02|D/domain/models.py|SignalData 57、TFData 71、DatasetRecord 92、ProbeCalibration 104、ChannelPairMapping 146、ChannelMappingTable 163|
|S03|D/domain/semantics.py|ChannelAvailability 7、ChannelState 49、acquired_channels 66、validate_signal_channels 80|
|S04|D/data_io/calibration_loaders.py|load_probe_master 90、load_frequency_response 201、load_channel_mapping 334、resolve_channel_calibration 429|
|S05|D/data_io/calibration.py|未実装入口89/129/160、単一感度185、周波数依存関数310〜、スペクトル校正556|
|S06|D/services/calibrated_tf.py|build_calibrated_tf 31、_create_correction_vector 190|
|S07|D/services/analysis_context.py|FrozenTF 49、TFView 74、CalibrationResolver 109、AnalysisContext 188、AnalysisEngine 259（後二者はシンボル抽出まで）|
|S08|D/ui/controllers.py|読込dispatch 392–410、校正Excel解決1329–1379（全UIは未読）|
|S09|B/observer_exporter/reference_connection.py|_reference_root 19、load_observer_reference 38：参照先/名前衝突管理|
|S10|B/observer_exporter/instrument_csv_adapter.py|load_instrument_voltage_record 6：役割・fs明示の電圧読込|
|S11|B/observer_exporter/stft_calibration_bridge.py|参照bind 18–24、固定mode 28–29、validate_raw_calibration_input 202、STFT逆変換経路32（後者の詳細は追加調査）|
|S12|B/observer_exporter/record_fft_calibration.py|calibrate_periodic_record_fft 14：周期全長AC校正|
|S13|B/observer_exporter/record_exporter.py|export_raw_records 12：校正→窓→4分割NPZ|
|S14|B/observer_exporter/window_generator.py|extract_windows 7：波形窓と開始sample。今回はsignature/guard抽出中心|
|S15|B/shared_contract/schema.py|schemaと必須key 7–44|
|S16|B/shared_contract/validation.py|validate_npz_schema 32、validate_metadata_json 93|
|S17|B/dl_import_adapter/loader_adapter.py|load_physical_waveform_npz 14、validate_for_dl_input 92|
|S18|B/dl_import_adapter/traceability.py|source_for_window 6|
|S19|N/input_adapter.py|MeasurementRecord 10、InputAdapter.load 17、DatasetPlanner.plan 91|
|S20|N/input_candidate.py|ColumnInputAdapter.convert 18 / load 94|
|S21|N/runner.py|validate_config 18、InputAdapter/Planner呼出48–50、maps保存123–134、prepare159|
|S22|R/domain/models.py|旧SignalData/TFData/DatasetRecord 54–82|
|S23|R/data_io/loaders.py|UFF pair 109–134、_estimate_fs196、instrument CSV 539。主に開発側との差を確認|
|S24|R/services/tf_transform.py|compute_tf 4–37：STFTの実軸・正規化|
|S25|R/services/calibrated_tf.py|校正TF生成144–175：開発側と状態メタデータが異なる|
|S26|B/offline_evaluator/calibration.py|evaluate_record 17、参照選択59–61、probe構築62–73（詳細監査未完）|

## 3. 機能間の入出力

```mermaid
flowchart TD
  File[CSV / UFF] --> DevLoad[observer_dev loader]
  DevLoad --> Signal[SignalData: time / p / u / fs / CH state]
  Excel[CH mapping / probe Excel] --> Resolver[CH名からprobeと係数を解決]
  Signal --> TF[TFData]
  TF --> View[CalibrationResolver / FrozenTF / TFView]
  Resolver --> View
  View --> Analyze[解析コンテキスト]
  CSV[計測器CSV] --> BLoad[Bridge明示CH・fs adapter]
  Ref[reference snapshot または明示参照先] --> BLoad
  BLoad --> Cal[周期FFT校正 またはexperimental STFT経路]
  Ref --> Cal
  Cal --> Export[窓とrecord IDと由来をNPZへ]
  Export --> Import[Bridge schema検証 / DL入力adapter]
  Canon[別形式のNV manifest + metadata + NPZ] --> NV[InputAdapter / DatasetPlanner]
  NV --> Routes[SignalService / RoutePlugin.prepare]
```

**[F] Bridge NPZ→NV manifestの自動接続は、調査した呼出経路にはない。** 配列軸・ID・metadataが違うので、同じNPZという理由で直接互換とは扱えない（S13/S15/S19/S21）。**[U]** 別ディレクトリに追加変換があるかは未確認。

## 4. As-Is契約

### 4.1 観測ツールの収録入力・時間軸

**[F]** SignalDataはname、time[N]、p[N]、u[N]、fs、source_paths、metadataを持つ。開発側はsignal_ref(UUID)、stage/units、channels、pair_validityを追加。reference側の型には後者がない（S02:L57–69、S22:L54–61）。metadataの型注釈はdict[str,str]だがBridgeはbool/list/floatも追加する（S10:L31–37）。注釈だけをJSON schemaとして流用できない。

**[F]** 通常CSVはtime/p/uのaliasを要求しfloatへ変換、fsは正の差分の中央値の逆数。通常CSV自体から校正済みSIを確定する処理は確認できず、開発側stage/unitsは既定unknownのまま（S01:L40–75,213–220、S02:L68–69）。計測器CSVはComment/DateTime/Time(s),CH1(V),CH2(V)、p/uフィールドへ電圧を格納する。部分欠損行は例外、全空欄行はスキップ、DateTimeは文字列metadataで時刻同期の根拠にはしない（S01:L558–577,612–695）。

**[F]** 開発側_loaded_signalは取得根拠をsource_pathsから作りvalidate_signal_channelsを呼ぶ。時間単調・有限・fs整合（rtol=1e-6, atol=1e-12）不適合はCHをINVALIDへ変更する。すべての問題がloader例外になるわけではない（S01:L10–20、S03:L80–113）。

**[F]** UFFペア入力はfsを比較し、時間軸を0から再構成。開発側は長さ不一致を拒否するがreference側は短い方へ切り詰める（S01:L122–149、S23:L109–134）。multi_pairの候補形成はpressure CHの次番号をvelocity CHとして照合。ペアが全く作れなければP-onlyを許可し、uにゼロ配列を置く（S01:L363–394,441–495）。開発側はmetadata p_onlyからCH missing/legacy_placeholderを付けるのでゼロを実測uとみなせない（S03:L66–76）。**[U]** UFF元の絶対時刻・遅延・計測器同期の検証範囲は未確定。

### 4.2 CH管理・probe・位置

**[F]** ChannelPairMappingはpair_no/probe_id、p/u CH名、csv_column、quantity、calibration_key、mapping_rule、use_for_phase、status/note。ChannelMappingTableはCH文字列を正規化して最初に一致した行を返す。実照合はpressure_ch/velocity_chで、同関数ではcsv_column/status/use_for_phaseを適用していない（S02:L146–176）。

**[F]** CH mapping Excelは`channel_mapping_24ch`シート、必須列pair_no/probe_id/pressure_ch/velocity_ch。pair_no不正・probe_idなし行はスキップ。返すのはpairsのlistであり、24CH収録装置ドライバーではない（S04:L334–426）。probe_masterはprobe_id辞書、同ID代入は後行で上書きされる。必須ヘッダーはprobe_idで、多くの係数はOptional（S04:L90–195）。

**[F]** resolve_channel_calibrationはCH→probe_id/quantity/key→ProbeCalibration、pressureは1kHz基準、velocityは250Hz基準感度を参照。CH/probe不在はValueError。任意frequency responseを添付できるが、今回確認した式校正経路はfreq_response=Noneまたは既定値で、主にprobe係数から計算する（S04:L461–517、S05:L616–651）。

**[F]** ChannelStateのavailabilityはpresent/missing/unavailable/invalid/unknown、originはmeasured/synthetic/legacy_placeholder/derived/unknown。根拠、grid_ref、parent_refs、operationを持つ。p/u配列の値だけでmissingをpresentへ昇格させない（S03:L7–113）。SignalData.unitsとChannelState.unitsは別フィールドで、acquired_channelsはCH unitsをunknownで作る（S03:L70–72）。**[I]** 更新時の一貫性は新契約検討の重要点。

**[F]** ここで見た旧CH/probe型には3D位置/方向の必須欄がない。一方NVは後述の位置・方向を必須とする（S02:L104–176、S19:L53–65）。**[U]** 他の測定メタデータで位置を保持しているかは未確認。CH名から物理位置を推測してはならない。

### 4.3 校正・補正の実装済み／未実装

**[F] 未実装**：apply_calibration_to_voltage_signal、load_probe_calibration_database、validate_calibration_configはNotImplementedError（S05:L89–179）。「校正機能全体がない」とは結論しない。

**[F] 実装済み**：apply_sensitivity_calibration_to_channelはpを `V / (mV/Pa / 1000)`、uを `V / (V/(m/s))` に変換し、配列と単位/CH/probe/感度をdictで返す。正感度・CH/probe解決を検査（S05:L239–302）。

**[F] 実装済み**：apply_formula_based_frequency_calibrationは対応長の複素スペクトルと正周波数を受け、probe係数の周波数依存感度で除算。位相補正は `exp(-j*radians(phase))`。velocity_modeはuncorr/corr、apply_phaseで選択。未知mode/quantity、DCを含む非正周波数等を拒否（S05:L556–675）。**[U]** 各P4式の原仕様との同値性・実機係数の有効帯域は今回再検証していない。

**[F]** build_calibrated_tfは周波数軸方向に係数を掛ける。STFTは[F,T]、power=abs²、cross=p*conj(u)。DCは0。元の時間波形は電圧のままで、出力p_rms/u_rmsはゼロplaceholder。開発側はunsupportedを記録し、stage=calibrated_physical、units、generation/親generationを付ける。referenceは同じゼロ値を返すが、その型にunsupported/stageがない（S06:L108–186,246–249、S25:L144–175）。ゼロRMSを物理的な0として扱わない。

**[F]** reference compute_tfは窓掛けrfftの未正規化スペクトルでabs²を返す。PSD/片側mean-square binと同一ではない。RMSは窓掛け前frameから算出。時間座標はframe中央sampleの時刻（S24:L4–48）。**[I]** NVの物理mapとの比較には正規化規約の照合が必要。

### 4.4 解析コンテキストへの受渡し

**[F]** 開発側CalibrationResolverはsource signal_ref、TF generation、window snapshot、配列hashを確認し、不明なTFや同generationの変更を拒否。校正要求時はraw_voltage/Vが必要、二重校正をunsupportedで拒否、設定/CH mapping/probe/実装hashをsnapshotに保持（S07:L115–176）。

**[F]** FrozenTFは配列のbytesコピーによるimmutable view、TFViewはsource_dataset_key/source_signal_ref/source_tf_generation/generationと校正状態を保持（S07:L49–98）。**[I]** GUIの可変状態から解析入力を隔離する再利用候補。ただしcore packageとして独立した契約ではなくdomain/servicesのimportに依存。**[U]** AnalysisEngine以降の全consumerが同一snapshotを使うか、export/比較の全分岐は次回調査。

### 4.5 Bridgeの電圧→波形→DL NPZ

**[F]** reference_connection既定は`reference/observer/Tool_A`、`PU_OBSERVER_REFERENCE_ROOT`で明示交換可能。domain/services/data_ioの既存moduleが別rootならImportError。import中だけsys.pathを変更し戻すがsys.modulesには残る。RLockあり（S09:L15–78）。**[I]** observer_devとの同一プロセス混用は無条件に安全ではない。

**[F]** load_instrument_voltage_recordはCH1/CH2の役割を明示要求し、逆配置ならp/uをswap。fsは呼出側指定、全時刻を `t0+i/fs` と16*eps*max(1,abs(t))で照合。丸め修復・resampleなし。time_boundaryはNone/periodicのみ（S10:L6–38）。元loaderの推定fsは監査値として残る。

**[F]** 周期FFT校正はraw/finite/同一time grid、異なるp/u CHとquantity/probeを検査してから、caller-declared periodicを要求。全長boxcar・1frameで既存TF校正を呼びirfft、DCと偶数長Nyquistを除去。長さとsample位置を維持し除去成分/境界/fft_length等を保存。uncorr+phase trueに固定（S11:L28–29,202–235、S12:L14–73）。これは周期離散AC演算の契約であり、任意の非周期実測への妥当性保証ではない。

**[F]** export_raw_recordsの既定legacy_stftはexperimental明示許可なしでは拒否。periodicとstft_config併用も拒否。各recordにsignal、非負unique int record_id、明示split、存在するsource_file、CH、testラベル0/1/2/3が必要。全4split・共通fsが必要（S13:L12–51）。ラベル各番号の意味はこの関数だけでは確定しない。

**[F]** 校正後窓を[windows,2,samples]、開始sample、record_idとともにexport。metadataにsource絶対path/hash、CH/probe、input_metadata、処理条件を残す（S13:L52–82）。NVの[time,channel]とは異なる。window_generatorは無効区間と交差する窓を除外する設計の入口を持つが、全切出しアルゴリズム詳細は未調査（S14:L7–30、S13:L59–64）。

**[F]** Bridge NPZ schema_nameはpu_physical_waveform_dataset、schema_versionは**整数1**。train/validation/calibration/test、各record_ids、test_labels、sampling_rate_hz、units、metadata_jsonが必須（S15:L7–44）。validatorはfinite floating [W,2,L]、非空・各split共通L、非負整数ID、split間ID非重複、同recordラベル整合を検査。start_samplesは一般schemaでは任意（S16:L32–90）。calibrationというsplitはセンサー校正処理そのものではない。

**[F]** metadata stageはcalibrated_physical_waveform、velocity_mode=uncorr、apply_phase=true。periodicの場合はrecordごとの境界/DC/Nyquist/長さも検査（S16:L101–165）。raw入力を受ける上流と、校正済み受渡し先を区別する。

**[F]** DL loaderはallow_pickle=False、Phase1A/unknown拒否、strict既定True。legacy形式をstrict=Falseで許可すると新schema検証前にreturnする。experimentalは追加opt-in必須（S17:L14–86）。validate_for_dl_input単独ではstage欠落がwarningだが、通常loaderは前段のvalidate_npz_schemaでも検証するため、単独helperの弱い条件だけで受渡し保証を判断しない（S17:L128–137、S16:L101–107）。

**[F]** source_for_windowはsplit/index→record_id→一意のrecord metadata→source_fileを返す。原本hashの再検証やsample区間そのものの返却はこの関数にない（S18:L6–16）。原本byte同一性を必要とする利用側は別の検証根拠が必要。

### 4.6 Phase 3入力境界

**[F]** InputAdapterはmanifest 1.0→metadata JSON＋NPZ→MeasurementRecord(meta,signals,rpm)。signalsはfloat変換後[N,2]、順序p/u、Pa/m/s、RPM任意[N]。同位置pair_id、3D位置/方向、uの単位方向ベクトル、共有clock、校正status=calibratedとreference必須。実際の感度/位相補正をここで計算しない（S19:L10–87）。校正証明の真偽や実機の同期精度まで保証するものではない。

**[F]** specimen/case/measurement/derived_group IDは限定文字列、source NPZ hashを照合。source_path/hash、n_samples、mapping、metadata_sha256を返しmeasurement_idでsort。校正referenceの実ファイル内容や校正係数を検証するコードはこのloadでは確認できない（S19:L24–87）。

**[F]** DatasetPlannerはtrain/evalでspecimen/case/source hash/derived group重複を拒否。fit/calは同個体・同原本・同派生元を連結群としてまとめseedで分割。不足時calibration_unavailable、cal空。ここでのcalibrationは**モデル閾値設定用分割**（S19:L91–136）。Bridgeはrecord ID単位の4splitであり個体・派生元の漏洩検査と同等ではない。

**[F]** ColumnInputAdapterはnv_dummy_columns 1.0 JSONのSI列をcanonical NPZへ積む候補。時間軸はatol=1e-10で明示timebase照合、未知列拒否、原本不変hash確認、destination既存拒否。truthを入力whitelistから隔離、別provenanceへoriginal hashとsample rangeを保存。resampling/scalingなし（S20:L18–95）。このcandidateは計測器V校正アダプターではない。

**[F]** RunnerはInputAdapterを直接生成しPlannerを呼び、SignalService mapsをartifactへ保存してRoutePlugin.prepareへrecordsを渡す（S21:L48–50,123–134,159）。今回の調査範囲でBridgeのreaderやColumnInputAdapterをRunnerが自動選択する経路はない。

## 5. テストと検証範囲

**全項目：今回未実行。** 下記は存在/テスト本文の静的確認。parametrizeのため関数数を試験件数とみなさない。過去ログ・測定ファイルは読んでいない。

|テスト根拠（workspace相対）|確認した検証内容|限界|
|---|---|---|
|09_DL-NPZ_Bridge/tests/test_instrument_file_pipeline.py:8–48|CSVサンプル読込、CH swap/raw metadata、units/mapping/time/nan/partial/fs拒否、24record/192窓のsynthetic pipeline期待値|実計測器からの収録・時計精度の保証ではない。|
|09_DL-NPZ_Bridge/tests/test_record_fft_calibration.py:44–80,84–160|既存校正呼出、uncorr/phase true、周期多音・独立直接畳込み比較、元配列不変、DC/Nyquist、拒否・由来改変|前2試験は256*eps*length*max(abs(truth))の数値budget。非周期一般波形の保証ではない。|
|09_DL-NPZ_Bridge/tests/test_offline_calibration.py:14–26|期待値照合PASS、物理量妥当性INCONCLUSIVE、DL性能NOT_RUN、原本不変、校正code hash保存のassert|結果文字列はテストが要求する値。今回の実測結果ではない。|
|09_DL-NPZ_Bridge/tests/test_package_imports.py:10–63|fresh interpreterのimport同一性/sys.path復元、reference module衝突拒否|実行にはpackage導入等の前提あり。今回環境構築していない。|
|nv_route_runner_poc/tests/test_contract_c01.py:10–34|record互換/任意回転、不正入力、分割・漏洩のテスト関数|今回の参照はシンボル中心、全assert監査は次回。|
|nv_route_runner_poc/tests/test_input_candidate.py:39–159|変換、truth/由来隔離、RPM欠落、版/軸/単位/CH/時間/ID/校正拒否、原本不変、consumer/CLI/派生元漏洩の関数|今回シンボル一覧中心。実行成功は未確認。|

追加候補（本文監査未完）：Bridge `test_phase_d.py:40,66,112,152,163,173,224,230`、Observer `test_uff_loader.py:18,75,135`、`test_calibration_path_resolution.py:12,72`、各verify_*校正script。名前にtestがあってもCI収集・外部fixture可用性は未確認。observer_devのCH/TFView仕様について、今回限定検索では専用回帰試験の所在を特定できていない。

再実行する場合の候補コマンド（**本調査では未実行**）：Bridgeは既存pyprojectに従い環境を用意して `python -m pytest tests/test_instrument_file_pipeline.py tests/test_record_fft_calibration.py tests/test_offline_calibration.py tests/test_package_imports.py`。NVは同プロジェクトで `python -m unittest discover -s tests -p 'test_contract_c01.py' -v` と `-p 'test_input_candidate.py'`。生成物先とimport参照先を確認してから実施する。

## 6. 不明・欠落・リスクを分けた台帳

|ID・分類|事実/未確認事項|次に必要な確認|
|---|---|---|
|G01 [F] 複数のAs-Is|observer_devとBridge既定referenceは異なる型・欠損処理。hash比較でも不一致|どの呼出入口/環境変数でどちらを使うかを実行単位で記録。開発側改善をreferenceの保証としない。|
|G02 [F] 未実装|S05の3入口はplaceholder|呼出元の有無を追加検索。存在する校正経路と一本化する設計判断は別工程。|
|G03 [F/U] CH検証不足|mapping最初一致、probe辞書後勝ち、status/use_for_phaseは照合関数で不使用|重複CH/probe、無効行、別probeのp/u、単位表記不一致を上位層が拒否するか。|
|G04 [F/U] 位置・同期|旧型に位置方向必須なし、UFF時間軸再生成、NVは宣言必須|計測器CH→物理sensor→座標系/時刻原点/遅延補正の実データ契約。|
|G05 [F/U] 校正監査|Bridge record exporterはCH/probe ID/processingと原本hashを保存。係数全snapshot/校正Excel hashはこの経路で必須化されていない|offline evaluator側の係数snapshot/code hashとの保証差、再現に十分な情報。|
|G06 [F] 未対応一般化|周期FFTは明示周期ACのみ、legacy STFTはexperimental opt-in|一般収録の端部・DC/Nyquist・遅延・有効帯域について別の妥当性検証が必要。|
|G07 [F/U] 由来の強度|Observer source_paths文字列、Bridge path/hash、NV hash/derived_groupで保証が違う|hash照合タイミング、original→derived→windowの連鎖と欠落時の扱い。|
|G08 [F] 軸・split差|TF[F,T]、Bridge[W,2,L]、NV[N,2]、整数schema1と文字列1.0。recordとspecimen IDも異なる|自動互換は未確認。新共通契約検討で変換に必要な情報を別途決める。|
|G09 [U] UI実入口|controllers.pyの呼出箇所は確認、controllers_.pyも存在|実起動entrypointがどちらをimportするか、全校正ボタン/解析/export分岐。|
|G10 [U] 実装と実測の適合|P4原式、校正証明書、温度補正、有効期限、センサー指向/遠近場の適用条件は未照合|実係数・証明書・測定仕様と独立した物理検証。温度欄の存在を補正実装と解釈しない。|

## 7. 独立実行・再利用の判断

- **[F]** BridgeはpyprojectでPython>=3.10、numpy/scipy/openpyxl、test optional pytestを宣言しsrc packageを列挙する（`09_DL-NPZ_Bridge/pyproject.toml:1–24`）。**[I]** loader/validator/窓/traceabilityは関数単位で試験しやすい。ただし校正はreference snapshotの配置と旧トップレベルimport名に依存し、Bridge srcだけで完結すると断言できない（S09）。
- **[I]** ObserverのExcel loader/校正式はGUIなし再利用候補だが、domain.models/data_io等のnamespace、Optional係数、欠損/単位政策を含めて移植する必要がある。校正GUI controllerのコピーは独立化の前提ではない。
- **[F]** NV入力AdapterとPlannerは明示ファイル/構成から呼べる。**[I]** 校正済みcanonical入力の受領境界として独立利用しやすいが、元計測器の読み出しや電圧校正まで担うものではない（S19/S20）。
- **[U]** 選別モジュールを独立環境へ抽出して実行する検証は今回していない。「再利用候補」と「移植・動作確認済み」を区別する。

## 8. 次回へ渡す最小指示

1. 本書とsource_inventory.jsonを読み、hash一致を確認する。対象全体を再読込せずG01/G09の入口選択から続ける。
2. G03のCH重複/有効状態・G05の係数由来について、calibration_audit、offline_evaluator/calibration後半、metadata_builderと呼出元を必要範囲だけ追加する。今回symbol-onlyの箇所を詳細確認済みとしない。
3. G04の座標/時刻情報は実在するmetadata経路を検索し、未発見を不存在と断定しない。
4. 承認された次工程で既存テストを実行し、参照root・条件・結果を新規証拠として残す。今回はテスト成功件数を報告していない。
5. 本書のAs-Isと新システムの採用設計を別文書にする。異なるcalibration（センサー補正/モデル閾値分割）、schema、軸、IDを名称だけで統合しない。
