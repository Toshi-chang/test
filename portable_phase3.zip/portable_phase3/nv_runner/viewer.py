"""Independent saved-Bundle reader -> portable offline interactive HTML."""
import json
from pathlib import Path
import numpy as np
from .bundle import BundleReader
from .common import read_json


def render(bundle_path, output):
    reader = BundleReader(bundle_path).validate()
    tables = reader.tables
    measurements = {m["measurement_id"]: m for m in tables["measurements"] if m["split"] == "evaluation"}
    artifacts = {a["artifact_id"]: a for a in tables["artifacts"]}
    data = {"manifest": {k: v for k, v in reader.manifest.items() if k != "members"},
        "measurements": measurements, "cases": tables["route_case_results"],
        "samples": [s for s in tables["samples"] if s["split"] == "evaluation"],
        "results": [s for s in tables["sample_results"] if s["split"] == "evaluation"],
        "thresholds": {a["artifact_id"]: a["threshold"] for a in artifacts.values() if "threshold" in a},
        "metrics": read_json(reader.path / "metrics.json"), "signals": {}, "masks": {}, "pu":{},"theory":{},
        "truth": read_json(reader.path / "truth.json") if (reader.path / "truth.json").exists() else {"cases": []}}
    for mid in measurements:
        with np.load(reader.path / artifacts[f"signal:{mid}"]["array_file"]["path"], allow_pickle=False) as arrays:
            data["signals"][mid] = {key: arrays[key].tolist() for key in
                ("waveform", "frequency_hz", "p_log_power", "frame_start", "frame_end", "display_center_seconds")}
            if "rpm" in arrays:
                data["signals"][mid]["rpm"] = arrays["rpm"].tolist()
        diagnostic = artifacts.get(f"pu_diagnostics:{mid}")
        if diagnostic:
            with np.load(reader.path/diagnostic["array_file"]["path"],allow_pickle=False) as arrays:
                data["pu"][mid] = {k:arrays[k].tolist() for k in arrays.files}
            truth = artifacts.get(f"truth:{mid}")
            if truth:
                with np.load(reader.path/truth["array_file"]["path"],allow_pickle=False) as arrays:
                    target_f = np.asarray(data["pu"][mid]["frequency_hz"])
                    source_f = arrays["transfer_frequency_hz"]
                    curves = []
                    for source in arrays["transfers_re_im"]:
                        p = np.interp(target_f,source_f,source[:,0])+1j*np.interp(target_f,source_f,source[:,1])
                        u = np.interp(target_f,source_f,source[:,2])+1j*np.interp(target_f,source_f,source[:,3])
                        valid = (abs(u)>1e-20) & (abs(p)>1e-20)
                        ratio = np.divide(p,u,out=np.zeros_like(p),where=valid)
                        curves.append({"z_abs":[float(abs(z)) if ok else None for z,ok in zip(ratio,valid)],
                            "phase":[float(np.angle(z)*180/np.pi) if ok else None for z,ok in zip(ratio,valid)]})
                    data["theory"][mid] = curves
        # Raw source contributions remain in numeric Bundle artifacts; do not bloat HTML or use them in predictions.
    for a in artifacts.values():
        if a["operation"] == "route_coordinates_or_selection" and a["artifact_id"].split(":")[-1] in measurements:
            with np.load(reader.path / a["array_file"]["path"], allow_pickle=False) as arrays:
                if "selection_mask" in arrays:
                    data["masks"][a["artifact_id"]] = arrays["selection_mask"].astype(int).tolist()
    template = Path(__file__).with_name("viewer.html").read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False).replace("<", "\\u003c")
    target = Path(output).resolve()
    if target.is_relative_to(reader.path):
        raise ValueError("write viewer outside immutable Bundle")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(template.replace("__BUNDLE_DATA__", payload), encoding="utf-8")
    return target
