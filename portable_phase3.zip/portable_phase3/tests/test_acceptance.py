"""Executable acceptance tests; synthetic fixtures and mutations stay under tests/_work."""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
import uuid
import numpy as np

from nv_runner.common import read_json, write_json, sha, union_length
from nv_runner.synthetic import generate
from nv_runner.profiles import experiment, settings
from nv_runner.input_adapter import InputAdapter, DatasetPlanner
from nv_runner.runner import ExperimentRunner, validate_config, compute_metrics
from nv_runner.routes import REGISTRY
from nv_runner.signals import SignalService, select_mask
from nv_runner.bundle import BundleReader, EvaluationAdapter


class Acceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parent / "_work" / uuid.uuid4().hex
        cls.root.mkdir(parents=True)
        options = settings("quick")
        options.update(train_specimens=8, duration_seconds=3)
        generate(cls.root / "data", options)
        cls.config = experiment("data", "runs")
        for rc in cls.config["routes"]:
            if rc["model"]["kind"] == "isolation_forest":
                rc["model"]["n_estimators"] = 16
            else:
                rc.update(frequency_bins=8, time_frames=4, hop_bins=8, hop_frames=8)
        cls.config_path = cls.root / "experiment.json"
        write_json(cls.config_path, cls.config)
        cls.bundle = ExperimentRunner().execute(cls.config_path)
        cls.reader = BundleReader(cls.bundle).validate()

    def unique(self, name):
        return self.root / (name + "_" + uuid.uuid4().hex[:6])

    def test_01_full_pipeline_real_models(self):
        self.assertEqual(self.reader.manifest["bundle_status"], "complete")
        self.assertEqual(len(self.reader.manifest["completed_routes"]), 5)
        for key in self.reader.manifest["completed_routes"]:
            self.assertTrue((self.bundle / "models" / f"{key}.joblib").is_file())
            threshold = read_json(self.bundle / "models" / f"{key}_threshold.json")
            self.assertIsNotNone(threshold["value"])
            values = [r["anomaly_score"] for r in self.reader.tables["sample_results"] if r["route_key"] == key and r["status"] == "scored"]
            self.assertGreater(np.std(values), 0)

    def test_02_separate_process_reader_and_viewer(self):
        target = self.root / "separate_viewer.html"
        result = subprocess.run([sys.executable, "-m", "nv_runner", "view", "--bundle", str(self.bundle), "--output", str(target)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('id="bundle"', target.read_text(encoding="utf-8"))

    def test_03_shuffle_and_batch_identity_all_routes(self):
        config, _, ev, fit, _, _ = validate_config(self.config_path)
        for rc in config["routes"]:
            plugin = REGISTRY[rc["plugin"]](rc)
            service = SignalService(config["signal"])
            fitted = plugin.fit(plugin.prepare(fit, service), rc["model"], config["seed"])
            first = plugin.prepare(ev, service)
            other = plugin.prepare(list(reversed(ev)), service)
            other.samples.reverse()
            a = {r["sample_id"]: r["anomaly_score"] for r in plugin.score(fitted, first, 1)}
            b = {r["sample_id"]: r["anomaly_score"] for r in plugin.score(fitted, other, 7)}
            self.assertEqual(a.keys(), b.keys())
            np.testing.assert_allclose([a[k] for k in sorted(a)], [b[k] for k in sorted(a)], rtol=1e-12, atol=1e-12)

    def test_04_eval_and_truth_do_not_change_model_or_threshold(self):
        dest = self.unique("mutated")
        shutil.copytree(self.root / "data", dest)
        manifest = read_json(dest / "eval_manifest.json")
        for entry in manifest["measurements"]:
            file = dest / entry["source_path"]
            with np.load(file, allow_pickle=False) as source:
                arrays = {k: source[k].copy() for k in source.files}
            arrays["waveform"][:, 0] *= 3.5
            np.savez_compressed(file, **arrays)
            entry["source_sha256"] = sha(file)
        write_json(dest / "eval_manifest.json", manifest)
        truth = read_json(dest / "truth.json")
        for c in truth["cases"]:
            c["label"] = "abnormal" if c["label"] == "normal" else "normal"
            c["regions"] = []
        write_json(dest / "truth.json", truth)
        config = copy.deepcopy(self.config)
        config.update(eval_manifest=str(dest / "eval_manifest.json"), truth_path=str(dest / "truth.json"))
        path = self.unique("config").with_suffix(".json")
        write_json(path, config)
        second = ExperimentRunner().execute(path)
        for rc in config["routes"]:
            for suffix in (".joblib", "_threshold.json"):
                self.assertEqual(sha(self.bundle / "models" / (rc["key"]+suffix)), sha(second / "models" / (rc["key"]+suffix)))

    def test_05_train_eval_leakage_specimen_hash_and_parent(self):
        _, train, ev, _, _, _ = validate_config(self.config_path)
        for key in ("specimen_id", "source_sha256", "derived_group_id"):
            altered = copy.deepcopy(ev)
            altered[0].meta[key] = train[0].meta[key]
            with self.assertRaises(ValueError):
                DatasetPlanner().plan(train, altered, self.config["split"], 42)

    def test_06_grouped_split(self):
        _, train, ev, _, _, _ = validate_config(self.config_path)
        train = copy.deepcopy(train)
        first = train[0].meta["specimen_id"]
        second = train[2].meta["specimen_id"]
        for r in train:
            if r.meta["specimen_id"] in (first, second):
                r.meta["derived_group_id"] = "shared_parent"
        fit, cal, _ = DatasetPlanner().plan(train, ev, self.config["split"], 42)
        for key in ("specimen_id", "source_sha256", "derived_group_id"):
            self.assertFalse({r.meta[key] for r in fit} & {r.meta[key] for r in cal})

    def test_07_missing_rotation_empty_selection_no_events_partial_failure(self):
        data = self.unique("edge_data")
        shutil.copytree(self.root / "data", data)
        manifest = read_json(data / "eval_manifest.json")
        for entry in manifest["measurements"]:
            entry["mapping"]["rpm"] = None
        write_json(data / "eval_manifest.json", manifest)
        config = copy.deepcopy(self.config)
        config["eval_manifest"] = str(data / "eval_manifest.json")
        config["routes"][1]["selection"]["condition"] = {"field": "msc", "comparison": ">", "value": 2}
        config["routes"][3]["threshold_pa"] = 100
        config["routes"][4]["simulate_failure"] = True
        path = self.unique("edges").with_suffix(".json")
        write_json(path, config)
        bundle = BundleReader(ExperimentRunner().execute(path)).validate()
        self.assertEqual(bundle.manifest["bundle_status"], "partial")
        for row in bundle.tables["route_case_results"]:
            key = row["route_key"]
            if key == "A_full":
                self.assertIsNotNone(row["case_score"])
            else:
                self.assertIsNone(row["case_score"])
                self.assertEqual(row["decision"], "undetermined")
                if key == "B_order":
                    self.assertEqual(row["execution_status"], "skipped")
                    self.assertEqual(row["coverage_status"], "not_applicable")
                if key == "A_selected":
                    self.assertIn("empty_selection", row["reason"])
                    self.assertGreater(row["n_created"], 0)
                if key == "C_event":
                    self.assertIn("no_events", row["reason"])
                if key == "D_patch":
                    self.assertEqual(row["execution_status"], "failed")

    def test_08_source_ranges_and_overlapping_union(self):
        measurements = {r["measurement_id"]: r for r in self.reader.tables["measurements"]}
        for sample in self.reader.tables["samples"]:
            meta = measurements[sample["measurement_id"]]
            self.assertLess(sample["start_sample"], sample["end_sample"])
            self.assertLessEqual(sample["end_sample"], meta["n_samples"])
            self.assertLessEqual(sample["support_start_sample"], sample["start_sample"])
            self.assertGreaterEqual(sample["support_end_sample"], sample["end_sample"])
        self.assertEqual(union_length([(0, 1024), (512, 1536), (2048, 2500)]), 1988)
        for row in self.reader.tables["route_case_results"]:
            self.assertLessEqual(row["scored_union_seconds"], row["observed_seconds"])

    def test_09_bundle_corruption_and_staging_rejected(self):
        dest = self.unique("corrupt")
        shutil.copytree(self.bundle, dest)
        (dest / "metrics.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(ValueError):
            BundleReader(dest).validate()
        with self.assertRaises(ValueError):
            BundleReader(self.root / "incomplete.staging")

    def test_10_import_idempotency_conflict_and_missing_source(self):
        dest = self.unique("inbox")
        first = EvaluationAdapter().import_bundle(self.bundle, dest)
        second = EvaluationAdapter().import_bundle(self.bundle, dest, {str(self.root): str(self.root / "unavailable")})
        self.assertEqual(first["status"], "imported")
        self.assertEqual(second["status"], "already_imported")
        self.assertTrue(second["unresolved_sources"])
        other = self.unique("conflict")
        shutil.copytree(self.bundle, other)
        manifest = read_json(other / "manifest.json")
        manifest["completed_at"] = "2000-01-01T00:00:00+00:00"
        write_json(other / "manifest.json", manifest)
        with self.assertRaisesRegex(ValueError, "conflict"):
            EvaluationAdapter().import_bundle(other, dest)

    def test_11_insufficient_calibration_keeps_scores(self):
        config = copy.deepcopy(self.config)
        config["split"]["min_calibration_groups"] = 100
        config["routes"] = config["routes"][:1]
        path = self.unique("no_calibration").with_suffix(".json")
        write_json(path, config)
        bundle = BundleReader(ExperimentRunner().execute(path)).validate()
        for row in bundle.tables["route_case_results"]:
            self.assertIsNotNone(row["case_score"])
            self.assertEqual(row["decision"], "undetermined")
            self.assertIn("calibration_unavailable", row["reason"])

    def test_12_versions_units_and_unimplemented_route_rejected(self):
        for mutation in ("version", "plugin"):
            config = copy.deepcopy(self.config)
            if mutation == "version":
                config["schema_version"] = "99.0"
            else:
                config["routes"][0]["plugin"] = "not_implemented"
            path = self.unique("invalid").with_suffix(".json")
            write_json(path, config)
            with self.assertRaises(ValueError):
                validate_config(path)
        data = self.unique("bad_units")
        shutil.copytree(self.root / "data", data)
        entry = read_json(data / "train_manifest.json")["measurements"][0]
        meta = read_json(data / entry["metadata_path"])
        meta["channels"][0]["unit"] = "unknown"
        write_json(data / entry["metadata_path"], meta)
        with self.assertRaises(ValueError):
            InputAdapter().load(data / "train_manifest.json")

    def test_13_and_or_truth_table(self):
        maps = {"msc": np.array([[.2, .8, .9]]), "intensity": np.array([[1., 0., 2.]])}
        a = {"field": "msc", "comparison": ">", "value": .5}
        b = {"field": "intensity", "comparison": ">", "value": .5}
        np.testing.assert_array_equal(select_mask({"op": "and", "children": [a,b]}, maps), [[False, False, True]])
        np.testing.assert_array_equal(select_mask({"op": "or", "children": [a,b]}, maps), [[True, True, True]])

    def test_14_specimen_metrics_denominators(self):
        base = {"route_key": "A", "coverage_status": "insufficient", "case_score": None, "execution_status": "completed"}
        rows = [{**base, "case_id": str(i), "specimen_id": str(i), "decision": d} for i,d in enumerate(["outside", "within", "undetermined", "undetermined"])]
        truth = {"cases": [{"case_id": str(i), "label": label} for i,label in enumerate(["normal", "abnormal", "normal", "abnormal"])]}
        m = compute_metrics(rows, truth)["routes"]["A"]
        self.assertEqual([m[k] for k in ["normal_total", "abnormal_total", "false_positive", "false_negative", "undetermined_normal", "undetermined_abnormal"]], [2,2,1,1,1,1])

    def test_15_sample_failure_isolation(self):
        config, _, ev, _, _, _ = validate_config(self.config_path)
        plugin = REGISTRY["fixed_window"](config["routes"][0])
        prepared = plugin.prepare(ev[:1], SignalService(config["signal"]))
        target = next(iter(prepared.values))
        prepared.values[target][0] = -999
        class BrokenOne:
            def score(self, values):
                if np.any(values[:, 0] == -999):
                    raise ValueError("simulated sample failure")
                return values[:, 0]
        results = plugin.score(BrokenOne(), prepared, 100)
        self.assertEqual(sum(r["status"] == "scored" for r in results), len(results)-1)
        failed = next(r for r in results if r["sample_id"] == target)
        self.assertIsNone(failed["anomaly_score"])
        self.assertIn("sample_processing_failed", failed["reason"])

    def test_16_fusion_explicit_rule_and_unknown_bundle_version(self):
        config = copy.deepcopy(self.config)
        config["routes"] = config["routes"][:1]
        config["fusion"]["enabled"] = True
        path = self.unique("fusion").with_suffix(".json")
        write_json(path, config)
        bundle = BundleReader(ExperimentRunner().execute(path)).validate()
        decisions = {r["case_id"]: r["decision"] for r in bundle.tables["route_case_results"]}
        for r in bundle.tables["case_results"]:
            self.assertEqual(r["decision"], decisions[r["case_id"]])
        dest = self.unique("future_bundle")
        shutil.copytree(self.bundle, dest)
        manifest = read_json(dest / "manifest.json")
        manifest["schema_version"] = "2.0"
        write_json(dest / "manifest.json", manifest)
        with self.assertRaisesRegex(ValueError, "unsupported"):
            BundleReader(dest).validate()

    def test_17_shape_and_score_reference_validation(self):
        for corruption in ("shape", "reference"):
            dest = self.unique("semantic_corruption")
            shutil.copytree(self.bundle, dest)
            filename = "artifacts.jsonl" if corruption == "shape" else "sample_results.jsonl"
            from nv_runner.common import read_lines, write_lines
            rows = read_lines(dest / filename)
            if corruption == "shape":
                artifact = next(r for r in rows if r.get("array_file"))
                next(iter(artifact["array_file"]["arrays"].values()))["shape"] = [999999]
            else:
                rows[0]["model_ref"] = "model:nonexistent"
            write_lines(dest / filename, rows)
            manifest = read_json(dest / "manifest.json")
            manifest["members"][filename] = {"bytes": (dest/filename).stat().st_size, "sha256": sha(dest/filename)}
            write_json(dest / "manifest.json", manifest)
            with self.assertRaises(ValueError):
                BundleReader(dest).validate()


if __name__ == "__main__":
    unittest.main(verbosity=2)
