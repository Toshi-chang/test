"""Validate saved evidence, regenerate report, export a source-only reproduction kit."""
import bootstrap_lab
from bootstrap_lab import ROOT,BASELINE,verify_baseline
from pathlib import Path
import json,re,zipfile,hashlib
from bridge.adapter import read,write,sha
from summarize import summarize

def finalize():
    run=ROOT/'outputs/comparison_v1';status=read(run/'status.json')
    if status['status']!='passed':raise ValueError('experiment has not passed')
    log=(ROOT/'reports/protocol_tests.log').read_text(encoding='utf-8-sig')
    if 'Ran 6 tests' not in log or not re.search(r'^OK\s*$',log,re.M):raise ValueError('new tests not passed')
    clean=read(run/'clean/evidence.json');disturbed=read(run/'disturbed/evidence.json')
    result=summarize(clean,disturbed,run)
    for evidence in [clean,disturbed]:
        for row in evidence['cases']:
            if row['top_inputs']:
                if abs(row['score']-row['top_inputs'][0]['score'])>1e-12:raise AssertionError('top input not case maximum')
                if row['decision']=='outside' and not row['score']>row['threshold']:raise AssertionError('inconsistent decision')
    # Fixed reference is materialized from the prior local report when available;
    # absence on another machine never substitutes an invented historical result.
    prior=ROOT.parent/'distributed_nv_integration/outputs/comparison_v1/validation.json'
    historical={'status':'unavailable','note':'optional earlier comparison; not required for factorial execution'}
    if prior.exists():
        old=Path(read(prior)['bundle']);new=Path(status['clean_bundle'])
        historical={'status':'matched','model_threshold_hashes':{}}
        for p in (old/'models').iterdir():
            a,b=sha(p),sha(new/'models'/p.name)
            historical['model_threshold_hashes'][p.name]={'previous':a,'clean':b,'match':a==b}
        if not all(v['match'] for v in historical['model_threshold_hashes'].values()):historical['status']='differs'
    write(ROOT/'reports/historical_model_comparison.json',historical)
    completion={'date_jst':'2026-11-07','status':'passed','new_unit_tests':6,'locked_baseline_assets':verify_baseline(),
        'factorial_variants':result['unique_eval_variants'],'independent_eval_families':result['independent_families'],
        'pairing':read(run/'pairing.json'),'old_model_hash_comparison':historical['status'],
        'baseline_130_tests':'not rerun; 164 frozen assets verified unchanged',
        'browser_interaction':'not run; existing viewer generated in separate process',
        'results':result['routes']}
    write(ROOT/'reports/completion.json',completion)
    # Small results and numerical evidence travel; large signals/models/Bundles do not.
    for name in ['REPORT.md','factorial_results.json','pairing.json']:
        (ROOT/'reports'/name).write_bytes((run/name).read_bytes())
    files=[]
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if any(x in {'outputs','_work','__pycache__','.venv'} for x in rel.parts):continue
        if not p.is_file() or p.name=='package_manifest.json':continue
        files.append({'path':rel.as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
    write(ROOT/'package_manifest.json',{'schema_version':'1.0','files':files})
    target=ROOT.parent/'disturbance_factorial_poc_source.zip'
    if target.exists():raise ValueError('archive already exists')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for f in files:z.write(ROOT/f['path'],'disturbance_factorial_poc/'+f['path'])
        z.write(ROOT/'package_manifest.json','disturbance_factorial_poc/package_manifest.json')
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:raise ValueError('archive integrity failed')
        for f in files:
            if hashlib.sha256(z.read('disturbance_factorial_poc/'+f['path'])).hexdigest()!=f['sha256']:raise ValueError('archive mismatch')
    print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'completion':completion},ensure_ascii=False))
if __name__=='__main__':finalize()
