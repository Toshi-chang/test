"""Reviewed registration definitions. No discovery and no plugin imports."""
from .plugin_descriptor import PluginDescriptor
from .plugin_registry import PluginRegistry


def positive_parameters(*names):
    """Legacy validator semantics, including bool and non-finite acceptance."""
    return {"type": "object", "required": list(names), "additionalProperties": True,
            "properties": {name: {"type": "number", "exclusiveMinimum": 0,
                                   "allow_bool": True, "finite": False} for name in names}}


BUILTIN_DESCRIPTORS = (
    PluginDescriptor("fixed_window", "0.2.0", "nv_runner.routes:FixedWindow",
                     positive_parameters("window_seconds", "hop_seconds")),
    PluginDescriptor("order_window", "0.2.0", "nv_runner.routes:OrderWindow",
                     positive_parameters("revolutions", "hop_revolutions", "samples_per_revolution")),
    PluginDescriptor("event", "0.2.0", "nv_runner.routes:EventRoute",
                     positive_parameters("highpass_hz", "envelope_seconds", "threshold_pa", "min_seconds", "merge_seconds", "margin_seconds")),
    PluginDescriptor("tf_patch", "0.2.0", "nv_runner.routes:TFPatch",
                     positive_parameters("frequency_bins", "time_frames", "hop_bins", "hop_frames")),
    PluginDescriptor("fixed_window_candidate", "0.2.0", "nv_runner.route_a_candidate:FixedWindowCandidate",
                     positive_parameters("window_seconds", "hop_seconds"),
                     validator="nv_runner.route_a_candidate:validate_candidate_config"),
)

DEFAULT_REGISTRY = PluginRegistry(BUILTIN_DESCRIPTORS)
