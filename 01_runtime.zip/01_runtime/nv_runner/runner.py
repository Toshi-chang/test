"""Sequential run orchestration. Truth is opened only after all route inference."""
import platform
import time
import traceback
import uuid
from pathlib import Path
import numpy as np
import scipy
import sklearn
from . import __version__
from .common import read_json, write_json, write_lines, require_version, array_file, sha, utc, identity
from .input_adapter import InputAdapter, DatasetPlanner
from .signals import SignalService, pu_diagnostics
from .routes import REGISTRY
from .bundle import TABLES, ResultCollector


def validate_config(path):
    path = Path(path).resolve()
    config = read_json(path)
    require_version(config)
    if not isinstance(config.get("batch_size", 128), int) or config.get("batch_size", 128) < 1:
        raise ValueError("batch_size must be positive integer")
    if config["export"]["format"] != "result_bundle_v1":
        raise ValueError("unsupported export format")
    if config.get("aggregation", {}).get("method") != "max_valid_sample_score":
        raise ValueError("only max_valid_sample_score supported")
    if not 0 < config["split"]["calibration_fraction"] < 1 or not 0 < config["calibration"]["quantile"] <= 1:
        raise ValueError("invalid fraction or quantile")
    if config.get("fusion", {}).get("enabled") and config["fusion"].get("rule") != "any_outside_all_within":
        raise ValueError("unknown fusion rule")
    keys = set()
    def check_selection(node):
        if "op" in node:
            if node["op"] not in ("and", "or") or len(node["children"]) < 2:
                raise ValueError("selection requires AND/OR with >=2 children")
            for child in node["children"]:
                check_selection(child)
        elif node["field"] not in ("frequency_hz", "msc", "intensity", "reactive_intensity", "phase", "p_power", "u_power") or node["comparison"] not in (">", ">=", "<", "<=") or not isinstance(node["value"], (int, float)):
            raise ValueError("invalid selection predicate")
    for route in config["routes"]:
        if route["key"] in keys or not route["key"].replace("_", "").isalnum():
            raise ValueError("duplicate or invalid route key")
        keys.add(route["key"])
        if not route.get("enabled", True):
            continue
        if route["plugin"] not in REGISTRY:
            raise ValueError(f"enabled plugin not implemented: {route['plugin']}")
        if route["model"]["kind"] not in ("isolation_forest", "pca"):
            raise ValueError("unknown model")
        if route.get("selection", {}).get("enabled"):
            check_selection(route["selection"]["condition"])
        required = {"fixed_window": ["window_seconds", "hop_seconds"],
                    "order_window": ["revolutions", "hop_revolutions", "samples_per_revolution"],
                    "event": ["highpass_hz", "envelope_seconds", "threshold_pa", "min_seconds", "merge_seconds", "margin_seconds"],
                    "tf_patch": ["frequency_bins", "time_frames", "hop_bins", "hop_frames"]}[route["plugin"]]
        for key in required:
            if not isinstance(route.get(key), (float, int)) or route[key] <= 0:
                raise ValueError(f"invalid/missing {key}")
    sig = config["signal"]
    if sig.get("spectral_convention","legacy_amplitude_squared") not in ("mean_square_bin_v2","legacy_amplitude_squared"):
        raise ValueError("unknown spectral convention")
    if sig["nfft"] < 8 or sig["hop_samples"] < 1 or sig["average_frames"] < 3 or sig["average_frames"] % 2 != 1:
        raise ValueError("invalid STFT/averaging config")
    train_path = (path.parent / config["train_manifest"]).resolve()
    if read_json(train_path).get("normal_only_attested") is not True:
        raise ValueError("training manifest requires normal_only_attested=true")
    train = InputAdapter().load(train_path)
    evaluation = InputAdapter().load(path.parent / config["eval_manifest"])
    fit, calibration, split = DatasetPlanner().plan(train, evaluation, config["split"], config["seed"])
    return config, train, evaluation, fit, calibration, split


def compute_metrics(rows, truth):
    labels = {r["case_id"]: r for r in truth.get("cases", [])}
    metrics = {}
    for route in sorted({r["route_key"] for r in rows}):
        subset = [r for r in rows if r["route_key"] == route]
        grouped = {}
        for row in subset:
            grouped.setdefault(row["specimen_id"], []).append(row)
        report = {"unit": "specimen", "normal_total": 0, "abnormal_total": 0,
                  "false_positive": 0, "false_negative": 0, "true_positive": 0, "true_negative": 0,
                  "undetermined_normal": 0, "undetermined_abnormal": 0, "unlabelled": 0, "specimens": [],
                  "case_coverage_counts": {k: sum(r["coverage_status"] == k for r in subset) for k in ("sufficient", "insufficient", "not_applicable")}}
        values = [r["case_score"] for r in subset if r["case_score"] is not None]
        report["case_score_distribution"] = {"n": len(values), "min": min(values) if values else None,
            "max": max(values) if values else None, "median": float(np.median(values)) if values else None}
        report["execution_counts"] = {k: sum(r["execution_status"] == k for r in subset) for k in ("completed", "skipped", "failed")}
        for sid, cases in grouped.items():
            available = [labels[c["case_id"]]["label"] for c in cases if c["case_id"] in labels]
            label = ("abnormal" if "abnormal" in available else "normal") if len(available) == len(cases) else None
            decisions = [c["decision"] for c in cases]
            decision = "outside" if "outside" in decisions else ("within" if all(d == "within" for d in decisions) else "undetermined")
            report["specimens"].append({"specimen_id": sid, "label": label, "decision": decision,
                "case_ids": [c["case_id"] for c in cases], "scenario": [labels.get(c["case_id"], {}).get("scenario") for c in cases]})
            if label is None:
                report["unlabelled"] += 1
                continue
            report[label+"_total"] += 1
            if decision == "undetermined":
                report["undetermined_"+label] += 1
            elif label == "normal":
                report["false_positive" if decision == "outside" else "true_negative"] += 1
            else:
                report["true_positive" if decision == "outside" else "false_negative"] += 1
        metrics[route] = report
    return {"schema_version": "1.0", "specimen_policy": "any outside; within only when all cases within", "routes": metrics,
            "warning": "synthetic development evaluation; no field-performance or false-positive-rate guarantee"}


class ExperimentRunner:
    def execute(self, config_path):
        started = time.perf_counter()
        started_at = utc()
        config_path = Path(config_path).resolve()
        config, train, evaluation, fit, calibration, split = validate_config(config_path)
        run_id = "run_" + uuid.uuid4().hex
        output = (config_path.parent / config["export"]["output_dir"]).resolve()
        output.mkdir(parents=True, exist_ok=True)
        staging = output / (run_id + ".staging")
        staging.mkdir()
        for sub in ("models", "arrays", "logs"):
            (staging / sub).mkdir()
        tables = {t: [] for t in TABLES}
        artifacts = tables["artifacts"]
        def artifact(aid, operation, parents=None, **kwargs):
            artifacts.append({"artifact_id": aid, "schema_version": "1.0", "operation": operation,
                              "parent_refs": parents or [], "software_version": __version__, **kwargs})
        write_json(staging / "experiment.json", config)
        write_json(staging / "dataset_split.json", split)
        code_hashes = {p.name: sha(p) for p in sorted(Path(__file__).parent.glob("*.py"))}
        write_json(staging / "environment.json", {"schema_version": "1.0", "python": platform.python_version(),
            "numpy": np.__version__, "scipy": scipy.__version__, "sklearn": sklearn.__version__,
            "software_version": __version__, "code_hashes": code_hashes, "code_sha256": identity(code_hashes)})
        splits = {mid: name for name in ("fit", "calibration", "evaluation") for mid in split[name]}
        all_records = train + evaluation
        service = SignalService(config["signal"])
        for r in all_records:
            m = {**r.meta, "split": splits[r.meta["measurement_id"]]}
            tables["measurements"].append(m)
            mid = m["measurement_id"]
            maps = service.maps(r)
            desc = array_file(staging, f"arrays/signal_{mid}.npz", **maps, waveform=r.signals,
                              **({"rpm": r.rpm} if r.rpm is not None else {}))
            convention = config["signal"].get("spectral_convention","legacy_amplitude_squared")
            physical_definition = ("one-sided mean-square bins: g FFT(pw)conj(uw)/(N sum(w^2)); g=2 interior,1 DC/Nyquist; integral=sum bins"
                                   if convention=="mean_square_bin_v2" else "LEGACY FFT/Hann.sum amplitude squared; not mean-square or PSD")
            artifact(f"signal:{mid}", "shared_stft_physical_maps_and_waveform_snapshot", [mid], array_file=desc,
                config=config["signal"], axes={"waveform": ["time", "channel"], "maps": ["frame", "frequency_bin"]},
                physical_definition=physical_definition+"; Cpu=P conj(U); phase=p minus u; MSC time averaged; u signed along sensor axis",
                units={"p_power": "Pa^2", "u_power": "(m/s)^2", "intensity": "W/m^2", "reactive_intensity":"W/m^2", "phase": "rad", "msc": "1"})
            artifact(f"pu_diagnostics:{mid}","welch_measured_pu_diagnostics",[mid],
                array_file=array_file(staging,f"arrays/pu_{mid}.npz",**pu_diagnostics(r)),
                definition="one-sided Welch PSD; Cpu=P conj(U); Z_H1=Cpu/Suu is mixed-field estimate; invalid bins masked",
                config={"window":"periodic Hann","nperseg":"min(512,2^floor(log2(N/4)))","overlap":.5,"detrend":False},
                units={"p_psd":"Pa^2/Hz","u_psd":"(m/s)^2/Hz","active_intensity_psd":"W/m^2/Hz","reactive_intensity_psd":"W/m^2/Hz","impedance":"Pa s/m","phase":"rad"})
        for sid in sorted({r.meta["specimen_id"] for r in all_records}):
            tables["specimens"].append({"specimen_id": sid})
        for cid in sorted({r.meta["case_id"] for r in all_records}):
            record = next(r for r in all_records if r.meta["case_id"] == cid)
            tables["cases"].append({"case_id": cid, "specimen_id": record.meta["specimen_id"], "split": splits[record.meta["measurement_id"]]})
        requested, completed, cancelled = [], [], False
        for rc in config["routes"]:
            if not rc.get("enabled", True):
                continue
            route_start = time.perf_counter()
            key = rc["key"]
            requested.append(key)
            plugin = REGISTRY[rc["plugin"]](rc)
            artifact(f"route_config:{key}", "route_configuration", config=rc, capabilities=plugin.capabilities())
            artifact(f"aggregation:{key}", "max_valid_sample_score", config=config["aggregation"])
            artifact(f"score:{key}", "score_definition", definition="higher is more anomalous; negative IF score_samples or standardized PCA mean squared residual", model=rc["model"])
            try:
                if cancelled:
                    raise RuntimeError("cancelled")
                if rc.get("simulate_failure"):
                    raise RuntimeError("explicit_test_failure")
                prepared = {name: plugin.prepare(records, service) for name, records in
                            [("fit", fit), ("calibration", calibration), ("evaluation", evaluation)]}
                model = None
                model_reason = None
                try:
                    model = plugin.fit(prepared["fit"], rc["model"], config["seed"])
                except ValueError as e:
                    if str(e) != "insufficient_training_samples":
                        raise
                    model_reason = str(e)
                if model is not None:
                    model_path = staging / "models" / f"{key}.joblib"
                    model.save(model_path)
                    artifact(f"model:{key}", "fit_normal_model", [f"route_config:{key}"], path=f"models/{key}.joblib",
                        sha256=sha(model_path), feature_schema=plugin.feature_schema(), fit_sample_ids=sorted(prepared["fit"].values),
                        input_schema="ordered numeric features only; no identifiers or labels", preprocessing="StandardScaler fit only")
                route_samples, route_results, route_artifacts = [], [], []
                output_cases = {}
                for phase, records in [("fit", fit), ("calibration", calibration), ("evaluation", evaluation)]:
                    p = prepared[phase]
                    scored = plugin.score(model, p, config.get("batch_size", 128))
                    route_results.extend({**s, "run_id": run_id, "split": phase} for s in scored)
                    output_cases[phase] = plugin.aggregate(p, scored, records)
                    ids = sorted(p.values)
                    if ids:
                        desc = array_file(staging, f"arrays/{key}_{phase}_inputs.npz", features=np.array([p.values[i] for i in ids]))
                        aid = f"inputs:{key}:{phase}"
                        artifact(aid, "prepared_input_table", [f"route_config:{key}"], array_file=desc,
                                 sample_ids=ids, feature_schema=plugin.feature_schema(), axes=["sample", "feature"])
                    index = {sid: i for i, sid in enumerate(ids)}
                    for mid, arrays in p.assets.items():
                        artifact(f"prepared:{key}:{mid}", "route_coordinates_or_selection", [f"signal:{mid}", f"route_config:{key}"],
                                 array_file=array_file(staging, f"arrays/{key}_{mid}.npz", **arrays))
                    for s in p.samples:
                        route_samples.append({**s, "run_id": run_id, "split": phase,
                            "input_ref": f"inputs:{key}:{phase}" if s["sample_id"] in index else None,
                            "input_row": index.get(s["sample_id"])})
                    artifact(f"coverage:{key}:{phase}", "coverage_ledger", [f"route_config:{key}"], measurements=p.coverage)
                threshold = plugin.calibrate(output_cases["calibration"], config["calibration"])
                artifact(f"calibration_cases:{key}", "case_aggregation_before_threshold", [f"aggregation:{key}"], cases=output_cases["calibration"])
                write_json(staging / "models" / f"{key}_threshold.json", threshold)
                artifact(f"threshold:{key}", "empirical_case_calibration", [f"calibration_cases:{key}"], **{"threshold": threshold})
                rows = plugin.decide(output_cases["evaluation"], threshold)
                if model_reason:
                    for row in rows:
                        row["reason"] = ";".join(filter(None, [row["reason"], model_reason]))
                tables["samples"].extend(route_samples)
                tables["sample_results"].extend(route_results)
                tables["route_case_results"].extend(rows)
                for s in route_results:
                    if s["reason"] and (s["reason"] == "non_finite_features" or s["reason"].startswith("sample_processing_failed")):
                        tables["errors"].append({"route_key": key, "sample_id": s["sample_id"], "reason": s["reason"]})
                completed.append(key)
            except (Exception, KeyboardInterrupt) as e:
                cancelled = cancelled or isinstance(e, KeyboardInterrupt)
                reason = "cancelled" if cancelled else str(e)
                tables["errors"].append({"route_key": key, "reason": reason, "traceback": traceback.format_exc()})
                for cid in sorted({r.meta["case_id"] for r in evaluation}):
                    sid = next(r.meta["specimen_id"] for r in evaluation if r.meta["case_id"] == cid)
                    tables["route_case_results"].append({"route_key": key, "case_id": cid, "specimen_id": sid,
                        "execution_status": "failed", "coverage_status": "insufficient", "decision": "undetermined",
                        "case_score": None, "threshold_ref": None, "aggregation_ref": f"aggregation:{key}",
                        "n_created": 0, "n_scored": 0, "reason": reason, "evidence_refs": []})
            elapsed = time.perf_counter() - route_start
            for row in tables["route_case_results"]:
                if row["route_key"] == key:
                    row.update(run_id=run_id, route_elapsed_seconds=elapsed)
            print(f"{key}: {'completed' if key in completed else 'failed'} ({elapsed:.2f}s)", flush=True)
        for cid in sorted({r.meta["case_id"] for r in evaluation}):
            rows = [r for r in tables["route_case_results"] if r["case_id"] == cid]
            decision, reason = "undetermined", "fusion_disabled"
            if config["fusion"]["enabled"]:
                decisions = [r["decision"] for r in rows]
                decision = "outside" if "outside" in decisions else ("within" if decisions and all(d == "within" for d in decisions) else "undetermined")
                reason = "any_outside_all_within"
            tables["case_results"].append({"run_id": run_id, "case_id": cid, "decision": decision, "reason": reason,
                                         "contributions": [{"route_key": r["route_key"], "decision": r["decision"]} for r in rows]})
        truth = {}
        if config.get("truth_path"):
            truth = read_json(config_path.parent / config["truth_path"])
            require_version(truth)
            # Source contributions, true rpm and transfer functions enter ONLY after every route has finished.
            truth_root = (config_path.parent / config["truth_path"]).resolve().parent
            for item in truth.get("source_artifacts",[]):
                mid = item["measurement_id"]
                original = item["array_file"]
                from .common import inside
                source = inside(truth_root,original["path"])
                if sha(source) != original["sha256"]:
                    raise ValueError("truth array hash mismatch")
                with np.load(source,allow_pickle=False) as arrays:
                    copied = array_file(staging,f"arrays/truth_{mid}.npz",**{k:arrays[k] for k in arrays.files})
                artifact(f"truth:{mid}","generator_truth_only_after_inference",[mid],array_file=copied,
                    config={"acoustic_schema_version":truth.get("acoustic_schema_version"),"use":"evaluation/view only"},
                    axes={"source_waveforms":["source","time","channel"],"source_drives":["source","time"],
                          "transfers_re_im":["source","frequency","Gp_real,Gp_imag,Gu_axial_real,Gu_axial_imag"]})
                item["array_file"] = copied
            write_json(staging / "truth.json", truth)
        metrics = compute_metrics(tables["route_case_results"], truth)
        metrics["elapsed_seconds"] = time.perf_counter() - started
        write_json(staging / "metrics.json", metrics)
        for name, rows in tables.items():
            write_lines(staging / f"{name}.jsonl", rows)
        write_json(staging / "logs" / "run.json", {"started": started_at, "elapsed_seconds": metrics["elapsed_seconds"],
            "requested_routes": requested, "completed_routes": completed, "cancelled": cancelled})
        return ResultCollector().finalize(staging, {"run_id": run_id, "requested_routes": requested, "completed_routes": completed,
            "bundle_status": "complete" if requested == completed else "partial", "cancelled": cancelled,
            "data_kind": sorted({r.meta["data_kind"] for r in all_records}), "resume_policy": "new run; no intermediate reuse"}, output / run_id)
