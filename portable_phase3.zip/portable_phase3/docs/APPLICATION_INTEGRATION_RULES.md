# 別GUIアプリケーション開発規則

2026-10-16。Phase 3完了版 PoC 0.2.0 / ResultBundle 1.0 / C01〜C08を対象とする追加開発規則。今回は文書・所有範囲テンプレートのみ追加し、GUIやServiceを実装していない。既存130試験・科学計算・契約を変更しない。

正本：[開発思想](DEVELOPMENT_ARCHITECTURE.md)、[最小契約](parallel_contracts/CONTRACTS_MINIMUM.md)、[変更手順](parallel_contracts/INTEGRATION.md)、[Phase 3実装記録](validation/phase3_registry.md)。本書と既存契約の不整合を発見した場合は既存契約を優先し、変更提案へ分離する。

## 1. 分離するもの

新GUIは既存 `nv_runner/viewer.py` / `viewer.html` の改修版ではなく、別アプリとする。依存は `GUI → Application Service → 共通基盤` の一方向。GUIはnv_runner、sklearnモデル、PreparedSet、SignalServiceを直接importしない。Serviceのworker内だけが下記の共通境界にアクセスする。共通基盤からアプリをimportしない。

移植先の配置案（未作成）：

```text
workspace/
  core/                     # portable_phase3由来。共通基盤単独で実行・試験
  application/
    gui/                    # GUIフレームワーク依存はここだけ
    service/                # 非同期制御、worker、core_adapter、read model
    contracts/              # アプリAPI/DTO版・互換性方針
    tests/gui/
    tests/service/
    tests/integration/
    packaging/              # アプリの依存・起動設定
  extensions/               # 新しい解析機能の専用パッケージ
  integration/              # レビュー済み登録composition、互換表、変更記録
  artifacts/{gui,service,core,qa}/
```

これは配置規則であり、coreがpip install可能な配布物になったという意味ではない。現行にpyproject/setupはない。初版はcoreを独立ソース配布単位として固定し、Serviceが設定で渡されたcore rootを使って専用Python子プロセスを起動する。core rootは元PCの絶対パスを埋め込まず移植先で解決する。wheel化・アプリ用pyproject/依存定義は今後の作業。アプリのGUI依存をcoreのrequirementsへ追加しない。複数GUI/CLIは同じService契約を使用できる。

## 2. 現行の接続境界

「現行」は呼出可能な既存境界を意味し、将来すべてのリリースでのABI保証ではない。アクセスの実装依存をServiceのcore_adapterへ閉じ込める。

|対象・根拠|現行の呼出し/形式|利用規則・限界|
|---|---|---|
|[runner.py](../nv_runner/runner.py)|`ExperimentRunner().execute(config_path) -> Path`|同期。確定したcomplete/partial Bundleのディレクトリを返す。失敗時に常に戻るとは限らない。registry引数や非同期job APIはない。|
|同上|`validate_config(path) -> (config, train, evaluation, fit, calibration, split)`|設定ファイル基準のパス解決、入力全読込、正常学習宣誓、分割、選択pluginの検査を行う。JSONだけの軽い検査ではない。戻り値のrecordsをGUIへ渡さない。|
|[plugin_catalog.py](../nv_runner/plugin_catalog.py), [plugin_registry.py](../nv_runner/plugin_registry.py)|`DEFAULT_REGISTRY` のiteration / `get_descriptor(id)` / `register` / `unregister` / `validate(route)`|一覧はiteration＋get_descriptorのみ。validateやfactory呼出は選択実装をimportしconstructorも実行する。登録後はworker中に変更しない。|
|[plugin_descriptor.py](../nv_runner/plugin_descriptor.py)|PluginDescriptor|descriptor/API 1.0、C01/C02→C03/C05、C04@1.0。1 IDに1実装版。版は完全一致。semver範囲解決ではない。|
|[plugin_validation.py](../nv_runner/plugin_validation.py)|宣言schemaによる検証|限定schema。全実行の検証はvalidate_config経由。画面側の入力補助だけで実行可としない。既定値注入・旧許容値の変更をしない。|
|[input_adapter.py](../nv_runner/input_adapter.py)|`InputAdapter().load(manifest_path) -> list[MeasurementRecord]`|NPZ [time,channel]のp/u 2列、Pa / m/s、同位置ペア、u単位方向、校正済み、共有時計、RPMは任意同長系列。Runner内で直接生成され、入力adapter選択Registryはない。|
|同上|`DatasetPlanner().plan(train,evaluation,config,seed)`|個体・派生元分離をcoreが担当。GUIで再分割しない。|
|[models.py](../nv_runner/models.py)|`NormalModel.fit(values,config,seed) -> self`, `score(values)`, `save(path)`|IF/PCA、fitだけでStandardScaler。ロード公開API・推論only CLI・モデル選択Registryはない。GUIでjoblibをロードしない。|
|[bundle.py](../nv_runner/bundle.py)|`BundleReader(path).validate() -> self`、`manifest/tables/path`|実際のクラス名はBundleReader（ResultBundleReaderではない）。検証済み保存結果だけを読取モデルへ変換する。ページング/evidence抽出APIは未実装。|
|同上|`EvaluationAdapter().import_bundle(bundle_path,destination,path_mapping=None) -> dict`|ローカルコピーと受領記録。HTTP受渡しではない。同run_id同hashはalready_imported、別hashは拒否。原本不足はunresolved_sourcesとして返る。並行同一宛先書込みは直列化。|
|[viewer.py](../nv_runner/viewer.py)|`render(bundle_path,output) -> Path`|保存Bundleから静的HTMLを生成。新GUIの必須依存にしない。参考/比較として利用可能。出力はBundle外。|

legacy A/B/C/Dは同じroutes.py内にあり、Runner importでこのmoduleはロードされる。「すべての未選択クラスのmoduleが未import」とは約束しない。candidateや外部拡張の不要なimportをしないという現行の遅延境界を維持する。

## 3. Serviceが担当する処理

詳細は [APPLICATION_SERVICE_CONTRACT](APPLICATION_SERVICE_CONTRACT.md)。GUI入力をcanonical experiment JSONへ変換し、manifest参照の相対パス基準を保存場所に合わせる。共有設定を上書きせずジョブ固有設定を保存する。core Validator、実行、例外収集、Bundle検証、読取モデル変換はworker側で行う。

科学計算・特徴・正規化・学習・閾値・判定をService/GUIに再実装しない。描画用の整形と配列の表示用間引きは可能だが、元ID/座標・単位・欠損マスクを保持し、表示間引きを解析入力へ戻さない。個体判定は保存metricsの既存集約を用い、別の集約定義が必要なら共通機能として審査する。正解ラベル/生成器真値は比較表示だけに使う。

## 4. 非同期・失敗・中断

初版は1ジョブ1子プロセス、同じServiceインスタンスの同時解析は1件までとする。GUIイベントループでは設定検証・NPZロード・fit・Bundleハッシュ検証を実行しない。stdout/stderrは継続読取りし、パイプ詰まりを防ぐ。ジョブ別cwd/出力/ログを確保する。

thread safetyは保証されていない。Registryはロックなしの可変辞書、SignalServiceはcache、MeasurementRecordは可変配列/辞書、NormalModel.fitはselfを書き換える。get_descriptorのdeepcopyやn_jobs=1はプロセス全体のthread safety証明ではない。並列ジョブは将来、資源制限・宛先競合を追加検証して有効化する。

Runnerの経路try内のException/KeyboardInterruptは失敗行を作り継続し、cancelledフラグを保持する。ただし入力検証、共通map生成、経路constructor/capabilities、真値読込、最終保存などはこのtry外。そこでの例外/強制終了は未確定stagingを残す可能性がある。プロセス終了コード0でもpartial/未評価があり、正常判定とは限らない。

現在、協調cancel token、途中checkpoint、callback、正式な百分率進捗はない。GUI初版はキャンセルを利用不可と明示する。KeyboardInterruptを安全な公開キャンセルAPIに見立てない。強制停止・タイムアウトは成功/キャンセル済みとせずinterruptedとして隔離し、stagingを完成Bundleに改名しない。再開は新ジョブで全工程。構造化進捗や安全停止をcoreへ追加する場合はC変更。

## 5. 変更の種類と責任

|種類|自由度/担当|統合条件|
|---|---|---|
|A アプリ固有|GUI、画面状態、表示、Service内変換/transportはアプリ担当|アプリ契約内で単体・結合試験。Service DTO境界変更はGUI/SERVICE/QAで調整。coreへ変更しない。|
|B 既存契約内の共通候補|専用Plugin、モデル/入力候補は共通機能担当|専用module・試験、C契約試験、QA監査。登録compositionは統合担当だけが編集。Runnerの名前分岐追加は禁止。|
|C 共通契約/公開境界|ID、座標、単位、状態、Feature Schema、Runner境界、Bundle、版/意味変更|影響調査→CR→producer/consumer/I/Q承認→移行/旧Reader試験。GUI担当は直接実施しない。無応答は承認ではない。|

新Pluginは外部extensions内で実装し、信頼済みworker bootstrapからDEFAULT_REGISTRYへ明示registerできる。新規登録IDを構成で選択する。GUI入力からfactory/module名を実行しない。新旧実装交換は異なる登録IDで構成選択し、非選択/無効化/撤去時の独立性を試験する。削除は利用構成を除去後に登録を除去する。core catalogへ恒久登録する場合も統合担当が既存所有規則で配線する。

**B候補がそのまま本番交換可能とは限らない。** RunnerはInputAdapterを直接使い、NormalModel種別/保存説明はIF/PCA・StandardScalerに制約される。入力候補はまずC01正規ファイルへ先行変換する。異なるモデル/前処理/score定義やFeature Schemaの意味変更には現行metadata/Validatorとの整合確認が必要で、既存境界に収まらなければCへ昇格する。

## 6. 並列開発と開始ゲート

[application_ownership.json](../templates/application_ownership.json) を新workspace用の所有表として採択する。既存ownership.jsonは変更しない。GUIはService mockから、SERVICEは既存coreで、COREは専用Pluginの直接試験から、QAは受入fixture作成から並列開始できる。先に固定するのはService DTO版、job状態、ファイル所有、worker登録経路だけ。GUIフレームワーク選定はGUI担当内で決められる。

共有編集はQA/Iのみ。アプリ契約変更はproducer/consumerの合意、core契約変更は既存CRを必須とする。統合はService単独→GUI接続→Plugin追加/交換→回帰の順で直列化する。生成物は各担当のartifacts以下に限定し、core Bundle内へ画面設定・受領情報を追記しない。

## 7. 互換性と受入

バージョン文字列0.2.0だけでは互換性を保証しない。coreハッシュ/環境、Service契約版、Bundle版、選択Descriptor/API/C契約/実装版を互換表で固定する。初版は検証済みPhase 3ハッシュ集合をallowlistとし、未検証更新は実行前に拒否する。互換更新はQAが130回帰とアプリ受入を通してallowlistへ追加する。数値を変更する更新はGUI表示変更とは分けて評価する。

受入は [GUI統合試験計画](../templates/gui_integration_test_plan.md)。GUIなしでcore130件、GUIからの実モデル実行、保存結果の表示、遅延import、画面変更前後の解析不変、互換更新/未知版拒否、応答性、partial/failed/unscored/undeterminedの区別を確認する。

本資料の追加時にはGUI・Serviceの受入試験は未実施。移植時130件成功の記録は [migration_validation.json](../migration_validation.json) を参照し、将来GUIの成功証拠として流用しない。
