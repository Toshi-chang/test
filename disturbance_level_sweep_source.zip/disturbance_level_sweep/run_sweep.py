import bootstrap_sweep
from bootstrap_sweep import ROOT,BASELINE,verify_baseline
from pathlib import Path
import argparse,sys,time,traceback,subprocess
from bridge.adapter import read,write,sha
from bridge.dataset import generate
from nv_runner.runner import ExperimentRunner,validate_config
from nv_runner.bundle import BundleReader
from sweep_data import build
from summarize_sweep import summarize

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);a=p.parse_args();out=a.output.resolve()
    if out.exists():raise ValueError('fresh output directory required')
    out.mkdir(parents=True);start=time.perf_counter();status={'status':'running'};write(out/'status.json',status)
    try:
        verify_baseline()
        # Always regenerate: no dependency on earlier conversational results or models.
        generate(BASELINE/'configs/dataset_comparison.json',out/'reference')
        data=build(out/'reference',out/'dataset',read(ROOT/'configs/sweep.json'))
        cfg=read(BASELINE/'configs/experiment.json')
        for k,f in [('train_manifest','train_manifest.json'),('eval_manifest','eval_manifest.json'),('truth_path','truth.json')]:cfg[k]=str(data/f)
        cfg['export']['output_dir']=str(out/'runs');write(out/'experiment.json',cfg)
        _,_,_,fit,cal,split=validate_config(out/'experiment.json');write(out/'split.json',split)
        bundle=ExperimentRunner().execute(out/'experiment.json');r=BundleReader(bundle).validate()
        if r.manifest['bundle_status']!='complete' or len(r.manifest['completed_routes'])!=5:raise AssertionError('incomplete routes')
        models={f.name:sha(f) for f in (bundle/'models').iterdir()};write(out/'model_hashes.json',models)
        summarize(r,out/'dataset',out)
        proc=subprocess.run([sys.executable,'-B','-m','nv_runner','view','--bundle',str(bundle),'--output',str(out/'viewer.html')],cwd=BASELINE/'runtime',capture_output=True,text=True,encoding='utf-8',errors='replace')
        (out/'viewer.log').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
        if proc.returncode:raise RuntimeError('viewer failed')
        if models!={f.name:sha(f) for f in (bundle/'models').iterdir()}:raise AssertionError('models changed')
        verify_baseline();status.update(status='passed',bundle=str(bundle),fit_measurements=len(fit),cal_measurements=len(cal),single_training_per_route=True,elapsed_seconds=time.perf_counter()-start)
    except Exception as e:
        status.update(status='failed',error=str(e));(out/'error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:write(out/'status.json',status)
    print(status)
if __name__=='__main__':main()
