import unittest
from contract_fixtures import pipeline, directory, bundle_copy
from nv_runner.common import sha, read_json, write_json
from nv_runner.bundle import EvaluationAdapter

class C07(unittest.TestCase):
    def test_import_idempotence_and_original_resolution(self):
        root,_,bundle=pipeline(); dest=directory(); adapter=EvaluationAdapter(); before=sha(bundle/'manifest.json')
        a=adapter.import_bundle(bundle,dest); b=adapter.import_bundle(bundle,dest)
        self.assertEqual((a['status'],b['status']),('imported','already_imported'))
        self.assertEqual(a['unresolved_sources'],[]); self.assertEqual(a['schema_version'],'1.0')
        missing=adapter.import_bundle(bundle,dest,{str(root/'data'):str(root/'absent')})
        self.assertGreater(len(missing['unresolved_sources']),0)
        self.assertEqual(before,sha(bundle/'manifest.json'))

    def test_conflict_and_invalid_bundle_rejected(self):
        _,_,bundle=pipeline(); dest=directory(); adapter=EvaluationAdapter(); adapter.import_bundle(bundle,dest)
        copy=bundle_copy(); m=read_json(copy/'manifest.json'); m['completed_at']='different'
        write_json(copy/'manifest.json',m)
        with self.assertRaisesRegex(ValueError,'conflict'): adapter.import_bundle(copy,dest)
        (copy/'metrics.json').write_text('{}',encoding='utf-8')
        with self.assertRaises(ValueError): adapter.import_bundle(copy,directory())
