"""Check portable package assets; generated files are not manifest assets."""
import hashlib
import json
from pathlib import Path


def verify(root):
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("manifest_version") != "1.0":
        raise ValueError("unsupported migration manifest version")
    failures = []
    for entry in manifest["files"]:
        path = (root / entry["path"]).resolve()
        if not path.is_relative_to(root.resolve()):
            raise ValueError("manifest path escapes package")
        if not path.is_file():
            failures.append({"path": entry["path"], "reason": "missing"})
            continue
        raw = path.read_bytes()
        if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            failures.append({"path": entry["path"], "reason": "size/hash mismatch"})
    result = {"status": "failed" if failures else "passed",
              "checked_files": len(manifest["files"]), "failures": failures}
    print(json.dumps(result, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(verify(Path(__file__).resolve().parent))
