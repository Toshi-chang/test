"""Development helper; freezes all dataset/analysis settings before evaluation."""
import bootstrap
import copy
from pathlib import Path
from bridge.adapter import read,write
ROOT=Path(__file__).resolve().parent

def make():
    template=read(ROOT/'physics/configs/box_surface.json')
    template['simulation'].update(sample_rate_hz=1024,duration_seconds=3,guard_seconds=.5)
    template['sources']=[]
    def s(id,kind,rms,geometry=None,**excitation):
        return {'id':id,'geometry':geometry or {'kind':'box_surface','size_m':[.12,.08,.06],'resolution':4},
            'strength_mode':'total_volume_velocity','drive_unit':'m^3/s','drive_rms':rms,
            'distribution':{'kind':'uniform'},'phase':{},'excitation':{'kind':kind,**excitation}}
    template['sources']=[s('shaft','order',6e-5,start_rpm=1350,end_rpm=1350,order=1),
        s('stationary','tone',3e-5,frequency_hz=100,phase_rad=0),
        s('usual1','event',1e-5,frequency_hz=300,center_seconds=.78,sigma_seconds=.045),
        s('usual2','event',1e-5,frequency_hz=300,center_seconds=2.16,sigma_seconds=.045),
        s('ambient','noise',5e-6,geometry={'kind':'point','center_m':[-.6,.2,.1]},band_hz=[20,420],seed_key=14)]
    additions={
        'band':[s('band_extra','tone',1.2e-4,geometry={'kind':'rectangle','size_m':[.04,.03],'center_m':[.06,0,.02],'resolution':4},frequency_hz=180,phase_rad=0)],
        'order':[s('order_extra','order',1.2e-4,geometry={'kind':'point','center_m':[.03,0,0]},start_rpm=1350,end_rpm=1350,order=3)],
        'event':[s('impact_extra','event',6e-5,geometry={'kind':'point','center_m':[.03,.02,0]},frequency_hz=320,center_seconds=1.53,sigma_seconds=.03)],
        'relation':[s('opposite_source','tone',8e-5,geometry={'kind':'point','center_m':[0,0,.4]},frequency_hz=100,phase_rad=0)],
        'disturbance':[s('external_extra','tone',8e-5,geometry={'kind':'point','center_m':[-.6,.2,.1]},frequency_hz=220,phase_rad=1.1)]}
    additions['mixed']=sum([copy.deepcopy(additions[k]) for k in ['band','order','event','relation']],[])
    dataset={'schema_version':'distributed-nv-dataset/1.0','seed':42,'train_families':8,'eval_families':1,
        'scenarios':['normal','disturbance','band','order','event','relation','mixed'],
        'modes':[{'name':'steady','start_rpm':1350,'end_rpm':1350},{'name':'ramp','start_rpm':1100,'end_rpm':1800}],
        'specimen_gain_range':[.9,1.1],'measurement_gain_range':[.97,1.03],
        'template_scene':template,'additions':additions,
        'truth_semantics':'injected source contribution, not a physically identified fault; relation is an opposite-side source',
        'normal_events':['usual1','usual2']}
    config=read(ROOT/'runtime/configs/acoustic_quick.json')
    config['physical_assumptions']={'generator':'distributed acoustic bridge 0.1.0','scene':'free-space distributed equivalent sources',
        'receiver_policy':'simultaneous receivers are measurements of the same specimen',
        'threshold_tuning':'frozen before first run; no evaluation-label tuning'}
    # Keep all scientific route/model/threshold parameters of acoustic_quick unchanged.
    target=ROOT/'configs';target.mkdir(exist_ok=True)
    write(target/'dataset_quick.json',dataset);write(target/'experiment.json',config)
    comparison=copy.deepcopy(dataset);comparison.update(train_families=20,eval_families=3)
    write(target/'dataset_comparison.json',comparison)
if __name__=='__main__':make()
