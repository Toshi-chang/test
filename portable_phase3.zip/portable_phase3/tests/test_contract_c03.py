import unittest
import numpy as np
from contract_fixtures import SPEC, record
from nv_runner.routes import FixedWindow, PreparedSet
from nv_runner.models import NormalModel

class C03(unittest.TestCase):
    def prepared(self):
        recipe=SPEC['prepared_recipe']; r=record()
        plugin=FixedWindow(recipe['route_config']); p=PreparedSet()
        for s in recipe['samples']:
            plugin.add(p,r,s['start'],s['end'],s['frequency'],s['features'],s.get('reason'))
        return plugin,p,r

    def test_ids_null_and_batch_order(self):
        plugin,p,r=self.prepared()
        self.assertEqual(len(p.samples),2); self.assertEqual(len(p.values),1)
        self.assertEqual(len(next(iter(p.values.values()))),len(plugin.feature_schema()))
        model=NormalModel().fit(np.arange(48).reshape(6,8),{'kind':'isolation_forest','n_estimators':16},42)
        before=plugin.score(model,p,1); p.samples.reverse(); after=plugin.score(model,p,7)
        self.assertEqual({s['sample_id']:s for s in before},{s['sample_id']:s for s in after})
        null=[s for s in before if s['anomaly_score'] is None]
        self.assertEqual(null[0]['reason'],'empty_selection')
        self.assertEqual(len({s['sample_id'] for s in before}),2)
        self.assertEqual({s['measurement_id'] for s in p.samples},{r.meta['measurement_id']})

    def test_nonfinite_features_and_untrained_model(self):
        plugin,p,r=self.prepared()
        plugin.add(p,r,1,3,[0,512],[np.nan]*8)
        self.assertEqual(p.samples[-1]['reason'],'non_finite_features')
        self.assertNotIn(p.samples[-1]['sample_id'],p.values)
        rows=plugin.score(None,p)
        self.assertTrue(all(s['anomaly_score'] is None for s in rows))
        self.assertEqual(rows[0]['reason'],'model_untrained')

    def test_invalid_score_is_not_normal(self):
        class InvalidScore:  # Boundary-test double only; never used by the real pipeline.
            def score(self,x): return np.full(len(x),np.nan)
        plugin,p,_=self.prepared(); rows=plugin.score(InvalidScore(),p)
        self.assertIsNone(rows[0]['anomaly_score'])
        self.assertIn('sample_processing_failed',rows[0]['reason'])
