param([ValidateSet('quick', 'comparison')][string]$Profile = 'quick', [ValidateSet('acoustic', 'legacy')][string]$Generator = 'acoustic')
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $pocPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $pocPython)) {
        throw 'Create .venv and install requirements.txt first; see README.md.'
    }
    & $pocPython -m nv_runner demo --profile $Profile --generator $Generator
    if ($LASTEXITCODE -ne 0) { throw "Demo failed: $LASTEXITCODE" }
    $summary = Get-Content -LiteralPath "reports/latest_${Generator}_$Profile.json" -Raw | ConvertFrom-Json
    Write-Output "Open in a browser: $($summary.viewer)"
} finally {
    Pop-Location
}
