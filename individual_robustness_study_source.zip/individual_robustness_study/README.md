# 正常個体差・分割・閾値安定性と外乱下の異常検出

既存の正常学習・個体分離を維持した追加検証です。共通基盤164ファイルをbaseline/に固定コピーし、変更しません。今回の結果から方式や閾値を選び直さず、すべての比較条件はprotocol.jsonで事前指定しました。

## 試験設計

1. 正常候補60群（family 0～59）を生成。生成seed42。既存の個体ゲイン±10%、測定ゲイン±3%、背景ノイズ、定常/回転変動を維持。**ばらつきの分布幅は拡大していません。** 60群で実機個体差を網羅したという意味ではありません。
2. 分割seed201/202/203で候補群を並べ替え。各回の先頭16/32群をfit、32番目以降4/8群を閾値設定に使う。fit16/cal4、fit16/cal8、fit32/cal8の9構成。
3. fit16/cal4対fit16/cal8はfitとモデルを同一にしてcalだけ追加。fit16/cal8対fit32/cal8はcalを同一にしてfitだけ追加。3回は同じ候補プールを共有するので独立反復や信頼区間としない。
4. 未使用の評価6群（200000～200005）を生成。正常と5種類の異常band/order/event/relation/mixed。全9構成を外乱なしの同じ36条件で評価。
5. 外乱下の評価構成は事前にs201_fit32_cal8へ固定。3周波数100/220/350 Hz×3位置original/front/side×3音圧20/40/60 dB。前回マップと一致する27条件の**部分比較**。全12音圧の再実行ではない。
6. 追加外乱なしを含め6群×6対象状態×28条件=1008条件、5経路=5040行。正常・異常は同じ正常基底と同じ外乱を共有し、対象異常の追加成分だけが異なる。

正常学習のみ。モデルseed42、StandardScalerはfitのみ、IF64/PCA4、max集約、calの95%分位点(higher)は既存のままです。cal4/cal8ではこの分位点がいずれも最大値になるため、cal数増加の影響はその前提で解釈してください。モデル・閾値は評価前に確定し、評価中は学習しません。

## 指標

- 正常判定率＝within/正常全数。異常検出率＝outside/異常全数。
- 判定不可は別計上し、分母から除外せず成功にも数えない。
- 対比較の両方正解＝同じ群・同じ外乱で、正常withinかつ対象異常outside。
- 異常outsideでも正常もoutsideなら、外乱に反応しただけの可能性があり、対象異常の識別成功とは扱わない。
- 各セル正常6群、異常5種類×6群=30条件。30独立個体ではない。生スコアの経路間平均はしない。

## 再実行

Windows/Python 3.12（今回3.12.14）。このディレクトリだけを移植し、ここを作業ディレクトリにします。

```powershell
py -3.12 -m venv .venv
.venv/Scripts/python.exe -m pip install -r baseline/requirements.txt
.venv/Scripts/python.exe -B -m unittest discover -s . -p test_study.py -v
.venv/Scripts/python.exe -B run_study.py --output outputs/comparison_v1
.venv/Scripts/python.exe -B register_pool.py outputs/comparison_v1
.venv/Scripts/python.exe -B tools/verify_results.py
```

過去データ・モデル・別プロジェクトは不要です。出力先は新規フォルダに限定。中断後の自動再開は未対応で、新しい出力先で再実行します。status.json/error.log/progress.jsonと完了ケースのcomplete.jsonを残すため、実行済み範囲は確認できます。モデルと入力を個別に回収できる構成ですが、手作業の再開を未検証のまま成功扱いしないでください。

tools/verify_results.pyは既定のoutputs/comparison_v1を対象に、件数・分離・モデル不変・対応する正常/異常間の差分・順序/バッチ変更を検証してreportsを作ります。出力名を変えた場合はこの監査スクリプトの対象指定も合わせてください。experiment.jsonは旧Runner設定に由来する計算条件のスナップショットであり、そこに残る旧Runner用の入出力パスは本実験では使用しません。実際の入力・分割はpool/、cases/、splits.jsonで管理します。

## 保存・閲覧

- index.html：9構成の比較、外乱下の正常/異常/両方正解。各セルから個体別の波形・最大入力・特徴量偏差へ移動。
- splits.json：分割の全個体ID。models/：各構成の実モデル、閾値、cal個体スコア、fit入力ID。
- pool/：学習候補の観測波形・標準入力・取得メタデータ・元生成条件。pool_attestation.json：正常のみの生成経路の証跡。
- register_pool.pyは正常生成の証跡を再確認し、pool/train_manifest.jsonとして正常学習用の標準登録を出力します。個別ケースのmanifestは汎用読込用、学習役割の正本はpool_attestationと集約train_manifestです。登録時に信号・モデル・判定は変更しません。
- cases/：全評価条件の元波形、取得情報、Adapter変換後入力、由来ハッシュ、全入力スコア・ID、特徴量、選択/計算座標、上位入力。generation.jsonは生成・真値の記録で、モデル入力には含めない。
- stability_rows/summary.json：9構成の比較。map_rows/summary.json：事前選択構成の外乱下比較。元データは0始まり半開sample区間、秒・Hz・センサー位置と対応。
- 黄色表示は入力の切出し区間であり、異常注入の正解区間ではない。B/Cのフィルタ支持範囲はsupport_start/end_sampleで別保持。特徴量zは学習分布からの偏差で、因果やモデル寄与度ではない。

今回の成果物は実験専用JSON/NPZ/HTMLです。ResultBundle 1.0を名乗らず、既存Bundle仕様を変更しません。既存Pluginのprepare/fit/score/aggregate/calibrate/decideを使います。候補プールから切り出したPreparedSetと、fit個体だけを独立prepareした結果のID・全特徴量一致を検証します。

## 残る範囲

実機特有の共振、位置ずれ、校正差、温度、個体構造差等は今回追加していません。relationは反対側の追加音源による関係変化で、実故障を実証していません。測定時間・受音点数を変えるmax集約の影響、外乱を含む正常学習、実測検証は未実施です。最終採用には別の未使用個体・外乱条件が必要です。

この試験は前回とは評価個体・学習集合が異なります。前回の率との差を、そのまま学習個体数増加の効果と解釈しないでください。効果は今回の共通評価群に対する9構成の比較で調べます。
