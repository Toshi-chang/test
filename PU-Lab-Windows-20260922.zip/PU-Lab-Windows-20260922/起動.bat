@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run the setup BAT file first.
  pause
  exit /b 1
)
echo Keep this window open while using PU Lab. Press Ctrl+C to stop.
".venv\Scripts\python.exe" -X utf8 -u "pu_lab\app.py" %*
set "LAB_EXIT=%errorlevel%"
if not "%LAB_EXIT%"=="0" pause
exit /b %LAB_EXIT%
