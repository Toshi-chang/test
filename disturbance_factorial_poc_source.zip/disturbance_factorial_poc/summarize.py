"""Deduplicate control conditions; paired transitions, not misleading accuracy gains."""
import html,collections
from bridge.adapter import write
ANOMALIES=['band','order','event','relation','mixed']

def summarize(clean,disturbed,out):
    routes=sorted({r['route'] for r in clean['cases']});stats={};pairs=[]
    c={(r['route'],r['family'],r['scenario']):r for r in clean['cases']}
    d={(r['route'],r['family'],r['scenario']):r for r in disturbed['cases']}
    families=sorted({r['family'] for r in clean['cases']})
    for route in routes:
        normal=[c[route,f,'normal'] for f in families];noise=[c[route,f,'disturbance'] for f in families]
        abnormal=[c[route,f,k] for f in families for k in ANOMALIES]
        combined=[d[route,f,k+'_with_disturbance'] for f in families for k in ANOMALIES]
        def counts(rows):return {'n':len(rows),**{key:sum(r['decision']==key for r in rows) for key in ['outside','within','undetermined']}}
        stats[route]={'normal_clean':counts(normal),'normal_disturbed':counts(noise),'abnormal_clean':counts(abnormal),'abnormal_disturbed':counts(combined)}
        for f in families:
            for k in ANOMALIES:
                a=c[route,f,k];b=d[route,f,k+'_with_disturbance'];n=c[route,f,'disturbance']
                pairs.append({'route':route,'family':f,'anomaly':k,'without_disturbance':a['decision'],'with_disturbance':b['decision'],
                    'normal_with_disturbance':n['decision'],'case_score_without':a['score'],'case_score_with':b['score'],
                    'score_change':b['score']-a['score'] if a['score'] is not None and b['score'] is not None else None,
                    'combined_minus_normal_disturbed':b['score']-n['score'] if b['score'] is not None and n['score'] is not None else None,
                    'threshold':a['threshold']})
    report={'schema_version':'disturbance-factorial/1.0','independent_families':len(families),
            'unique_eval_variants':len(families)*12,'reused_controls':'normal and disturbance-only are counted once, not once per anomaly',
            'routes':stats,'paired_transitions':pairs,'scope':'fixed synthetic conditions; exploratory evaluation, not field performance'}
    write(out/'factorial_results.json',report)
    lines=['# 異常×外乱：固定条件の対比較','',f'独立正常実現{len(families)}群、重複対照を除く評価{12*len(families)}シナリオ個体。受音点は個体数に数えない。',
        '', '|経路|正常・外乱なし FP/n|正常・外乱あり FP/n|異常・外乱なし TP/n|異常・外乱あり TP/n|','|---|---:|---:|---:|---:|']
    html_rows=[]
    for route,s in stats.items():
        values=[f'{s[key]["outside"]}/{s[key]["n"]}' for key in ['normal_clean','normal_disturbed','abnormal_clean','abnormal_disturbed']]
        lines.append('|'+route+'|'+'|'.join(values)+'|')
        html_rows.append('<tr><th>'+route+'</th>'+''.join('<td>'+v+'</td>' for v in values)+'</tr>')
    lines+=['','判定不可はfactorial_results.jsonの各セルに別保存。FP/TPの母数に判定不可も含める。',
        '**外乱のみでoutsideになる場合、異常＋外乱でoutsideとなっても対象異常を識別できた証拠にはならない。**',
        '', '## 外乱追加による判定遷移','', '|経路|within→outside|outside→within|判定不可が関係する比較|','|---|---:|---:|---:|']
    for route in routes:
        pp=[p for p in pairs if p['route']==route]
        lines.append(f'|{route}|{sum(p["without_disturbance"]=="within" and p["with_disturbance"]=="outside" for p in pp)}|{sum(p["without_disturbance"]=="outside" and p["with_disturbance"]=="within" for p in pp)}|{sum("undetermined" in (p["without_disturbance"],p["with_disturbance"]) for p in pp)}|')
    lines+=['','## 異常種類別の範囲外判定','', '|経路|対象異常|外乱なし outside/n|外乱あり outside/n|','|---|---|---:|---:|']
    for route in routes:
        for kind in ANOMALIES:
            pp=[p for p in pairs if p['route']==route and p['anomaly']==kind]
            lines.append(f'|{route}|{kind}|{sum(p["without_disturbance"]=="outside" for p in pp)}/{len(pp)}|{sum(p["with_disturbance"]=="outside" for p in pp)}/{len(pp)}|')
    lines+=['','## 外乱なし正常の誤判定：最大スコアを作った入力','',
            '特徴量zはfit全入力に対する偏差であり、Isolation Forestの寄与度・因果説明ではない。時間・周波数の範囲は計算入力の範囲。']
    for r in clean['cases']:
        if r['scenario']=='normal' and r['decision']=='outside' and r['top_inputs']:
            t=r['top_inputs'][0];feat=', '.join(f'{f["feature"]}: z={f["z"]:.3g}' for f in t['feature_deviations'][:3])
            lines+=['',f'- {r["route"]} / {r["family"]}: score={r["score"]:.6g}, threshold={r["threshold"]:.6g}。',
                    f'  最大入力：{t["measurement_id"]}、受音点{t["receiver"]}、{t["mode"]}、{t["time_seconds"]}秒、{t["frequency_hz"]}Hz。',
                    f'  偏差上位：{feat}。通常イベントとの区間重なり：{t["normal_event_overlap"]}。']
    lines+=['','## 判定根拠と制約','',
        '- clean/evidence.json、disturbed/evidence.json：各ケースの上位3入力、sample ID、座標、時間、周波数、特徴量偏差。',
        '- 受音点別max、閾値超過入力数、受音点を一つ除いたmaxも保存。後者は同じ閾値の診断であり、新方式の性能ではない。',
        '- p/Uの正常・対象成分は対比較で完全一致、外乱追加差分は外乱寄与と一致することをpairing.jsonで検証。',
        '- 既存Runnerに固定モデル推論CLIがないため同一正常データで決定論的に再学習し、全モデル・閾値ファイルのSHA一致を必須とした。',
        '- 外乱学習、特徴追加、受音点集約変更、閾値調整は行っていない。今回の結果を使って改良する場合、次の独立評価条件を別途確保する。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    body='''<!doctype html><html lang="ja"><meta charset="utf-8"><title>異常×外乱 対比較</title>
    <style>body{font:17px sans-serif;max-width:1100px;margin:40px auto;color:#163047;background:#f3f6f8}section{background:white;padding:24px;margin:20px 0}table{width:100%;border-collapse:collapse}td,th{padding:13px;border-bottom:1px solid #ccd}pre{white-space:pre-wrap;font-size:14px}</style>
    <h1>対象異常 × 外乱：同じモデル・閾値で比較</h1><section><table><tr><th>経路</th><th>正常/外乱なし<br>誤判定</th><th>正常/外乱あり<br>誤判定</th><th>異常/外乱なし<br>範囲外</th><th>異常/外乱あり<br>範囲外</th></tr>'''+''.join(html_rows)+'''</table>
    <p>外乱のみでも範囲外になる場合、異常＋外乱で範囲外となっても対象異常を識別したとは言えません。</p></section>
    <section><a href="clean/viewer.html">外乱追加前のBundleを見る</a> ／ <a href="disturbed/viewer.html">外乱追加後のBundleを見る</a></section>
    <section><pre>'''+html.escape('\n'.join(lines))+'''</pre></section></html>'''
    (out/'index.html').write_text(body,encoding='utf-8')
    return report
