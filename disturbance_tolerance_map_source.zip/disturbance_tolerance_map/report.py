import html,json
import numpy as np
from bridge.adapter import write

def counts(rows):
    if len({r['family'] for r in rows})!=len(rows):raise ValueError('duplicate family in cell')
    return {'n':len(rows),**{k:sum(r['decision']==k for r in rows) for k in ['within','outside','undetermined']}}

STYLE='<style>body{font:15px sans-serif;max-width:1200px;margin:32px auto;background:#edf3f6;color:#173448}section{background:white;padding:20px;margin:20px 0}table{border-collapse:collapse;width:100%;margin:12px 0}td,th{padding:8px;border:1px solid #ccd}td a{display:block;color:inherit}svg{width:100%}pre{white-space:pre-wrap}details{margin:12px 0}small{color:#567}</style>'

def case_page(rows,records,dest):
    rec={r.meta['measurement_id']:r for r in records};parts=[]
    for row in rows:
        body=f'<h2>{row["route_key"]}: {row["decision"]}</h2><p>score={row["case_score"]} / threshold={row["threshold"]}; coverage={row["coverage_status"]}; reason={html.escape(str(row["reason"]))}</p>'
        if row['top_inputs']:
            top=row['top_inputs'][0];s=top['sample'];r=rec[s['measurement_id']];x=r.signals;fs=r.meta['timebase']['sample_rate_hz'];n=len(x)
            body+=f'<p>最大スコア入力：{s["measurement_id"]} / {s["start_sample"]/fs:.3f}–{s["end_sample"]/fs:.3f}秒 / 周波数範囲 {s["frequency_hz"]} Hz</p>'
            for ch,unit in [(0,'p [Pa]'),(1,'u [m/s]')]:
                a=x[:,ch];scale=max(float(np.max(abs(a))),1e-30);ix=np.linspace(0,n-1,min(n,1000),dtype=int)
                pts=' '.join(f'{40+900*i/n:.2f},{75-55*a[i]/scale:.2f}' for i in ix)
                body+=f'<p>{unit} 波形表示（最大絶対値 {scale:.5g}、表示は間引き、計算は全サンプル）</p><svg viewBox="0 0 980 150"><rect x="{40+900*s["start_sample"]/n}" y="10" width="{900*(s["end_sample"]-s["start_sample"])/n}" height="125" fill="#ffdf99"/><polyline points="{pts}" fill="none" stroke="#126b85" stroke-width="1"/></svg>'
            body+='<p>黄色：モデルが最大スコアを出した入力の切出し時間。生成器の正解：対象は正常、追加外乱は全記録の連続単音。黄色は異常の正解領域ではありません。</p>'
        body+='<p>特徴量のfit_zは学習分布からの偏差で、モデル寄与度や因果関係ではありません。</p><details><summary>上位入力・特徴量・元座標</summary><pre>'+html.escape(json.dumps(row['top_inputs'],ensure_ascii=False,indent=2))+'</pre></details>'
        body+=f'<a href="{row["route_key"]}_samples.json">全入力ID・スコア・被覆情報</a>';parts.append('<section>'+body+'</section>')
    (dest/'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8">'+STYLE+'<a href="../../index.html">耐性マップへ</a><h1>'+html.escape(dest.name)+'</h1>'+''.join(parts),encoding='utf-8')

def render(rows,protocol,out):
    keys=sorted({r['route_key'] for r in rows});sections=[];cells=[];bounds=[]
    for key in keys:
        rr=[r for r in rows if r['route_key']==key];base=[r for r in rr if r['db_spl'] is None];bc=counts(base)
        sections.append(f'<section><h2>{key}</h2><p>追加外乱なし：正常 {bc["within"]}/{bc["n"]}、誤判定 {bc["outside"]}、判定不可 {bc["undetermined"]}</p>')
        for direction in protocol['positions_m']:
            sections.append(f'<h3>音源位置：{direction}</h3><table><tr><th>dB SPL ↓ / Hz →</th>'+''.join(f'<th>{f}</th>' for f in protocol['frequencies_hz'])+'</tr>')
            for level in protocol['levels_db_spl']:
                sections.append(f'<tr><th>{level}</th>')
                for freq in protocol['frequencies_hz']:
                    rs=[r for r in rr if r['direction']==direction and r['frequency_hz']==freq and r['db_spl']==level];c=counts(rs)
                    old=counts([r for r in rs if r['family']<=100002]);new=counts([r for r in rs if r['family']>100002]);cid=f'{key}_{direction}_{freq}_{level}'
                    cells.append(dict(route=key,direction=direction,frequency_hz=freq,db_spl=level,**c,previous_families=old,new_families=new))
                    color=f'hsl({120*c["within"]/max(1,c["n"]):.1f},45%,82%)'
                    sections.append(f'<td style="background:{color}"><details><summary>{c["within"]}/{c["n"]}</summary><small>旧群 {old["within"]}/{old["n"]}・新群 {new["within"]}/{new["n"]}<br>判定不可 {c["undetermined"]}</small>'+''.join(f'<a href="{r["detail"]}">{r["family"]}: {r["decision"]}</a>' for r in rs)+'</details></td>')
                sections.append('</tr>')
            sections.append('</table>')
            for freq in protocol['frequencies_hz']:
                cs=[c for c in cells if c['route']==key and c['direction']==direction and c['frequency_hz']==freq];last=None;first=None
                if bc['within']==bc['n']:
                    for c in cs:
                        if c['within']!=c['n']:first=c['db_spl'];break
                        last=c['db_spl']
                bounds.append({'route':key,'direction':direction,'frequency_hz':freq,'baseline_all_within':bc['within']==bc['n'],'last_consecutive_tested_db':last,'first_failure_tested_db':first})
        sections.append('</section>')
    write(out/'results.json',rows);write(out/'cells.json',cells);write(out/'bounds.json',bounds)
    intro='<h1>外乱耐性マップ：周波数 × 音圧 × 音源位置</h1><p>セル＝正常判定数 / 評価群数。クリックで個体ごとの判定根拠を表示。モデル・閾値は全条件で固定。</p><p>外乱単独の正面受音点RMS、基準20 µPa・無補正。単音・自由空間モデル。旧3群＋追加3群を分けて表示し、周波数や受音点を独立個体として数えません。未完了の場合は分母が6未満です。</p>'
    (out/'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8">'+STYLE+intro+''.join(sections),encoding='utf-8')
    lines=['# 外乱耐性マップ結果','', '正常対象のみ。改善・異常検出力の再評価は次段階。周波数100/220/350 Hz、3位置、12音圧、6正常群。旧3群は継続比較、新3群は追加評価。学習正常20群（fit16/cal4）は固定。','', '|経路|外乱なし 正常/群数|誤判定|判定不可|','|---|---:|---:|---:|']
    for key in keys:
        c=counts([r for r in rows if r['route_key']==key and r['db_spl'] is None]);lines.append(f'|{key}|{c["within"]}/{c["n"]}|{c["outside"]}|{c["undetermined"]}|')
    lines+=['','|経路|音源位置|Hz|外乱なし全群正常|連続正常の最終試験点 dB|最初の失敗試験点 dB|','|---|---|---:|---|---|---|']
    for b in bounds:lines.append('|'+ '|'.join(str(b[k]) for k in ['route','direction','frequency_hz','baseline_all_within','last_consecutive_tested_db','first_failure_tested_db'])+'|')
    lines+=['','## 制約・解釈','', '- Noneは許容音圧0 dBという意味ではない。外乱なしで成立しない経路には上限を定義しない。最初の試験点5 dBで崩れた場合、0–5 dBを補間しない。', '- 全群正常という厳しい指標のほか、セルで正常・誤判定・判定不可、旧群・追加群を保存。6群で一般母集団の限界は保証できない。', '- 同じ正面音圧でも他受音点の音圧とu方向は変わる。距離を正面受音点から揃えた3位置であり、平面波の方向だけを変えた試験ではない。', '- 周波数・位置・phase=1.1固定の条件網羅で、位相や広帯域外乱の頑健性は未検証。', '- A全領域の外乱なし誤判定は各baselineケースの最大入力・特徴量偏差から調べる。偏差は因果説明ではない。', '- 専用実験Adapterは固定モデルを読み、既存Pluginのprepare/score/aggregate/decideを呼ぶ。既存Runner全105評価との一致をcompatibility.jsonに記録。元の共通基盤は変更しない。', '- training_runsはResultBundle 1.0。掃引結果は別形式でありBundle 1.0と偽らない。cases内の全入力ID・スコア・特徴量・選択マスク・元波形・取得ハッシュで追跡可能。', '- 改善候補の学習や閾値調整はしていない。次は弱点の説明を確認し、別評価条件で異常＋外乱の見逃しを含めて改善を比較する。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
