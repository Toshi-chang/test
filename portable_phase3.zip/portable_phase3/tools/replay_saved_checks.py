"""Replay prior ad-hoc saved-result/relocation checks on a newly generated demo."""
import argparse
import json
from pathlib import Path, PureWindowsPath
import shutil
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from nv_runner.bundle import BundleReader, EvaluationAdapter
from nv_runner.common import read_json, write_json, sha
from nv_runner.runner import ExperimentRunner, validate_config


def check(example, output):
    example, output = Path(example).resolve(), Path(output).resolve()
    if output.exists():
        raise ValueError("Use a fresh output directory; existing evidence is never overwritten")
    summary = read_json(example / "summary.json")
    original = Path(summary["bundle"])
    reader = BundleReader(original).validate()
    if reader.manifest["bundle_status"] != "complete":
        raise AssertionError("Expected a successful demo before relocation testing")
    output.mkdir(parents=True)
    report = {"schema_version": "1.0", "status": "running", "source_bundle": str(original),
              "script_sha256": sha(Path(__file__)), "runtime_root": str(PROJECT)}
    write_json(output / "report.json", report)
    try:
        shutil.copytree(example / "data", output / "data")
        moved = output / "saved_bundle"
        shutil.copytree(original, moved)
        relocated = BundleReader(moved).validate()
        mapping = {m["source_path"]: str(output / "data" / PureWindowsPath(m["source_path"]).name)
                   for m in relocated.tables["measurements"]}
        for m in relocated.tables["measurements"]:
            if sha(Path(mapping[m["source_path"]])) != m["source_sha256"]:
                raise AssertionError("Relocated source hash mismatch")
        write_json(output / "path_mapping.json", mapping)
        receipt = EvaluationAdapter().import_bundle(moved, output / "inbox", mapping)
        if receipt["unresolved_sources"]:
            raise AssertionError("Unresolved relocated source")
        report["source_count"] = len(mapping)
        report["receipt"] = receipt
        command = [sys.executable, "-m", "nv_runner", "view", "--bundle", str(moved),
                   "--output", str(output / "reopened.html")]
        result = subprocess.run(command, cwd=PROJECT, capture_output=True, text=True, encoding="utf-8", errors="replace")
        (output / "viewer_process.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise AssertionError("Separate viewer process failed")
        report["viewer_process"] = "passed"
        config = read_json(example / "experiment.json")
        for key in ("train_manifest", "eval_manifest", "truth_path"):
            if config.get(key):
                config[key] = str(output / "data" / Path(config[key]).name)
        config["export"]["output_dir"] = str(output / "reruns")
        write_json(output / "experiment.json", config)
        validate_config(output / "experiment.json")
        rerun = ExperimentRunner().execute(output / "experiment.json")
        rerun_reader = BundleReader(rerun).validate()
        if rerun_reader.manifest["completed_routes"] != reader.manifest["completed_routes"]:
            raise AssertionError("Completed routes changed")
        if read_json(rerun / "metrics.json")["routes"] != read_json(original / "metrics.json")["routes"]:
            raise AssertionError("Route metrics differ within the same environment")
        report["route_metrics_match"] = True
        report["rerun_bundle"] = str(rerun)
        # This is same-environment determinism, not cross-platform binary equivalence.
        report["model_threshold_hashes"] = {}
        for route in reader.manifest["completed_routes"]:
            for suffix in (".joblib", "_threshold.json"):
                name = route + suffix
                if sha(original / "models" / name) != sha(rerun / "models" / name):
                    raise AssertionError("Model/threshold changed: " + name)
                report["model_threshold_hashes"][name] = sha(rerun / "models" / name)
        report["status"] = "passed"
    except Exception as error:
        report.update(status="failed", error=repr(error))
        raise
    finally:
        write_json(output / "report.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--example", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = check(args.example, args.output)
    print(json.dumps({"status": result["status"], "source_count": result["source_count"]}))
