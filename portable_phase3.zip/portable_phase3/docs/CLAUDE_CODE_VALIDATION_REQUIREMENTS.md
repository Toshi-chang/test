# Claude Code向け：NV Route Runner 検証再実行要件書

版1.0 / 作成2026-10-12 / 対象：独立PoC nv_route_runner_poc、現行ソフトウェア0.2.0

## 0. 実行者への指示と範囲

01_runtimeのソースと本書だけを移送し、過去のデータ・モデル・Bundle・viewer・ログは取得できない前提で実行する。過去結果を生成し直したように装わず、新しい環境の再試験として記録する。既存試験の合格値を変更して通さない。失敗は入力、環境、実装のどこで発生したかを残す。実データ、認証情報、外部システムは既存再試験に不要。

本書の**実施済み**は旧環境で実行記録または保存Bundleを確認できた範囲、**未実施**は提案のみ、**不明**は証跡から条件・実施を確認できないものを意味する。新環境では全項目を未実行から開始し、新たな合否を別欄で記録する。合成検出性能を実機性能や外乱分離性能と解釈しない。

共通条件を§1のIDで定義し、各検証から参照する。これは各検証の入力・分割・学習・閾値・保存条件の一部である。記載のない数値を推測で補完しない。新規提案は§8に隔離した。

### 根拠と限界

- 現行コード：nv_runner/*.py、viewer.html、profiles.py、configs/*.json。
- 実行可能な根拠：tests/test_acceptance.pyの17試験、tests/test_acoustics.pyの15試験、nv_runner/verify_physics.py、tests/viewer_smoke.cjs。
- 旧環境で確認した記録：reports/acceptance_tests.txt（17件成功）、reports/acoustic_regression_tests.txt（32件成功、40.005秒）、reports/acoustic/physical_validation.json（passed=true）、同quick/comparison_viewer_test.json、examples/*/summary.jsonと各Bundle。
- 過去の一時コマンド：移植用コピーの再実行・ハッシュ・参照解決はtransfer_20261012/TRANSFER_VALIDATION.jsonで成功確認。厳密な当時の単独スクリプトは存在しないため§7と付録の追加スクリプトで再構成した。今回、新規生成quickから実行して成功を確認した。
- 上記大容量証跡は移送しない。本書の過去の数値は照合用の転記であり、移送先での独立した原本検証はできない。
- 過去OSはWindows、Python 3.12.14。CPU型番、メモリ、過去のNode/Playwright/Edgeの厳密な版は本書作成時に確認しておらず**不明**。別OSでの実行は**未実施**。
- 旧0.1の完全ソースは移送対象にない。legacy再実行も現行0.2による再試験であり、旧結果のビット単位一致は要求しない。

## 1. 全検証に適用する条件

### ENV：依存環境

Python 3.12・64bitを起点に、requirements.txtを使用する：numpy 2.3.5、scipy 1.16.3、scikit-learn 1.7.2、joblib 1.6.0、threadpoolctl 3.7.0、cloudpickle 3.1.2。CPU実行、GPU不要。NormalModelはthreadpool_limits=1、IF n_jobs=1。実際に導入された版をpip freezeへ保存する。

ブラウザー試験だけNode.js、Playwright、ブラウザーが必要。過去はインストール済みEdgeで実行。新環境の版は記録し、同一版であると推測しない。HTML閲覧自体はPython・サーバー・外部CDN不要。

### DATA-A：物理生成データ（acoustic）

対象：acoustic_generator.acoustic_settings / sources_for / generate_acoustic、acoustics.synthesize / drive_spectrum / rotation_trace / measured_rpm。既定seed=42、fs=1024 Hz、各個体2測定（定常、回転数変化）。quickは正常学習12、評価7、4秒。comparisonは正常学習40、評価28、6秒。

ρ=1.2 kg/m³、c=343 m/s。受音点[0.05,0,0] m、速度軸[1,0,0]。exp(+jωt)、U=−∇P/(jωρ)、記録u=軸との内積。単極子対象音＋平面波背景。p/uを別々に再正規化しない。

|正常音源|場|駆動RMS・条件|
|---|---|---|
|shaft_order_1 / 3|原点の単極子|6e−5 / 3e−5 m³/s、1次/3次|
|stationary_target|単極子|2e−5 m³/s、100 Hz、位相0|
|usual_events|単極子|4e−5 m³/s、300 Hz、中心0.26/0.72×測定長、Gaussian σ=0.045秒|
|ambient|平面波、方向[−0.6,0.8,0]|0.003 Pa、15〜430 Hzの雑音|

正常音源ごとに個体倍率±10%、測定倍率±3%（一様）。定常1350 rpm、ramp1100→1800 rpm、共通倍率±2.5%、ripple比0.005・2 Hz。明示位相がない音源はseed由来の位相。ガード0.5秒、HP5 Hz、遷移5 Hz、LP0.44fs、DC/Nyquistを除外する。

追加音源：band=180 Hz単極子1.5e−4 m³/s、order=3次単極子1.4e−4、event=300 Hz単極子2.5e−4・中心0.51・σ0.03秒、relation=逆向き平面波100 Hz・0.12 Pa、disturbance=方向[−0.6,0.8,0]の平面波220 Hz・0.06 Pa。band/order/relation/disturbanceのgateは0.4〜0.62×測定長、立上り/下り0.02秒。mixedはband/order/event/relationの4成分。normalとdisturbanceの正解は正常、他5種類は異常。

評価は同じ正常実現を7シナリオで共有する対比較。quickは独立ベース1群、comparisonは4群であり、28独立実現ではない。train family=i、eval family=100000+j。測定seedはSeedSequence([42,family,repeat]).generate_state(1)[0]、音源seedはさらに[測定seed,seed_key]。個体/測定振幅はsources_for内の[42,family,seed_key,1] / [42,family,seed_key,repeat,2]。センサー残留gain/phase/delay/noiseは既定0、rpm_sensor.enabled=False。観測NPZはwaveformとshaft_rpmのみ。真値はtruth.jsonとtruth_arraysへ隔離する。

### DATA-L：旧簡易生成データ（legacy）

対象：synthetic.generate、profiles.settings。数・長さ・fs・全体seedは同名profileのDATA-Aと同じ。個体ごとのrng=default_rng(SeedSequence([42,count]))、derived_group_id=specimen_id。評価の正常実現はacousticのような対比較を実装していない。

正常pは1次0.32 Pa、3次0.11 Pa、95〜105 Hz一様の固定周波数0.14 Pa。個体gain0.9〜1.1、測定gain0.97〜1.03、p/u位相差0.03〜0.13 rad、u倍率1/410。独立雑音σp=0.016、σu=0.016/410。定常rpm1300〜1400、ramp1100→1800。通常イベント300 Hz、振幅0.55〜0.65 Pa、σ0.045秒、中心0.26/0.72×長さに±0.08秒jitter。

異常区間0.4〜0.62×長さ、band180 Hz/1.1 Pa、order3次/1.0 Pa、event300 Hz/2.5 Pa/中心0.51/σ0.03秒、relationは区間内uを−2倍、disturbanceはpだけへ220 Hz/0.5 Pa/位相1.1。mixedは4異常。**この生成器のp/uは物理音場の実証には使わない。**

### SPLIT：分割・正解隔離

InputAdapter.loadでNPZ/JSONのハッシュ、schema1.0、p[Pa]/u[m/s]、共置・単位方向、時間軸を検証。DatasetPlanner.planでtrain/evalの個体・case・元ハッシュ・派生元重複を拒否。train内の個体/元ハッシュ/派生元を連結した群をseed42でshuffle、cal群数=max(2,ceil(群数×0.2))、fit最低3群。足りなければ全trainをfit、calibration_unavailable。

標準quickはfit9/cal3、comparisonは32/8。学習は正常のみ、正解ラベルや音源成分は学習・入力選択へ渡さない。IDは対応づけに使うが特徴量ではない。具体的なID配列は実行したdataset_split.jsonを保存する。

### PROC/MODEL：前処理・経路・モデル・閾値

SignalService.maps：Hann128、hop32、MSCは5frame平均、平均支持不足の端frameを無効化。acousticはmean_square_bin_v2で、bin量=g|FFT(wp)|²/(NΣw²)、gは内部2/DC・Nyquist1。相互量はP conj(U)、実部active/虚部reactive。相対power floor=1e−8、絶対floor p=1e−24/u=1e−30。legacyのSTFTはFFT/Hann.sumの非2倍補正二乗。basic_featuresとBのpowerは現行コードではmean_square_spectrumを使用し、旧0.1と異なり得る。

|経路|入力・特徴・前処理|学習|
|---|---|---|
|A_full|1秒窓、hop0.5秒。p/u RMS、p crest、p-u相関、pの0–80/80–150/150–240/240–Nyquistのbin power和|IF|
|A_selected|同じ窓。支持範囲が窓内のframeを選択。選択p/u power平均、MSC、符号付きactive intensity、cos/sin位相、占有率|IF|
|B_order|10回転窓、hop5回転、64点/回転。rpm台形積分、4次ゼロ位相LP、線形角度補間。1〜8次±0.15のp/u power、RMS、相関|IF|
|C_event|pの4次ゼロ位相HP250 Hz→20 ms RMS→閾値超え。最短20 ms、gap40 ms結合、前後60 ms。元信号basic_features＋core長|IF|
|D_patch|STFT8frame×16bin×2ch、hop4frame/8bin。log10(power)、floor p1e−12/u1e−18、flatten|PCA|

acoustic A_selected条件はMSC≥0.65 AND f≥10 Hz AND (active>1e−10 OR reactive>1e−10)。legacyはMSC≥0.65 AND active>1e−9 AND (f≤140 OR f≥160)。C検出閾値はacoustic0.025 Pa、legacy0.10 Pa。Bではrpm>0、変化上限既定20000 rpm/s、Nyquist確認、LP cutoff=min(0.45fs,0.45×64×最低rpm/60)。不良区間を跨がない。

NormalModel.fitで**fitだけ**からStandardScalerをfit、IFは64本・random_state42・n_jobs1（他パラメータは固定依存版sklearnの既定）。PCAはfull SVD、成分数=max(1,min(4,n_fit−1,n_features−1))。最小入力数IF3/PCA5。パッチごとの振幅正規化なし。IF score=−score_samples、PCA score=標準化空間の平均再構成二乗誤差。sample_id順でfit/score、batch128。テストfixtureで本数等を変える場合は各条件に記載。

RoutePlugin.aggregateのcase_scoreは有効入力最大。coverage sufficientは有効入力あり・全生成入力を採点済み・測定にincompleteなしで決まる（全時間を必ず評価したという意味ではない）。十分なcal caseの最大スコア群から95%分位点method=higher、最低2個体。score>thresholdでoutside、同値以下はcoverage sufficientのときwithin。閾値不足やスコアなしはundetermined。誤判定率保証なし。1個体複数caseでは1つoutsideなら個体outside、全withinならwithin、他undetermined。fixtureは1個体1case、各2測定。fusionは既定無効。生スコアを経路間で単純平均しない。

### SAVE：保存物・評価指標・合否の扱い

demoは生成NPZ、metadata、train/eval manifests、generation.json、truthと音源別真値、experiment.json、runs/run_ID、evaluation_inboxとreceipt、summary.json、viewer.htmlを保存する。Bundleにはmodels/*.joblib（Scalerを含む）、*_threshold.json、特徴/波形/座標/選択mask等のNPZ、JSONL台帳、dataset_split.json、environment.json、metrics.json、errors、manifestとSHA256を保存する。詳細はBundleReaderの必須項目が正。途中.stagingは結果としない。

モデルを使わない数理試験・真理値試験にはモデル/閾値/分割は**非該当**。配列がメモリ内だけの試験では全中間配列は保存されない。unittestのstdout/stderrログを必ず保存し、失敗時は該当入力を追加保存して診断する。fixtureを使う試験の生成物はtests/_work/<UUID>、物理pipelineは同/acoustic_<UUID>に残る。終了後に削除する前に必要な証跡を保管する。

指標は個体単位TP/FP/FN/TN、正常/異常それぞれのundetermined、unlabelled、coverageとexecution状態。正常母数には外乱のみを含める。TP+FN+異常undetermined=異常数、TN+FP+正常undetermined=正常数。欠落・未評価をスコア0/正常へ補完しない。性能100%や過去検出件数との一致は一般の合格条件ではない。個々のassert・数理誤差・契約整合を機能合格の根拠にする。

## 2. 新環境での実行順序と再開

以下のpythonは新設した仮想環境のPythonを表す。コマンドは01のルートをcwdとし、親の旧PoCをimportしない。Windowsは `.venv\Scripts\python.exe`、POSIXは `.venv/bin/python` に置き換える。

```text
python -m venv .venv
<venv-python> -m pip install -r requirements.txt
<venv-python> tools/verify_transfer.py .
<venv-python> -m pip freeze
```

WindowsでPython3.12を選択するときは `py -3.12 -m venv .venv`。移送manifestは編集前に検査する。ログ用reportsを作成する。以下の順序を推奨：S01 A入口確認 → T01〜T17 → P01〜P15 → Q01物理レポート → S02/S03 acoustic全経路 → S04 legacy参考 → V01閲覧 → X01移設再実行。Aが基盤確認であり、Aのみで全検証を完了にしない。

```powershell
New-Item -ItemType Directory -Force reports | Out-Null
.\.venv\Scripts\python.exe -m unittest discover -s tests -v *> reports/all_tests.txt
if ($LASTEXITCODE -ne 0) { throw 'Test failure: inspect all_tests.txt' }
.\.venv\Scripts\python.exe -m nv_runner.verify_physics --output reports/physics
```

POSIXでは `mkdir -p reports`、`.venv/bin/python -m unittest discover -s tests -v > reports/all_tests.txt 2>&1` とし終了コードを確認する。

各実験は未作成の出力先を使う。生成途中で失敗したdemoを同じ出力先へ再実行しない。新しいrun/ディレクトリで全工程を実行する。既存生成データを再利用するときは `validate --config <config>` 後に `execute --config <config>`（新runで再学習）。学習checkpoint再開と固定モデル単独推論CLIは未実装。画面だけの失敗は保存済みBundleからviewだけ再実行できる。

unittestを1件だけやり直すには下記の -k に**完全なメソッド名**を指定する。setUpClassはそのたびに新規生成・学習するので元の失敗runは変更しない。

```text
python -m unittest discover -s tests -p test_acceptance.py -k test_03_shuffle_and_batch_identity_all_routes -v
python -m unittest discover -s tests -p test_acoustics.py -k test_04_euler_equation_finite_difference -v
```

## 3. 生成から学習・評価までの再実行要件

### S01：A全領域・選択領域を入口から出口まで

- 状態：**実施済み**。旧保存run_94659f1461014495a7afa4bb064bb680はcomplete、A_full/A_selected完了、seed42、fit9/cal3を確認。ただしソフト0.1であり現行による完全一致は対象外。
- 目的/問い：A入力、実学習、閾値、評価、Bundleが先に成立するか。
- 対象：configs/a_first.json、synthetic.generate、FixedWindow、ExperimentRunner.execute。追加スクリプト不要。
- 入力/学習：DATA-L quick、SPLIT、PROC/MODELのA2経路のみ。追加条件なし。
- コマンド：`python -m nv_runner generate --settings configs/quick_data.json --output data/quick` → `python -m nv_runner validate --config configs/a_first.json` → `python -m nv_runner execute --config configs/a_first.json`。
- 評価/合格：Bundle complete、requested/completedがA2経路、モデルと非null閾値あり、保存Bundleをinspect/viewで検証できる。根拠は入口〜出口の契約確認。検出率基準なし。
- 保存/依存/再開：SAVE、ENV。生成先既存ならハッシュ/設定確認後再利用、別条件は新ディレクトリとconfigのパスを変更。旧run値の上書き禁止。

### S02/S03：物理モデルquick / comparison

- 状態：ともに**実施済み**。旧コード・設定と保存metricsを根拠とする。
- 目的/問い：物理p/uを観測入力アダプタへ渡し、全5経路の学習・calibration・推論・個体比較・閲覧まで成立するか。
- 対象：demo.demo、acoustic_generator.generate_acoustic、profiles.acoustic_experiment、InputAdapter、全RoutePlugin、NormalModel、runner、bundle、viewer。追加スクリプト不要。
- 入力/生成/分割/前処理/学習：DATA-A quick / comparison、SPLIT、PROC/MODEL。そのまま使用し、テストの縮小fixtureを代用しない。
- コマンド：`python -m nv_runner demo --generator acoustic --profile quick --output demos/replay_acoustic_quick`、comparisonは `--profile comparison --output demos/replay_acoustic_comparison`。
- 評価/合格：5経路完了、Bundle complete、モデル・前処理・閾値・全case結果・truth隔離保存、receiptに原本未解決なし。個体の誤判定/見逃し/未確定を残す。以下過去値は参考であって必須一致ではない。
- 保存/順序/再開：SAVE、ENV、§2。各実行でgeneration.json/experiment.jsonを保存。demoはprofiles.pyから設定するためconfigsだけ編集しても反映されない。

|profile|経路|TP|FN|FP|TN|未確定 正常/異常|
|---|---|---:|---:|---:|---:|---|
|quick|A_full|5|0|0|2|0/0|
|quick|A_selected|5|0|2|0|0/0|
|quick|B_order|4|1|1|1|0/0|
|quick|C_event|1|4|0|2|0/0|
|quick|D_patch|3|2|0|2|0/0|
|comparison|A_full|18|2|0|8|0/0|
|comparison|A_selected|20|0|4|4|0/0|
|comparison|B_order|19|1|2|6|0/0|
|comparison|C_event|11|9|2|6|0/0|
|comparison|D_patch|14|6|2|6|0/0|

### S04：legacy quick / comparisonの参考再実行

- 状態：旧0.1で**実施済み**。現行0.2で旧値が完全再現するかは**不明**、一致保証なし。
- 目的/問い：旧生成方式の処理経路を再実行できるか。物理更新前との性能差を厳密な因果比較としない。
- 対象：synthetic.generate、profiles.experiment、demo.demo、全経路。追加スクリプト不要。
- コマンド：`python -m nv_runner demo --generator legacy --profile quick --output demos/replay_legacy_quick`。comparisonも同様に別出力先。
- 入力/学習：DATA-L、SPLIT、PROC/MODEL legacy。評価指標/保存/依存/再開はSAVE、ENV、§2。
- 合格：全5経路とBundle検査成功。過去比較値との違いは記録し、過去スコアを作るためコードや閾値を調整しない。
- 旧参考値（TP/FN/FP、経路順A_full/A_selected/B/C/D）：quick=2/3/0,5/0/0,5/0/1,1/4/0,4/1/1。comparison=17/3/2,17/3/0,19/1/4,4/16/0,14/6/1。全て判定不可0。旧ソース完全版不在のため旧数値そのものの再現判定は対象外。

## 4. 既存自動試験の個別要件

### Fixtureと各項目の読み方

**F-T**：Acceptance.setUpClass。DATA-L quickをtrain8・duration3秒へ変更。seed42/fs1024/eval7/各2測定。SPLITはfit6/cal2。IF16本、Dは4frame×8bin×2ch、hop4frame/8bin、PCA4。残りはPROC/MODEL legacy。最初にBundleを作り、各テストで指定の改変を行う。各Tの保存はSAVE＋そのテストが残すコピー/ログ。追加スクリプト不要、実行順と再開は§2。

**F-PH**：AcousticPhysics.setUp。cfg=DATA-A quick、medium1.2/343、伝達式試験receiver[0.08,0,0]・軸+x、f=[20,100,300] Hz。source()は原点、seed_key1、drive_rms0.01、128 Hz tone・位相0、plane方向+x、piston normal+x/radius0.0375 m、wall normal+x/incident−x。synthesizeに渡すcfg.receiverは**0.05 m**であり伝達式setUpの0.08 mとは区別。各P01〜P13はモデル/分割/学習/閾値が非該当、結果はunittestログ、配列は原則メモリのみ。

**F-PP**：AcousticPipeline.setUpClass。DATA-A quickをtrain6・duration3秒へ変更。seed42/fs1024/eval7/各2測定、fit4/cal2。IF16本、Dは通常8×16・PCA4、他PROC/MODEL acoustic。SAVEに加えtruth配列と診断artifactを保存。

全T/Pの旧実施状態は**実施済み・合格**（32件ログ）。各項目の「合格」は当該コード内assertに対応する範囲だけであり、その周辺機能全体の保証ではない。

### T01：全経路の実学習

- 目的/問い：固定値でなく実モデルの結果が保存されるか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_01_full_pipeline_real_models`、実装 `ExperimentRunner.execute、NormalModel.fit/score、BundleReader.validate`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_01_full_pipeline_real_models -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-Tを変更しない。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：complete、completed_routes=5、各model存在・閾値非null・採点scoreの標準偏差>0。実学習の最小契約であり検出精度基準ではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：基準Bundle、モデル、閾値、入力/結果、ログ。単独実行もfresh fixtureを生成する。

### T02：別プロセス閲覧

- 目的/問い：保存結果だけから別PythonでHTMLを生成できるか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_02_separate_process_reader_and_viewer`、実装 `viewer.render、CLI view`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_02_separate_process_reader_and_viewer -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T Bundleをsys.executable -m nv_runner viewへ渡す。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：終了0、HTMLにid="bundle"を含む。ブラウザーの描画確認はV01で別途実施。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：separate_viewer.html、基準Bundle、ログ。単独実行もfresh fixtureを生成する。

### T03：IDとバッチ対応

- 目的/問い：入力順・バッチサイズが変わっても同じIDに同じscoreが対応するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_03_shuffle_and_batch_identity_all_routes`、実装 `全plugin.prepare/fit/score`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_03_shuffle_and_batch_identity_all_routes -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-Tのfitで各モデルを再fit。eval測定順を反転、samples順も反転。batch1対7。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：ID集合一致、ID順に揃えたscoreがrtol=atol=1e−12で一致。乱数シャッフルではなく反転順テスト。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：fixture Bundleとログ。局所の再fitモデル/2つのscore辞書はメモリ内のみ。単独実行もfresh fixtureを生成する。

### T04：評価/ラベル漏洩

- 目的/問い：評価波形や正解を書き換えても学習成果物が不変か。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_04_eval_and_truth_do_not_change_model_or_threshold`、実装 `ExperimentRunner.execute、NormalModel、RoutePlugin.calibrate`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_04_eval_and_truth_do_not_change_model_or_threshold -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T evalのpを3.5倍、元hash更新。正解normal/abnormal反転、regions空。trainを変更しない。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：全経路.joblibと_threshold.jsonのSHA256が基準と一致。評価scoreの不変は要求しない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：改変data/config、前後Bundleとモデル、ログ。単独実行もfresh fixtureを生成する。

### T05：train/eval漏洩拒否

- 目的/問い：同一個体・元データ・派生元が混入したとき拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_05_train_eval_leakage_specimen_hash_and_parent`、実装 `DatasetPlanner.plan`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_05_train_eval_leakage_specimen_hash_and_parent -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T eval先頭のspecimen_id/source_sha256/derived_group_idを1項目ずつtrain先頭と一致させる。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：それぞれValueError。case_id重複はこのテストで直接改変していない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：F-T Bundle、ログ。改変recordはメモリのみ。単独実行もfresh fixtureを生成する。

### T06：派生元の群分割

- 目的/問い：別個体でも共通祖先を持つと分割を跨がないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_06_grouped_split`、実装 `DatasetPlanner.plan`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_06_grouped_split -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T trainの先頭2個体をshared_parentに変更、seed42で再分割。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：fit/calの個体ID・元SHA・派生元の集合交差が空。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：基準分割とログ。改変後の局所分割はメモリのみ。単独実行もfresh fixtureを生成する。

### T07：不足と経路部分失敗

- 目的/問い：未評価を正常/0へ変えず他経路を保存するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_07_missing_rotation_empty_selection_no_events_partial_failure`、実装 `各prepare、ExperimentRunner例外隔離、aggregate`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_07_missing_rotation_empty_selection_no_events_partial_failure -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T eval rpm mapping=None。A_selected MSC>2、C検出閾値100 Pa、D simulate_failure=True。変更はこの試験だけ。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：Bundle partial。A_full scoreあり、他score null/undetermined。B skipped/not_applicable、A空選択理由と生成数>0、C no_events、D failed。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：改変manifest/config、partial Bundle、errors、ログ。単独実行もfresh fixtureを生成する。

### T08：元範囲とcoverage

- 目的/問い：範囲が原本内で重複窓を二重計数しないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_08_source_ranges_and_overlapping_union`、実装 `RoutePlugin.add/aggregate、common.union_length`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_08_source_ranges_and_overlapping_union -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T全sample、区間[(0,1024),(512,1536),(2048,2500)]。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：start<end≤原本長、支持範囲が切出しを包含、union=1988、scored_union_seconds≤observed_seconds。周波数位置の物理正解との一致を直接試験するものではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：基準Bundleのsamples/measurements/route_case、ログ。単独実行もfresh fixtureを生成する。

### T09：破損と未完成Bundle

- 目的/問い：ハッシュ不一致・stagingを拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_09_bundle_corruption_and_staging_rejected`、実装 `BundleReader.__init__/validate`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_09_bundle_corruption_and_staging_rejected -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T Bundleコピーのmetrics.jsonを{}に改変。別にincomplete.staging指定。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：いずれもValueError。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：破損コピー、ログ。単独実行もfresh fixtureを生成する。

### T10：取込・再送・衝突

- 目的/問い：ローカル取込が冪等で原本不明を隠さないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_10_import_idempotency_conflict_and_missing_source`、実装 `EvaluationAdapter.import_bundle`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_10_import_idempotency_conflict_and_missing_source -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T Bundleを初回取込。再送時mappingを存在しない場所へ。manifest completed_atだけ変えた別コピーも取込。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：初回imported、再送already_imported・unresolved_sources非空、同run内容違いはconflictで拒否。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：inbox、receipt、衝突用Bundle、ログ。単独実行もfresh fixtureを生成する。

### T11：calibration不足

- 目的/問い：閾値を設定できないときscoreを残し未確定にするか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_11_insufficient_calibration_keeps_scores`、実装 `DatasetPlanner.plan、calibrate/decide`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_11_insufficient_calibration_keeps_scores -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T min_calibration_groups=100、A_fullのみ。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：case_scoreあり、decision=undetermined、reasonにcalibration_unavailable。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：新config/Bundle/閾値null、ログ。単独実行もfresh fixtureを生成する。

### T12：未知版・plugin・単位

- 目的/問い：非互換入力を明確に拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_12_versions_units_and_unimplemented_route_rejected`、実装 `validate_config、InputAdapter.load`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_12_versions_units_and_unimplemented_route_rejected -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T config schema99.0、plugin not_implementedを別々に試す。train先頭p単位unknown。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：各ValueError。全ての必須項目の欠落を網羅した試験ではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：不正config/dataコピー、ログ。単独実行もfresh fixtureを生成する。

### T13：AND/OR真理値

- 目的/問い：複合条件が論理どおりか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_13_and_or_truth_table`、実装 `signals.select_mask`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_13_and_or_truth_table -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：msc=[.2,.8,.9]、intensity=[1,0,2]、ともに>.5。学習・分割・閾値は非該当。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：AND=[false,false,true]、OR=[true,true,true]と完全一致。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：ログのみ。テストクラス共通F-T生成は実行される。単独実行もfresh fixtureを生成する。

### T14：個体指標母数

- 目的/問い：誤判定・見逃し・未確定を正しく数えるか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_14_specimen_metrics_denominators`、実装 `runner.compute_metrics`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_14_specimen_metrics_denominators -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：4個体、判定outside/within/undetermined/undetermined、正解normal/abnormal/normal/abnormal。学習非該当。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：normal_total/abnormal_total/FP/FN/正常未確定/異常未確定=[2,2,1,1,1,1]。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：ログのみ。指標辞書はメモリ内。単独実行もfresh fixtureを生成する。

### T15：入力単位の例外隔離

- 目的/問い：バッチ1件の失敗で全件を失わないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_15_sample_failure_isolation`、実装 `RoutePlugin.score`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_15_sample_failure_isolation -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T A_full eval1測定の最初のfeatureを−999。BrokenOneは−999を含むbatchで例外、それ以外feature先頭を返す。これは意図的な例外用stubで実モデル精度評価ではない。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：1件のみunscored/null、reason sample_processing_failed。他はscored。学習/判定閾値は当該問いに非該当。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：基準Bundle、ログ。stub結果はメモリのみ。単独実行もfresh fixtureを生成する。

### T16：fusionとBundle版

- 目的/問い：有効化したfusionが単一経路の判定を反映し未知版を拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_16_fusion_explicit_rule_and_unknown_bundle_version`、実装 `ExperimentRunner fusion、BundleReader`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_16_fusion_explicit_rule_and_unknown_bundle_version -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-T A_fullだけ、fusion enabled=True。別コピーBundle schema2.0。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：case_resultsがA_full判定と同じ。未知版はunsupported。複数経路の混在/未確定の全真理値は未検証。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：fusion Bundle、改変Bundle、ログ。単独実行もfresh fixtureを生成する。

### T17：意味的完全性

- 目的/問い：ハッシュだけ整合させた不正shape/参照を拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acceptance.py::Acceptance.test_17_shape_and_score_reference_validation`、実装 `BundleReader.validate`。
- 実行：`python -m unittest discover -s tests -p test_acceptance.py -k test_17_shape_and_score_reference_validation -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-Tコピーの最初のarray shape=[999999]、別コピーのmodel_ref=model:nonexistent。各JSONLのhash/bytesをmanifestへ更新。前処理・学習・正規化・閾値はF-Tを適用。局所条件が優先。
- 評価/合格/根拠：それぞれValueError。単なるハッシュチェックを越える契約検証。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：2つの意味的破損Bundle、ログ。単独実行もfresh fixtureを生成する。

### P01：進行波インピーダンスと軸

- 目的/問い：p/u=ρcと軸の反転/直交が成立するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_01_plane_impedance_direction_and_active_flux`、実装 `axial_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_01_plane_impedance_direction_and_active_flux -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH plane、seed不要。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：p/u=411.6・active=.5/411.6をrtol1e−14、軸−xはu反転・yはu=0をatol1e−15。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P02：単極子の近遠場と距離

- 目的/問い：近接場Zと距離減衰が成立するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_02_monopole_near_far_impedance_and_distance`、実装 `axial_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_02_monopole_near_far_impedance_and_distance -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH mono、r=.08/.16 m、別条件f1000 Hz/r100 m、seed不要。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：Z=ρc·jkr/(1+jkr) rtol1e−14、位相>0、p距離比.5 rtol1e−14、active比4 rtol1e−13、遠方Z/ρcとの差<.001。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P03：ピストン軸上

- 目的/問い：独立式と一致し軸外を拒否するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_03_piston_impedance`、実装 `field_transfer、axial_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_03_piston_impedance -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH piston、r=.08/a=.0375、軸外位置[.08,.01,0]。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：Z=ρc(1−exp(−2jγ))/(1−αexp(−2jγ))、α=r/√(r²+a²)、γ=k(√(r²+a²)−r)/2、rtol1e−13。軸外ValueError(axis)。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P04：Euler圧力勾配

- 目的/問い：速度が−∇P/(jωρ)を満たすか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_04_euler_equation_finite_difference`、実装 `field_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_04_euler_equation_finite_difference -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH4場。wall入射[−.8,.6,0]。中心差分h1e−6 m、xyz各軸（pistonはxのみ）。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：差分速度と伝達速度がrtol2e−7/atol1e−10で一致。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P05：剛壁境界

- 目的/問い：壁面法線速度0と定在場のactive/reactiveが整合するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_05_rigid_wall_boundary_and_reactive_flux`、実装 `axial_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_05_rigid_wall_boundary_and_reactive_flux -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH wall、壁面r0とr.08。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：壁p=2/u=0 atol1e−15、p=2coskr/u=−2j sinkr/(ρc) rtol1e−14、active0 atol1e−14、reactive>0。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P06：時間波形のp/u

- 目的/問い：FFT生成した同時波形が解析比を満たすか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_06_single_tone_time_domain_impedance`、実装 `synthesize、axial_transfer`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_06_single_tone_time_domain_impedance -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH4場、cfg r=.05、seed123、4秒、中央1≤t<3秒を128 Hz復調。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：複素p/uと解析比rtol3e−4/atol1e−6、平均puと.5Re(PconjU)の差≤max(1e−10,abs(expected)×1e−4)。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P07：重ね合わせとセンサー応答

- 目的/問い：音源和と指定gain/phase/delayが波形へ反映されるか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_07_superposition_and_sensor_response`、実装 `synthesize、sensor_response`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_07_superposition_and_sensor_response -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH plane128 Hz＋方向[−.6,.8,0]180 Hz・seed_key2、seed22。u gain6 dB/phase15°/delay.0002秒。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：合成波形=個別和=source_waveforms和 atol1e−14。中央1–3秒復調U/Pが10^(6/20)exp(j15°−j2π128×.0002)/(ρc) rtol3e−4。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P08：スペクトル量とintensity

- 目的/問い：bin量・PSD積分が時間領域量と一致するか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_08_bin_parseval_and_intensity_integral`、実装 `SignalService.maps、pu_diagnostics`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_08_bin_parseval_and_intensity_integral -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：解析p=√2×.2 sin(2π128t)、u=p/(ρc)、fs1024/N4096。STFT128/hop64/avg5/v2。seed不要。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：bin和=Hann²重み平均二乗rtol1e−14、intensity和（端2frame除外）=.04/(ρc) rtol1e−6。Welch pPSD/intensity積分小数12桁、Z実部411.6小数10桁、MSC1小数12桁。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P09：ゼロエネルギーの無効化

- 目的/問い：無信号を有効なp/u関係として表示しないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_09_zero_energy_undefined_relation_masked`、実装 `SignalService.maps、pu_diagnostics`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_09_zero_energy_undefined_relation_masked -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：ゼロ[2048,2]、fs1024、STFT128/hop64/avg5/v2、seed不要。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：maps.valid/diagnostics.validが全false。モデル/閾値非該当。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P10：ガード長の収束

- 目的/問い：指定イベント波形がガード長に敏感でないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_10_guard_convergence`、実装 `synthesize`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_10_guard_convergence -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH monoイベント300 Hz/中心.5/σ.03、seed10、guard.5対1秒。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：全保存波形のch別相対L2誤差<1e−4。一般の全音源/距離での収束保証ではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P11：回転観測誤差の隔離

- 目的/問い：rpm観測誤差だけで真の波形・rpmが変わらないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_11_rpm_sensor_changes_only_observed_rpm`、実装 `synthesize、measured_rpm`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_11_rpm_sensor_changes_only_observed_rpm -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：sources_for normal/family99/repeat0、seed23、ramp。rpm enabled、delay.05秒/gain.02/quantization10/dropout.1。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：waveformとtruth.rpm_true完全一致、rpm_measured最大差>10。全rpm_sensorパラメータの網羅ではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P12：外乱と対象の分離生成

- 目的/問い：外乱追加で対象音源が不変、外乱がp/u双方へ入るか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_12_disturbance_preserves_target_and_generates_both_channels`、実装 `sources_for、synthesize`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_12_disturbance_preserves_target_and_generates_both_channels -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：normal対disturbance、family100000/repeat0、seed51。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：既存source_waveforms完全一致。差分p std>.001、u std>1e−6、Δu=Δp×(−.6)/(ρc) atol1e−15。モデルの外乱除去性能は評価しない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P13：物理設定の拒否

- 目的/問い：適用範囲外を黙って生成しないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPhysics.test_13_invalid_physical_configuration_rejected`、実装 `field_transfer、axial_transfer、synthesize`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_13_invalid_physical_configuration_rejected -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PH monoの距離0、単位Paへ誤変更、plane+wall混在、非単位軸[2,0,0]、混在/軸のseed1。前処理・学習・正規化・閾値はF-PH（モデル/分割/閾値は非該当）を適用。局所条件が優先。
- 評価/合格/根拠：各ValueError。すべての不正パラメータ組合せの網羅ではない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：unittestログ。波形/伝達配列はメモリ内のみ。単独実行もfresh fixtureを生成する。

### P14：物理pipelineと真値隔離

- 目的/問い：物理生成データで学習でき観測入力へ正解が混入しないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPipeline.test_14_all_models_fit_and_truth_isolated_from_input`、実装 `AcousticPipeline.setUpClass、InputAdapter.load、ExperimentRunner.execute`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_14_all_models_fit_and_truth_isolated_from_input -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PP。学習/分割/閾値はF-PPとPROC/MODEL。前処理・学習・正規化・閾値はF-PPを適用。局所条件が優先。
- 評価/合格/根拠：Bundle complete、5model存在。record.truth属性なし/meta.scenarioなし。NPZキーがwaveform/shaft_rpmのみ。truth後付けartifactとWelch artifact存在。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：F-PPデータ・Bundle・モデル・閾値・truth・ログ。P15は改変後truthと2回目Bundleも保存。単独実行もfresh fixtureを生成する。

### P15：音源別真値改変の隔離

- 目的/問い：真値を大きく変えてもモデル/閾値が変わらないか。状態：**実施済み・合格**（旧32件ログ）。
- 対象：`tests/test_acoustics.py::AcousticPipeline.test_15_mutated_truth_arrays_do_not_change_models`、実装 `ExperimentRunner.execute、AcousticPipeline`。
- 実行：`python -m unittest discover -s tests -p test_acoustics.py -k test_15_mutated_truth_arrays_do_not_change_models -v`。追加スクリプト不要。ENV、順序/再開は§2。
- 入力・条件：F-PPのevalラベル全normal、最後のtruth artifactのrpm_true×7/source_waveforms×100、hash更新。他観測入力不変。前処理・学習・正規化・閾値はF-PPを適用。局所条件が優先。
- 評価/合格/根拠：全経路model/thresholdファイルSHA256が一致。判定後の正解指標が同じであることは要求しない。記載値は当該試験assertに由来し、現場の許容差ではない。
- 保存：F-PPデータ・Bundle・モデル・閾値・truth・ログ。P15は改変後truthと2回目Bundleも保存。単独実行もfresh fixtureを生成する。
## 5. 数値物理レポートの再生成

### Q01：4種類の場の定量照合

- 状態：**実施済み・PASS**。根拠はnv_runner/verify_physics.pyと旧physical_validation.json。
- 目的/問い：Euler式の数値微分、時間領域puとWelch積分、ガード変更を独立指標で照合できるか。
- 対象：verify_physics.verify、acoustics.field_transfer/axial_transfer/synthesize、signals.pu_diagnostics。既存スクリプトがあるため追加不要。
- 実行：`python -m nv_runner.verify_physics --output reports/physics`。
- 入力/生成：DATA-A quickのcfg、r=.05 m、ρ1.2/c343、軸+x。plane/mono/piston/wallの順、source drive_rms=.001・seed_key1、128 Hz tone・位相0、synthesis seed42。piston radius=.0375 m、wall incident−x。f=geomspace(10,450,120)、中心差分h=1e−7 mでx方向。Zの代表値は100 Hz。
- 分割/モデル/学習/正規化/閾値：モデル学習は非該当。伝達関数は無正規化、intensity差をp_rms×u_rmsで除して比較。Welchはhann、nperseg=min(512,2^floor(log2(max(8,N//4))))、overlap50%、detrend=False、scaling=density。csd(u,p)=Pconj(U)。guard試験は単極子300 Hzイベント・中心.5・σ.03・seed42、guard.5秒対1秒。
- 評価/合格：各場のEuler最大相対誤差<1e−6、intensity積分正規化誤差<1e−3、guardのp/u相対L2最大<1e−4。根拠はverify()に宣言された数理回帰用許容差。測定器の不確かさではない。
- 過去参考：|Z|/位相はplane411.6/約0°、mono37.542/84.7668°、piston46.8777/84.1167°、wall4481.287/90°。最大Euler誤差約1.33e−7、intensity正規化差約1.33e−9、guard p4.899e−16/u4.576e−16。これらの桁一致は要求せず上記許容差を使う。
- 保存：physical_validation.json、PHYSICAL_VALIDATION.md、コマンドstdout/stderr。モデルなし。新環境のENVを別記。失敗時は同じ条件のまま原因調査、再開は新出力先で全4場再実行。

## 6. 閲覧・保存結果の検証

### V01：オフライン画面の操作

- 状態：acoustic quick35行/comparison140行、各5経路/物理5表示で**実施済み・passed**、browser_errors空。legacy quick/comparisonも過去報告では実施済み。ただし当時のNode/Playwright/Edge版は不明。
- 目的/問い：保存データから、経路・入力選択、時間軸、元範囲、真値表示を操作できるか。
- 対象：viewer.render、nv_runner/viewer.html、tests/viewer_smoke.cjs。追加スクリプト不要。
- 入力：S02/S03で今回生成したviewer.html。legacyはS04。生成条件、seed、分割、学習条件は元のSに従う。V自体はモデルをロード/学習しない。
- 依存/実行例：NodeとPlaywrightを導入。`npm install --no-save playwright`、`npx playwright install chromium`。導入版を記録。Windows Edgeを使う場合は`$env:BROWSER_CHANNEL='msedge'`とし、PlaywrightのChromium追加導入は不要。既存PLAYWRIGHT_MODULEを使う場合も実際の場所と版を記録する。下記output親reportsを先に作る。

```text
node tests/viewer_smoke.cjs demos/replay_acoustic_quick/viewer.html reports/replay_quick_viewer
node tests/viewer_smoke.cjs demos/replay_acoustic_comparison/viewer.html reports/replay_comparison_viewer
```

- 評価/合格：終了0、status passed、各経路の入力option>0、選んだevidence.routeが一致・end>start、timeline click/真値toggle操作で例外なし、pageerrorなし。acousticはphysicalChecksがz_abs/phase/msc/active/reactiveの5件、case_route_rowsが35/140であることも出力JSONで確認する。legacyは物理5件を要求しない。
- 制限：スクリプトはpuPanelが見えないと物理チェックをskipするため、status passedだけでacoustic物理表示合格とはしない。真値非表示時のsource情報は確認するが、ピクセル描画の数理的正確性・全点のクリック結果は網羅しない。過去の目視チェックの厳密な全操作履歴は不明。
- 保存：*_test.json、*.png、stdout/stderr、Node/Playwright/ブラウザー版。必要なら手動で重なり/ラベル切れを確認し人手確認として別記。再開は新出力prefixで同じHTMLを開けばよく再学習不要。

### V02：Bundleの別プロセス再読込・受渡しコピーからの閲覧

- 状態：**実施済み**（T02、過去imported_comparison.html、移植検証記録）。
- 目的/問い：実行中オブジェクトがなくても保存Bundleだけで閲覧でき、ローカル取込後も同じ根拠へ辿れるか。
- 対象：BundleReader.validate、EvaluationAdapter.import_bundle、viewer.render、CLI inspect/import/view。
- 入力・モデル：Sで再生成したcomplete Bundle。生成/分割/前処理/学習は元S。閲覧時の学習・joblibロードはなし。
- コマンド：`python -m nv_runner inspect --bundle <Bundle>`、`python -m nv_runner import --bundle <Bundle> --output reports/local_inbox`、`python -m nv_runner view --bundle <local_inbox内のrun_ID> --output reports/imported.html`。
- 評価/合格：Bundle検証成功、receipt importedまたはalready_imported、元データが現在位置にある通常条件ではunresolved_sources空、再生成HTMLをV01で確認。元測定の不在を調べる異常系はT10。
- 保存/再開：受渡しBundle、receipt、生成HTML、CLIログ。ENVとV01環境。importは冪等、viewだけ再実行可。外部サービス接続を意味しない。

## 7. 標準コード外だった検証の再実行

### X01：移設した元データ・Bundleの参照解決と再学習

- 過去状態：同一Windows上で別フォルダの01コピーを用い、4Bundleと元測定参照（各136/38/136/38測定）を検証、acoustic quick再実行のroute metrics一致・別プロセスHTML再生成・quick取込で原本未解決0を確認した。別OSへの実移設は未実施。
- 目的/問い：作業場所が変わっても元データハッシュとモデル入力の由来を維持し、新しい保存先で再学習できるか。
- 対象：tools/replay_saved_checks.py（**本書作成時に追加**）、InputAdapter/validate_config/ExperimentRunner、BundleReader、EvaluationAdapter、CLI view。過去の一時コマンドそのものの完全再現ではなく、同等の問いを新規生成物で試す。
- 入力/条件：S02などで今生成したdemoのdata/experiment/summary/Bundle。seed、分割、前処理、学習、閾値はそのSの条件。スクリプトはdataとBundleを別フォルダへコピーし、元ファイルごとの完全path mappingを生成、元データhashを検証。configだけを移設先へ合わせ、保存Bundle内部を改変しない。
- 実行：`python tools/replay_saved_checks.py --example demos/replay_acoustic_quick --output reports/relocated_acoustic_quick`。残る3profileもそれぞれSから生成して異なるoutputで同じコマンドを実行できる。大容量過去結果を一切必要としない。付録Aにスクリプト全文を収録したので、01に未収録ならそのままtools/replay_saved_checks.pyへ保存する。
- 評価/合格：保存Bundleと全原本SHAが整合、取込の未解決参照0、別Pythonのview終了0、再実行completed_routes一致、同一環境でroute metrics辞書が一致。さらにmodel/thresholdのSHA一致も確認する。この最後のSHA確認は**今回追加した検査**で、過去移設検証が同じassertを実施したとは主張しない。異OS間のファイルhash一致要求ではない。
- 今回の追加スクリプト確認：新規acoustic quickを生成して本スクリプト実行、38原本参照・5経路再学習・指標一致・model/threshold一致でpassed。comparison/legacyをこの新スクリプトで実行したかは本書作成時点では**未実施**。
- 保存：コピーdata/saved_bundle、path_mapping.json、inbox/receipt、experiment.json、reruns、reopened.html、viewer_process.log、report.json（失敗時errorを含む）。モデル・閾値は前後Bundle。ENV。同じoutputは拒否、新出力へ最初からやり直す。部分状態の自動再開なし。
- 限界：同一ホストのコピー検証ではネットワーク断・権限差・別OSの挙動を実証しない。元ディレクトリを削除して完全切断した条件ではない。コード上、viewerはBundle配列を読むが、原本に一切到達不能な隔離環境の試験は別提案。

### X02：最小配布物の完全性と単独再配布

- 状態：**実施済み**。01のみの環境から--runtime-only再梱包、manifest検査、ZIP CRC、必要ファイル存在・大容量NPZ/joblib不在を確認。旧3ZIP一式も当時検査済みだが本再試験では再作成不要。
- 目的/問い：02/03、過去examples/reportsなしでコードを移送・再配布できるか。
- 対象：tools/build_transfer.py、tools/verify_transfer.py。モデル/入力/seed/分割/閾値は非該当。ENVのPython標準ライブラリだけで実行可能。
- コマンド：`python tools/verify_transfer.py .`（未編集01）、`python tools/build_transfer.py --runtime-only --output transfer_replay`（未作成先）。
- 合格：verifyが全登録ファイルのSHA/bytes一致、再梱包成功。01/.gitignore、docs/本書、nv_runner/viewer.html、tests、requirementsが存在し、npz/joblibなし。ZIP CRCは下記追加の短い標準ライブラリコマンドで検証する。

```text
python -c "import zipfile; z=zipfile.ZipFile('transfer_replay/01_runtime.zip'); assert z.testzip() is None; assert not any(n.endswith(('.npz','.joblib')) for n in z.namelist()); print('PASS')"
```

- 保存：PACKAGE_INDEX.json、TRANSFER_MANIFEST.json、ZIP SHA、コマンドログ。Gitには展開したコードと小さい文書だけ登録し、ZIPは登録しない。編集後の旧配布manifest不一致は検証機能の失敗とせず、再配布manifestを新しく作る。これまでの配布ZIP hashは版ごとに変わるため本書で固定しない。

## 8. 新規検証提案（既存再実行とは別・原則未実施）

ここからは過去合格済みとして扱わない。数値合格条件は事前承認/決定する必要があり、実測仕様がないものは**未確定**と明示する。既存のデモ件数を増やすだけで検証完了としない。

|ID・状態|目的/問い・対象|入力/生成/分割/モデル|実行手段・合格条件・保存|
|---|---|---|---|
|N01 未実施|距離/角度/周波数/反射/音源比/センサー誤差に対する物理適用範囲。acoustics、SignalService|条件掃引表を事前定義。seed集合未確定。単一場→混合場。学習なしの物理照合とPROC/MODELの性能照合を分ける|一括sweepスクリプトは未実装、再実装が必要。解析解が成立する条件の誤差と無効領域を記録。許容誤差は演算/校正に応じ事前設定。全設定・波形・曲線保存|
|N02 未実施|独立個体を増やした検出性能。generator、runner.compute_metrics|独立family/seedを増やし、開発/calibration/最終評価を群単位で分離。数・seed未確定。前処理/閾値を最終評価前に固定|多seed比較・信頼区間・異常強度掃引スクリプト未実装。TP/FP/FN/判定不可と群を考慮した区間推定。基準は用途から事前決定。全runを保存|
|N03 未実施|pのみ/uのみ/p-u、経路条件の寄与。routes/models|同一個体分割、固定比較条件。単ch特徴モデルは現行比較用に未実装。評価後の閾値調整禁止|ablation用plugin/集計スクリプトの実装が必要。正常/外乱/異常別で改善/悪化を報告。統計基準未確定。モデルと設定を保存|
|N04 未実施|複数経路fusionの全真理値、停止/急変rpm、全sensor誤差、全必須項目欠落の網羅|既存T/Pの不足を個別fixture追加。学習不要の契約試験と実学習試験を分ける|追加unittestが必要。仕様に従う状態/null/理由をassert。T16等の限定試験成功で代替しない|
|R01 未実施|実測の形式/単位/由来。InputAdapter|実ファイル、キー、dtype、ch、時間軸、個体/派生元、校正情報。生成seed非該当。欠損・重複・不正入力を含める|実測用変換アダプタとfixture未実装。正確なSI換算/原本hash/ID/形状、未知条件の拒否を合格条件とする。校正記録・原本・変換manifest保存|
|R02 未実施|p/u校正、相対位相/遅延、方向/共置、既知音場整合|実測の校正治具/手順を選定、周波数・距離・軸反転。モデルなし。機器仕様/不確かさは不明|計測手順・比較スクリプトが必要。許容差は機器不確かさから事前決定。p/u=ρcを近接場へ一律適用しない。補正前後と位相/応答曲線を保存|
|R03 未実施|同期/rpm/データ品質。InputAdapter、B、validity|独立回転基準、停止/急変/欠測/遅延、clip/alias/noise。モデルなしの計測照合→PROC/MODEL|実測rpm/パルスアダプタ未実装の場合は追加。許容同期/次数誤差未確定。未評価を正常にしない。基準計測・除外区間・全ログ保存|
|R04 未実施|正常の測定再現性と誤判定|同一個体の再測定/付け直し/別日/操作者/機器、独立正常個体。個体/日などの分布設計は事前決定。正常fit/cal/評価の個体重複禁止|登録後validate/executeが入口。階層別集計は追加実装が必要。個体単位FP/TN/未確定・信頼区間、許容値は用途から決定。原本/モデル/分割保存|
|R05 未実施|対象正常で外乱のみを変えた場合と既知異常の識別|対象固定の対測定、外乱/位置/運転条件の変更。独立検査で異常正解を取得。生成器truthの転用禁止|実測正解登録・種類別集計を追加。TP/FN/FP/未確定を別報告、正解なしなら精度は不明。モデル/閾値固定、条件/正解根拠保存|
|R06 未実施|運転域外・ドリフト・センサー交換後の適用性|未知回転域/負荷/温度/経時、固定済みモデル。再学習のトリガー未確定|監視・再校正ルール未実装。coverage/分布変化と誤判定の基準を事前設定。評価データを自動学習へ混ぜない|
|M01 未実施|固定モデルだけで新測定を推論|保存モデル/Scaler/特徴順序・単位/閾値/版を固定、新しい実測。新規学習なし|専用ロード/推論CLI未実装。実装後に同一入力再現、順序/バッチ不変、追加入力でモデル/閾値不変、非互換拒否を試験。モデルhashと推論結果保存|
|E01 未実施|外部システム受渡し・再送・部分失敗。EvaluationAdapter|新生成Bundleで開始可。相手schema/ID/認証/保存条件は不明。モデル学習は元Sに従う|外部transportは未実装。相手側受領、冪等性、ID衝突、欠損/未知版/改変拒否、timeout再送、未評価保存、原本参照/表示一致を合格条件とする。送受ログ・receipt保存|

実測原本は再生成できないためGit外で保存する。現行入力は共置p/u 1ペア、SI校正済み、等間隔・共通時計。非共置/非同期/多センサーは現行で自動補完せず、必要な実装と検証を先に行う。実測configのtruth_pathを外して実行できるが、正解不在の検出精度は「不明」。安全・性能の合格条件を後付けで過去結果に合わせない。

## 9. 新環境の完了報告・証跡

検証IDごとに、実施日、コードcommit/hash、依存版、入力/config/seed、実行コマンド、exit code、結果、失敗理由、成果物参照を記録する。実行時間は環境依存の参考値であり旧40.005秒等を性能基準にしない。

推奨の小さい報告書：docs/validation/<日付>_<環境>.md。Gitへはコード・設定・本書・小さい集計だけ保存。NPZ、joblib、Bundle、HTML、画像、長大ログはGit外の保存場所とmanifest SHAで参照する。generated viewer.htmlとソースnv_runner/viewer.htmlテンプレートを混同しない。CLAUDE.md等へ本書を参照する場合も、結果を見ずに実施済みへ書き換えない。

新環境の完了条件は、S01、T01〜T17、P01〜P15、Q01、S02/S03、V01/V02、X01（最低acoustic quick）、X02の結果を保存し、S04とX01の残りprofileについて実施/未実施を明記すること。既存機能の再試験完了と§8の新規研究・実測・外部接続完了を分ける。旧0.1厳密再現、別OS間の完全バイナリ一致、現場検出率は完了条件に含めない。

## 付録A：一時コマンドだった移設検証を再実行する追加スクリプト

次のPythonを `tools/replay_saved_checks.py` として保存する。最新版01には同じファイルを含めている。既存ファイルがある場合は本文と一致を確認し、無条件上書きしない。本書だけでコード断片を再構成できるよう全文を掲載する。

```python
"""Replay prior ad-hoc saved-result/relocation checks on a newly generated demo."""
import argparse
import json
from pathlib import Path, PureWindowsPath
import shutil
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from nv_runner.bundle import BundleReader, EvaluationAdapter
from nv_runner.common import read_json, write_json, sha
from nv_runner.runner import ExperimentRunner, validate_config


def check(example, output):
    example, output = Path(example).resolve(), Path(output).resolve()
    if output.exists():
        raise ValueError("Use a fresh output directory; existing evidence is never overwritten")
    summary = read_json(example / "summary.json")
    original = Path(summary["bundle"])
    reader = BundleReader(original).validate()
    if reader.manifest["bundle_status"] != "complete":
        raise AssertionError("Expected a successful demo before relocation testing")
    output.mkdir(parents=True)
    report = {"schema_version": "1.0", "status": "running", "source_bundle": str(original),
              "script_sha256": sha(Path(__file__)), "runtime_root": str(PROJECT)}
    write_json(output / "report.json", report)
    try:
        shutil.copytree(example / "data", output / "data")
        moved = output / "saved_bundle"
        shutil.copytree(original, moved)
        relocated = BundleReader(moved).validate()
        mapping = {m["source_path"]: str(output / "data" / PureWindowsPath(m["source_path"]).name)
                   for m in relocated.tables["measurements"]}
        for m in relocated.tables["measurements"]:
            if sha(Path(mapping[m["source_path"]])) != m["source_sha256"]:
                raise AssertionError("Relocated source hash mismatch")
        write_json(output / "path_mapping.json", mapping)
        receipt = EvaluationAdapter().import_bundle(moved, output / "inbox", mapping)
        if receipt["unresolved_sources"]:
            raise AssertionError("Unresolved relocated source")
        report["source_count"] = len(mapping)
        report["receipt"] = receipt
        command = [sys.executable, "-m", "nv_runner", "view", "--bundle", str(moved),
                   "--output", str(output / "reopened.html")]
        result = subprocess.run(command, cwd=PROJECT, capture_output=True, text=True, encoding="utf-8", errors="replace")
        (output / "viewer_process.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise AssertionError("Separate viewer process failed")
        report["viewer_process"] = "passed"
        config = read_json(example / "experiment.json")
        for key in ("train_manifest", "eval_manifest", "truth_path"):
            if config.get(key):
                config[key] = str(output / "data" / Path(config[key]).name)
        config["export"]["output_dir"] = str(output / "reruns")
        write_json(output / "experiment.json", config)
        validate_config(output / "experiment.json")
        rerun = ExperimentRunner().execute(output / "experiment.json")
        rerun_reader = BundleReader(rerun).validate()
        if rerun_reader.manifest["completed_routes"] != reader.manifest["completed_routes"]:
            raise AssertionError("Completed routes changed")
        if read_json(rerun / "metrics.json")["routes"] != read_json(original / "metrics.json")["routes"]:
            raise AssertionError("Route metrics differ within the same environment")
        report["route_metrics_match"] = True
        report["rerun_bundle"] = str(rerun)
        # This is same-environment determinism, not cross-platform binary equivalence.
        report["model_threshold_hashes"] = {}
        for route in reader.manifest["completed_routes"]:
            for suffix in (".joblib", "_threshold.json"):
                name = route + suffix
                if sha(original / "models" / name) != sha(rerun / "models" / name):
                    raise AssertionError("Model/threshold changed: " + name)
                report["model_threshold_hashes"][name] = sha(rerun / "models" / name)
        report["status"] = "passed"
    except Exception as error:
        report.update(status="failed", error=repr(error))
        raise
    finally:
        write_json(output / "report.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--example", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = check(args.example, args.output)
    print(json.dumps({"status": result["status"], "source_count": result["source_count"]}))
```

## 付録B：本書作成時の根拠ソースSHA256

移植したコードの照合用。異なる場合は当該検証条件を再確認し、以下の値へ合わせるため結果を改変しない。

|ファイル|SHA256|
|---|---|
|nv_runner/__init__.py|cac7d2f661e8d0f8ddaf36fef2a7497f67709abd0084774118573e952a3cfd26|
|nv_runner/__main__.py|402803cc4d1420ab242e3cdcb5bf8f35b6af4590113246f7866d004626d21d57|
|nv_runner/acoustic_generator.py|f96eada9a9679296e1550dd8751778c3b515c6ca1a2d5560d48402ca969a340c|
|nv_runner/acoustics.py|64e88430fb9c2d2670943ec3356143420d430c3fa3480f5c87bf725282cbda11|
|nv_runner/bundle.py|8bc1ea3f2027fab4f343a60403e071b98faa78b0506a1ade4cd74c89cab89a7b|
|nv_runner/common.py|69193add3e232c56338e5b020ec847cd588731c5431d0114eb95833b0d276709|
|nv_runner/demo.py|98da51fd5001ebc335222d194b028090dbadad9ae0172647dbb26dbcca425126|
|nv_runner/input_adapter.py|8bf5ba1aee35131eecdf2c45d1b665be69bfcaaf3f3c94c0a6d6f07134ae8990|
|nv_runner/models.py|a7b74d6da8037bfd7a8712cccff39f5d9f4fa910aec7bf7dbebafac5de25cb9e|
|nv_runner/profiles.py|bcb37083e9cee0107e9cfe8d18b29f34df3b0691a39f0afb10f46014e7b18608|
|nv_runner/routes.py|76c3a408f8a5542443968c0b0d754a05cccf0730a1ee790c9eb0a8e70d58f3fa|
|nv_runner/runner.py|63dac28ec8bf044b5c4a675ab33a8cd76aea6021b6ec92e8eae8c2824f30c536|
|nv_runner/signals.py|66bac05f8f7492ec83ba12f8eca954196a3de25c3436e543ee5be76d804c0fa4|
|nv_runner/synthetic.py|ae2b2b164f39e0649bb2c5b9e1359e527ed4be2cb1b55dcd8afc94f6c2127f67|
|nv_runner/verify_physics.py|84e461fee8fca5056fc66a5875513b712b8e73808ad6475502fdbdff33741d1f|
|nv_runner/viewer.py|440e0892ccdbfef948d0f248354121dc7e632709ff0bcebb4edd1c61031b4d61|
|configs/a_first.json|79f4ef7b7cb0ab477050225d998e384615cf24cbb2c6755f8136250e6868f45c|
|configs/acoustic_comparison.json|a800718f00320736eea130e552c03c883dc23f84077d59df45832d3e3f99776e|
|configs/acoustic_comparison_data.json|06f2cbabaccbadb886dfc97399559b20419c411ebd14c987b09d675b96034ca5|
|configs/acoustic_quick.json|50d4fcd716f8aad43459b39353db74bcb59e6bcce09ecb8c838c15a2157f3210|
|configs/acoustic_quick_data.json|76b083a4a6985e23c593673d39f112e8e20290f1f352c52033dd0d3fe76da1b6|
|configs/comparison.json|f8283c39a5d61cfeeac96f6b1b1f88fc8c7f375510a08aa54cf5877528b2eba0|
|configs/comparison_data.json|9c5394fc0dfe5b0b86018eac4fb846358bbb9b01860d183d1304e5306a929701|
|configs/quick.json|cc1dd19d9e31e1e56b4a924ecd07f4eebe46d939a5716752aab88ffa383cd698|
|configs/quick_data.json|8ef0fe77cce6d3b17a4b2f9dabdf8415e5efea0ecbe196e460ba515c5e4d0c17|
|nv_runner/viewer.html|b25f00a70dd738de40feaa857ce64f3a87e557f35fb0f2eb6579016f1777cc24|
|tests/test_acceptance.py|86f98b2244280f40c39d4ddeb08e81466c224181299d4d39f7de18c504bebf6d|
|tests/test_acoustics.py|fd21d70a9389631b1e7186faece0188e58bff2c43aaa21a011fde6f011a2900c|
|tests/viewer_smoke.cjs|576b6927c7ddaa3827be5dda9f398dd0d22757ca7ea90315d3e9e33ad9d9b7da|
|tools/replay_saved_checks.py|42da2e30564feba5220ee1dffa8077b785a8181414903449913167f3a599d2ad|
|tools/build_transfer.py|d5b7311c4f003eea04012238dda44312baf4ec94f4081eb5c5401a59ad2d3b21|
|tools/verify_transfer.py|be21df099b2f1a838f9b7c25e824af8830227653625dd62a438a9aeafc160ba5|
|requirements.txt|415e0026da4e0382a23f32b0fed3ed7f540f1374e8edbfc137d52285be723b88|

各試験のモデル/閾値条件はfixtureまたはPROC/MODELに明示した。これ以外の過去の手動条件、記録のない試行回数、調整過程の全履歴は不明であり再現対象として捏造しない。
