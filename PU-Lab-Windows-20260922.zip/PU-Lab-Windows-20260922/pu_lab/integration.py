"""Import workspace experiments without changing their waveforms."""
from pathlib import Path
import hashlib
import json
import shutil
from dataset import load_dataset

def import_legacy(workspace, outputs):
    workspace, outputs = Path(workspace), Path(outputs)
    sources = [workspace/'results'/'waveforms.npz']
    sources += sorted((workspace/'experiments').glob('*/waveforms.npz'))
    imported = []
    for source in sources:
        if not source.is_file():
            continue
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        folder = outputs/'legacy'/f'{source.parent.name}_{digest[:12]}'
        target = folder/'dataset.npz'
        if not target.exists():
            load_dataset(source)
            folder.mkdir(parents=True, exist_ok=True)
            temporary = folder/'dataset.partial.npz'
            shutil.copy2(source, temporary)
            for name in ('config.json', 'metrics.json', 'test_results.csv', 'model_weights.npz',
                         'dl_result.png', 'waveform_examples.png', 'learning_curve.png'):
                if (source.parent/name).is_file():
                    shutil.copy2(source.parent/name, folder/name)
            provenance = dict(source=str(source), sha256=digest,
                kind='legacy_synthetic', units=['Pa', 'm/s'],
                note='旧版の合成波形を無変換で保存。旧設定はPU Lab物理モデルへ変換していません。')
            (folder/'provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding='utf-8')
            temporary.replace(target)
        imported.append(target.relative_to(outputs).as_posix())
    return imported

def saved_runs(outputs):
    outputs = Path(outputs)
    result = []
    for path in sorted(outputs.rglob('result.json'), key=lambda p:p.stat().st_mtime, reverse=True):
        if not (path.parent/'dl_result.png').exists():
            continue
        data = json.loads(path.read_text(encoding='utf-8'))
        settings_path = path.parent/'run_settings.json'
        settings = json.loads(settings_path.read_text(encoding='utf-8')) if settings_path.exists() else {}
        result.append(dict(folder=path.parent.relative_to(outputs).as_posix(),
                           channels=data['metrics']['channels'], metrics=data['metrics'], settings=settings))
    return result
