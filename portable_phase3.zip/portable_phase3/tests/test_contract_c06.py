import copy
import subprocess
import sys
import unittest
from unittest.mock import patch
from contract_fixtures import pipeline, bundle_copy, directory, refresh_member, run_variant
from nv_runner.common import read_json, write_json, read_lines, write_lines
from nv_runner.bundle import BundleReader

class C06(unittest.TestCase):
    def test_bundle_reader_and_separate_viewer_without_truth_or_originals(self):
        root,cfg,_=pipeline(); cfg=copy.deepcopy(cfg); cfg.pop('truth_path',None)
        reader=run_variant(cfg)
        self.assertEqual(reader.manifest['schema_version'],'1.0')
        self.assertFalse((reader.path/'truth.json').exists())
        # Hide observations only during a synchronous subprocess; restore even after failure.
        data=root/'data'; hidden=root/'data_hidden'; data.rename(hidden)
        try:
            target=directory()/'viewer.html'
            result=subprocess.run([sys.executable,'-m','nv_runner','view','--bundle',str(reader.path),'--output',str(target)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('id="bundle"',target.read_text(encoding='utf-8'))
        finally: hidden.rename(data)

    def test_corruption_extra_member_version_and_staging_rejected(self):
        for mutation in ('hash','extra','version'):
            path=bundle_copy()
            if mutation=='hash': (path/'metrics.json').write_text('{}',encoding='utf-8')
            elif mutation=='extra': (path/'extra.txt').write_text('extra')
            else:
                m=read_json(path/'manifest.json'); m['schema_version']='2.0'; write_json(path/'manifest.json',m)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): BundleReader(path).validate()
        with self.assertRaises(ValueError): BundleReader(directory()/'run.staging')

    def test_semantic_ids_coordinates_and_references_rejected(self):
        for mutation in ('duplicate','coordinate','reference'):
            path=bundle_copy()
            name='sample_results.jsonl' if mutation=='reference' else 'samples.jsonl'
            rows=read_lines(path/name)
            if mutation=='duplicate': rows.append(copy.deepcopy(rows[0]))
            elif mutation=='coordinate': rows[0]['end_sample']=-1
            else: rows[0]['model_ref']='missing-model'
            write_lines(path/name,rows); refresh_member(path,name)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): BundleReader(path).validate()
