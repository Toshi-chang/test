# Phase 3：開発アーキテクチャと運用境界

本書は別環境で最初に読む案内であり、既存契約を変更しない。実行手順は [MIGRATION](../MIGRATION.md)、実装事実は [Phase 3記録](validation/phase3_registry.md)、契約の正本は [C01〜C08](parallel_contracts/CONTRACTS_MINIMUM.md)。現行PoC 0.2.0 / ResultBundle 1.0を維持する。

## 1. 機能単位の独立開発

入力変換、経路、モデル、実行管理、保存/受渡し、閲覧を境界で分ける。内部アルゴリズムを統一することは目的ではない。専用実装・試験を追加し、同じ境界契約で交換を検証する。A/B/C/Dの計算・閾値を本移植で変更しない。

## 2. 最小境界契約

C01〜C08と現行 `RoutePlugin` / `PreparedSet` / `NormalModel` を優先する。個体・測定・入力ID、単位、時間/周波数/位置、由来、状態、未評価null、理由を保持する。契約範囲外を将来汎用APIに合わせて作り替えない。詳細は [契約試験計画](parallel_contracts/CONTRACT_TEST_PLAN.md)。

## 3. Descriptor / Registry / Validator

`plugin_descriptor.py` が識別子、実装版、factory、schema、API/入出力/model契約、任意制約validatorを宣言する。`plugin_registry.py` が登録、版/契約検査、factory解決、呼出署名の事前検査を行う。`plugin_validation.py` が宣言schemaと共通条件を検査する。runner.pyは検査をRegistryへ委譲する。既存 `REGISTRY[id](config)` のMapping互換を維持する。

## 4. 明示登録

`plugin_catalog.py` にレビュー済み実装を登録する。構成ファイルは登録済みpluginを選択するだけで、任意コードを指定・自動探索しない。新経路のために中央Runner/Validatorへ個別分岐を追加しない。登録定義の変更は共有コードとして統合担当が行う。

## 5. 遅延読み込み

登録・一覧・存在確認で実装moduleをimportしない。選択された経路の検証/実行時に解決する。未選択candidate・無効経路の依存欠落が独立した経路を壊さないことを試験する。constructorは事前検査と実行時に呼ばれ得るため副作用を持たせない。

## 6. 選択的追加・交換・無効化・廃止

実装・Descriptor・専用試験・利用構成で追加する。fixed_windowとfixed_window_candidateを設定で交換できる。enabled=falseまたは構成からの除去で停止し、利用がなくなってから登録を削除する。IDが変わる交換比較は元測定座標とfeature schemaを併用し、同一IDを無理に要求しない。

## 7. 複数エージェントによる並列開発

[AGENT_TASKS](parallel_contracts/AGENT_TASKS.md) と [WORK_AND_MIGRATION](plugin_architecture/WORK_AND_MIGRATION.md) を使う。Phase 3ではP=Registry、V=Validator、T=交換試験、I=統合という分担を実施した。新環境でも担当の専用ファイルを先に確定し、共有変更の所有者を1人にする。設計全体の完成待ちではなく、確定済み契約に収まる実装から開始する。

## 8. 所有範囲と変更監査

[development/ownership.json](../development/ownership.json) と [development README](../development/README.md) を正本とする。`tools/check_workstream_scope.py` で変更範囲を監査し、ハッシュによる変更記録を残す。保護された契約・既存テストを担当の都合で編集しない。Gitは任意の開発基盤であり、この移植処理で初期化しない。

## 9. 契約・回帰・統合試験

専用試験 → C契約試験 → 全130回帰 → CLI生成/学習/評価 → BundleReader/出力adapter/viewerの順に確認する。入力対応、座標、異常状態、fit/cal/eval分離、モデル/閾値独立性を保持する。合格させるために既存テストを変更しない。新しいfeatureの追加後は新試験も含める。現行130件という件数だけで新機能の品質を代用しない。

## 10. 共通契約の変更承認

[INTEGRATION](parallel_contracts/INTEGRATION.md) の変更申請/承認を適用する。変更理由、影響する契約/利用者、互換性、試験、移行策を分離提出し、承認前に破壊的変更を混ぜない。契約に収まる内部変更は専用範囲で進める。

## 11. 既存システムとの互換性

既存CLI、設定、5経路、ResultBundle1.0、Reader、viewer、EvaluationAdapterを維持する。入力はInputAdapter、外部受渡しはBundle/EvaluationAdapterで接続する。外部実システムへの接続は未実施。raw waveform参照と表示用HTMLを混同しない。測定を移送しない場合は元波形参照が不足する。

## 12. 実装済みと将来構想

実装済みは現行lifecycle `prepare/fit/score/aggregate/calibrate/decide` と明示Registry、対応版の完全一致、限定schema検証。schemaは完全なJSON Schemaではない。未対応keywordは拒否する。旧設定の許容値・既定値を変えず、新schemaにだけ必要な制約を宣言する。

[DESIGN](plugin_architecture/DESIGN.md) / [ACCEPTANCE](plugin_architecture/ACCEPTANCE.md) は将来の隔離PoC計画も含む。汎用Composition Planner、任意依存DAG、semver範囲解決、複数版同時選択、動的探索、コードsandbox、HTTP/クラウド、全モデルの汎用プラグイン化は現行の完成機能として扱わない。既存IF/PCA制約は残る。候補入力/modelモジュールが存在しても自動的に本番選択へ統合されたことを意味しない。詳しい状態は各workstream文書とPhase 3記録を参照する。
