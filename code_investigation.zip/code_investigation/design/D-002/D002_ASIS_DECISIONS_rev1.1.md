# D-002 As-Is統合・差分・設計判断台帳

2026-10-20 / rev.1.1 草案。意味的定義は[D002_DESIGN_rev1.1.md](D002_DESIGN_rev1.1.md)を正とする。F=資料/コードの静的事実、I=推論、P=提案、U=未確認、V=実行検証。本件の機能Vはなし。

## 1. 根拠と再利用方法

[round01](../../round01/INVESTIGATION.md)と[round02](../../round02/INVESTIGATION.md)を主根拠とし、両台帳にある54件の一意ソースをSHA-256照合した。相違0件。ソース全文の再読込、追加製品コード調査、テスト実行はしていない。以下のS/Q番号は両調査の根拠IDで、[evidence.json](evidence.json)に完全パス・hash・元台帳との対応を保存する。行番号はそのhashの版に対するもの。

ユーザー提供のD-001収録条件は入力要求の事実として扱う。D-001設計文書や実CSVを別途取得・検証したとは主張しない。先頭5行に有意metadataなし、第6行以降数値、第1列が秒単位の時間関連値、第2列以降電圧、追加RPMという説明があるが、厳密な意味・配置はU。

|根拠ID|ファイル・シンボル・行|設計に用いるF|
|---|---|---|
|E01|S09 `09_DL-NPZ_Bridge/src/observer_exporter/reference_connection.py` load_observer_reference:38–78、S11 stft_calibration_bridge.py:15–24|既定reference、env指定、module origin衝突拒否、import時bind|
|E02|Q01 Start-Evaluation.cmd:1–6、Q02 scripts/Start-Evaluation.ps1:1–26、Q03 src/offline_evaluator/__main__.py:22–32、Q04 runner.py:34–43、Q05 observer_dev/Tool_A/app.py:26|入口・strict/legacy分岐。実稼働環境を証明しない|
|E03|S02 `09_DL-NPZ_Bridge/observer_dev/Tool_A/domain/models.py` SignalData:57–69、ChannelMappingTable:163–176、S03 domain/semantics.py:7–113|CH状態は値と別。最初一致mapping|
|E04|S04 同Tool_A/data_io/calibration_loaders.py load_probe_master:134–195、load_channel_mapping:378–426、resolve_channel_calibration:461–517|probe後勝ち、CH解決・係数。位置/配線証拠と別|
|E05|S05 同Tool_A/data_io/calibration.py:89–179,239–302,556–675|未実装入口と実装済み感度/周波数校正が併存|
|E06|S06 同Tool_A/services/calibrated_tf.py build_calibrated_tf:108–186、S07 analysis_context.py FrozenTF:49–98/CalibrationResolver:115–176|TF限定補正、immutable snapshot、二重校正/入力変更検査|
|E07|S24 `09_DL-NPZ_Bridge/reference/observer/Tool_A/services/tf_transform.py` compute_tf:4–48、S25 calibrated_tf.py:144–175|未正規化FFT/abs²、RMS placeholderと旧型|
|E08|S10 `09_DL-NPZ_Bridge/src/observer_exporter/instrument_csv_adapter.py` load_instrument_voltage_record:6–38、S11 stft_calibration_bridge.py:202–235、S12 record_fft_calibration.py:14–73|2CH役割/格子検査、周期AC限定、DC/Nyquist除去|
|E09|Q06 `09_DL-NPZ_Bridge/src/offline_evaluator/inspection.py`:76–164、Q07 calibration.py evaluate_record:17–135|時刻丸めの扱い、係数snapshot、original_time、実行成功と実機適合の別check|
|E10|Q08 `09_DL-NPZ_Bridge/observer_dev/Tool_A/services/calibration_audit.py`:24–35,77–158|監査CSVは係数再計算、当該runの自動証明ではない|
|E11|S13 `09_DL-NPZ_Bridge/src/observer_exporter/record_exporter.py`:34–82、Q11 window_generator.py:35–98、Q12 metadata_builder.py:60–99|元開始sample保持、float32窓、任意由来欄、sourceとsignalの拘束不足|
|E12|S15 `09_DL-NPZ_Bridge/src/shared_contract/schema.py`:7–44、S16 validation.py:32–165、S17 dl_import_adapter/loader_adapter.py:14–86、S18 traceability.py:6–16|整数schema1、4split、source文字列解決とhash検証の違い|
|E13|Q09 `09_DL-NPZ_Bridge/src/offline_evaluator/strict_integration.py`:76–111,177–206,268–306,339–407、Q10 shared_contract/artifact_state.py:107–127,264–311,326–360,387–428|捕捉bytes/公開/member hash/親由来/用途別品質|
|E14|Q13 `09_DL-NPZ_Bridge/src/offline_evaluator/model_runner.py` decode_record_bytes:25–67|校正record schema、raw/derived hash、窓開始、hash存在検査と実体結合の差|
|E15|S19 `nv_route_runner_poc/nv_runner/input_adapter.py` MeasurementRecord:10、InputAdapter.load:17–87、DatasetPlanner.plan:91–136|SI 2CH、位置/方向/共有clock宣言、NPZ hash、個体/派生元分離|
|E16|S20 `nv_route_runner_poc/nv_runner/input_candidate.py` convert:18–95、S21 runner.py:48–50,123–134,159|SI列変換、truth隔離、Runner受渡し。電圧校正ではない|

### 第2回による更新（第1回を無断訂正しない）

|第1回の課題|第2回で増えた確認|残る限界|
|---|---|---|
|G01/G09 実行入口・参照先|E02でlauncher/CLI/開発appのimport先を特定|過去runのenv/import状態はU。referenceと開発側を同一実装としない|
|G03 CH照合の保証不足|E09で上位CH1/CH2宣言検査、E08でquantity検査、別probeの許容を明確化|物理配線一致や全GUIの拒否網羅はU|
|G05 係数snapshotの不足|E09/E13ではraw/probe/config保存・bindingがあると確認|通常exportへ保証を拡張しない。全依存環境や校正証明の復元はU|
|G07 hash/窓追跡|E11/E13/E14で原sample、strict再照合、member/親連鎖を追加|通常trace helperはpath解決のみ。保証の強さが経路別|
|G04 位置/同期|時刻丸めと正規格子化は確認|位置/方向の実取得、実機時計/遅延は未確認のまま|

これは主に確認範囲の拡張であり、既存静的事実の撤回ではない。「Bridge全体がsnapshotを保存しない」「校正全体が未実装」と一般化する読み方は誤りとして排除する。

## 2. As-IsとRequiredの対応

分類：充足=既存情報で満たせる、変換候補=Adapterで満たせる可能性、追加=外部metadata必要、復元不可=当該成果物だけでは失われた意味を復元できない、未確認=調査不足、新設計=契約自体が必要。複数分類が並ぶ場合は項目ごとの判定。

|対象/責務|As-Is（F）|Requiredとの差分（I/P）・分類|Adapter/再利用候補・限界|
|---|---|---|---|
|Observer raw入力|time/p/u[N]、fs、source_paths。開発型にstage/CH状態/ref。旧型に追加状態なし|CH状態は充足候補、原本hash/安定IDは追加、無記録placeholder区別は復元不可の場合あり|loader＋semanticsを選別。p/u名を物理単位としない（E03）|
|Observer CH/probe|mapping最初一致/probe後勝ち|一意性・bindingは新設計。元Excelがあれば重複再検査可能、上書き後dictだけでは重複履歴は復元不可|係数解決を再利用候補とするが、先に外部表の全行検証（E04）|
|Observer校正TF|[F,T]、元波形Vのまま、TF単位変更、RMSゼロunsupported|DerivedArtifactへ変換候補。時間物理波形へ直接変換不可|TFのdomain/stateを保持。参照版のゼロRMSに実測意味を追加しない（E05〜07）|
|Bridge raw/周期校正|明示2CH/同格子、周期AC、DC/Nyquist除去|時間波形Revisionへ変換候補。一般非周期/多CH/別時計は新設計・未確認|周期条件を満たす入力だけ。既存係数式を独立科学検証とセットで候補化（E08）|
|offline inspection/calibration|時刻丸め/校正snapshot/元time保存、実機適合INCONCLUSIVE|係数/変換履歴は充足候補。証明書/温度/gain/方向は追加|チェック群・snapshotの思想を再利用。INCONCLUSIVEをReadyへ変えない（E09）|
|通常Bridge窓NPZ|[W,2,L]、record ID/source、start任意、4split|CH軸変換は可能。start欠損の窓から元時刻は復元不可。原本とsignalの同一性は未確認|source/座標が揃う対象のみ適合Adapter。窓をraw Recordingと偽装しない（E11/E12）|
|strict artifact|捕捉bytes、親hash、native binding、用途policy|由来・完全性は充足候補。D-002全体の意味を自動充足しない|InputSnapshot/検証順序を候補化。native schemaの結合を切り離す設計が必要（E13）|
|NV InputAdapter|[N,2] Pa/m/s、RPM[N]任意、位置方向/共有clock/校正宣言/hash|正規SI受領は充足候補。可変CH・未知位置・校正実行証跡は追加/新設計|現APIの制約を満たすViewから明示変換。未知座標を既定値で通さない（E15）|
|NV Planner/Runner|個体/派生元fit/cal/eval分離、route.prepareへ渡す|分割はD-006へ移管候補。Recording IDの同義語ではない|科学入力とtruth/分割を別管理する方針の候補（E15/E16）|

全システムでセンサー実体・時計精度・測定イベントが十分保存されるとは未確認。失われた位置/位相/同期/元区間は推測復元しない。元CSV、校正表、測定記録が新たに得られれば再評価できる。「当該成果物では復元不可」と「世界のどこにも情報がない」を区別する。

### 推奨Adapter境界（P、実装しない）

1. D-001 CSV＋metadata → raw PhysicalRecording：実列仕様を確認し、原列・raw V・時計解釈・bindingを保持。
2. Observer/Bridge → PhysicalRecording/DerivedArtifact：選択rootと実装版を固定、配列軸とdomainを明示変換、復元できない情報はUnknown/診断限定。
3. PhysicalRecording SignalView → NV：2CH/SI/共置/方向/共有clock/校正宣言の既存条件を満たす対象だけ射影する。D-002全体をNV仕様へ縮退させない。
4. strict artifact → provenance asset解決：既存native validatorの保証を記録するがD-002の受領検証を省略しない。

## 3. 実装候補比較（採用未確定）

必須ゲートは、単位/CH/参照矛盾の拒否、原本不変、欠損状態保持、区間追跡、版拒否、GUI独立。いずれか不合格の候補を速度や記述量の点数で救済しない。

|観点|A NumPy＋辞書|B NumPy＋型付き構造|C xarray中心|
|---|---|---|---|
|意味/整合性|自由だがキー欠落・上書きに独自Validator必須|型で形を明示、意味Validatorは別途必要|dims/coordsは表現しやすいがattrsだけでは保証不足|
|単位/時間/CH|手動対応表が必要|CH/TimeBase refを型で分離しやすい|軸名が利点。単位や同期の意味検証は別途必要|
|静的型/保守|低コスト開始、呼出元ごとの解釈拡散が懸念|フィールド所有が明確、型変更の管理負担|ライブラリのデータ操作規約と独自契約双方の学習負担|
|可変CH/別時計|CHごとのarrayで可能|同左、異なるTimeBaseを明示|一つの共通time次元へ無理に揃えず複数変数/次元設計が必要|
|部分読込/大容量|provider併設が必要|型は参照を持ちproviderを交換可能|backend/lazy機構が候補、実際のIO/依存構成は比較が必要|
|独立PoC/既存接続|既存NumPyへ近いが境界が弱い|薄いarray変換で接続、wrapper実装が必要|NumPyへの抽出時にattrs/座標を失わないAdapterが必要|
|テスト容易性|辞書破壊入力を多く準備|型/Validator/consumerを分離試験可能|alignmentやselectionの規約も試験対象|
|拡張性|拡張容易だが既存意味の上書きに弱い|namespace拡張＋版付き契約が適合|軸付き派生配列には有利、全Recording管理まで含める必然性はない|
|推奨位置|比較の最小基準|暫定第一候補|派生TF等の内部実装候補も含め比較|

以上はI/Pの比較仮説であり性能Vではない。Bはデータ検証ライブラリの特定採用を意味しない。dataclass等の型だけで実体参照・unit・不変性を保証できるとはしない。どの候補もcopy/view/lazyの所有規約が必要。

|保存候補|利点（設計上の見込み）|注意/比較点|決定先|
|---|---|---|---|
|NPZ＋metadata|既存接続の試作が容易|対象memberの部分読込・圧縮・メモリ挙動を測る。拡張子だけで意味を判定しない|D-004/T-09,T-10|
|HDF5＋metadata|chunk単位アクセスの候補|追加依存、chunk配置、writer所有、破損/中断を比較|D-004/T-09,T-10|
|配列asset分離＋manifest|参照/移送/immutable設計に合う|多数ファイル/参照解決/公開の整合性管理|D-004/T-09,T-10|

内部表現A/B/Cと保存方式の組合せは独立変数。性能比較で同時に両方を変えない。Registry/DAG/Plugin方式はこの比較から選定しない。

## 4. 判断台帳

FIX-Eは外部制約、FIX-Pは採用済みユーザー原則。EARLY/SELECTの推奨は今回の合意前の設計案。各行の「根拠」は要求R（添付指示）または上記E根拠を示す。

|ID/判断|候補・推奨|理由/得失|根拠|状態|未確認・検証方法|拘束する後工程|
|---|---|---|---|---|---|---|
|J01 外部境界|Windows/外部ファイル受領、DAQなし|既存装置を維持、直接収録は範囲外|R§2|FIX-E|実ファイル詳細は別U。D-001照合|D-001/007|
|J02 研究原則|原本保護/観察可能/追跡/独立検証/GUI分離|研究比較の必要条件|R§3|FIX-P|実現方法はT群で確認|全工程|
|J03 ID|推奨：root＋immutable revision＋derived。代替：全処理を同ID上書き|前者は比較を維持、ID管理増。後者は変更検出が困難|E03,E11,E13,E15|EARLY|登録冪等化/issuer namespaceをD-006で検証、T-08/09|入力/保存/比較|
|J04 時間|推奨：複数TimeBase、uniform/explicit/unresolved。代替：全CH単一fs|前者は実測を保持、consumerの条件検査増。後者は非同期を隠す|E08/E09,R§5.2|EARLY|CSV第1列・clock資料、T-02/07/11|窓/次数/PU解析|
|J05 区間|推奨：sample半開区間＋秒要求別記。代替：秒だけ|端点と原sample追跡が明確、変換記録は増える|E11/E14|EARLY|境界丸めpolicy、T-07|全派生API|
|J06 CH状態|推奨：availability/validity/origin分離。代替：NaN/0一本化|状態を失わない、欄は増える|E03/E07|EARLY|T-03/05/09|入力/可視化/全consumer|
|J07 pair/座標|推奨：参照整合と解析可否分離、別p/u位置。代替：共置固定|情報不足でも単独CH利用可、用途policyが必要|E04/E08/E15|EARLY|実配線/座標系未確認、T-04/12|Intensity/方向解析|
|J08 校正|推奨：domain/適用範囲/証跡/物理妥当性分離。代替：calibrated bool|TF補正の誤用を防ぐ、証拠収集の費用|E05〜10|EARLY|係数/証明書/帯域、T-08/12|校正/科学比較|
|J09 provenance|推奨：hash付親参照＋元support。代替：path文字列|移設/改変識別に有効、asset管理が必要|E11〜14|EARLY|環境再現範囲、T-07/08/09|D-004/006|
|J10 Validator|推奨：4層＋用途別3状態。代替：単一valid|部分利用と科学証拠を分離、profile定義が必要|E09/E13|EARLY|required policyの承認、T-03〜05/12|全consumer/GUI|
|J11 View実体|copy / view / lazy。推奨：immutable参照＋provider、copy基準|大容量と隔離の両立候補、alias/寿命が課題|E06,R§6|SELECT|T-06/09/10で採否|D-003/004|
|J12 内部表現|A/B/C、B暫定推奨|明示境界と既存NumPy接続の均衡|上記比較/E15|SELECT|T-01〜10、全必須ゲート|実装PoC|
|J13 保存|NPZ/HDF5/asset分離。採択保留|内部型と独立、性能・移植・破損対応で比較|E12/E13|SELECT|T-09/10、実環境予算|D-004|
|J14 版互換|推奨：major/minor対応表＋capability。代替：minor無条件許可|未知の必須意味を拒否、登録管理の負担|E12/E14/E15|EARLY|T-09/13|全Adapter/API|
|J15 metadata結合|推奨：明示測定ID＋source hash証拠。代替：ファイル名照合|誤結合を防ぐが外部ツール調整が必要|R§2.3,E13|EARLY|実照合キーU、T-05/D-001|入力/Context|
|J16 許容差/物理条件|計測精度/用途から導出。既存閾値の一括流用は非推奨|根拠を維持、実情報待ち|E08/E09|EARLY|時計/帯域/誤差budget、T-11/12|Validator/science|
|J17 実行アーキテクチャ|Registry/Runner/Artifact State再利用または別方式|既存コードへの適合を契約採用理由にしない|R§3,E13/E16|DEFER|D-003/005で独立評価|実行管理|
|J18 性能SLO|実作業予算から決定、現時点は測定比較|48k/120s/12PU固定化を避ける|R§2/10|SELECT|T-10で測定し予算を合意|D-004/GUI|
|J19 ラベル/分割|推奨：Contextの物理条件と別の実験管理参照|ラベル漏洩と校正用語混同を避ける|E12/E15/E16|EARLY|T-06、D-006分割試験|学習/評価|

## 5. 不足事実・推奨と停止範囲

|未確認|条件付きで進める設計|実装前/実測接続前に必要な確認|
|---|---|---|
|CSV第1列とRPM列|TimeBase解釈を外部parser宣言としunresolved保持|実ファイルと収録仕様でtimestamp/dt等を照合。既存2CH parserをそのまま採用しない|
|metadata照合キー|Known/Unknown bindingで合成PoCを実施可能|実施ID、原本hash、訂正/版管理手順を外部担当と確認|
|校正適用条件|domain/係数/証拠の器は設計可能|P4式、gain、期限、温度、帯域、位相極性を独立照合|
|物理位置/時計|Unknownを正しく禁止条件へ反映する比較は可能|機器仕様、CH配線表、座標frame、同期精度と実測証拠|
|過去実行の実装root|新規runへ実装refを要求可能|過去のどの結果を再利用するか決まった場合だけログ/envを追加調査|
|独立移植の完全性|再利用候補として切り分け可能|必要になった実装の依存/環境だけを確認。今回未実行|

不明項目は契約全体の検討停止理由にしない。ただし実測物理解析のReady判定をUnknownのまま通さない。実装に進む承認を本設計成果物だけで代替しない。

## 6. rev.1.1の追加判断 J20〜J25

すべてP。Fの根拠は既存E01〜E16とevidence.jsonを再利用する。新しいソース実装事実・機能Vは追加していない。各案はEARLY/SELECTのまま、承認済みFIXへ昇格させない。

|ID/事項|候補・推奨と理由|利点/費用・既存案への影響|状態|未確認・比較PoC|後工程|
|---|---|---|---|---|---|
|J20 SourceBinding|推奨：raw/derived/synthetic判別union＋ProcessingRecord ref。代替：共通辞書＋拡張、履歴だけの統一|種類ごとの欠落検査可能、variant検査は増える。CSV列必須というrev.1案を変更。E11/E13/E16と合成研究要求が根拠|EARLY|合成パラメータの監査公開範囲。T-01/06/08/09|D-003/004/006|
|J21 CH/表現識別|推奨：論理CH ID＋(root,定義revision,CH)表現ref。代替：毎回CH ID変更、独立representation UUID|同一CH比較と参照共有を両立。多対一は新CH。複合refはやや長い。rev.1の取得CH限定を一般化。E03/E06/E15|EARLY|外部ID aliasの衝突規約、T-02/07/08/09|全Adapter/保存/比較|
|J22 部分更新|推奨：新manifest＋未変更表現ref。代替：全複製、可変in-place|過去View維持・無駄な値複製なし、参照寿命管理必要。全複製も意味契約上可だが物理保存はSELECT。E06/E13|EARLY（意味）/SELECT（保存）|差分manifest解決費用、T-06/08/09/10|D-004/006|
|J23 ConsumerProfile|推奨：版付き役割/条件集合＋固定policy。代替：各consumer内の自由検査、万能条件DSL|独立一次検査と再評価可能。predicateの共通語彙管理が必要。rev.1用途判定を具体化。E09/E13|EARLY|各科学方式の帯域/同期budget、T-03/05/11/12/13|D-003/005/007|
|J24 AdapterReport|推奨：変換outcome/field disposition＋Process/Validation ref。代替：bool、全文ログ複製|形式変換と適合/科学状態を分離、参照解決の手間。rev.1 Adapter案の補強。E07/E11〜16|EARLY|旧値の復元不能判定、T-01/05/07/09/13|D-003/004|
|J25 Core境界|推奨：同一契約内必須性/Unknown/capability。代替：Coreと各用途の巨大別schema、全欄必須|最小取込が可能、用途条件を別検査する必要。原本/CH/time/unitの意味は省かない。E03/E09/E15|EARLY|最小validatorの実装負担、T-01/03/05/13|全工程|

### J01〜J19の継承・解釈更新

|既存ID|rev.1.1での扱い・理由|既存選択肢/状態への影響|
|---|---|---|
|J01/J02|外部制約と原本保護等をそのまま維持|FIX-E/FIX-Pのみ継承|
|J03|root/revision維持、派生IDはrevisionのalias可、合成根を追加|EARLY維持。J21へ具体化、ID乱増を避ける|
|J04/J05|複数TimeBase/半開区間維持。一部resampleで相対同期を再評価|EARLY維持、T-02/07/11|
|J06|availability/validity/origin維持。excludedとmissingを分離|EARLY維持、J21/J22|
|J07|pair/解析可否分離維持。derived logical CHに架空sensorを与えない|EARLY維持|
|J08|校正のdomain/証拠/妥当性分離維持。部分CH/区間の適用scopeを明確化|EARLY維持、T-08|
|J09|hash/親support維持、合成親も必須追跡|EARLY維持、J20/J24|
|J10|4層/3状態維持、必須/助言条件と矛盾証拠処理を具体化|EARLY維持、J23|
|J11/J12/J13|copy/view/lazy、A/B/C、保存候補を維持|SELECT維持。参照共有は意味契約で保存採用ではない|
|J14|対応版/capabilityの明示拒否維持|EARLY維持、文書rev.1.1とpayload版を区別|
|J15/J16|metadata binding/実測budget未確定を維持|EARLY維持、既定値補完禁止|
|J17|実行基盤の採用は決めない|DEFER維持|
|J18|性能SLOは比較と作業予算で決める|SELECT維持|
|J19|truth/分割隔離維持、生成設定への監査refをモデル特徴へ渡さない|EARLY維持、T-06/08|

### As-Isとの適合性と未確認

E03/E06のCH状態/immutable snapshotは新案の発想を支えるが、論理CH/representation refや部分Revision manifestが既存に実装済みとは言わない。E13の用途policyはConsumerProfileそのものではない。E15のNV校正宣言はCalibrationRecordの完全証拠を満たさない。新案に合わせて既存C01〜C08/schema1.0を変更しない。

新規設計の未確認は、(1)表現参照共有の保存費用、(2)profileに必要な実機同期/校正budget、(3)旧artifactで実際に失われた元区間、(4)生成器の再現範囲である。順にT-09/10、D-001実資料＋T-11/12、必要な既存成果物のみの調査、T-06/08で確認する。追加の広域コード調査を前提にしない。
