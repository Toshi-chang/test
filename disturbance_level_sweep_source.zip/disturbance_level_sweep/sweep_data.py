"""Linear p/U superposition for an amplitude-only controlled synthetic experiment."""
from pathlib import Path
import copy,shutil
import numpy as np
from bridge.adapter import DistributedAdapter,read,write,sha
from bridge.dataset import region

def pressure_from_db(db,pref=2e-5):return pref*10**(float(db)/20)
def db_from_pressure(p,pref=2e-5):return None if p==0 else float(20*np.log10(p/pref))
def mix_field(normal,external,gain):return normal+gain*external

def build(reference,output,protocol):
    reference=Path(reference).resolve();root=Path(output).resolve()
    if root.exists():raise ValueError('fresh dataset directory required')
    if protocol.get('schema_version')!='disturbance-level-sweep/1.0':raise ValueError('unknown sweep schema')
    levels=protocol['levels_db_spl'];pref=protocol['reference_pressure_pa']
    if not levels or not all(np.isfinite(x) for x in levels) or levels!=sorted(set(levels)) or pref!=2e-5 or protocol['include_no_added_disturbance'] is not True:raise ValueError('invalid level protocol')
    root.mkdir(parents=True);canonical=root/'canonical';canonical.mkdir()
    train=read(reference/'canonical/train_manifest.json')
    for item in train['measurements']:
        for k in ['source_path','metadata_path']:
            p=reference/'canonical'/item[k];q=canonical/item[k];shutil.copyfile(p,q)
            if sha(p)!=sha(q):raise AssertionError('training copy changed')
    write(canonical/'train_manifest.json',train)
    base_truth=read(reference/'canonical/truth.json')
    normal_cases=[c for c in base_truth['cases'] if c['scenario']=='normal']
    disturbance_cases={c['independent_family_id']:c for c in base_truth['cases'] if c['scenario']=='disturbance'}
    cfg=read(reference/'generation.json');mode_count=len(cfg['modes']);entries=[];refs=[];cases=[];case_levels=[];acoustic=[];max_error=0.
    level_values=[None]+levels
    for fi,normal_case in enumerate(normal_cases):
        family=normal_case['independent_family_id'];ext_case=disturbance_cases[family]
        for li,level in enumerate(level_values):
            sid=f'sweep_f{fi:03d}_l{li:03d}';cid=f'case_f{fi:03d}_l{li:03d}'
            ct={'specimen_id':sid,'case_id':cid,'label':'normal','scenario':'normal_level_sweep','independent_family_id':family,'regions':[],'normal_events':[]}
            case_levels.append({'case_id':cid,'specimen_id':sid,'family':family,'level_index':li,'requested_db_spl':level,
                'requested_external_p_rms_pa':0 if level is None else pressure_from_db(level,pref)})
            for mi in range(mode_count):
                nr=reference/'raw'/f'{normal_case["case_id"]}_m{mi}'
                er=reference/'raw'/f'{ext_case["case_id"]}_m{mi}'
                acquisition=read(nr/'acquisition.json');fs=acquisition['sample_rate_hz'];n=acquisition['n_samples']
                ids=[r['id'] for r in acquisition['receivers']];reference_index=ids.index(protocol['reference_receiver_id'])
                scene=read(er/'scene.json');ext_ids=[i for i,s in enumerate(scene['sources']) if s['id']=='external_extra']
                if len(ext_ids)!=1:raise ValueError('exactly one external source required')
                with np.load(nr/'observations.npz',allow_pickle=False) as z:normal={k:z[k].copy() for k in z.files}
                with np.load(er/'generator_truth.npz',allow_pickle=False) as z:
                    pext=z['source_pressure_pa'][ext_ids[0]].copy();uext=z['source_velocity_m_s'][ext_ids[0]].copy()
                rms=float(np.sqrt(np.mean(pext[:,reference_index]**2)))
                if rms<=0:raise ValueError('zero reference source pressure')
                target=0 if level is None else pressure_from_db(level,pref);gain=target/rms
                p=mix_field(normal['pressure_pa'],pext,gain);u=mix_field(normal['velocity_m_s'],uext,gain)
                axes=np.asarray([r['axis'] for r in acquisition['receivers']]);axial=np.einsum('nri,ri->nr',u,axes)
                ext_axial=np.einsum('nri,ri->nr',uext,axes)*gain
                if level is None:
                    np.testing.assert_array_equal(p,normal['pressure_pa']);np.testing.assert_array_equal(axial,normal['axial_velocity_m_s'])
                actual=float(np.sqrt(np.mean((pext[:,reference_index]*gain)**2)))
                np.testing.assert_allclose(actual,target,rtol=1e-12,atol=1e-15)
                max_error=max(max_error,abs(actual-target))
                raw=root/'observations'/f'{cid}_m{mi}';raw.mkdir(parents=True)
                np.savez_compressed(raw/'observations.npz',time_s=normal['time_s'],pressure_pa=p,velocity_m_s=u,axial_velocity_m_s=axial)
                shutil.copyfile(nr/'rpm_observation.npz',raw/'rpm_observation.npz')
                acquisition['observations']={'path':'observations.npz','sha256':sha(raw/'observations.npz')}
                acquisition['rpm']={'path':'rpm_observation.npz','sha256':sha(raw/'rpm_observation.npz')}
                write(raw/'acquisition.json',acquisition)
                items,origin=DistributedAdapter().convert(raw/'acquisition.json',canonical,{'specimen_id':sid,'case_id':cid,'derived_group_id':family,'capture_id':f'{cid}_m{mi}'})
                entries+=items;refs+=origin
                for ri,receiver in enumerate(acquisition['receivers']):
                    ext_rms=float(np.sqrt(np.mean((gain*pext[:,ri])**2)));normal_rms=float(np.sqrt(np.mean(normal['pressure_pa'][:,ri]**2)))
                    acoustic.append({'case_id':cid,'measurement_id':origin[ri]['measurement_id'],'receiver_id':receiver['id'],'mode':cfg['modes'][mi]['name'],
                        'requested_reference_db_spl':level,'gain':gain,'nominal_source_drive_rms_m3_s':scene['sources'][ext_ids[0]]['drive_rms'],
                        'scaled_source_drive_rms_m3_s':scene['sources'][ext_ids[0]]['drive_rms']*gain,
                        'external_p_rms_pa':ext_rms,'external_db_spl':db_from_pressure(ext_rms,pref),
                        'normal_observation_p_rms_pa':normal_rms,'mixture_p_rms_pa':float(np.sqrt(np.mean(p[:,ri]**2))),
                        'normal_to_added_disturbance_db':None if ext_rms==0 else float(20*np.log10(normal_rms/ext_rms)),
                        'normal_source_sha256':sha(nr/'observations.npz'),'external_truth_sha256':sha(er/'generator_truth.npz')})
                    if gain>0:
                        span=region(np.column_stack([pext[:,ri]*gain,ext_axial[:,ri]]),fs)
                        if span:span.update(measurement_id=origin[ri]['measurement_id'],kind='disturbance',role='disturbance');ct['regions'].append(span)
                    old_mid=f'{normal_case["case_id"]}_m{mi}_{receiver["id"]}'
                    for span in normal_case['normal_events']:
                        if span['measurement_id']==old_mid:
                            record=copy.deepcopy(span);record['measurement_id']=origin[ri]['measurement_id'];ct['normal_events'].append(record)
            cases.append(ct)
    write(canonical/'eval_manifest.json',{'schema_version':'1.0','role':'eval','normal_only_attested':False,'measurements':entries})
    write(canonical/'truth.json',{'schema_version':'1.0','cases':cases,'training_cases':base_truth['training_cases'],
        'model_limit':'normal target; added source amplitude sweep; no target fault or physical enclosure model'})
    write(root/'protocol.json',protocol);write(root/'case_levels.json',case_levels);write(root/'acoustic_levels.json',acoustic)
    write(root/'conversion_index.json',{'schema_version':'distributed-conversion/1.0','measurements':refs})
    write(root/'generation_validation.json',{'status':'passed','independent_families':len(normal_cases),'levels_including_zero':len(level_values),
        'eval_cases':len(cases),'eval_measurements':len(entries),'max_reference_rms_error_pa':max_error,
        'normal_component':'unchanged per family/mode across all levels','p_u_gain':'same scalar for pressure and all velocity components',
        'no_added_disturbance':'exact observed p/u equality verified','training':'copied unchanged'})
    return canonical
