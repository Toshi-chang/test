"""Independent RA candidate acceptance. Generates observations through InputAdapter."""
import copy
from pathlib import Path
import unittest
import uuid
import numpy as np
from nv_runner.acoustic_generator import generate_acoustic, acoustic_settings
from nv_runner.common import read_json, write_json
from nv_runner.input_adapter import InputAdapter, DatasetPlanner
from nv_runner.profiles import acoustic_experiment
from nv_runner.route_a_candidate import FixedWindowCandidate, validate_candidate_config
from nv_runner.routes import FixedWindow
from nv_runner.signals import SignalService

ROOT = Path(__file__).resolve().parents[1]


class RouteCandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = ROOT / 'tests/_work/RA' / uuid.uuid4().hex
        cls.root.mkdir(parents=True)
        settings = acoustic_settings('quick')
        settings.update(train_specimens=6, duration_seconds=3)
        write_json(cls.root / 'generation.json', settings)
        generate_acoustic(cls.root / 'data', settings)
        cls.train = InputAdapter().load(cls.root / 'data/train_manifest.json')
        cls.evaluation = InputAdapter().load(cls.root / 'data/eval_manifest.json')
        experiment = acoustic_experiment('data', 'runs')
        cls.fit_records, cls.cal_records, split = DatasetPlanner().plan(cls.train, cls.evaluation, experiment['split'], 42)
        write_json(cls.root / 'split.json', split)
        cls.config = read_json(ROOT / 'configs/parallel/route_a_candidate.json')
        cls.config['model']['n_estimators'] = 16
        write_json(cls.root / 'route.json', cls.config)
        cls.service = SignalService(experiment['signal'])
        cls.route = FixedWindowCandidate(cls.config)
        cls.fit = cls.route.prepare(cls.fit_records, cls.service)
        cls.cal = cls.route.prepare(cls.cal_records, cls.service)
        cls.evaluation_prepared = cls.route.prepare(cls.evaluation, cls.service)
        cls.model = cls.route.fit(cls.fit, cls.config['model'], 42)
        cls.model.save(cls.root / 'model.joblib')
        cal_results = cls.route.score(cls.model, cls.cal)
        cls.threshold = cls.route.calibrate(cls.route.aggregate(cls.cal, cal_results, cls.cal_records), experiment['calibration'])
        write_json(cls.root / 'threshold.json', cls.threshold)

    def test_01_features_and_coordinates_match_legacy_computation(self):
        # Same config for semantic oracle only: production A uses its own plugin/key.
        baseline = FixedWindow(self.config)
        legacy = baseline.prepare(self.evaluation, self.service)
        candidate = self.evaluation_prepared
        self.assertEqual(baseline.feature_schema(), self.route.feature_schema())
        self.assertEqual(legacy.samples, candidate.samples)
        self.assertEqual(legacy.coverage, candidate.coverage)
        for sid in legacy.values:
            np.testing.assert_allclose(candidate.values[sid], legacy.values[sid], rtol=1e-12, atol=1e-12)

    def test_02_actual_fit_calibration_and_evaluation(self):
        scored = self.route.score(self.model, self.evaluation_prepared)
        self.assertEqual(self.threshold['status'], 'available')
        self.assertTrue(all(r['status'] == 'scored' for r in scored))
        self.assertGreater(np.std([r['anomaly_score'] for r in scored]), 0)
        cases = self.route.decide(self.route.aggregate(self.evaluation_prepared, scored, self.evaluation), self.threshold)
        self.assertEqual(len(cases), 7)
        self.assertTrue(all(r['decision'] in {'within', 'outside'} for r in cases))
        write_json(self.root / 'sample_results.json', scored)
        write_json(self.root / 'case_results.json', cases)

    def test_03_shuffle_and_batches_preserve_id_score_pairs(self):
        shuffled = self.route.prepare(list(reversed(self.evaluation)), self.service)
        shuffled.samples.reverse()
        first = {r['sample_id']: r['anomaly_score'] for r in self.route.score(self.model, self.evaluation_prepared, 1)}
        second = {r['sample_id']: r['anomaly_score'] for r in self.route.score(self.model, shuffled, 7)}
        self.assertEqual(first.keys(), second.keys())
        np.testing.assert_allclose([first[k] for k in sorted(first)], [second[k] for k in sorted(second)], rtol=1e-12, atol=1e-12)

    def test_04_inputs_and_maps_not_mutated(self):
        record = self.evaluation[0]
        original_meta, original_wave = copy.deepcopy(record.meta), record.signals.copy()
        maps = self.service.maps(record)
        snapshots = {k: v.copy() for k, v in maps.items()}
        self.route.prepare([record], self.service)
        self.assertEqual(original_meta, record.meta)
        np.testing.assert_array_equal(original_wave, record.signals)
        for key in maps:
            np.testing.assert_array_equal(snapshots[key], maps[key])

    def test_05_short_record_untrained_and_invalid_range(self):
        short = copy.deepcopy(self.evaluation[0])
        short.signals = short.signals[:10]
        short.meta['n_samples'] = 10
        prepared = self.route.prepare([short], self.service)
        self.assertEqual(prepared.samples, [])
        self.assertEqual(prepared.coverage[short.meta['measurement_id']]['reason'], 'too_short')
        rows = self.route.aggregate(prepared, [], [short])
        self.assertIsNone(rows[0]['case_score'])
        self.assertEqual(rows[0]['decision'], 'undetermined')
        invalid = copy.deepcopy(self.evaluation[0])
        invalid.meta['validity'] = [{'start_sample': 0, 'end_sample': len(invalid.signals), 'reason': 'test invalid'}]
        prepared = self.route.prepare([invalid], self.service)
        scored = self.route.score(self.model, prepared)
        self.assertTrue(all(r['anomaly_score'] is None and r['reason'] == 'invalid_input_range' for r in scored))
        untrained = self.route.score(None, self.evaluation_prepared)
        self.assertTrue(all(r['anomaly_score'] is None and r['reason'] == 'model_untrained' for r in untrained))

    def test_06_bad_config_and_unsupported_selection_rejected(self):
        for field, value in [('window_seconds', True), ('window_seconds', float('nan')),
                             ('window_seconds', 0), ('hop_seconds', -1), ('hop_seconds', '1'),
                             ('selection', {'enabled': True}), ('selection', {'enabled': 0})]:
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                config = copy.deepcopy(self.config)
                config[field] = value
                validate_candidate_config(config)
        config = copy.deepcopy(self.config)
        config['window_seconds'] = 2 / 1024
        with self.assertRaisesRegex(ValueError, 'three samples'):
            FixedWindowCandidate(config).prepare(self.evaluation, self.service)

    def test_07_actual_route_config_separates_ids_without_losing_coordinates(self):
        legacy_config = {**self.config, 'plugin': 'fixed_window', 'key': 'A_full'}
        legacy = FixedWindow(legacy_config).prepare(self.evaluation, self.service)
        candidate = self.evaluation_prepared
        self.assertTrue(set(legacy.values).isdisjoint(candidate.values))
        for old, new in zip(legacy.samples, candidate.samples):
            for key in ('measurement_id', 'case_id', 'specimen_id', 'start_sample', 'end_sample',
                        'support_start_sample', 'support_end_sample', 'frequency_hz', 'display_center_seconds'):
                self.assertEqual(old[key], new[key])

    def test_08_pca_and_failed_features_preserve_states(self):
        model = self.route.fit(self.fit, {'kind': 'pca', 'components': 4, 'min_samples': 5}, 42)
        scored = self.route.score(model, self.evaluation_prepared)
        self.assertTrue(all(np.isfinite(r['anomaly_score']) for r in scored))
        # Deliberately malformed direct record: production InputAdapter already rejects NaN.
        malformed = copy.deepcopy(self.evaluation[0])
        malformed.signals[:] = np.nan
        prepared = self.route.prepare([malformed], self.service)
        self.assertFalse(prepared.values)
        self.assertTrue(all(s['reason'] == 'non_finite_features' for s in prepared.samples))
        with self.assertRaisesRegex(ValueError, '^insufficient_training_samples$'):
            self.route.fit(prepared, self.config['model'], 42)

    def test_09_chunk_boundary_and_odd_window_width(self):
        config = {**self.config, 'window_seconds': 129 / 1024, 'hop_seconds': 10 / 1024}
        candidate = FixedWindowCandidate(config).prepare(self.evaluation[:1], self.service)
        legacy = FixedWindow(config).prepare(self.evaluation[:1], self.service)
        self.assertGreater(len(candidate.samples), 64)
        self.assertEqual(candidate.samples, legacy.samples)
        for sid in candidate.values:
            np.testing.assert_allclose(candidate.values[sid], legacy.values[sid], rtol=1e-12, atol=1e-12)

    def test_10_legacy_lifecycle_equivalence_under_matched_ids(self):
        # Route config is matched deliberately so sample-ID sorting does not confound training.
        legacy = FixedWindow(self.config)
        fit = legacy.prepare(self.fit_records, self.service)
        cal = legacy.prepare(self.cal_records, self.service)
        evaluation = legacy.prepare(self.evaluation, self.service)
        model = legacy.fit(fit, self.config['model'], 42)
        old_scores = legacy.score(model, evaluation)
        new_scores = self.route.score(self.model, self.evaluation_prepared)
        np.testing.assert_allclose([r['anomaly_score'] for r in old_scores],
                                   [r['anomaly_score'] for r in new_scores], rtol=1e-12, atol=1e-12)
        old_threshold = legacy.calibrate(legacy.aggregate(cal, legacy.score(model, cal), self.cal_records),
                                         {'quantile': .95, 'min_specimens': 2})
        self.assertEqual(old_threshold, self.threshold)
        old_cases = legacy.decide(legacy.aggregate(evaluation, old_scores, self.evaluation), old_threshold)
        new_cases = self.route.decide(self.route.aggregate(self.evaluation_prepared, new_scores, self.evaluation), self.threshold)
        self.assertEqual(old_cases, new_cases)
        write_json(self.root / 'legacy_comparison.json', {
            'samples_compared': len(old_scores), 'cases_compared': len(old_cases),
            'same_config_ids': True, 'threshold_equal': True, 'cases_equal': True,
            'score_rtol': 1e-12, 'score_atol': 1e-12,
            'note': 'Production candidate key/plugin differ; their ID-based fit ordering can change IF scores.'})


if __name__ == '__main__':
    unittest.main()
