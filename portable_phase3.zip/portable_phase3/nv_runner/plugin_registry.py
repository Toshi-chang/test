"""Explicit, lazy registry of trusted Python declarations.

Entrypoints come only from register(PluginDescriptor(...)), never config data.
Registration checks declarations; selected-route preflight resolves dependencies
and checks the actual lifecycle call signatures without preparing or fitting.
"""
from collections.abc import Mapping
from copy import deepcopy
import importlib
import inspect
import re
from .plugin_descriptor import PluginDescriptor
from .plugin_validation import validate_schema, validate_route_config


_ENTRYPOINT = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*:[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\Z")
# Positional argument counts on bound methods, matching the current runner.
_CALLS = {"capabilities": 0, "feature_schema": 0, "prepare": 2,
          "fit": 3, "score": 3, "aggregate": 3, "calibrate": 2, "decide": 2}


def _entrypoint(value):
    if not isinstance(value, str) or not _ENTRYPOINT.fullmatch(value):
        raise ValueError("entrypoint must be a trusted module:attribute declaration")


def _resolve(value):
    module, attribute = value.split(":")
    try:
        result = importlib.import_module(module)
        for part in attribute.split("."):
            result = getattr(result, part)
    except Exception as exc:
        raise ValueError(f"plugin entrypoint unavailable: {value}: {exc}") from exc
    if not callable(result):
        raise ValueError(f"plugin entrypoint is not callable: {value}")
    return result


class PluginRegistry(Mapping):
    def __init__(self, descriptors=()):
        self._descriptors = {}
        for descriptor in descriptors:
            self.register(descriptor)

    def register(self, descriptor):
        if not isinstance(descriptor, PluginDescriptor):
            raise ValueError("registration requires PluginDescriptor from trusted code")
        if not isinstance(descriptor.plugin_id, str) or not re.fullmatch(r"[A-Za-z0-9_]+", descriptor.plugin_id):
            raise ValueError("invalid plugin_id")
        if descriptor.plugin_id in self._descriptors:
            raise ValueError(f"duplicate plugin: {descriptor.plugin_id}")
        if not isinstance(descriptor.implementation_version, str) or not descriptor.implementation_version:
            raise ValueError("implementation_version must be a nonempty string")
        if descriptor.api_version != "1.0" or descriptor.descriptor_version != "1.0":
            raise ValueError("unsupported plugin API/descriptor version")
        if descriptor.input_contracts != {"C01": "1.0", "C02": "1.0"} or descriptor.output_contracts != {"C03": "1.0", "C05": "1.0"} or descriptor.model_contract != "C04@1.0":
            raise ValueError("unsupported plugin contracts")
        _entrypoint(descriptor.factory)
        if descriptor.validator is not None:
            _entrypoint(descriptor.validator)
        validate_schema(descriptor.config_schema)
        if descriptor.config_schema.get("type") != "object":
            raise ValueError("route configuration schema must declare type object")
        # Callers cannot subsequently mutate the registered contract dictionaries.
        self._descriptors[descriptor.plugin_id] = deepcopy(descriptor)

    def unregister(self, plugin_id):
        del self._descriptors[plugin_id]

    def get_descriptor(self, plugin_id):
        return deepcopy(self._descriptors[plugin_id])

    def __len__(self):
        return len(self._descriptors)

    def __iter__(self):
        return iter(self._descriptors)

    def __contains__(self, plugin_id):
        return plugin_id in self._descriptors

    def __getitem__(self, plugin_id):
        # Lookup, iteration and membership never import any plugin.
        self._descriptors[plugin_id]

        def create(config):
            if config.get("plugin") != plugin_id:
                raise ValueError("factory/config plugin mismatch")
            return self._create(config)
        return create

    def _create(self, config):
        plugin_id = config.get("plugin")
        if plugin_id not in self:
            raise ValueError(f"enabled plugin not implemented: {plugin_id}")
        descriptor = self._descriptors[plugin_id]
        if "implementation_version" in config and config["implementation_version"] != descriptor.implementation_version:
            raise ValueError(f"plugin implementation version mismatch: {plugin_id}")
        validate_route_config(config, descriptor.config_schema)
        if descriptor.validator:
            _resolve(descriptor.validator)(config)
        factory = _resolve(descriptor.factory)
        try:
            inspect.signature(factory).bind(config)
            instance = factory(config)
            for name, count in _CALLS.items():
                method = getattr(instance, name, None)
                if not callable(method):
                    raise ValueError(f"missing route method: {name}")
                inspect.signature(method).bind(*([None] * count))
        except Exception as exc:
            raise ValueError(f"invalid route lifecycle for {plugin_id}: {exc}") from exc
        return instance

    def validate(self, config):
        if not config.get("enabled", True):
            return
        self._create(config)
