# Application Service最小契約案

2026-10-16 / proposal 0.1。**以下のService API・DTO・worker protocolは未実装**。coreの新APIとして扱わない。既存呼出しとの対応は [開発規則](APPLICATION_INTEGRATION_RULES.md) に記載した。Serviceをアプリ側に新設することで、初版にcoreのAPI変更は不要。

## 1. 実装配置と通信

GUIがimportできるのは `application.service` のFacade/DTOだけ。FacadeはGUIフレームワーク非依存とし、I/Oを子プロセス/監視処理へ移す。workerのcore_adapterのみnv_runnerをimportする。信頼済みcompositionで拡張を登録してから検証・実行する。登録はプロセス開始時に1回、実行中は固定する。

最小transportはジョブディレクトリ内の版付きJSON request/responseと別stdout/stderrログ。JSONはUTF-8、非有限数禁止。responseは一時ファイルからrenameし、job_idを照合する。stdoutの最後の行を完了protocolにしない。worker終了後にresponseとBundleを照合する。パスは設定済みアプリworkspace内へ解決し、ファイルの信頼・原本参照はローカル運用規則に従う。これはコードsandboxではない。

## 2. 最小Facade（提案）

各submit呼出しはjob_idを返して速やかに戻る。起動時の明白な不正要求のみ同期エラー。処理結果はpoll経由。Pythonの署名を表す疑似コードであり現行クラスではない。

|操作|入力→出力|workerで使う現行機能|
|---|---|---|
|`submit_catalog()`|なし→job_id|catalogのiteration/get_descriptor。全pluginのvalidateはしない。|
|`submit_validation(request)`|RunRequest→job_id|設定snapshot保存→validate_config(path)。実行時にも再検証する。|
|`submit_run(request)`|RunRequest→job_id|validate_config/ExperimentRunner.execute。既存execute自身も再検証する。|
|`submit_open(bundle_path)`|確定Bundleパス→job_id|BundleReader(path).validate→ResultView。|
|`submit_evidence(bundle_ref,sample_id)`|検証済みBundle参照とID→job_id|再検証したtables/artifacts/NPZの読取→EvidenceView。新しい解析はしない。|
|`poll(job_id)`|job_id→JobSnapshot|Service所有の状態・結果・診断。未登録IDはエラー。|

EvaluationAdapterの受渡しが必要なアプリでは将来 `submit_export(bundle_ref,destination,path_mapping)` を追加する。初版必須APIに含めない。cancel/resume/progress-stream/model-loadは未実装・非公開とし、実装なしのボタンを提供しない。

## 3. DTO版と必要項目

Service JSONに `service_contract_version: "0.1"` を必須とする。未知版は実行前拒否。coreの `schema_version: "1.0"` とは別物で、BundleへService版を書き足さない。

**RunRequest**：`service_contract_version`, `experiment`（既存experiment JSON構造）, `path_base`（選択元設定/参照の基準ディレクトリ）, `request_id`（アプリのopaque ID）。Serviceは担当workspace内にジョブ固有の出力先を割当てる。train_manifest/eval_manifest/truth_path等の相対参照を新設定保存位置に正しく変換し、元設定と解決後設定を監査保存する。seed・signal・split・calibration・model・selectionは既存値を変更しない。output先等の運用値変更は記録する。学習正常宣誓をGUIが自動的にtrueへ補完しない。

`routes` は既存配列のまま、key/plugin/enabled/実装版指定と固有設定を保持。複数Plugin/同Pluginの複数keyに対応する。enabled=falseでもkey重複/不正は既存検証で拒否される。実装のfactory名をRunRequestへ受け付けない。全経路無効をcoreは必ずしも拒否しないので、GUIの「解析開始」は少なくとも1有効経路を要求する。これはアプリ操作上の制約でありcore Validatorの変更ではない。

**CatalogView**：登録ID、実装版、descriptor/API版、入出力/model契約、config_schema。factory/validatorの実行やcapabilities呼出しで一覧を作らない。schemaにない画面ラベル等はアプリ側の表示定義とする。schemaは限定機能であり、完全JSON Schema UI generatorを前提にしない。

**ValidationView**：`valid`, `errors`, `warnings`, `config_digest`, `core_identity`, 件数/分割の要約。train/eval波形やモデルをGUIへ渡さない。validation成功後に入力が変わることを考慮し、実行でも再検証し設定digestの対応を確認する。原本ファイルの実行中変更は許可しない。

**JobSnapshot**：`service_contract_version`, `job_id`, `request_id`, `operation`, `state`, `stage`, `bundle_ref|null`, `result|null`, `error|null`, `log_ref`, `created_at`, `finished_at|null`。timestampはUTC ISO8601、画面でローカル表示してよい。job_idはcore run_idとは別。run_idは確定Bundle検証後に取得する。errorはアプリのcategory（validation/compatibility/execution/bundle_validation/protocol/worker_exit）、message、traceback/log参照を持ち、core例外型やreason文字列を保存する。core typed error APIは存在しない。

## 4. 状態遷移と判定

アプリjob state：`queued → running → succeeded | partial | failed | interrupted`。validation/catalog/open/evidenceも同じ機構を使うがpartialは解析結果が部分Bundleの場合に用いる。未知状態はprotocolエラーとして拒否。stageはアプリの `queued/preflight/executing/reading/done` 程度とし、core内部の工程進捗や百分率を捏造しない。ログは診断表示であって安定した進捗イベントではない。

|観測|アプリの扱い|
|---|---|
|executeが返り、worker正常終了、応答整合、Reader valid、complete、cancelled=false|succeeded。ただし「実行完了」であり「正常個体」とは表示しない。未評価件数・coverage・decisionを併記。|
|同条件でBundle partial、cancelled=false|partial。処理済み経路と失敗/未完了経路を表示。|
|確定Bundleにcancelled=true|interrupted。Bundleが読めるなら部分結果として提供、通常成功としない。|
|検証拒否、例外、Bundle破損/版不一致|failed。診断と出力有無を保持。|
|worker強制終了、応答なし、Service再起動時の未完了job|interrupted。stagingを読取対象にしない。終了コードだけでcancelledと断定しない。|

valid Bundleがあるのにプロセスが異常終了した場合は通常成功へ昇格させず、interruptedと結果存在を併記し、別のopen操作で検証済み結果を読む。起動中jobの自動再実行はしない。新requestで全工程をやり直す。

Bundle `complete` は経路処理の完了で、モデル不足・入力未評価・undeterminedを排除しない。GUIはmanifest状態、execution_status、coverage_status、decision、sample statusを独立に表示する。score nullを0へ変換しない。融合無効のcase_resultsを全個体正常とみなさない。

## 5. 保存結果の読取モデル

**ResultView**：Bundle識別（run_id、manifest SHA、schema版）、requested/completed routes、bundle_status/cancelled、errors、route_case_results、specimens/casesの対応、sample/result参照、保存metricsの個体別結果、threshold/artifact参照。元dict/ndarrayの可変参照をUIへ共有せず、コピーしたDTOを返す。paginationはアプリ内表示最適化として追加可能だが、全件数・フィルター・IDを明示する。

**EvidenceView**：sample_id/measurement_id/case_id/specimen_id/route_key、半開start/end_sample、support_start/end_sample、frequency_hz、display_center_seconds、センサー位置/方向、timebase、運転条件、selection maskと切出し範囲を分けて返す。artifactの記録済みarray descriptorを参照し `allow_pickle=False` で読む。信号snapshotと任意PU診断/真値は存在を確認し、不在はavailable=falseと理由で返す。IDを行番号や並び順から推定しない。

現行表示座標はsample/fs基準の箇所がある。timebase.start_secondsを暗黙に加算して意味を変えず、経過時間と絶対時刻を分ける。科学的な変換/新指標が必要なら共通側の専用機能として扱う。真値overlayには「生成器の正解」、model根拠には「推論結果」を表示する。

BundleReaderは配列/参照/ハッシュを検証するが、任意の新GUIに必要な全artifact存在を保証するものではない。表示に必要なsignal artifact等はServiceが追加確認し、不足領域を明示する。元測定がなくても保存snapshotがあれば表示できる。原本欠落と保存結果欠落を混同しない。Readerはjoblibをunpickleしない。GUI/Serviceも閲覧のためモデルをロードしない。

Bundleは不変。画面選択/ブックマーク/キャッシュ/受領記録はBundle外。再検証時にhashが変わったら別内容として拒否し、キャッシュを破棄する。

## 6. 互換性ハンドシェイク（アプリ側に新設）

worker起動時にcoreの `__version__`, `SCHEMA_VERSION` と配布ハッシュ集合、実行Python/依存版、Service契約版を互換表に照合する。catalogのDescriptor版/契約は登録時のcore検査を利用し、選択実装版はconfigのimplementation_versionで固定可能。未知coreハッシュを同じ0.2.0という理由だけで許可しない。

互換表は統合担当が試験成功後に更新する。新Pluginの登録追加は固定core＋別extensionハッシュとして記録できる。GUIはworker実装のimport pathやbase classへ依存しない。このハンドシェイク、job DTO、worker protocol、read-model APIは新Serviceで実装する最小追加であり、coreには同名APIはない。

## 7. 保存・例外・試験

ジョブ外側にrequest、resolved experiment、core/extension identity、job状態、response、stdout/stderrを保存する。coreには固有output_dirを渡し、生成Bundle内のモデル・前処理・分割・閾値を再編集しない。例外クラスはValueErrorに限定せずI/O/KeyError等も捕捉し、原因を残す。採番だけ完了して応答が途切れたjobを正常扱いしない。

必要試験は [gui_integration_test_plan.md](../templates/gui_integration_test_plan.md)。mockテストだけでは実解析の受入にならない。共通契約への変更が必要になるまで、上記アプリ内契約の実装を独立して開始できる。
