import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('scope',ROOT/'tools/check_workstream_scope.py')
scope=importlib.util.module_from_spec(spec); spec.loader.exec_module(scope)

class Ownership(unittest.TestCase):
    def test_exclusive_and_shared_paths(self):
        policy=json.loads((ROOT/'development/ownership.json').read_text(encoding='utf-8'))
        for owner,paths in policy['owners'].items():
            for path in paths:
                sample=path.replace('*','example')
                self.assertTrue(scope.permitted(owner,sample,policy),(owner,sample))
                self.assertEqual([o for o in policy['owners'] if scope.permitted(o,sample,policy)],[owner])
        self.assertFalse(scope.permitted('RA','nv_runner/routes.py',policy))
        self.assertTrue(scope.permitted('I','nv_runner/routes.py',policy))

    def test_frozen_and_escaping_paths(self):
        policy=json.loads((ROOT/'development/ownership.json').read_text(encoding='utf-8'))
        for path in ('tests/test_acceptance.py','docs/parallel_contracts/CONTRACTS_MINIMUM.md','../nv_runner/selection.py','C:/outside','/outside','nv_runner/../nv_runner/selection.py'):
            for owner in policy['owners']:
                self.assertFalse(scope.permitted(owner,path,policy))
