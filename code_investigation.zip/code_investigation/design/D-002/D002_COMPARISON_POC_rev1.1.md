# D-002 比較PoC・採否計画

2026-10-20 / rev.1.1 **設計のみ。全T項目未実施。試験コードも作成していない。** [契約案](D002_DESIGN_rev1.1.md)と[判断台帳](D002_ASIS_DECISIONS_rev1.1.md)のEARLY/SELECTを判断するための計画であり、既存テストの成功記録ではない。

## 1. 共通実験規約（P）

- 比較対象A=NumPy＋辞書、B=NumPy＋型付き構造、C=xarray中心。同じ意味Validator/profile/fixtureを使用し、内部表現だけを変える。特定候補のライブラリ既定値を正解にしない。
- 初期fixtureは計測器再現ではなく契約用の決定論的値列を用いる。例：sample iの識別値、既知区間の欠損、既知sensor/CH対応。乱数不要。ノイズ/性能fixtureで使うなら**提案seed 20020、RNG方式/ライブラリ版/生成設定を保存**し、過去検証seedとは扱わない。
- 学習・推論は今回の比較PoCの対象外。fit/cal/evalやモデル閾値を契約試験へ混ぜない。物理正解を必要とする校正試験は別の科学検証とする。
- 小fixture例：fs=1000 Hz、N=30000、30秒、float64、local origin=0。これは任意の契約試験値であり実機仕様ではない。別値・別dtype・別CH数も追加する。
- ID、enum、単位、親参照、整数sample範囲、非演算copyのbytesは完全一致。数値演算を含む比較は誤差budgetを方式/dtype/長さから事前定義し、根拠未設定なら数値同等性を合格としない。
- `acceptance.json`相当の結果記録にはcandidate、fixture hash、環境/実装版、操作、観測値、期待値、判定、理由、未実施/阻害条件を保存する計画。成果物・stdout/例外・時間/RSS測定方法も残す。保存先の標準化はD-004で決める。
- 機能合否は必須ゲートで判定し、性能点で相殺しない。性能は測定後に利用者の作業予算と比較する。数値/性能の根拠が未定なら判定保留と明記する。
- 各PoCは元fixtureをread-only扱いとし、開始前後hashを比較する。失敗後の再開は同じfixture/設定/hashから該当Tを再実行し、古い失敗記録を上書きしない。実装/fixture/規約が変わった場合は影響するTを再実行する。

## 2. T-01：PU 1セットの受渡し

|項目|具体化|
|---|---|
|目的・仮説|CH/単位/校正/時間を失わず、内部表現に依存しない同一Viewを取り出せる|
|入力・必要データ|小fixture：p/u各N、Pa/m/s、共通TimeBase、既知pair/座標/方向、合成origin、生成由来。別fixtureとしてraw V→校正履歴付き波形を用意|
|操作変数|A/B/C、物理格納CH順序、表示名。CH IDと数値対応は維持|
|固定条件|bytes、root/revision、sample範囲、unit、profile、dtype|
|操作・期待挙動|pair IDでViewを取得し独立consumerへ渡す。格納順が逆でも同じCH値/単位/時刻/親参照|
|拒否・警告|unit逆転/不在CH/未知版は拒否。合成を実機校正済みと表示しない|
|比較・判定|A/B/Cの正規化した読取結果を照合。値は演算なしなので完全一致|
|合格・根拠|全必須項目/値/参照が一致、原本hash不変。INV-01〜06/09/12|
|確定できる判断|基本フィールド/CH個別配列/Adapter境界の実現性。実機のp–u関係は確定できない|

### rev.1.1追加条件：raw / synthetic識別とAdapter写像

- 入力・変数・固定条件・期待結果・拒否条件：raw V/合成Paの2fixture、同値でunit/Bindingだけを変更。parser/generator ref固定。軸転置だけでPa化せず、合成仕様へ到達すること。必須Binding欠落は拒否。
- 合格条件・判断対象：非演算値一致＋origin/quantity/参照保持。J20/J24/J25
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 3. T-02：PU 12セット＋RPM

|項目|具体化|
|---|---|
|目的・仮説|可変CHとRPM別時計を2CH固定に縮退せず表現できる|
|入力・必要データ|24物理CH＋RPM、12pair、p/u共通1000 Hz/N=30000。RPMは同格子版と100 Hz/N=3000版。同期既知版/Unknown版を用意|
|操作変数|CH数1/2/24/26、RPM有無/clock、並び順、pair選択。26は固定上限がないことの反例用|
|固定条件|各CHの値列/ID、同一選択範囲、policy、座標fixture|
|操作・期待挙動|pair単位で10〜20秒を取得。RPMは別のresolved range。同期不明でもp単独表示可、次数解析要求はUnavailable|
|拒否・警告|別clockを無条件同一indexで結合する実装は不合格。ID衝突は拒否|
|比較・判定|A/B/C、CH選択結果/時間対応/eligibility。個数・ID・親sample対応を独立に照合|
|合格・根拠|暗黙補間なし、すべてのCHを正しく選択、別時計状態保持。INV-03/04/08|
|確定できる判断|複数TimeBase・可変CHの構造、consumerの同期要求境界。実時計精度は未確定|

### rev.1.1追加条件：CH追加/欠損/除外と別時計RPM

- 入力・変数・固定条件・期待結果・拒否条件：24CHから1CHをexcluded、別variantでmissing、新logical CHを追加。入力値固定。旧Viewを維持し、excludedとmissingを別code。RPM clock不明は回転profileのみUnavailable。
- 合格条件・判断対象：残るCHが同じ表現を参照、関係不明の暗黙同期なし。J21/J22/J23
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 4. T-03：一部CH欠損

|項目|具体化|
|---|---|
|目的・仮説|欠損CHが非依存解析を止めず、0値と混同されない|
|入力・必要データ|12pair fixtureからu03 missing、p04一部invalid [100,200)、p05 presentで全ゼロ、p06 legacy_placeholderを作る|
|操作変数|missing/unavailable/unknown/invalid/partial、必要CH profile|
|固定条件|残る値/座標/ID、原本、解析対象区間|
|操作・期待挙動|pair03利用不可、p03単独可。無効区間交差Viewはprofileに応じUnavailable/明示除外、p05はmissingにしない|
|拒否・警告|欠損を0埋め/正常扱いすれば不合格。partialなのに範囲なしは拒否。定値品質は別finding|
|比較・判定|A/B/C、各scopeでavailability/validity/originと理由を比較|
|合格・根拠|対象外CHへ影響せず、欠損理由と元範囲を維持。INV-10/11|
|確定できる判断|状態の直交性、部分利用policy。品質閾値は決めない|

### rev.1.1追加条件：pだけのRMSと必須条件迂回禁止

- 入力・変数・固定条件・期待結果・拒否条件：pのみfiniteでu missing、RMSとMSC profileを切替。p/時間固定。RMS可、MSC不可。required校正不成立codeをallowed_warningへ入れても不可。
- 合格条件・判断対象：scope限定の状態、requiredがwarningで通らない。J23/J25
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 5. T-04：不正p/uペア

|項目|具体化|
|---|---|
|目的・仮説|構造的な参照不正と物理的な不足を異なる結果で返せる|
|入力・必要データ|正常pairから役割逆転、同一CH p/u、存在しないCH、重複pair ID、共有pのalias有/無、別probe、方向Unknownを各1変更|
|操作変数|一度に一つの対応条件|
|固定条件|信号値・単位・時刻・その他pair|
|操作・期待挙動|参照不正を実行前拒否。明示alias/別probeは構造を保持し、適用条件で解析可否判定|
|拒否・警告|Unknown方向だけで全CH拒否しない。役割不一致をwarningで通さない|
|比較・判定|A/B/C、拒否scope/reason、独立CH読取の可否|
|合格・根拠|最初一致/後勝ちなし、正しいscopeで拒否。INV-04/05/08|
|確定できる判断|共有CHの明示alias方式、pair検証境界。共置許容距離は別物理検証|

### rev.1.1追加条件：論理派生CHのpair宣言

- 入力・変数・固定条件・期待結果・拒否条件：多対一d01をp01と同じsensorへ無根拠に割当てる不正fixture、明示仮想信号fixtureを比較。値固定。実在sensorへの誤認を拒否/Unknown化しIntensity要求を制限。
- 合格条件・判断対象：論理CHと取得CHを区別、他pair無影響。J21/J23
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 6. T-05：メタデータ未登録

|項目|具体化|
|---|---|
|目的・仮説|未知意味を捏造せず原本取込と限定診断を継続できる|
|入力・必要データ|同じraw CSV assetにcontextなし、sensorなし、時間解釈未登録、異なるhashのmetadata、正常bindingの5状態|
|操作変数|binding/項目状態のみ|
|固定条件|CSV bytes/hash、parserの数値読取、登録主体|
|操作・期待挙動|原本とV値/sample表示を保持。時間未確定は秒/FFT不可、温湿度のみ未知なら非依存consumerは利用可能|
|拒否・警告|ファイル名類似で自動結合しない。binding矛盾は結合拒否、不在はUnknown|
|比較・判定|A/B/C、値/出典/Unknown理由、要求別eligibility|
|合格・根拠|未知fs/方向/測定IDを既定生成して物理事実にしない。INV-01/02/08|
|確定できる判断|未登録状態とmetadata結合境界。外部実照合キーは決まらない|

### rev.1.1追加条件：Adapter不足5分類

- 入力・変数・固定条件・期待結果・拒否条件：同一payloadにNOT_RECORDED/MAPPING_UNSUPPORTED/REFERENCE_UNAVAILABLE/TRANSFORMATION_LOSS/INPUT_CONFLICTを個別注入。必須性固定。Unknown許容欄はlimited、必須実体不足はpending、矛盾はrejected。
- 合格条件・判断対象：field dispositionとscopeが正しく保存、推測補完なし。J24/J25
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 7. T-06：同一信号を複数PoCへ入力

|項目|具体化|
|---|---|
|目的・仮説|consumerの実装・呼出順・変更試行によらず比較入力が不変|
|入力・必要データ|同一revision/Viewをconsumer X/Yへ。Xは和など検査値、Yは入力変更を試行するダミー。truth/experiment metadataを別assetに用意|
|操作変数|copy/view/lazy、X→Y/Y→X、外部alias変更、別プロセス読取、truthの変更|
|固定条件|入力snapshot/選択/dtype、読取profile。科学アルゴリズム比較ではない|
|操作・期待挙動|変更操作は拒否またはprivate copyだけに作用。他consumer・root不変。truth変更で値/選択が変わらない|
|拒否・警告|mutable owner経由で内容が変わるreadonly viewは不合格。期限切providerは明示失敗|
|比較・判定|A/B/C×copy/view/lazyを段階比較。開始前後hash、X検査値、値配列、単位/参照の一致|
|合格・根拠|非演算配列完全一致、順序非依存、原本不変。INV-09。演算差は同じ方式/dtypeで比較|
|確定できる判断|所有/寿命規約、providerの必要性、独立実行境界。並列実行エンジンの採用は決めない|

### rev.1.1追加条件：生成設定隔離と共有表現

- 入力・変数・固定条件・期待結果・拒否条件：同一Viewを複数consumerへ。truth assetだけ変更、旧representation共有へ書込試行。生成パラメータref自体の変更なら新revisionが必要。
- 合格条件・判断対象：truthだけで数値入力不変、共有変更不可、generator設定が特徴に入らない。J20/J22/J23
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 8. T-07：時間区間と元データ追跡

|項目|具体化|
|---|---|
|目的・仮説|端点・欠損・派生後も表示範囲と計算supportを区別して逆引き可能|
|入力・必要データ|uniform/explicit time、各sampleを識別できる値。10〜20秒、隣接区間、先頭/末尾、空/逆順/範囲外、時刻境界近傍を用意。既知のslice/補間supportを持つ派生fixture|
|操作変数|秒/index選択、端点、timebase種類、変換履歴|
|固定条件|source snapshot、時刻精度宣言、選択規則|
|操作・期待挙動|半開区間のindex解決、隣接窓の意図しない重複なし。無効区間を除いても元index保持。補間後は寄与範囲を返す|
|拒否・警告|自動clip/時間詰め禁止。実sampleなしはEMPTY_SELECTION、時間不明は秒選択不可|
|比較・判定|A/B/C、独立に列挙した条件a≤t<bのindex集合と照合。整数対応は完全一致|
|合格・根拠|全選択の元CH/sampleに到達、表示中心とsupport別。INV-03/07|
|確定できる判断|半開端点/秒変換/派生support契約。実時計の許容差は別検証|

### rev.1.1追加条件：多対一と追跡不能Adapter

- 入力・変数・固定条件・期待結果・拒否条件：p01+p02の派生fixtureに両親sample support。別variantでBridge窓startを欠落。time/値固定。多対一は両親へ到達、start欠落は診断assetのみlimitedで適合窓出力禁止。
- 合格条件・判断対象：一親でも欠落すれば追跡適合にしない。J20/J21/J24
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 9. T-08：校正条件変更と派生結果

|項目|具体化|
|---|---|
|目的・仮説|別校正の値・証拠・領域が分離され、旧Viewの意味を変えない|
|入力・必要データ|raw Vの固定fixture、係数snapshot K1/K2、単一感度の独立期待値、TFだけ補正したartifact、宣言のみの旧値、校正失敗fixture|
|操作変数|係数、phase flag、domain、実装ref、証明状態。一度に一変数|
|固定条件|raw bytes/hash/root/timebase/CH、計算方式（係数比較の場合）、数値budget|
|操作・期待挙動|K1/K2は異なるderived/revision、原本同一、係数hash別。TF補正でraw波形unit不変。失敗は成功値として流れない|
|拒否・警告|係数sensor不一致/単位不一致/欠落は拒否。declared_onlyや物理未評価は用途policyで制限|
|比較・判定|A/B/Cの履歴/参照/domainを比較。感度計算は独立期待値と事前budgetで照合|
|合格・根拠|過去View不変、全出力が実使用係数へ到達、実行成功と物理妥当性別。INV-06/09/11|
|確定できる判断|校正記録の粒度/派生ID政策。実センサーの周波数/位相補正精度はこの試験では確定不可|

### rev.1.1追加条件：部分校正・混合由来

- 入力・変数・固定条件・期待結果・拒否条件：12PUのPU03だけraw親からK2適用、他22CH参照共有。同じ根へのsynthetic異常重畳を別variantに追加。係数/seed以外固定。
- 合格条件・判断対象：旧版hash不変、K2 scopeは2CHだけ、混合は実測/合成両親と設定を追跡。J20/J21/J22
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 10. T-09：保存・再読込による情報維持

|項目|具体化|
|---|---|
|目的・仮説|独立プロセス/移設後も意味と完全性が保持される|
|入力・必要データ|T-01〜08の最小manifest/asset集合、Unknown/partial/別時計/派生/校正、親欠損/改変/不対応版の派生fixture|
|操作変数|内部A/B/Cを固定して保存候補を比較、その後保存固定で内部候補を比較。保存先移動、元path削除、1byte改変|
|固定条件|各比較内の入力・schema・metadata・dtype・候補以外の保存設定|
|操作・期待挙動|新プロセスで読み、ID/品質/参照/配列/軸復元。snapshotがあれば元path消失でも読める。hashのみで実体なしならASSET_UNAVAILABLE|
|拒否・警告|改変/未知版/意味必須拡張を拒否。失われたparentを成功扱いしない。絶対path依存を検出|
|比較・判定|canonical意味の差分、非演算配列bytes/shape/dtype、asset hash、Viewの逆引き照合|
|合格・根拠|必要意味の欠落0、改変検知、移設可能、未知版拒否。INV-01/06/07/09/11/12|
|確定できる判断|保存Adapterの適合性、版互換方針、D-004に渡す必須metadata。保存性能はT-10|

### rev.1.1追加条件：AdapterReport/共有表現の移設

- 入力・変数・固定条件・期待結果・拒否条件：部分校正manifestとAdapterReportを保存・移設し独立読込。共有元asset不在/改変を別注入。保存候補以外固定。
- 合格条件・判断対象：共有解決/情報損失分類/profile refs保持、不在と改変を別理由。J22/J24
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 11. T-10：大容量データ性能

|項目|具体化|
|---|---|
|目的・仮説|意味保持を維持したまま、必要範囲だけを読み取れる候補を識別する|
|入力・必要データ|48 kHz×120秒×24CH＋同rate RPMの例。float64値だけなら5,760,000×25×8=1,152,000,000 bytes。時刻/metadata/一時コピーは別加算。別rate RPMと長時間条件も用意|
|操作変数|A/B/C、copy/view/lazy、保存方式/chunk/圧縮は別ラウンド、全読込vs1pairの1秒、繰返し/ランダム区間、Nを段階増加|
|固定条件|同Windows機/ストレージ/Python依存版/dtype/fixture、操作集合、測定方法。cache cold/warmを分離記録|
|操作・期待挙動|値/意味はT-09と同等、部分取得が可能。全体ロードが起こる候補も隠さず測定|
|拒否・警告|OOM/timeout/不完全出力/暗黙float32化は失敗として記録。意味ゲート違反の候補は速度評価で救済しない|
|比較・判定|初回読取/区間読取/serialize時間、peak RSS、読込bytes、disk量、複数consumer時の増分を測る。計測tool/粒度、反復数を事前固定して全観測値を保存|
|合格・根拠|意味ゲートと原本不変は必須。性能採用閾値は作業時間/搭載RAM/必要同時数に基づき別途合意。根拠なしの秒数・GB上限をFIXしない|
|確定できる判断|provider/保存の比較順位と増加傾向。予算未合意なら候補絞込みまで、性能合格は保留|

この容量は宣言した仮条件の算術値であり実測性能や現収録ファイル容量ではない。12PUを超える条件も扱える構造を維持する。

### rev.1.1追加条件：部分更新の実体量

- 入力・変数・固定条件・期待結果・拒否条件：24CHの2CHのみ校正するfixtureを全コピー/参照共有で比較。内部型/保存方式を同時変更しない。
- 合格条件・判断対象：意味ゲート維持、保存bytes/peak RSS/読取時間を記録。根拠のない性能合格値は置かない。J22/J25
- 比較候補は本TのA/B/C等を継承。新しい機能試験結果ではなく未実施計画。

## 12. 追加試験（新規提案）

|ID|問い/入力・変数・固定条件|期待・判定/拒否・合格|判断対象|
|---|---|---|---|
|T-11 時刻不確かさ|既知uniformに丸め/offset/drift/欠落/逆転を別々に注入。値列固定。A/B/Cで原列と派生格子を比較|未宣言修復なし。重複/逆転は利用不可。丸めbudgetが証拠から導ける条件だけ派生格子可。物理同期の合格budget未定なら保留|J04/J16|
|T-12 方向・位相の適用条件|同値にdirection Unknown/符号反転/別frame、校正domain/帯域、sync unknownを付与。consumer requirements固定|構造整合と科学可否を分離しIntensityのみ制限。座標transform証拠なしに符号を推定しない。解析数値の科学合格は別試験|J07/J08/J10|
|T-13 互換性・途中成果物|既知版/未知major/未対応minor/任意拡張/必須未知capability、missing member/途中公開。payload固定|対応表どおりの受領/拒否。未知必須意味・未完了を通常入力にしない。A/B/C共通で一致|J09/J14、D-004|

### T-11〜T-13のrev.1.1補強

**T-11 同期要求と再評価**：同一p/uにsync Unknown/既知証拠、片CHだけresampleの各版。profile固定。MSCはUnknown不可、改訂証拠では新report。 合格条件・判断対象：旧reportを新revisionに流用しない、方向UnknownだけでMSCを止めない。J23 比較対象はA/B/Cの同一profile/共通Validator。未実施。

**T-12 8 consumer要求差**：同一p/uで方向/校正/位相証拠を一項目ずつ欠落。p表示/RMS/FFT/MSC/位相/Intensity/回転/ML profileは事前固定。 合格条件・判断対象：設計§17のマトリクス通りのscope/state、方向UnknownでIntensity不可。J23/J25 比較対象はA/B/Cの同一profile/共通Validator。未実施。

**T-13 判定証拠矛盾と変換失敗**：同一scope/checkにpass/failの証拠、supersedes有無、未知profile版、Adapter実行例外を別fixture。値固定。 合格条件・判断対象：矛盾未解決はUnavailable、未知版拒否、例外はfailedで入力不適格と混同しない。J23/J24 比較対象はA/B/Cの同一profile/共通Validator。未実施。

## 13. 実施順序・次工程への引継ぎ

1. J03〜J10/J14の意味案をレビューし、比較用の契約版と共通fixtureの期待状態を固定する。物理的に不明な値はUnknownのままにする。
2. T-01/03/04/05/07を小規模で比較する。A/B/Cが同じ必須ゲートを通らなければ速度比較へ進めない。
3. T-02/06/08で複数時計・不変性・校正派生を確認する。新コードの実装許可は別工程とする。
4. T-09/13で保存/移設/版/完全性を確認し、D-004候補を絞る。旧Bridge/NV接続は必要な項目が揃うfixtureだけで別Adapter試験を計画する。
5. T-10で性能を比較し、予算と照合してJ11〜13/J18を選ぶ。T-11/12は不足状態の拒否を先に試せるが、実機条件の合格にはD-001実資料が必要。
6. 結果を判断台帳へ関連付ける。失敗・保留・未実施を残し、候補採用と実機適合を別承認する。

後続担当へ渡すものは本3文書とevidence.json、参照元のround01/02。**現時点で渡せる実行スクリプト・新schema実装・PoC成功結果はない。** 既存130試験等の過去baselineをこの新契約の実証結果として利用しない。新契約を既存コードへ適用する際は既存契約変更とは分離して影響評価する。

## 14. 最小PoCの推奨範囲と開始条件（rev.1.1）

新T-IDは追加しない。SourceBinding/部分RevisionはT-01/02/06/07/08、ConsumerProfileはT-03/04/05/11/12/13、AdapterはT-01/05/07/09/13へ組み込み、元の目的を維持する。

実装前に固定する比較条件は、(1)J20のBinding欄、(2)J21の複合representation ref、(3)J22の変更/共有manifest、(4)J23の固定profile/policyとreason code、(5)J24のoutcome/scope、(6)J25のCoreゲート。同時にfixtureのexpected状態と参照graphを独立にレビューする。数値方式や実機同期budgetをこの合意で決定しない。

最小段階は、1raw＋1synthetic根、2CHの校正派生、12PUのうち1pairだけ更新、多対一1CH、欠損/除外のfixtureを用意する。p表示/RMS/MSC/Intensity/回転profileは入力条件の判定だけから始める。実解析アルゴリズムの新規実装、汎用Registry、DAG、万能rule DSLは不要。Adapterは明示fixtureの変換と損失報告に限定する。

T-01/03/05/07/08/12/13の意味ゲートを先に、T-06/09で不変性・保存を、T-02/04/11で対応条件を広げ、最後にT-10を行う。実機の物理適合が不明でもUnknownの拒否・限定利用は検証可能。数値校正の期待値照合を実機校正の合格としない。全項目未実施であり再開コマンドはまだ存在しない。
