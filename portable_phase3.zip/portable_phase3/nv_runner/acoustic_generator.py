"""Acoustic scenes -> the SAME public InputAdapter contract; truth is a sidecar."""
import copy
from pathlib import Path
import numpy as np
from .acoustics import ACOUSTIC_VERSION, synthesize
from .common import write_json, sha, array_file


def acoustic_settings(profile="quick"):
    def target(name,key,kind,rms,**kwargs):
        return {"name":name,"seed_key":key,"role":"target_normal","field":"monopole","position_m":[0,0,0],
                "drive_unit":"m^3/s","drive_rms":rms,"excitation":{"kind":kind,**kwargs}}
    return {"schema_version":"1.0","generator":"acoustic","acoustic_schema_version":ACOUSTIC_VERSION,
        "seed":42,"train_specimens":12 if profile=="quick" else 40,"eval_repeats":1 if profile=="quick" else 4,
        "measurements_per_specimen":2,"sample_rate_hz":1024,"duration_seconds":4 if profile=="quick" else 6,
        "medium":{"density_kg_m3":1.2,"sound_speed_m_s":343.},
        "receiver":{"position_m":[.05,0,0],"axis":[1,0,0]},
        "numerics":{"guard_seconds":.5,"highpass_hz":5.,"transition_hz":5.,"lowpass_fraction":.44},
        "variation":{"specimen_drive_fraction":.10,"measurement_drive_fraction":.03,"steady_rpm_fraction":.025},
        "rotation":{"start_rpm":1350.,"end_rpm":1350.,"ripple_fraction":.005,"ripple_hz":2.},
        "ramp_rotation":{"start_rpm":1100.,"end_rpm":1800.,"ripple_fraction":.005,"ripple_hz":2.},
        "sensor":{"gain_db":[0.,0.],"phase_degrees":[0.,0.],"delay_seconds":[0.,0.],"noise_std_si":[0.,0.]},
        "rpm_sensor":{"enabled":False,"update_hz":100.,"delay_seconds":0.,"smoothing_seconds":0.,
                      "gain_error_fraction":0.,"offset_rpm":0.,"noise_std_rpm":0.,"quantization_rpm":0.,
                      "dropout_fraction":0.,"pulses_per_revolution":0},
        "normal_sources":[target("shaft_order_1",10,"order",6e-5,order=1),target("shaft_order_3",11,"order",3e-5,order=3),
            target("stationary_target",12,"tone",2e-5,frequency_hz=100.,phase_radians=0.),
            target("usual_events",13,"events",4e-5,frequency_hz=300.,center_fractions=[.26,.72],sigma_seconds=.045),
            {"name":"ambient","seed_key":14,"role":"ambient_normal","field":"plane","position_m":[0,0,0],
             "direction":[-.6,.8,0],"drive_unit":"Pa","drive_rms":.003,"excitation":{"kind":"noise","band_hz":[15.,430.]}}],
        "additional_sources":{
            "band":{**target("target_band",100,"tone",1.5e-4,frequency_hz=180.,gate_fraction=[.4,.62]),"role":"target_anomaly"},
            "order":{**target("target_order_3",101,"order",1.4e-4,order=3,gate_fraction=[.4,.62]),"role":"target_anomaly"},
            "event":{**target("target_impact",102,"events",2.5e-4,frequency_hz=300.,center_fractions=[.51],sigma_seconds=.03),"role":"target_anomaly"},
            "relation":{"name":"target_counterpropagating_component","seed_key":103,"role":"target_anomaly", "field":"plane",
                "position_m":[0,0,0],"direction":[-1,0,0],"drive_unit":"Pa","drive_rms":.12,
                "excitation":{"kind":"tone","frequency_hz":100.,"phase_radians":0.,"gate_fraction":[.4,.62]}},
            "disturbance":{"name":"independent_external_wave","seed_key":104,"role":"external_disturbance","field":"plane",
                "position_m":[0,0,0],"direction":[-.6,.8,0],"drive_unit":"Pa","drive_rms":.06,
                "excitation":{"kind":"tone","frequency_hz":220.,"gate_fraction":[.4,.62]}}}}


def sources_for(settings, scenario, family, repeat):
    sources = copy.deepcopy(settings["normal_sources"])
    variant = settings["variation"]
    for s in sources:
        # Same normal realization for paired eval scenarios; independent across fit/cal/eval families.
        specimen_rng = np.random.default_rng(np.random.SeedSequence([settings["seed"],family,s["seed_key"],1]))
        measure_rng = np.random.default_rng(np.random.SeedSequence([settings["seed"],family,s["seed_key"],repeat,2]))
        s["drive_rms"] *= specimen_rng.uniform(1-variant["specimen_drive_fraction"],1+variant["specimen_drive_fraction"])
        s["drive_rms"] *= measure_rng.uniform(1-variant["measurement_drive_fraction"],1+variant["measurement_drive_fraction"])
    additions = ["band","order","event","relation"] if scenario=="mixed" else ([] if scenario=="normal" else [scenario])
    for name in additions:
        source = copy.deepcopy(settings["additional_sources"][name])
        source["scenario_component"] = name
        sources.append(source)
    return sources


def effective_region(pair, source, fs, duration):
    maxima = np.max(abs(pair),axis=0)
    relative = np.max(abs(pair)/np.maximum(maxima,1e-30),axis=1)
    support = np.where(relative > 1e-3)[0]
    if not len(support):
        return None
    # Approximate energy band for display, not a sharp physical band assertion.
    freq = np.fft.rfftfreq(len(pair),1/fs)
    power = (abs(np.fft.rfft(pair,axis=0))**2/np.maximum(maxima,1e-30)**2).sum(axis=1)
    cumulative = np.cumsum(power)/max(float(power.sum()),1e-30)
    bins = np.searchsorted(cumulative,[.0005,.9995]).clip(0,len(freq)-1)
    ex = source["excitation"]
    if "gate_fraction" in ex:
        core = [round(v*duration*fs) for v in ex["gate_fraction"]]
    elif ex["kind"]=="events":
        core = [max(0,round((min(ex["center_fractions"])*duration-3*ex["sigma_seconds"])*fs)),
                min(len(pair),round((max(ex["center_fractions"])*duration+3*ex["sigma_seconds"])*fs))]
    else:
        core = [0,len(pair)]
    return {"start_sample":int(support[0]),"end_sample":int(support[-1]+1),"excitation_core_range":core,
        "frequency_hz":[float(freq[bins[0]]),float(freq[bins[1]])],"sensors":["p","u"],
        "support_definition":"source contribution > 0.001 channel peak; weak tails outside remain",
        "frequency_definition":"99.9% combined normalized p/u spectral energy; finite-record approximation"}


def generate_acoustic(root, settings):
    settings = copy.deepcopy(settings)
    if settings.get("schema_version") != "1.0" or settings.get("acoustic_schema_version") != ACOUSTIC_VERSION:
        raise ValueError("unsupported acoustic settings version")
    if settings["sample_rate_hz"] < 800 or settings["duration_seconds"] < 2 or min(settings["train_specimens"],settings["eval_repeats"],settings["measurements_per_specimen"]) < 1:
        raise ValueError("invalid acoustic dataset dimensions")
    root = Path(root).resolve()
    root.mkdir(parents=True,exist_ok=False)
    truth = {"schema_version":"1.0","generator":"acoustic","acoustic_schema_version":ACOUSTIC_VERSION,
        "settings":settings,"cases":[],"training_cases":[],"source_artifacts":[],"measurement_diagnostics":{},
        "physical_scope":"linear homogeneous acoustics; specified ideal fields, not identified machinery",
        "pu_definition":"exp(+j omega t); U=-grad(P)/(j omega rho); stored u=axis dot U; peak intensity=.5 P conj(U)"}
    manifests = {"train":[],"eval":[]}
    plans = [("train","normal",i) for i in range(settings["train_specimens"])] + [
        ("eval",kind,100000+j) for j in range(settings["eval_repeats"]) for kind in ("normal","band","order","event","relation","mixed","disturbance")]
    for index,(split,scenario,family) in enumerate(plans,1):
        sid,cid = f"s{index:04d}",f"c{index:04d}"
        ct = {"case_id":cid,"specimen_id":sid,"label":"normal" if scenario in ("normal","disturbance") else "abnormal",
              "scenario":scenario,"counterfactual_family":f"family_{family}","regions":[],"normal_events":[]}
        for repeat in range(settings["measurements_per_specimen"]):
            mid = f"m{index:04d}_{repeat}"
            seed = int(np.random.SeedSequence([settings["seed"],family,repeat]).generate_state(1)[0])
            rotation = copy.deepcopy(settings["ramp_rotation"] if repeat%2 else settings["rotation"])
            rng = np.random.default_rng(seed)
            gain = rng.uniform(1-settings["variation"]["steady_rpm_fraction"],1+settings["variation"]["steady_rpm_fraction"])
            rotation["start_rpm"] *= gain
            rotation["end_rpm"] *= gain
            sources = sources_for(settings,scenario,family,repeat)
            rec = synthesize(settings,sources,seed,rotation)
            np.savez_compressed(root/f"{mid}.npz",waveform=rec["waveform"],shaft_rpm=rec["rpm_measured"])
            receiver = settings["receiver"]
            meta = {"schema_version":"1.0","specimen_id":sid,"case_id":cid,"measurement_id":mid,
                "derived_group_id":f"family_{family}","data_kind":"synthetic_acoustic_v1",
                "protocol":"paired acoustic scene; steady/ramp; shared normal realization within eval family",
                "channels":[{"name":name,"quantity":quantity,"unit":unit,"position_m":receiver["position_m"],
                             "direction":receiver["axis"],"pair_id":"pair_1"} for name,quantity,unit in
                            [("p","pressure","Pa"),("u","particle_velocity","m/s")]],
                "timebase":{"sample_rate_hz":settings["sample_rate_hz"],"start_seconds":0,"signal_sync":"shared_clock","rpm_sync":"shared_clock"},
                "calibration":{"status":"calibrated","reference":"analytic_SI_acoustic_1.0_with_declared_residual_sensor_response",
                               "units":["Pa","m/s"],"residual_response":settings["sensor"]},
                "operating_conditions":{"mode":"ramp" if repeat%2 else "steady","rpm_key":"shaft_rpm","shaft":"primary"},"validity":[],
                "acoustic_contract":{"version":"1.0","phasor":"exp(+j omega t)","medium":settings["medium"],
                                     "velocity":"signed axial acoustic particle velocity","collocated":True}}
            write_json(root/f"{mid}.json",meta)
            manifests[split].append({"metadata_path":f"{mid}.json","source_path":f"{mid}.npz","source_sha256":sha(root/f"{mid}.npz"),
                "mapping":{"signals":"waveform","rpm":"shaft_rpm","axes":["time","channel"]}})
            desc = array_file(root,f"truth_arrays/{mid}.npz",**rec["truth"])
            truth["source_artifacts"].append({"measurement_id":mid,"array_file":desc})
            details = []
            for si,source in enumerate(sources):
                pair = rec["truth"]["source_waveforms"][si]
                details.append({**source,"source_index":si,"received_rms_si":np.sqrt(np.mean(pair**2,axis=0)).tolist(),
                                "realized_drive_rms":float(np.sqrt(np.mean(rec["truth"]["source_drives"][si]**2)))})
                if source["role"] in ("target_anomaly","external_disturbance") or source["excitation"]["kind"]=="events":
                    region = effective_region(pair,source,settings["sample_rate_hz"],settings["duration_seconds"])
                    if region:
                        region.update(measurement_id=mid,kind=source.get("scenario_component","normal_event"),
                            role="disturbance" if source["role"]=="external_disturbance" else source["role"],source_index=si)
                        ct["regions" if source["role"] in ("target_anomaly","external_disturbance") else "normal_events"].append(region)
            truth["measurement_diagnostics"][mid] = {"seed":seed,"rotation":rotation,"sources":details,
                "receiver":receiver,"sensor":settings["sensor"],"rpm_sensor":settings["rpm_sensor"],
                "p_rms_pa":float(np.sqrt(np.mean(rec["waveform"][:,0]**2))),"u_rms_m_s":float(np.sqrt(np.mean(rec["waveform"][:,1]**2))),
                "mean_observed_intensity_w_m2":float(np.mean(rec["waveform"][:,0]*rec["waveform"][:,1]))}
        truth["training_cases" if split=="train" else "cases"].append(ct)
    for split,items in manifests.items():
        write_json(root/f"{split}_manifest.json",{"schema_version":"1.0","role":split,"normal_only_attested":split=="train","measurements":items})
    write_json(root/"truth.json",truth)
    write_json(root/"generation.json",settings)
    return root
