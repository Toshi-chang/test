# 契約と仮設定 v1

schema_versionは文字列 `1.0` のみ、未知の版は拒否。ソフトウェア版は `0.2.0`。JSONはUTF-8、日時はUTC ISO8601。非有限数値は禁止、未評価はnull＋reason。NPZは数値配列のみ、allow_pickle=False。IDは英数字開始、英数字・`.`・`_`・`-`、最大128文字。ID、ファイル名、正解は特徴量に含めません。

## 入力契約

manifest必須項目はschema_versionとmeasurements。trainは `normal_only_attested:true` が必要です。正常性は登録者の表明であり、実測の真の正常性を自動保証しません。

各measurements要素：source_path、source_sha256、metadata_path、mapping。パスはmanifest基準。mapping例：

```json
{"signals":"waveform","rpm":"shaft_rpm","axes":["time","channel"]}
```

signalsは `[n_samples,2]`、ch0音圧Pa、ch1粒子速度m/s。rpmは欠落ならnull、存在すれば `[n_samples]` のrev/min。元NPZのキーをmappingで明示し、自動推定しません。metadataの必須項目：

|項目|意味|
|---|---|
|specimen_id / case_id / measurement_id|個体・評価一式・測定。1caseは1個体|
|derived_group_id|共通派生元グループ。複数祖先を共有する場合は連結する全派生物を同一グループで登録|
|channels|各chのname、quantity、unit、position_m[3]、direction[3]、同じpair_id|
|timebase|sample_rate_hz、start_seconds、signal_sync=shared_clock。rpmがあればrpm_sync=shared_clock|
|calibration|status=calibrated、reference、units。校正状態は自動補完しない|
|operating_conditions|mode、rpm_key、shaft等。未知はunknown。Bにはshaftが必要|
|validity|使用不可start_sample/end_sample（半開区間）とreasonの配列。正常は[]|
|protocol / data_kind|測定プロトコル、synthetic等の由来|

InputAdapter.load(manifest) → MeasurementRecord配列。検証済みmetadataハッシュ・元ハッシュ・サンプル数を追加します。truthは読まず、未知のmetadata列をモデルに渡しません。

## 分割・学習境界

train/eval間の個体ID、case ID、元SHA256、派生元ID重複を拒否。train内部では同じ個体・SHA256・派生元を連結したグループをfit/calibrationへ分割します。固定seed、既定80/20。最低fit/calibrationグループ数を確保できない場合は全trainをfitに置きcalibration_unavailable。

StandardScaler、IF、PCAはfit入力だけで学習。sample_idでソートし、バッチでも対応を保持します。IFは `-score_samples`、PCAは標準化空間での次元平均再構成二乗誤差。ともに大きいほど異常。IFの内蔵predict閾値は使いません。

caseスコアは有効入力の最大。十分なcoverageを持つcalibration caseスコアの95%経験分位点、method=higher、比較 `>`。同値はoutsideではありません。calibration個体数不足時は閾値null、スコアのみ。`calibration.explicit_threshold` で明示閾値を指定できます。由来・個体数・caseスコアを保存し、誤検出率保証は表示しません。

複数caseを持つ個体は1caseでもoutsideならoutside、全case withinならwithin、他はundetermined。個体指標はmetrics.jsonに保存。case数・時間の異なる個体間で一定の誤検出率を保証しません。納品fixtureは1個体1case、各caseに定常・回転数変化の2測定で揃えています。

## 経路・モデル契約

RoutePlugin(config) はcapabilities、prepare(records, SignalService)、fit(PreparedSet, model_config, seed)、score(model, PreparedSet, batch_size)、aggregate(PreparedSet, SampleResults, records)、calibrate(calibration_case_results, policy)、decide(case_results, threshold)を提供します。

PreparedSetはsamples（台帳）、values（sample_id→特徴ベクトル）、assets（mask/角度等の数値配列）、coverage（除外・未探索理由）。空選択は台帳だけ保持します。共有計算はSignalService経由。特徴量の名前・順序・単位は入力/model artifactに固定します。

|経路|仮設定・計算|未評価等|
|---|---|---|
|A_full|1秒/0.5秒hop、p/u RMS、p crest、p-u相関、pの4帯域power → IF|末尾は除外台帳へ|
|A_selected|同じ窓、MSC/符号付きintensity/周波数AND/OR。採用p/u power、MSC、intensity、位相sin/cos、占有率 → IF|平均化支持範囲まで窓内に入るframeだけ使用。空選択はunscored|
|B_order|同期rpm台形積分、10回転/5回転hop、64点/回転、order1〜8 power＋RMS/相関 → IF|回転なしはskip/not_applicable。停止・品質不良は区間分離|
|C_event|pの250Hz highpass、20ms RMS>0.10Pa、20ms未満除外、40ms以内結合、60ms余白。波形特徴＋core長 → IF|探索済み0件=no_events/null。正常イベント不足はmodel_untrained|
|D_patch|128点Hann/32点hop、8frame×16bin×2ch、4frame/8bin hopのlog power → PCA4成分|fit変換のみ、パッチごとの振幅正規化なし|

新規acoustic設定のspectral_conventionはmean_square_bin_v2。片側bin量はg|FFT(wp)|²/(N sum(w²))、相互量はg FFT(wp)conj(FFT(wu))/(N sum(w²))。内部binのg=2、DC/Nyquist=1。bin和は窓二乗重み付き平均二乗・平均puに一致し、PSDはこれをdfで割ります。実部が能動、虚部が無効インテンシティで、単位W/m²。MSCは5frame平均、低エネルギーと端の平均不足は無効mask。旧設定はlegacy_amplitude_squared（FFT/Hann.sumの非2倍補正二乗）で再現し、未知の規約は拒否します。音源帰属や外乱分離は保証しません。

入力のp/u位置は一致、u方向は単位ベクトルを必須とします。任意項目acoustic_contractはversion=1.0のみ。exp(+jωt)、uは測定軸の符号付き速度成分。物理式と適用条件はACOUSTIC_DESIGN.mdを参照。Welch診断の位相はarg(P conj(U))、Z_H1=Cpu/Suuは混合場推定です。無効binは数値0＋valid=falseで保存し、閲覧から除外します。生成器の音源別真値は全推論完了後にtruth artifactとして追加し、学習・入力選択に使いません。

Bは角度補間前に4次ゼロ位相lowpassでangular Nyquist以下へ制限、線形補間。rpm変化上限は仮値20000 rpm/s。停止/不良点を跨いで角度を補間せず、Nyquistを超える次数を拒否。元positions・角度・角度波形を保存。パルス検査は未実装で今回の回転入力はrpmです。

## 座標・由来

start_sample/end_sampleは元測定の半開切出し区間。support_start_sample/support_end_sampleは演算支持範囲。display_center_seconds/display_time_rangeは表示座標。STFT frame_start/frame_endと平滑化support_start/support_endも別です。Cはcore_rangeと余白を分離。B/Cのゼロ位相フィルタ支持範囲は有効区間全体なので切出しより広くなります。

map配列は `[frame,frequency_bin]`、waveformは `[time,channel]`、featuresは `[sample,feature]`。周波数はfrequency_hz軸＋bin_range（終端除外）。選択はcondition tree、格子requested_mask、validity反映selection_maskを分け、窓で採用したframe_indicesを保存します。周波数maskから波形は再構成しません。

sample_idは元ハッシュ、検証済みmetadata、経路設定、ソフトウェア版、範囲・座標から生成。artifactのparent_refs、operation、config/config_ref、software_versionで由来を保持。sample→measurement→sensor位置/方向・運転情報・rpm・元時間を逆引きできます。

## Bundle・状態・受渡し

run_<uuid>/ 内はmanifest.json、experiment.json、dataset_split.json、environment.json、metrics.json、specimens/cases/measurements/artifacts/samples/sample_results/route_case_results/case_results/errors.jsonl、models/、arrays/、logs/。正解がある場合だけtruth.json。波形は解析snapshotとして保存し、元NPZ/metadata原本はコピーせず参照します。

SampleResult必須：run_id、route_key、case_id、sample_id、model_ref、status、anomaly_score、score_definition_ref、evidence_ref。status=scored/unscored、未評価スコアnull＋reason。

RouteCaseResult必須：run_id、route_key、case_id、specimen_id、execution_status、coverage_status、decision、case_score、threshold_ref、aggregation_ref、n_created、n_scored、reason、evidence_refs。execution_status=completed/failed/skipped、coverage_status=sufficient/insufficient/not_applicable、decision=within/outside/undetermined。観測時間・重複をunionした評価時間・p95・イベント数/秒・所要時間も保存。

一部未評価でも有効スコアが閾値超過ならoutsideを出せます。withinには十分なcoverageと閾値が必要。イベント0件、学習不可、閾値不足を0やwithinへ置換しません。sample推論失敗はそのsampleをnullにし、他を継続します。

fusionは既定無効で全case=undetermined/fusion_disabled。enabled:true、rule:any_outside_all_withinなら1経路outsideでoutside、全経路withinでwithin、他はundetermined。生スコアの平均はしません。

Collectorはstaging内で全memberの相対パス・bytes・SHA256、shape/dtype、入力行ID、参照、件数、状態、元座標、runを検証してからrenameします。manifest自身は自己参照になるのでmembersに含めず、取込時にmanifestハッシュを別計算。bundle_status=complete/partial。途中stagingは拒否。

EvaluationAdapter.import_bundle(bundle, destination, path_mapping)は検証・stagingコピー・rename。run_id＋manifest SHA256が同じならalready_imported、同じrun_idでhashが異なれば競合拒否。receiptはBundle外、欠落原本はsource_unavailable。原本がなくてもBundle閲覧可能。

## 正解・指標

seed、通常/異常パラメータ、通常イベント、異常/外乱区間・帯域・sensorをtruth.jsonへ保存します。このsidecarは全経路推論後にだけ開き、個体単位の混同行列、正常誤判定、異常見逃し、未確定、母数、可視化に使います。外乱のみ個体はnormalで別scenario。ラベルなしでは分布・coverage・実行成功数・時間を出します。

API根拠：IF符号は[scikit-learn公式資料](https://scikit-learn.org/1.7/modules/generated/sklearn.ensemble.IsolationForest.html)。依存版はrequirements.txt、実行版とコードハッシュはenvironment.jsonに保存します。
