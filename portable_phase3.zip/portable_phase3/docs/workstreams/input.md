# Agent A / ownership D: 独立入力Adapter

`ColumnInputAdapter` は既存InputAdapterと並行して利用できる候補。共有入口・CLI・契約・schema・既存試験は変更していない。他候補の実装もimportしない。実測機器への接続は未実施。

## 入出力と再実行

```powershell
.venv/Scripts/python.exe -m unittest discover -s tests -p test_input_candidate.py -v
.venv/Scripts/python.exe -m nv_runner.input_candidate configs/parallel/input_dummy_columns.json reports/parallel_development/A/example_converted
```

出力先は新規フォルダのみ。再実行は異なる出力先を指定する。生成後は標準 `InputAdapter().load(".../manifest.json")` で読み込める。既存runnerへ渡す場合は統合担当が既存experimentのtrain/evaluation manifestをこの標準manifestへ指定する。候補CLIは単一測定を変換するため、実運用の複数個体登録manifestの組立は別途統合責務。

入力形式は `format=nv_dummy_columns`、`format_version=1.0`、`axes=[sample]`。`columns` はtime_seconds, pressure_pa, velocity_m_sと任意rpm_rev_minの独立1D配列。単位は名前が示すs/Pa/m/s/rev/minを固定する。全列同長N≥2、有限数値、bool/string不可。time_secondsは明示sample_rate_hz/start_secondsと絶対誤差1e-10秒以内で一致する等間隔列を要求する。補間・校正・単位推定はしない。

`metadata` はC01必須項目と任意acoustic_contractのみを採用する。C01の既存InputAdapterがschema、ID、p/u量とSI単位、共置pair、u方向、共有時計、校正、invalid区間を検査する。候補は時刻数値の有限性とcalibration.units=[Pa,m/s]も確認する。入力に存在する未知top-level/metadata項目（truth等）はRecordへ渡さない。必須metadata内に虚偽の校正や真値を書かれた場合の科学的妥当性まで機械検証したとは扱わない。

出力は標準signal.npz / metadata.json / manifest.jsonとadapter専用provenance.json。signal.npzはpressure/velocity列のcolumn_stackだけを行い、元サンプル順・値を完全保存する。Record.source_sha256は変換後NPZを指す。原本column JSONのパス/SHA、変換後SHA、measurement_id、derived_group_id、原本半開範囲[0,N)をsidecarへ保存する。派生元は明示IDを保存し自動的に付け替えない。原本内truthの内容はsidecarにもコピーしない（原本ハッシュはtruth変更時に変わる）。原本への逆引きはsidecar経由。

変換は一時領域で検証後に出力名へrenameする。失敗時は完成フォルダを残さず、既存出力は上書きしない。原本は変更しない。元ファイルを移動した際のパス解決、原本container内で異なる派生元を偽申告した場合の検出、実機校正・同期推定は未実装。

## 独立試験の範囲

13試験（負例のsubTestを含む）：数値と標準reader互換、原本と変換後由来、truth変更の観測不変、rpm欠落、未知版/axes、p/u単位/共置/方向/pair、列shape/type/未知列、時刻/同期、必須meta/ID/校正/invalid区間、上書き拒否/原本不変、非有限JSON、既存SignalService接続、派生元漏洩拒否、別プロセス候補CLI。

fixtureは2048点、fs1024Hz、128Hz正弦、p実効値0.2Pa、u=p/(1.2×343)、rpm1200、seedなしの解析式。正常/異常検出性能や実際の音場再現の検証ではない。配布例は8点でadapter境界用（STFTには短い）。試験生成物はtests/_work/D/<uuid>、ログと担当hashはreports/parallel_development/Aに保存する。

書込範囲：nv_runner/input_candidate.py、tests/test_input_candidate.py、configs/parallel/input_*.json、本書。統合担当が候補を選択しなければ旧動作はそのまま。切戻しは候補への呼出し/設定を除外するだけで共有ソース復元不要。依存追加なし。契約変更申請なし。
