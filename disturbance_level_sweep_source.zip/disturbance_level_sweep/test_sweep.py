import bootstrap_sweep
import unittest
import numpy as np
from sweep_data import pressure_from_db,db_from_pressure,mix_field
from summarize_sweep import prefix_limit

class SweepTests(unittest.TestCase):
    def test_units(self):
        self.assertAlmostEqual(pressure_from_db(80),.2)
        for d in [20,50,80]:self.assertAlmostEqual(db_from_pressure(pressure_from_db(d)),d)
        self.assertIsNone(db_from_pressure(0))
    def test_common_gain(self):
        ratio=pressure_from_db(46.02059991327962)/pressure_from_db(40)
        self.assertAlmostEqual(ratio,2)
        p=np.array([1.,2.]);u=p/400
        np.testing.assert_allclose(mix_field(p,p,ratio),400*mix_field(u,u,ratio))
    def test_zero(self):
        p=np.array([1.,-2.,0.]);np.testing.assert_array_equal(mix_field(p,p,0),p)
    def test_baseline_failure(self):
        self.assertFalse(prefix_limit([{'db':None,'n':3,'within':2}])['baseline_pass'])
    def test_reentry_does_not_extend_prefix(self):
        cells=[{'db':d,'n':3,'within':n} for d,n in [(None,3),(20,3),(25,2),(30,3)]]
        self.assertEqual(prefix_limit(cells),{'baseline_pass':True,'last_consecutive_db':20,'first_failure_db':25})
    def test_undetermined_is_not_success(self):
        cells=[{'db':None,'n':3,'within':3},{'db':20,'n':3,'within':2,'undetermined':1}]
        self.assertEqual(prefix_limit(cells)['first_failure_db'],20)
    def test_upper_censored(self):
        self.assertEqual(prefix_limit([{'db':None,'n':3,'within':3},{'db':80,'n':3,'within':3}])['last_consecutive_db'],80)

if __name__=='__main__':unittest.main()
