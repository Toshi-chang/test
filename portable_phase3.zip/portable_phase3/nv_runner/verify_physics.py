"""Reproducible quantitative checks independent of anomaly labels/models."""
from pathlib import Path
import numpy as np
from .acoustics import axial_transfer,field_transfer,synthesize
from .acoustic_generator import acoustic_settings
from .common import write_json
from .input_adapter import MeasurementRecord
from .signals import pu_diagnostics,mean_square_spectrum


def verify(output):
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    cfg = acoustic_settings()
    receiver,medium = cfg["receiver"],cfg["medium"]
    f = np.geomspace(10,450,120)
    rows = []
    for field in ("plane","monopole","piston","rigid_wall"):
        source = {"name":field,"field":field,"position_m":[0,0,0],"direction":[1,0,0],"normal":[1,0,0],
            "incident_direction":[-1,0,0],"radius_m":.0375,"drive_unit":{"plane":"Pa","monopole":"m^3/s","piston":"m/s","rigid_wall":"Pa"}[field],
            "drive_rms":.001,"seed_key":1,"excitation":{"kind":"tone","frequency_hz":128.,"phase_radians":0.}}
        p,u = axial_transfer(f,source,receiver,medium)
        step = 1e-7
        pp,_ = field_transfer(f,source,{"position_m":[.05+step,0,0]},medium)
        pm,_ = field_transfer(f,source,{"position_m":[.05-step,0,0]},medium)
        gradient_u = -(pp-pm)/(2*step)/(1j*2*np.pi*f*medium["density_kg_m3"])
        error = float(np.max(abs(gradient_u-u)/np.maximum(abs(u),1e-20)))
        pp,uu = axial_transfer(np.array([100.]),source,receiver,medium)
        z = (pp/uu)[0]
        pair = synthesize(cfg,[source],42)["waveform"]
        record = MeasurementRecord({"timebase":{"sample_rate_hz":1024},"validity":[]},pair,None)
        diag = pu_diagnostics(record)
        integrated = float(diag["active_intensity_psd"].sum()*(diag["frequency_hz"][1]-diag["frequency_hz"][0]))
        measured = float(np.mean(pair[:,0]*pair[:,1]))
        peak_scale = float(np.sqrt(np.mean(pair[:,0]**2)*np.mean(pair[:,1]**2)))
        normalized_error = abs(integrated-measured)/max(peak_scale,1e-30)
        rows.append({"field":field,"frequency_hz":100.,"distance_m":.05,"z_abs_pa_s_m":float(abs(z)),
            "phase_p_minus_u_degrees":float(np.angle(z)*180/np.pi),"euler_max_relative_error":error,
            "observed_mean_intensity_w_m2":measured,"welch_integrated_intensity_w_m2":integrated,
            "intensity_error_normalized_by_p_rms_u_rms":normalized_error,
            "pass":error<1e-6 and normalized_error<1e-3})
    source["field"]="monopole"
    source["drive_unit"]="m^3/s"
    source["excitation"]={"kind":"events","frequency_hz":300.,"center_fractions":[.5],"sigma_seconds":.03}
    a=synthesize(cfg,[source],42)["waveform"]
    cfg["numerics"]["guard_seconds"]=1.
    b=synthesize(cfg,[source],42)["waveform"]
    convergence=(np.linalg.norm(a-b,axis=0)/np.linalg.norm(b,axis=0)).tolist()
    report={"acoustic_schema_version":"1.0","checks":rows,"guard_0_5_to_1s_relative_l2_p_u":convergence,
            "passed":all(r["pass"] for r in rows) and max(convergence)<1e-4,
            "scope":"mathematical verification only; not measured system validation"}
    write_json(output/"physical_validation.json",report)
    lines=["# p–u物理検証結果", "", "ρ=1.2 kg/m³、c=343 m/s、距離0.05 m、軸+x。インピーダンスは100 Hz。Euler照合は10〜450 Hzの120点。", "",
        "|場|\u007cZ\u007c [Pa·s/m]|位相p−u [deg]|Euler相対誤差 最大|intensity積分誤差 / (p_rms u_rms)|",
        "|---|---:|---:|---:|---:|"]
    # Escape table separator characters inside the impedance column title.
    lines[4] = "|場|Zの絶対値 [Pa·s/m]|位相p−u [deg]|Euler相対誤差 最大|intensity積分誤差 / (p_rms u_rms)|"
    for r in rows:
        lines.append(f"|{r['field']}|{r['z_abs_pa_s_m']:.6g}|{r['phase_p_minus_u_degrees']:.6g}|{r['euler_max_relative_error']:.3e}|{r['intensity_error_normalized_by_p_rms_u_rms']:.3e}|")
    lines += ["",f"ガード0.5→1秒のイベント中央波形相対L2誤差：p={convergence[0]:.3e}、u={convergence[1]:.3e}。",
              "",f"総合：{'PASS' if report['passed'] else 'FAIL'}。音場の数理実装の検証であり、実機との一致を意味しません。"]
    (output/"PHYSICAL_VALIDATION.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    if not report["passed"]:
        raise AssertionError("physical verification failed")
    return report


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",default="reports/acoustic")
    print(verify(parser.parse_args().output))
