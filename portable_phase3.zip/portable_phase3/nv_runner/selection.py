"""Physical-map predicate evaluation, independent of routes and signal generation.

Configuration validation remains at runner.validate_config (C08). This function
preserves the C02 map/C03 selection behavior, including existing exceptions.
It returns the requested mask; validity and window support belong to the caller.
"""
import numpy as np


def select_mask(node, maps):
    if "op" in node:
        children = [select_mask(child, maps) for child in node["children"]]
        if node["op"] == "and":
            return np.logical_and.reduce(children)
        if node["op"] == "or":
            return np.logical_or.reduce(children)
        raise ValueError("selection op must be and/or")
    field = node["field"]
    values = maps[field]
    if field == "frequency_hz":
        values = np.broadcast_to(values, maps["msc"].shape)
    operation = {">": np.greater, ">=": np.greater_equal, "<": np.less, "<=": np.less_equal}[node["comparison"]]
    return operation(values, node["value"])
