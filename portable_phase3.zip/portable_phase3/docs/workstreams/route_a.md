# RA: route_a

正式な担当指示は ../parallel_contracts/AGENT_TASKS.md を参照。

専用編集範囲:

- `nv_runner/route_a_candidate.py`
- `tests/test_route_a_candidate.py`
- `configs/parallel/route_a_*.json`
- `docs/workstreams/route_a.md`
- `nv_runner/selection.py`
- `tests/test_selection.py`

実装済み候補は `nv_runner.route_a_candidate.FixedWindowCandidate(config)`。`validate_candidate_config(config)` が候補固有条件を検証する。共有基底RoutePlugin/PreparedSetを使用し、他候補をimportしない。生成物は `tests/_work/RA/<uuid>/` に保存する。

共有ファイルの編集・CLIへの接続は統合担当Iへ差分を提出する。契約に変更が必要なら当該実装を止め、INTEGRATION.mdのCR手順に従う。

提出時に `python tools/check_workstream_scope.py --owner RA <変更ファイル一覧>` を実行する。これは申告パスの検査でありOS権限制御や変更検出ではない。

## 今回の提出 (Agent B / RA)

- plugin=`fixed_window_candidate`、通常key=`A_candidate`。設定例は `configs/parallel/route_a_candidate.json`（全体experimentではなくroutes配列の1要素）。window_seconds/hop_secondsは有限正値、selection.enabled=falseのみ。選択領域版は明示拒否する。record到着時に窓3sample以上、hop1sample以上も検査する。
- 独自内部実装: 64窓ずつまとめた配列でRMS/相関/Hann FFTを計算。既存Aのprepare/basic_features/mean_square_spectrumは呼ばない。特徴定義8個・単位・帯域・Hann正規化は既存A全域と同等。科学的改善を主張しない。巨大record全窓の同時展開は避けるが1窓自体の巨大メモリ問題は対象外。
- C01/C02読取専用→C03 PreparedSet、C04 StandardScaler + IF/PCA、C05既存集約/閾値/判定を継承。表示と計算支持範囲を既存addで保存。真値を開かずIDを特徴に含めない。short/invalid/untrained/nonfiniteはnullと理由を保持。
- 同じconfigを与えたoracle比較で既存Aとfeatures(1e-12)、ID/座標/coverage、IF score(1e-12)、閾値/個体判定一致。実運用では別key/pluginなのでsample IDは意図的に異なる。ID順のfitが変わるため実運用config間のモデルhash/IF score一致は一般保証しない。

単独実行 (PoCルート、依存は既存requirements):

```powershell
.venv/Scripts/python.exe -m unittest discover -s tests -p test_route_a_candidate.py -v
```

2026-10-15 JSTに10試験成功、1.692秒。seed42、acoustic quickからtrain6個体・各2測定・3秒・1024Hz、評価7ケース各2測定。DatasetPlannerの既存fit/cal分割を使用。IF16木(min3)、PCA4(min5)を実学習。閾値はcal95% higher・最低2個体。生成条件、分割、モデル、閾値、個別/個体結果、既存A比較を各runへ保存する。各再実行は新uuidで全工程を生成する。

10試験: 特徴/座標互換、実fit/cal/eval、シャッフルとbatch、入力/map不変、short/invalid/untrained、不正config/選択拒否、ID分離と由来維持、PCA/nonfinite/不足、64窓境界/奇数FFT、同configで旧A全lifecycle比較。保存Bundle/Reader/viewer/既存59件回帰は統合担当の結合ゲートとして別報告。実測・外部接続は未実施。共通契約変更・依存追加・Git変更なし。

単独ログ/hash/進捗は `reports/parallel_development/B/`。既存selection.py/test_selection.pyは今回変更しない。共有への必要変更はIに依頼した登録/検証のみ。未解決CRなし。候補を選ばなければ既存の経路を利用できる。
