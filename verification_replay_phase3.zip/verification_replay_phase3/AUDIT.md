# 検証資産の移植監査

2026-11-06。対象：元nv_route_runner_pocと、そのportable_phase3。実際に別PCへ持ち込まれたファイル・設定・結果は未取得。そのため以下は移植用正本の監査であり、別PCの原因を断定しない。既存コード・設定・試験は変更せず、生成・学習・試験実行も行っていない。新規audit_inventory.pyは静的照合だけを行う。

## 結論

1. **対話で決めた条件が全部失われたわけではない。** docs/CLAUDE_CODE_VALIDATION_REQUIREMENTS.mdに生成条件、seed、分割、前処理、モデル、閾値、試験ごとのassert、保存・再開が詳細に残っており、portableにもバイト一致で存在する。
2. **同じquick/seedでも入口次第でデータが違う。** `demo`既定はacoustic、`generate`はsettingsにgeneratorがなければlegacy。configs/quick_data.jsonはgeneratorなし。acoustic_quick_data.jsonを明示する必要がある。
3. **130試験の再実行と、報告した比較実験の再実行は別。** テストは独自の縮小fixtureを使う。通過数だけでは比較データ・検出結果の再現を示さない。
4. **手順文書に時点と用途の混在がある。** 10/12要件書は01_runtime/32試験時点、Phase3移植手順は130試験時点。さらにreplay_saved_checksの必要入力について説明が矛盾する。
5. **D-002はPhase3パッケージの対象外。** 後続の比較PoCは別フォルダにあり、このパッケージだけでは再実行できない。Phase3以降を取り込まない方針による範囲外であり、欠落事故とは断定しない。

## 照合結果と限界

inventory.jsonを参照。nv_runner/tests/tools/configs/development/docsの小容量テキストを限定照合：142件中108件同梱・SHA-256一致、同梱ファイルの差異0。未同梱34件はdevelopment/docsとdevelopment/development以下の重複配置。142は全パッケージ総数ではない。ルートrequirements等やバイナリ、大容量実行生成物はこの件数に含めない。

tests/test_*.pyから静的に数えたtest_メソッドは130。本日実行成功したという意味ではない。過去移植記録は130成功だが、同一PC・同一基礎Pythonの条件付き成功。実移植先でのファイル一致・試験数・実行結果は不明。

examples/acoustic_quickとacoustic_comparisonのdata/generation.jsonは、現在configsの対応する*_data.jsonとJSON内容が完全一致。experiment.jsonの差はtrain_manifest/eval_manifest/truth_path/exportの4トップレベルキーで、生成・解析設定そのものは一致。差分の値をinventory.jsonに保存した。これは過去出力波形を再生成して一致確認した結果ではない。

legacyのgeneration.jsonはschema_versionとsignal_parametersを生成記録として追加しており、設定との単純JSON一致はしない。旧0.1完全ソースがないことは既存要件書にも明記されている。旧結果の厳密再現を保証しない。

初期ファイル探索でtests/_work等のアクセス拒否が発生。回避せず、以後はソース・設定・正規報告と選択したexamplesだけを対象にした。全一時作業を完全棚卸ししたとは扱わない。

## 検証別の判定

以下「再実行可能」は必要コード・条件を静的に確認した意味。新環境でのPASSは未確認。

|ID・検証の問い|条件・入口・根拠|同梱／不足|判定|
|V01 acoustic quick/comparisonの方式比較|acoustic_generator.py、acoustics.py、configs/acoustic_*、profiles.acoustic_experiment。生成と解析の両設定が必要。CLI generate→validate→execute→inspect/view|生成器・設定・要件書同梱、過去Bundleは非同梱。過去件数は要件書§3と元reports/ACOUSTIC_DELIVERY.mdに残る|条件付き再実行可能。数値・配列の再生成一致は未検証|
|V02 legacy/A先行と旧簡易方式比較|synthetic.py、configs/quick_data.json/comparison_data.json/a_first.json。要件書S01/S04|現行コードでの再試験可能。旧0.1の完全ソースなし|現行再試験可能／旧版厳密再現不可|
|V03 受入17試験|tests/test_acceptance.py。legacy、train8、3秒、IF16本、Dパッチ縮小。標準quickのtrain12・4秒・IF64本と異なる|試験・fixture同梱|再実行可能。報告comparisonデータの代用不可|
|V04 音響15試験|tests/test_acoustics.py。数理式の局所試験＋pipelineはacoustic train6・3秒・IF16本|同梱|再実行可能。検出性能の反復評価ではない|
|V05 物理数値レポート|python -m nv_runner.verify_physics --output reports/physics。要件書Q01|verify_physics.py同梱。過去レポート自体は元reports/acousticにある|再実行可能。130試験だけではレポート再生成されない|
|V06 C01〜C08契約22試験|tests/test_contract_c*.py、contract_fixtures.py、docs/parallel_contracts/fixtures.json|同梱|再実行可能|
|V07 独立化・候補機能・Phase3追加試験|test_selection、independence_tools、input_candidate、model_candidate、route_a_candidate、parallel_integration、plugin_*。各fixtureの局所条件を使用|全test_*.py同梱・ハッシュ一致、総計130に含む|再実行可能。ただしモデル候補の存在と本番選択は別|
|V08 viewer実ブラウザー操作|tests/viewer_smoke.cjs＋新規生成viewer。要件書V01|スクリプト同梱、Node/Playwright/ブラウザー別依存。過去厳密版不明|追加環境が必要。Python130試験で代用不可|
|V09 移設・参照解決・再学習比較|tools/replay_saved_checks.py --example <新規demo> --output <新規出力>。要件書X01|同梱。data/experiment/summary/Bundleはdemoで新規生成可能|再実行可能。過去データ不要。MIGRATIONの分類をそのまま適用しない|
|V10 並列統合の変更前後一致|tools/run_parallel_verification.py --baseline ... --output ...|PRE-INTEGRATION baselineが必要、非同梱|過去比較は再実行不可。現行でbaselineを作ると別の問いになる|
|V11 Phase3導入前後の互換性証明|tools/verify_phase3.py。reports/phase3/Iのbaseline_demo、baseline_hashes、前後ログ等を読む|過去証跡非同梱|歴史的比較は不足。新規の交換・互換性試験とは分ける|
|V12 D-002最小比較|code_investigation/poc/D002_minimal/scripts/run_tests.py, benchmark.py、fixtureと候補A/B/C|Phase3 portable対象外。元側には独立一式あり|別途移送が必要。過去A/B24PASS、C12BLOCKEDを全候補成功と扱わない|
|V13 実測CSVの物理接続・外乱下の性能|実測CSV、CH対応、校正・同期・メタデータ、正常登録、実測正解が必要|研究上の今後の検証。合成結果で代用不可|既存合成検証の再現ではなく新規検証|

## データ・条件を取り違える具体的な経路

|操作・選択|実際の意味|
|demo --profile quick（generator省略）|acoustic_settingsとacoustic_experimentで実行。configs/*.jsonを読む処理ではない|
|generate --settings configs/quick_data.json|generatorなし→legacy。seed42でもacousticとは別波形|
|configsを編集後にdemoを実行|編集したJSONはdemoに反映されない。profiles/生成器の既定から別途構成される|
|generate acoustic＋execute quick.json|物理生成とlegacy解析設定の混在になり得る。正しい組合せはacoustic_*同士|
|unittest全件成功をcomparison再現と解釈|異なるfixture規模・前処理・モデル条件の検証を取り違えている|
|01_runtimeの古い手順をportable_phase3へ適用|verify_transferとverify_migration、32と130、履歴比較の範囲が異なる|

この表は実装上成立する取り違えの可能性であり、移植先で実際に起きたことの断定ではない。

## 手順の具体的な矛盾

portable_phase3/MIGRATION.md「過去成果物を必要とする保存済みツール」はreplay_saved_checks.pyとprepare_history.pyをまとめて過去成果物が必要とする。一方、CLAUDE_CODE_VALIDATION_REQUIREMENTS.md:510–516はX01を新規demoだけで可能と定義。replay_saved_checks.py:18以降もexample/summary.jsonから今生成したBundleを読める。後者が当該スクリプトの能力と整合する。

既存文書は監査中に修正していない。この説明の整理は後続の移植手順改訂対象。

## 次に移植先と照合する最小証拠

1. 実際に移送したpackageのmanifestと、生成器・profiles・__main__・configs・testsのSHA-256。
2. 実行したコマンドと作業ディレクトリ。demoかgenerate/executeか、generator指定有無。
3. 再生成データのgeneration.json、experiment.json、train/eval manifest、dataset_split.json。
4. environment.json、metrics.json、試験ログ、Bundle manifest。元測定の大容量配列をまず送る必要はない。
5. 比較したい元検証ID（上表V01〜V13）。件数一致だけでなく「同じ問い」を先に指定する。

上記で設定差を特定してから配列ハッシュや数値許容差の比較へ進む。日時・UUID・パスを含むJSON全体やNPZコンテナのハッシュだけで数値再現失敗と決めない。一方、無根拠に差を無視もしない。ビット一致、数値一致、判定一致、契約試験成功を別々に記録する。

## 再実行計画（今回は実行していない）

正本portable_phase3のルートで、まずverify_migration.py。物理モデル比較には明示的に下記を使用する。依存導入はMIGRATION.mdに従う。

```powershell
python -m nv_runner generate --settings configs/acoustic_quick_data.json --output data/acoustic_quick
python -m nv_runner validate --config configs/acoustic_quick.json
python -m nv_runner execute --config configs/acoustic_quick.json
```

comparisonは上記quickをcomparisonへ変更。既存出力は上書きせず新しいコピーで行う。使用設定のSHA、生成記録、分割、環境、結果を一緒に保管する。X01専用には `python -m nv_runner demo --profile quick --generator acoustic --output demos/replay_acoustic_quick` を実行してから要件書のreplayコマンドを使う。demoはprofilesから構成されるためconfigs方式とは入口を明記する。

合否は既存assertと既存要件書に従い、新環境で同じ検出件数になるように条件を調整しない。過去件数との差が出たら原因調査として残す。

## 根拠の入口

- nv_runner/__main__.py:12–34：generator選択
- nv_runner/demo.py:14–30：JSON設定を読むのではなく関数で生成・実験条件を作る
- tests/test_acceptance.py:26–40：縮小legacy fixture
- tests/test_acoustics.py:197–206：縮小acoustic fixture
- docs/CLAUDE_CODE_VALIDATION_REQUIREMENTS.md：DATA-A/L、SPLIT、PROC/MODEL、S/T/P/Q/V/Xの詳細条件
- portable_phase3/MIGRATION.md、migration_validation.json：移植範囲と検証限界
- tools/replay_saved_checks.py、run_parallel_verification.py、verify_phase3.py：必要成果物の違い
- code_investigation/poc/D002_minimal/results/completion.json：production_integration=false、候補C未実行
- inventory.json：今回照合したファイルごとのハッシュ、試験名、過去設定との差

## 未完了事項

実移植先の証拠未取得。波形再生成比較・移植先試験は未実施。元環境のすべての一時コマンドの網羅性は保証できない。次の作業は上記最小証拠による差分診断であり、不足条件をAIが推測して埋めることではない。
