import html
from bridge.adapter import write

def metrics(rows):
    normal=[r for r in rows if r['label']=='normal'];abnormal=[r for r in rows if r['label']=='abnormal']
    return {'normal_n':len(normal),'normal_correct':sum(r['decision']=='within' for r in normal),'false_positive':sum(r['decision']=='outside' for r in normal),'normal_undetermined':sum(r['decision']=='undetermined' for r in normal),'abnormal_n':len(abnormal),'detected':sum(r['decision']=='outside' for r in abnormal),'missed':sum(r['decision']=='within' for r in abnormal),'abnormal_undetermined':sum(r['decision']=='undetermined' for r in abnormal)}

def paired(rows):
    normal={r['family']:r for r in rows if r['scenario']=='normal'};abnormal=[r for r in rows if r['scenario']!='normal']
    if len(normal)!=sum(r['scenario']=='normal' for r in rows):raise ValueError('duplicate normal family')
    return {'paired_n':len(abnormal),'both_correct':sum(normal[r['family']]['decision']=='within' and r['decision']=='outside' for r in abnormal),'outside_with_normal_outside':sum(normal[r['family']]['decision']=='outside' and r['decision']=='outside' for r in abnormal)}

def summarize(rows,stability,protocol,out):
    keys=sorted({r['route_key'] for r in rows});stats=[];cells=[]
    for variant in sorted({r['variant'] for r in stability}):
        for key in keys:
            rr=[r for r in stability if r['variant']==variant and r['route_key']==key];stats.append(dict(variant=variant,route=key,threshold=rr[0]['threshold'],**metrics(rr),**paired(rr)))
    conditions=[(None,None,None)]+[(d,f,l) for d in protocol['positions_m'] for f in protocol['frequencies_hz'] for l in protocol['levels_db_spl']]
    for key in keys:
        for d,f,l in conditions:
            rr=[r for r in rows if r['route_key']==key and r['direction']==d and r['frequency_hz']==f and r['db_spl']==l]
            cell=dict(route=key,direction=d,frequency_hz=f,db_spl=l,**metrics(rr),**paired(rr));cell['by_anomaly']={k:metrics([r for r in rr if r['scenario']==k]) for k in protocol['scenarios'][1:]};cells.append(cell)
    write(out/'stability_summary.json',stats);write(out/'map_summary.json',cells)
    lines=['# 個体差・閾値安定性と外乱下の異常検出','', '事前固定した9構成を共通の未使用6群で比較。評価結果による調整・最良構成の採用は行っていない。外乱下は事前指定s201_fit32_cal8だけを評価。','', '|構成|経路|正常正解/n|異常検出/n|正常・異常とも正解/n|閾値|','|---|---|---:|---:|---:|---:|']
    for s in stats:lines.append(f'|{s["variant"]}|{s["route"]}|{s["normal_correct"]}/{s["normal_n"]}|{s["detected"]}/{s["abnormal_n"]}|{s["both_correct"]}/{s["paired_n"]}|{s["threshold"]:.6g}|')
    lines+=['','正常6群・異常5種類×6群=30条件。同じ6群の派生であり30独立個体ではない。正常誤判定、見逃し、判定不可をJSONに別保存。','', '## 読み方・制約','', '- 外乱ありの異常がoutsideでも、対応する正常もoutsideなら対象異常を識別した証拠にしない。both_correctは正常withinかつ異常outsideの対比較。', '- 三分割は同じ60群の候補プールを共有するため、独立反復や信頼区間とは扱わない。', '- fit16/cal4対fit16/cal8は同じfit・同じモデルを使い、閾値用個体を4群追加。fit16/cal8対fit32/cal8はcalを固定してfitを16群追加。', '- 学習個体差の定義は既存合成器の音源振幅変動と測定変動・ノイズ。実機の構造・共振・センサー再設置等のばらつきを網羅したとは言えない。', '- 今回は前回マップと同じ周波数・位置で20/40/60 dBの27条件を選んだ部分比較。前回の全12音圧を再実行したものではない。', '- relation異常は反対側追加音源によるp-u関係変化という模擬で、実故障の同定ではない。', '- 測定時間・窓数・受音点数を変える集約の検証、および実測検証は今回未実施。', '- これは追加の開発検証。結果を方式選択に使った後は別の未使用個体・外乱条件で最終確認する。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    parts=[]
    for key in keys:
        parts.append(f'<section><h2>{key}</h2><table><tr><th>位置</th><th>Hz</th><th>dB</th><th>正常正解</th><th>異常検出</th><th>両方正解</th></tr>')
        for c in cells:
            if c['route']!=key:continue
            d,f,l=c['direction'],c['frequency_hz'],c['db_spl'];rr=[r for r in rows if r['route_key']==key and r['direction']==d and r['frequency_hz']==f and r['db_spl']==l];ratio=c['both_correct']/max(1,c['paired_n']);color=f'hsl({120*ratio},45%,85%)'
            parts.append(f'<tr><td>{d or "追加なし"}</td><td>{f or "—"}</td><td>{l if l is not None else "—"}</td><td>{c["normal_correct"]}/{c["normal_n"]}</td><td>{c["detected"]}/{c["abnormal_n"]}</td><td style="background:{color}"><details><summary>{c["both_correct"]}/{c["paired_n"]}</summary>'+''.join(f'<a href="{r["detail"]}">{r["family"]} {r["scenario"]}: {r["decision"]}</a><br>' for r in rr)+'</details></td></tr>')
        parts.append('</table></section>')
    (out/'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8"><title>個体差・異常検出検証</title><style>body{font:15px sans-serif;max-width:1200px;margin:32px auto;background:#eef3f5;color:#173448}section{background:white;padding:20px;margin:20px 0}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ccc}pre{white-space:pre-wrap}</style><h1>正常個体差を学習した上で、外乱下でも異常を識別できるか</h1><p>緑色は「正常と異常の両方を正しく判定した割合」。異常判定が増えただけでは成功にしません。独立評価6群。</p><section><pre>'+html.escape('\n'.join(lines))+'</pre></section>'+''.join(parts),encoding='utf-8')
