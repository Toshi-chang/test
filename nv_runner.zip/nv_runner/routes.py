"""Route contract: capabilities/prepare/fit/score/aggregate/calibrate/decide."""
from dataclasses import dataclass, field
import numpy as np
from . import __version__
from .common import identity, union_length
from .signals import valid_interval, select_mask, mean_square_spectrum
from .models import NormalModel


@dataclass
class PreparedSet:
    samples: list = field(default_factory=list)
    values: dict = field(default_factory=dict)
    assets: dict = field(default_factory=dict)
    coverage: dict = field(default_factory=dict)


def basic_features(x, fs):
    rms = np.sqrt(np.mean(x*x, axis=0))
    corr = np.mean(x[:, 0] * x[:, 1]) / max(float(rms[0]*rms[1]), 1e-20)
    power = mean_square_spectrum(x[:,0])
    freq = np.fft.rfftfreq(len(x), 1/fs)
    return [*rms, float(np.max(abs(x[:, 0])) / max(rms[0], 1e-12)), float(corr),
            *[float(power[(freq >= a) & (freq < b)].sum()) for a, b in [(0, 80), (80, 150), (150, 240), (240, fs/2+1)]]]


class RoutePlugin:
    def __init__(self, config):
        self.config = config
        self.key = config["key"]

    def capabilities(self):
        return {"schema_version": "1.0", "channels": ["pressure:Pa", "particle_velocity:m/s"],
                "rpm": False, "axes": ["time", "channel"]}

    def add(self, prepared, record, start, end, frequency, features, reason=None, **extra):
        m = record.meta
        ident = identity({"source": m["source_sha256"], "metadata": m["metadata_sha256"],
                          "route": self.config, "version": __version__, "range": [start, end], "frequency": frequency,
                          "coordinates": extra})
        sample = {"sample_id": ident, "route_key": self.key, "specimen_id": m["specimen_id"], "case_id": m["case_id"],
            "measurement_id": m["measurement_id"], "start_sample": int(start), "end_sample": int(end),
            "support_start_sample": int(start), "support_end_sample": int(end), "frequency_hz": frequency,
            "display_center_seconds": (start+end)/2/m["timebase"]["sample_rate_hz"], "status": "prepared" if features is not None else "unscored",
            "reason": reason, "parent_refs": [m["measurement_id"]], "operation": self.config["plugin"],
            "config_ref": f"route_config:{self.key}", "software_version": __version__, **extra}
        prepared.samples.append(sample)
        if features is not None:
            values = np.asarray(features, dtype=float)
            if not np.isfinite(values).all():
                sample.update(status="unscored", reason="non_finite_features")
            else:
                prepared.values[ident] = values

    def fit(self, prepared, model_config, seed):
        ordered = sorted(prepared.values)
        return NormalModel().fit(np.array([prepared.values[k] for k in ordered]), model_config, seed)

    def score(self, model, prepared, batch_size=128):
        values = {}
        failures = {}
        ids = sorted(prepared.values)
        if model is not None:
            for offset in range(0, len(ids), batch_size):
                batch = ids[offset:offset+batch_size]
                try:
                    scores = model.score(np.array([prepared.values[k] for k in batch]))
                    if len(scores) != len(batch) or not np.isfinite(scores).all():
                        raise ValueError("invalid score batch")
                    values.update(zip(batch, map(float, scores)))
                except Exception:
                    for sid in batch:
                        try:
                            score = float(model.score(np.array([prepared.values[sid]]))[0])
                            if not np.isfinite(score):
                                raise ValueError("non-finite score")
                            values[sid] = score
                        except Exception as e:
                            failures[sid] = "sample_processing_failed: " + str(e)
        return [{"sample_id": s["sample_id"], "route_key": self.key, "case_id": s["case_id"],
                 "status": "scored" if s["sample_id"] in values else "unscored",
                 "anomaly_score": values.get(s["sample_id"]),
                 "reason": None if s["sample_id"] in values else (failures.get(s["sample_id"]) or s["reason"] or "model_untrained"),
                 "model_ref": f"model:{self.key}" if model is not None else None,
                 "score_definition_ref": f"score:{self.key}", "evidence_ref": s["sample_id"]} for s in prepared.samples]

    def aggregate(self, prepared, results, records):
        rows = []
        lookup = {r["sample_id"]: r for r in results}
        for cid in sorted({r.meta["case_id"] for r in records}):
            rr = [r for r in records if r.meta["case_id"] == cid]
            samples = [s for s in prepared.samples if s["case_id"] == cid]
            good = [s for s in samples if lookup[s["sample_id"]]["anomaly_score"] is not None]
            scores = [lookup[s["sample_id"]]["anomaly_score"] for s in good]
            reasons = sorted({s["reason"] for s in samples if s["reason"]} |
                             {lookup[s["sample_id"]]["reason"] for s in samples if lookup[s["sample_id"]]["reason"]} |
                             {prepared.coverage[r.meta["measurement_id"]]["reason"] for r in rr if prepared.coverage[r.meta["measurement_id"]]["reason"]})
            not_applicable = all(prepared.coverage[r.meta["measurement_id"]].get("not_applicable", False) for r in rr)
            sufficient = bool(good) and len(good) == len(samples) and not any(
                prepared.coverage[r.meta["measurement_id"]].get("incomplete", False) for r in rr)
            observed = sum(r.meta["n_samples"]/r.meta["timebase"]["sample_rate_hz"] for r in rr)
            scored_time = sum(union_length([(s["start_sample"], s["end_sample"]) for s in good if s["measurement_id"] == r.meta["measurement_id"]]) /
                              r.meta["timebase"]["sample_rate_hz"] for r in rr)
            rows.append({"route_key": self.key, "case_id": cid, "specimen_id": rr[0].meta["specimen_id"],
                "execution_status": "skipped" if not_applicable else "completed", "coverage_status": "not_applicable" if not_applicable else ("sufficient" if sufficient else "insufficient"),
                "decision": "undetermined", "case_score": max(scores) if scores else None, "threshold_ref": None,
                "aggregation_ref": f"aggregation:{self.key}", "n_created": len(samples), "n_scored": len(good),
                "reason": ";".join(reasons) or ("model_untrained" if not good else None),
                "evidence_refs": [s["sample_id"] for s in good], "observed_seconds": observed,
                "scored_union_seconds": scored_time, "score_p95": float(np.quantile(scores, .95)) if scores else None,
                "events_per_second": len(samples)/observed if self.config["plugin"] == "event" else None})
        return rows

    def calibrate(self, cases, policy):
        usable = [r for r in cases if r["case_score"] is not None and r["coverage_status"] == "sufficient"]
        n = len({r["specimen_id"] for r in usable})
        value = policy.get("explicit_threshold")
        source = "explicit" if value is not None else "calibration"
        if value is None and n >= policy.get("min_specimens", 2):
            value = float(np.quantile([r["case_score"] for r in usable], policy["quantile"], method="higher"))
        return {"schema_version": "1.0", "route_key": self.key, "value": value,
                "status": "available" if value is not None else "calibration_unavailable", "source": source,
                "quantile": policy["quantile"], "method": "higher", "comparison": ">", "n_specimens": n,
                "n_cases": len(usable), "case_ids": [r["case_id"] for r in usable], "false_positive_rate_guaranteed": False}

    def decide(self, rows, threshold):
        for row in rows:
            row["threshold_ref"] = f"threshold:{self.key}"
            if row["case_score"] is not None and threshold["value"] is not None:
                if row["case_score"] > threshold["value"]:
                    row["decision"] = "outside"
                elif row["coverage_status"] == "sufficient":
                    row["decision"] = "within"
            if threshold["value"] is None:
                row["reason"] = ";".join(filter(None, [row["reason"], "calibration_unavailable"]))
        return rows


class FixedWindow(RoutePlugin):
    def feature_schema(self):
        if self.config.get("selection", {}).get("enabled"):
            return list(zip(["selected_p_power", "selected_u_power", "msc", "signed_intensity", "cos_phase", "sin_phase", "occupancy"],
                            ["Pa^2", "(m/s)^2", "1", "W/m^2", "1", "1", "1"]))
        return list(zip(["p_rms", "u_rms", "p_crest", "pu_correlation", "p_band_0_80", "p_band_80_150", "p_band_150_240", "p_band_240_nyquist"],
                        ["Pa", "m/s", "1", "1", "Pa^2", "Pa^2", "Pa^2", "Pa^2"]))

    def prepare(self, records, service):
        out = PreparedSet()
        selected = self.config.get("selection", {}).get("enabled", False)
        for r in records:
            fs = r.meta["timebase"]["sample_rate_hz"]
            width, hop = round(fs*self.config["window_seconds"]), round(fs*self.config["hop_seconds"])
            if min(width, hop) < 1:
                raise ValueError("window/hop less than one sample")
            mid, n = r.meta["measurement_id"], len(r.signals)
            maps = service.maps(r) if selected else None
            if selected:
                requested = select_mask(self.config["selection"]["condition"], maps)
                mask = requested & maps["valid"]
                out.assets[mid] = {"requested_mask": requested, "selection_mask": mask}
            last = 0
            for start in range(0, n-width+1, hop):
                end = start+width
                last = end
                features, reason, extra = None, None, {}
                if not valid_interval(r, start, end):
                    reason = "invalid_input_range"
                elif selected:
                    frame_idx = np.where((maps["support_start"] >= start) & (maps["support_end"] <= end))[0]
                    active = mask[frame_idx]
                    extra = {"frame_indices": frame_idx.tolist(), "bin_range": [0, len(maps["frequency_hz"])],
                             "mask_ref": f"prepared:{self.key}:{mid}", "map_ref": f"signal:{mid}"}
                    if active.any():
                        features = [float(maps[k][frame_idx][active].mean()) for k in ("p_power", "u_power", "msc", "intensity")]
                        phase = maps["phase"][frame_idx][active]
                        features += [float(np.cos(phase).mean()), float(np.sin(phase).mean()), float(active.mean())]
                    else:
                        reason = "empty_selection"
                else:
                    features = basic_features(r.signals[start:end], fs)
                self.add(out, r, start, end, [0, fs/2], features, reason, **extra)
            out.coverage[mid] = {"reason": "too_short" if last == 0 else None,
                "incomplete": last == 0, "excluded_ranges": [[last, n]] if last < n else []}
        return out


class OrderWindow(RoutePlugin):
    def capabilities(self):
        return {**super().capabilities(), "rpm": True, "rpm_unit": "rev/min", "shaft_required": True,
                "rotation_source": "synchronized rpm; pulse decoding belongs in input adapter"}

    def feature_schema(self):
        return [(f"{ch}_order_{order}_power", unit) for ch, unit in [("p", "Pa^2"), ("u", "(m/s)^2")]
                for order in range(1, self.config["max_order"]+1)] + [("p_rms", "Pa"), ("u_rms", "m/s"), ("pu_correlation", "1")]

    def prepare(self, records, service):
        out = PreparedSet()
        revs, step, spr = self.config["revolutions"], self.config["hop_revolutions"], self.config["samples_per_revolution"]
        for r in records:
            mid, fs = r.meta["measurement_id"], r.meta["timebase"]["sample_rate_hz"]
            out.coverage[mid] = {"reason": None, "excluded_ranges": [], "incomplete": False}
            if r.rpm is None:
                out.coverage[mid].update(reason="rotation_signal_missing", not_applicable=True, incomplete=True)
                continue
            if not r.meta["operating_conditions"].get("shaft"):
                out.coverage[mid].update(reason="shaft_undefined", not_applicable=True, incomplete=True)
                continue
            quality = r.rpm > 0
            bad_jumps = np.abs(np.diff(r.rpm, prepend=r.rpm[0])) * fs > self.config.get("max_rpm_change_per_second", 20000)
            quality &= ~bad_jumps
            for span in r.meta["validity"]:
                quality[span["start_sample"]:span["end_sample"]] = False
            edges = np.diff(np.r_[False, quality, False].astype(int))
            segments = list(zip(np.where(edges == 1)[0], np.where(edges == -1)[0]))
            invalid_edges = np.diff(np.r_[False, ~quality, False].astype(int))
            out.coverage[mid]["excluded_ranges"] = [[int(a), int(b)] for a,b in zip(np.where(invalid_edges == 1)[0], np.where(invalid_edges == -1)[0])]
            if not quality.all():
                out.coverage[mid].update(reason="invalid_or_stopped_rotation", incomplete=True)
            assets = {}
            created = 0
            for a, b in segments:
                rpm = r.rpm[a:b]
                if len(rpm) < 2:
                    continue
                angle = np.r_[0., np.cumsum((rpm[1:] + rpm[:-1]) / (120 * fs))]
                if self.config["max_order"] * rpm.max()/60 >= fs/2:
                    out.coverage[mid].update(reason="order_band_above_nyquist", incomplete=True)
                    continue
                from scipy.signal import butter, sosfiltfilt
                cutoff = min(.45*fs, .45*spr*float(rpm.min())/60)
                sos = butter(4, cutoff, fs=fs, btype="low", output="sos")
                if len(rpm) <= 15:
                    out.coverage[mid].update(reason="rotation_segment_too_short", incomplete=True)
                    continue
                filtered = sosfiltfilt(sos, r.signals[a:b], axis=0)
                last = int(a)
                for origin in np.arange(0, max(0., angle[-1]-revs), step):
                    grid = origin + np.arange(round(revs*spr))/spr
                    positions = np.interp(grid, angle, np.arange(a, b))
                    start, end = int(np.floor(positions[0])), min(len(r.signals), int(np.ceil(positions[-1]))+1)
                    last = end
                    # Limit physical bandwidth before interpolation to the angular Nyquist.
                    resampled = np.column_stack([np.interp(positions, np.arange(a, b), filtered[:, k]) for k in range(2)])
                    spectrum = mean_square_spectrum(resampled)
                    order_axis = np.fft.rfftfreq(len(resampled), 1/spr)
                    features = [float(spectrum[abs(order_axis-order) <= .15, ch].sum()) for ch in range(2) for order in range(1, self.config["max_order"]+1)]
                    rms = np.sqrt(np.mean(resampled**2, axis=0))
                    features += [*rms, float(np.mean(resampled[:, 0]*resampled[:, 1])/max(float(rms.prod()), 1e-20))]
                    array_key = f"source_positions_{created}"
                    assets[array_key] = positions
                    assets[f"angle_revolutions_{created}"] = grid
                    assets[f"angular_waveform_{created}"] = resampled
                    self.add(out, r, start, end, [0, float(self.config["max_order"]*rpm.max()/60)], features,
                        map_ref=f"signal:{mid}", angular_ref=f"prepared:{self.key}:{mid}", angular_key=array_key,
                        order_range=[0, self.config["max_order"]], rpm_range=[float(r.rpm[start:end].min()), float(r.rpm[start:end].max())],
                        interpolation="linear; trapezoidal rpm integration; 4th-order zero-phase lowpass",
                        support_start_sample=int(a), support_end_sample=int(b), angle_origin_sample=int(a))
                    created += 1
                if last < b:
                    out.coverage[mid]["excluded_ranges"].append([last, int(b)])
            if not created and not out.coverage[mid]["reason"]:
                out.coverage[mid].update(reason="insufficient_revolutions", incomplete=True)
            if assets:
                out.assets[mid] = assets
        return out


class EventRoute(RoutePlugin):
    def feature_schema(self):
        return FixedWindow({"selection": {}, "key": self.key}).feature_schema() + [("core_duration", "s")]

    def prepare(self, records, service):
        from scipy.signal import butter, sosfiltfilt
        from scipy.ndimage import uniform_filter1d
        out = PreparedSet()
        for r in records:
            mid, fs, n = r.meta["measurement_id"], r.meta["timebase"]["sample_rate_hz"], len(r.signals)
            if self.config["highpass_hz"] >= fs/2:
                raise ValueError("event highpass exceeds Nyquist")
            if r.meta["validity"]:
                out.coverage[mid] = {"reason": "invalid_input_filter_support", "incomplete": True, "searched_ranges": []}
                continue
            filtered = sosfiltfilt(butter(4, self.config["highpass_hz"], fs=fs, btype="high", output="sos"), r.signals[:, 0])
            envelope = np.sqrt(np.maximum(0, uniform_filter1d(filtered**2, max(1, round(fs*self.config["envelope_seconds"])), mode="nearest")))
            mask = envelope > self.config["threshold_pa"]
            edges = np.diff(np.r_[False, mask, False].astype(int))
            spans = [(int(a), int(b)) for a, b in zip(np.where(edges == 1)[0], np.where(edges == -1)[0]) if (b-a)/fs >= self.config["min_seconds"]]
            merged = []
            for a, b in spans:
                if merged and a-merged[-1][1] <= fs*self.config["merge_seconds"]:
                    merged[-1][1] = b
                else:
                    merged.append([a, b])
            out.assets[mid] = {"event_envelope_pa": envelope, "candidate_mask": mask}
            out.coverage[mid] = {"reason": None if merged else "no_events", "incomplete": False,
                                 "searched_ranges": [[0, n]], "event_count": len(merged)}
            for a, b in merged:
                margin = round(fs*self.config["margin_seconds"])
                start, end = max(0, a-margin), min(n, b+margin)
                features = basic_features(r.signals[start:end], fs) + [(b-a)/fs]
                self.add(out, r, start, end, [0, fs/2], features, core_range=[a, b],
                    detector_frequency_hz=[self.config["highpass_hz"], fs/2], map_ref=f"signal:{mid}",
                    detector_ref=f"prepared:{self.key}:{mid}", support_start_sample=0, support_end_sample=n,
                    detector_definition="whole-record zero-phase highpass, centered RMS; short removal then gap merge then margin")
        return out


class TFPatch(RoutePlugin):
    def feature_schema(self):
        return [(f"log10_{channel}_power_t{t}_f{f}", "log10 relative to 1 SI-unit squared")
                for t in range(self.config["time_frames"]) for f in range(self.config["frequency_bins"]) for channel in ("p", "u")]

    def prepare(self, records, service):
        out = PreparedSet()
        nt, nf = self.config["time_frames"], self.config["frequency_bins"]
        for r in records:
            mid = r.meta["measurement_id"]
            maps = service.maps(r)
            frequencies = maps["frequency_hz"]
            matrix = np.stack([maps["p_log_power"], maps["u_log_power"]], axis=-1)
            count, last_frame, last_bin = 0, 0, 0
            for ti in range(0, matrix.shape[0]-nt+1, self.config["hop_frames"]):
                for fi in range(0, matrix.shape[1]-nf+1, self.config["hop_bins"]):
                    start, end = int(maps["frame_start"][ti]), int(maps["frame_end"][ti+nt-1])
                    valid = valid_interval(r, start, end)
                    self.add(out, r, start, end, [float(frequencies[fi]), float(frequencies[fi+nf-1])],
                        matrix[ti:ti+nt, fi:fi+nf].ravel() if valid else None, None if valid else "invalid_input_range",
                        frame_range=[ti, ti+nt], bin_range=[fi, fi+nf], map_ref=f"signal:{mid}",
                        display_time_range=[float(maps["display_center_seconds"][ti]), float(maps["display_center_seconds"][ti+nt-1])],
                        normalization="fit StandardScaler; no per-patch amplitude normalization")
                    count += 1
                    last_frame, last_bin = ti+nt, fi+nf
            out.coverage[mid] = {"reason": None if count else "too_short_for_patch", "incomplete": count == 0,
                "excluded_frame_range": [last_frame, matrix.shape[0]], "excluded_bin_range": [last_bin, matrix.shape[1]],
                "waveform_tail": [int(maps["frame_end"][-1]), len(r.signals)]}
        return out


def _fixed_window_candidate(config):
    # Lazy registration: unselected candidates need not be installed or imported.
    from .route_a_candidate import FixedWindowCandidate
    return FixedWindowCandidate(config)


REGISTRY = {"fixed_window": FixedWindow, "order_window": OrderWindow, "event": EventRoute, "tf_patch": TFPatch,
            "fixed_window_candidate": _fixed_window_candidate}
