"""Integration-owner tests. Candidates A/C are intentionally not adopted by runner."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest
import uuid
import numpy as np

from nv_runner.acoustic_generator import generate_acoustic, acoustic_settings
from nv_runner.profiles import acoustic_experiment
from nv_runner.common import read_json, write_json
from nv_runner.bundle import BundleReader
from nv_runner.runner import validate_config


class ParallelIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(__file__).resolve().parent/'_work'/'I'/uuid.uuid4().hex
        cls.root.mkdir(parents=True)
        options=acoustic_settings('quick'); options.update(train_specimens=6,duration_seconds=3)
        generate_acoustic(cls.root/'data',options)
        cls.config=acoustic_experiment('data','runs')
        for route in cls.config['routes']:
            if route['model']['kind']=='isolation_forest': route['model']['n_estimators']=16

    def config_path(self,config):
        path=self.root/(uuid.uuid4().hex+'.json'); write_json(path,config); return path

    def cli(self,config,block,expect_success=True):
        # A missing module is simulated at Python import resolution, not by moving/deleting source.
        path=self.config_path(config); result_path=self.root/(uuid.uuid4().hex+'_process.json')
        script='''
import importlib.abc, json, pathlib, sys
blocked=set(json.loads(sys.argv[1])); config=sys.argv[2]; report=pathlib.Path(sys.argv[3])
class BlockCandidates(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in blocked:
            raise ModuleNotFoundError('candidate intentionally unavailable: '+fullname)
sys.meta_path.insert(0,BlockCandidates())
from nv_runner.__main__ import main
sys.argv=['nv_runner','execute','--config',config]
main()
report.write_text(json.dumps({'imported_candidates':sorted(n for n in sys.modules if n.startswith('nv_runner.') and n.endswith('_candidate'))}),encoding='utf-8')
'''
        completed=subprocess.run([sys.executable,'-c',script,json.dumps(block),str(path),str(result_path)],capture_output=True,text=True)
        if not expect_success:
            self.assertNotEqual(completed.returncode,0)
            return completed
        self.assertEqual(completed.returncode,0,completed.stdout+'\n'+completed.stderr)
        reader=BundleReader(completed.stdout.strip().splitlines()[-1]).validate()
        return reader,read_json(result_path)

    def candidate_config(self):
        config=copy.deepcopy(self.config)
        candidate=copy.deepcopy(config['routes'][0])
        candidate.update(key='A_candidate',plugin='fixed_window_candidate')
        config['routes'].append(candidate)
        return config

    def test_default_runs_without_any_candidate_installed(self):
        reader,process=self.cli(self.config,['nv_runner.input_candidate','nv_runner.route_a_candidate','nv_runner.model_candidate'])
        self.assertEqual(process['imported_candidates'],[])
        self.assertEqual(reader.manifest['bundle_status'],'complete')
        self.assertEqual(len(reader.manifest['completed_routes']),5)

    def test_selected_route_full_cli_bundle_and_existing_features(self):
        reader,process=self.cli(self.candidate_config(),['nv_runner.input_candidate','nv_runner.model_candidate'])
        self.assertEqual(process['imported_candidates'],['nv_runner.route_a_candidate'])
        self.assertEqual(reader.manifest['schema_version'],'1.0')
        self.assertEqual(reader.manifest['bundle_status'],'complete')
        self.assertIn('A_candidate',reader.manifest['completed_routes'])
        samples=reader.tables['samples']
        def key(s): return (s['measurement_id'],s['start_sample'],s['end_sample'],s['split'])
        old={key(s):s for s in samples if s['route_key']=='A_full'}
        new={key(s):s for s in samples if s['route_key']=='A_candidate'}
        self.assertEqual(old.keys(),new.keys())
        artifacts={a['artifact_id']:a for a in reader.tables['artifacts']}
        arrays={}
        for route in ('A_full','A_candidate'):
            for split in ('fit','calibration','evaluation'):
                ref=f'inputs:{route}:{split}'
                with np.load(reader.path/artifacts[ref]['array_file']['path'],allow_pickle=False) as data:
                    arrays[ref]=data['features'].copy()
        for k,s in old.items():
            n=new[k]
            for field in ('specimen_id','case_id','measurement_id','frequency_hz','support_start_sample','support_end_sample','display_center_seconds','status','reason'):
                self.assertEqual(s[field],n[field])
            self.assertNotEqual(s['sample_id'],n['sample_id'])  # config/plugin identity is intentionally different.
            np.testing.assert_allclose(arrays[s['input_ref']][s['input_row']],arrays[n['input_ref']][n['input_row']],rtol=1e-12,atol=1e-12)
        scored=[s for s in reader.tables['sample_results'] if s['route_key']=='A_candidate']
        self.assertEqual({s['sample_id'] for s in scored},{s['sample_id'] for s in new.values()})
        self.assertTrue(all(s['status']=='scored' and np.isfinite(s['anomaly_score']) for s in scored))
        target=self.root/'candidate_viewer.html'
        viewer=subprocess.run([sys.executable,'-m','nv_runner','view','--bundle',str(reader.path),'--output',str(target)],capture_output=True,text=True)
        self.assertEqual(viewer.returncode,0,viewer.stderr)

    def test_disabled_candidate_does_not_import_or_execute(self):
        config=self.candidate_config(); config['routes'][-1]['enabled']=False
        reader,process=self.cli(config,['nv_runner.input_candidate','nv_runner.route_a_candidate','nv_runner.model_candidate'])
        self.assertEqual(process['imported_candidates'],[])
        self.assertNotIn('A_candidate',reader.manifest['requested_routes'])
        self.assertFalse(any(s['route_key']=='A_candidate' for s in reader.tables['samples']))

    def test_selected_missing_dependency_rejected(self):
        result=self.cli(self.candidate_config(),['nv_runner.route_a_candidate'],expect_success=False)
        self.assertIn('candidate intentionally unavailable',result.stderr)

    def test_candidate_contract_mismatch_rejected_at_validation(self):
        for mutation in ('window','selection'):
            config=self.candidate_config(); route=config['routes'][-1]
            if mutation=='window': route['window_seconds']=-1
            else: route['selection']={'enabled':True,'condition':{'field':'msc','comparison':'>','value':.5}}
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_config(self.config_path(config))
