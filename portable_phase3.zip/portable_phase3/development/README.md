# 独立開発の開始手順

今回のユーザー指定によりC01〜C08を作業基準として採用。契約文書は変更していない。Git/Worktree操作は行わず、所有範囲を `ownership.json` に記録した。実装未着手のcandidateはパス予約であり、ダミーの本番実装ではない。

1. `docs/workstreams/<担当>.md` と既存AGENT_TASKSの担当指示を読む。
2. 専用moduleと専用testを作成し、既存APIを直接呼んで検証する。共有REGISTRYの編集を開始条件にしない。
3. 変更一覧を `python tools/check_workstream_scope.py --owner RA nv_runner/selection.py tests/test_selection.py` の形式で確認する。全変更パスを自己申告する検査であり、Git差分検出・セキュリティ制御ではない。
4. `python -m unittest discover -s tests -p 'test_contract_c*.py' -v` と担当試験を実行する。
5. 共有ファイルへの配線だけをIが行い、既存32試験と全試験を再実行する。

Iが共有コードの唯一の編集担当。Qが契約fixture/契約試験の担当。既存32試験および設計契約書は今回全員変更禁止。専用ファイルは所有者本人が編集し、Iは統合レビューする。生成物は担当ごとの `tests/_work/<owner>/<uuid>/`。依存ライブラリ追加、単位・座標・状態・科学計算の変更はINTEGRATION.mdのCR手順へ分離する。

今回RA領域に `selection.py` と `test_selection.py` を追加した。既存 `signals.select_mask` の互換importはI管理。無効化・選択実行は従来のselection.enabledを利用する。任意pluginの動的交換基盤を実装したものではない。

設定例は現行profilesから担当専用JSONへ生成する。全担当の共通既定設定やrequirementsを並列編集しない。将来のcandidateファイルは未作成でも所有権は予約済み。所有表の変更はIが重複と契約影響を確認する。
