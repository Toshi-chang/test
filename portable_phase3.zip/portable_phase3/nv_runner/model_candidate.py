"""Independent C04 candidate; optional semantic checks stay inside this module.

No labels, IDs, truth paths or thresholds enter fit/score. The caller remains
responsible for supplying normal-only fit rows and disjoint evaluation rows.
Bare arrays preserve C04 compatibility but cannot prove column semantics.
"""
from dataclasses import dataclass
import hashlib
import json

import joblib
import numpy as np
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits


@dataclass(frozen=True)
class FeatureBatch:
    """Candidate-local input: ordered (name, unit) columns and processing recipe.

    This is not a new required C04 type or a ResultBundle schema extension.
    Metadata is checked on every call; the model retains a canonical snapshot.
    """
    values: np.ndarray
    feature_schema: tuple
    processing: dict
    schema_version: str = "1.0"

    def canonical_schema(self):
        if self.schema_version != "1.0":
            raise ValueError("unsupported_feature_schema_version")
        if not isinstance(self.feature_schema, (list, tuple)) or not self.feature_schema:
            raise ValueError("invalid_feature_schema")
        names = []
        columns = []
        for column in self.feature_schema:
            if (not isinstance(column, (list, tuple)) or len(column) != 2
                    or any(not isinstance(v, str) or not v.strip() for v in column)):
                raise ValueError("invalid_feature_schema")
            names.append(column[0])
            columns.append(list(column))
        if len(set(names)) != len(names):
            raise ValueError("duplicate_feature_name")
        if not isinstance(self.processing, dict) or not self.processing:
            raise ValueError("invalid_processing_conditions")
        # JSON is data, never executable code. No fallback stringification.
        try:
            return json.dumps({"schema_version": self.schema_version,
                               "columns": columns, "processing": self.processing},
                              sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (TypeError, ValueError) as exc:
            raise ValueError("invalid_processing_conditions") from exc


def _matrix(values):
    if not isinstance(values, np.ndarray) or values.dtype.kind not in "fiu":
        raise ValueError("features_require_real_numeric_ndarray")
    if values.ndim != 2 or values.shape[1] == 0:
        raise ValueError("features_require_matrix_with_columns")
    if not np.isfinite(values).all():
        raise ValueError("non_finite_features")
    return values


def _unpack(values):
    schema = None
    if isinstance(values, FeatureBatch):
        schema = values.canonical_schema()
        matrix = _matrix(values.values)
        if len(values.feature_schema) != matrix.shape[1]:
            raise ValueError("feature_schema_width_mismatch")
        return matrix, schema
    return _matrix(values), schema


def _configuration(config):
    if not isinstance(config, dict) or config.get("kind") not in {"isolation_forest", "pca"}:
        raise ValueError("unknown model kind")
    key = "n_estimators" if config["kind"] == "isolation_forest" else "components"
    if set(config) - {"kind", "min_samples", key}:
        raise ValueError("unknown_model_configuration")
    for name in ("min_samples", key):
        value = config.get(name, 3 if name == "min_samples" else (64 if key == "n_estimators" else 4))
        if type(value) is not int or value < 1:
            raise ValueError("model_configuration_requires_positive_integer")


class CandidateNormalModel:
    """Same IF/PCA mathematics as the baseline, independently owned lifecycle."""

    @threadpool_limits.wrap(limits=1)
    def fit(self, values, config, seed):
        matrix, schema = _unpack(values)
        _configuration(config)
        if type(seed) is not int or not 0 <= seed <= 2**32 - 1:
            raise ValueError("seed_requires_uint32_integer")
        if len(matrix) < config.get("min_samples", 3):
            raise ValueError("insufficient_training_samples")
        if config["kind"] == "pca" and len(matrix) < 2:
            raise ValueError("insufficient_training_samples")
        # Commit state only after successful fitting; failed refit preserves it.
        scaler = StandardScaler().fit(matrix)
        z = scaler.transform(matrix)
        if config["kind"] == "isolation_forest":
            estimator = IsolationForest(n_estimators=config.get("n_estimators", 64),
                                        random_state=seed, n_jobs=1).fit(z)
            definition = "negative IsolationForest.score_samples after fit-only StandardScaler"
        else:
            rank = max(1, min(config.get("components", 4), len(z)-1, z.shape[1]-1))
            estimator = PCA(n_components=rank, svd_solver="full").fit(z)
            definition = "mean squared PCA reconstruction error in fit-only standardized feature space"
        self.scaler = scaler
        self.estimator = estimator
        self.kind = config["kind"]
        self.width = matrix.shape[1]
        self.schema_json = schema
        self.schema_sha256 = None if schema is None else hashlib.sha256(schema.encode("utf-8")).hexdigest()
        self.config = dict(config)
        self.seed = seed
        self.score_definition = definition
        self.score_direction = "higher_is_more_anomalous"
        return self

    @threadpool_limits.wrap(limits=1)
    def score(self, values):
        if not hasattr(self, "estimator"):
            raise ValueError("model_not_fitted")
        matrix, schema = _unpack(values)
        if matrix.shape[1] != self.width:
            raise ValueError("feature_width_mismatch")
        if schema != self.schema_json:
            raise ValueError("feature_schema_mismatch")
        if len(matrix) == 0:
            return np.empty(0, dtype=float)
        z = self.scaler.transform(matrix)
        if self.kind == "isolation_forest":
            scores = -self.estimator.score_samples(z)
        else:
            restored = self.estimator.inverse_transform(self.estimator.transform(z))
            scores = np.mean((z-restored)**2, axis=1)
        if scores.shape != (len(matrix),) or not np.isfinite(scores).all():
            raise ValueError("non_finite_or_invalid_model_scores")
        return scores

    def save(self, path):
        if not hasattr(self, "estimator"):
            raise ValueError("model_not_fitted")
        joblib.dump(self, path, compress=0)
