# 並列開発の最小契約設計案

2026-10-14 / 提案版0.1 / 対象ソフト0.2.0・データschema1.0

## 結論：全体設計を待たず、既存境界を凍結して着手する

最初に固定するのは **観測Record、PreparedSet/score対応、状態と座標、Bundleの必須構造、変更所有者**。科学的な特徴量の選択、モデル内部、UI、実ファイルの読出し形式、外部通信方式は並列に検討できる。

本資料は設計案であり、承認・実装・エージェント起動は行っていない。既存コード/設定/テストは変更しない。次に実装を開始する場合、共通境界は既存実装を採用する短い合意だけでよく、将来のAPI・大規模schema・全機能設計を先に完成させる必要はない。

|成果物|内容|
|---|---|
|本書|機能依存図、優先確定事項、未決定事項、根拠と現行制約|
|[CONTRACTS_MINIMUM.md](CONTRACTS_MINIMUM.md)|8つの最小境界契約、入出力・保証・拡張方法|
|[AGENT_TASKS.md](AGENT_TASKS.md)|作業分割・エージェント指示・ファイル所有権・着手可否|
|[CONTRACT_TEST_PLAN.md](CONTRACT_TEST_PLAN.md)|契約ごとのダミー・契約テスト案・既存試験対応|
|[INTEGRATION.md](INTEGRATION.md)|変更申請/承認、段階統合、結合ゲート、再開/巻戻し|
|[fixtures.json](fixtures.json)|小さい具体的なRecord/特徴/状態ダミーと生成レシピ。完全Bundleではない|
|[baseline_hashes.json](baseline_hashes.json)|調査対象ファイルの照合値。既存コード無変更の確認用|

## 1. 調査範囲と優先順位

作業フォルダには独立PoC `nv_route_runner_poc` と参照用 `09_DL-NPZ_Bridge` がある。今回の並列開発対象は、ここまで開発・移植準備した前者。後者はsrcにdl_import_adapter/observer_exporter/offline_evaluator/shared_contractを持つ参照プロジェクトだが、PoCのAST import調査では参照プロジェクトへの実行依存はない。後者の内部契約まで今回共通化しない。別プロジェクト全体の並列化が必要ならスコープを追加して調査する。

既存仕様 `docs/NV_route_runner_implementation_spec_v0_1.md`、現行契約 `docs/CONTRACTS.md`、音響設計 `docs/ACOUSTIC_DESIGN.md`、現行コード/32試験を根拠とする。仕様の言語非依存な擬似interfaceより、現行の実呼出しを接続の出発点にする。仕様と実装の差を隠さず下表へ分離する。

凡例：**[確定済み]** は現行仕様/実装で使用中の外部意味、**[実装依存]** は現実の結合点だが理想APIとは限らない、**[仮契約]** は今回提案する開発上の制約、**[未決定]** は実情報不足。今回の文書作成は提案の承認ではない。

調査時に作業ルートで `git rev-parse --show-toplevel` は失敗した。実Gitリポジトリ/remote/default branchは不明。Gitの初期化・ブランチ作成は未実施。ファイル単位の並列設計は可能だが、独立checkoutによる実作業前にGit管理対象を確定する。

## 2. 現在の機能依存関係

矢印はデータ供給/呼出し方向。点線は推論完了後だけ読む情報。

```mermaid
flowchart TD
  CLI[__main__ / demo / profiles] --> GEN[acoustic_generator / synthetic]
  GEN --> PHY[acoustics: 同一音源からp/u]
  GEN --> OBS[観測NPZ + metadata + manifest]
  GEN --> TRUTH[truth JSON / 音源別真値]
  OBS --> INPUT[InputAdapter: MeasurementRecord]
  INPUT --> SPLIT[DatasetPlanner: fit/cal/eval]
  CLI --> RUN[ExperimentRunner / validate_config]
  SPLIT --> RUN
  RUN --> SIG[SignalService / pu_diagnostics]
  RUN --> ROUTE[routes.py: A全/選択, B, C, D]
  SIG --> ROUTE
  ROUTE --> MODEL[NormalModel: fit/score/save]
  ROUTE --> PREP[PreparedSet / score / case集約 / 閾値]
  PREP --> RUN
  TRUTH -. 全推論終了後 .-> RUN
  RUN --> COLL[ResultCollector]
  COLL --> BUNDLE[不変ResultBundle 1.0]
  BUNDLE --> READER[BundleReader.validate]
  READER --> VIEW[viewer.py + viewer.html]
  READER --> OUT[EvaluationAdapter: local import]
  COMMON[common.py: 版/ID/JSON/配列記述] --> INPUT
  COMMON --> ROUTE
  COMMON --> COLL
```

|モジュール|依存/担当|並列化上の制約|
|---|---|---|
|acoustics.py|物理伝達、励振、センサー/rpm観測|モデル/正解ラベルには依存しない。単独数理試験可|
|acoustic_generator.py / synthetic.py|commonと物理→観測登録/真値sidecar|入力契約を守れば独立。正常/異常情報をRecordへ増やさない|
|input_adapter.py|common、Record検証とDatasetPlannerが同居|読出し形式追加と分割ロジックの共同編集を避ける|
|signals.py|Recordの配列/metaを読む。キャッシュはmeasurement_id|共有map変更はA選択/D/runner/viewerへ波及。config単位のサービスを使いまわす前提|
|routes.py|common/models/signals。4plugin＋基底＋REGISTRYが1ファイル|A/B/C/D担当が同時編集すると衝突。新規専用モジュールで開発する|
|models.py|Scaler/IF/PCA、fit/score/save|モデル自由化にはrunnerのkind whitelistと保存metadataも関係|
|runner.py|検証/分割/実行/保存用組立/状態/fusion/正解指標|最大の統合点。単一担当。現状は逐次実行|
|bundle.py|TABLES、collector、reader、output adapterが同居|出力担当がcollectorも直す形にしない。専用出力モジュールを追加|
|viewer.py/html|BundleReader、signal/threshold/prepared/truthの命名|汎用Bundleだけでは足りず、実artifact名が暗黙契約|
|profiles.py / configs / CLI / demo|経路キー、モデル種別、入力先を接続|共有設定は統合担当が一元更新。担当専用configは自由|
|tests/test_acceptance.py等|複数モジュールを横断|既存回帰を固定、担当別新規testファイルへ追加|

## 3. 今すぐ固定する部分と仮のまま着手する部分

|領域|着手前に必要な合意|その合意なしの作業|仮のまま進められる内部|
|---|---|---|---|
|測定入出力 C01|[確定済み] p/uの順序・SI単位・時間軸・共置・u軸・ID・真値隔離|標準Recordを変更する実装は不可。機器フォーマット調査は可能|ファイル読出し方法、校正処理、ログ。標準への変換後で統一|
|共通map C02|[実装依存] key/shape/単位/位相/validの意味をbaseline維持|mapの意味/スケール変更を他担当へ未通知で渡さない|計算最適化、独自局所特徴は専用モジュール内。数値許容差はCT02|
|経路/モデル C03/C04|[確定済み/実装依存] PreparedSet、ID対応、feature_schema、fit/score/save、異常方向|境界を自由に書換える開発は不可|特徴内容/モデル内部は自由。ただし保存schema/モデル説明を更新し合意されたscore方向を守る|
|結果 C05|[確定済み] 状態、null、case/個体、座標、coverage/閾値の意味|未評価を0/正常へ変更不可|経路固有の除外詳細、追加診断値は任意artifactへ|
|保存/表示/受渡し C06/C07|[確定済み/実装依存] Bundle1.0、必須tables/refs、artifact名、receipt|既存Bundleを読む開発には新設計不要|UI、出力先transport、内部索引。ただしBundle改変禁止|
|登録・統合 C08|[仮契約] plugin key、ファイル所有者、統合担当のみshared edit|新pluginの本番CLI登録は統合待ち|クラス直接呼出しと独立testで着手できる|

**先に確定するのは境界の意味と所有者だけ。** 共通dataclassへの全面移行、サービス分割、HTTP仕様、DL選定、最適閾値、全パラメータ表は開始条件にしない。C01〜C08の既存互換部分をbaselineとして凍結し、新機能は暫定schemaの独立領域で試作する。

## 4. 仕様と実装を区別して扱う点

1. 仕様はcollect(route_outputs)を描くが、現行はrunnerがtables/artifactsを作り、collector.finalize(staging,manifest,destination)を呼ぶ。新collect APIを既存だと扱わない。
2. RoutePluginに加えrunnerはfeature_schema()、model.save(path)、PreparedSet内部dictの具体的keyを使用する。これらも現在必要な接続契約。
3. REGISTRYは存在するがvalidate_configにplugin別必須パラメータとmodel種別の固定辞書がある。新規plugin/modelは単なる登録追加では動かない。
4. routeのprepare/fit/score等はtry内だが、共有STFT/Welch、plugin生成とcapabilities取得、最後のtruth読込・finalizeは同じ隔離範囲ではない。全ての失敗がpartial Bundleになると保証しない。最小変更ではこの制約を記録し、拡張はCRで行う。
5. completeは要求経路の実行完了を指し、全個体が採点/正常判定できた意味ではない。学習不足・閾値なしでも経路completedがあり得る。
6. SignalServiceのcacheはmeasurement_idのみ。同一サービス内で同IDに異なる波形を与える使い方は禁止する提案。並行thread/process安全性は未検証。並列**開発**と実行の並列化を区別する。
7. InputAdapterはmetadataを許可列に絞る。任意のextensions辞書を足せば通るわけではない。拡張情報は専用設定/sidecarへ保持し、Record昇格はCRで決める。
8. viewerはsignal:{mid}、threshold:{route}、prepared:{route}:{mid}等に依存。最低限必要なartifactはC06で固定する。新たな表示情報を必須化する場合はwriter/reader双方の合意が必要。
9. docs/CONTRACTSのC閾値0.10 Paはlegacy例で、acoustic profileは0.025 Pa。これらは契約固定値ではなく設定。スペクトルのlegacy/v2も意味を混同しない。
10. sample_idはソフト版も含む。全体__version__変更は他担当のIDを変えるため統合担当だけが行う。乱数seedと入力順の安定性を保っても異なる版のID一致は要求しない。

## 5. 未決定事項とブロック範囲

|ID|未決定/実装依存事項|暫定方針|決める人・期限|止まる範囲|
|---|---|---|---|---|
|U01|実Git repo/基準commit/remote|PoCのみを管理対象とする案、生成物除外。既存repoの存在を推測しない|ユーザー/統合担当、worktree開始前|checkout作成だけ。設計/ローカル専用ファイル作業は可|
|U02|実測ファイル形式・校正・同期|既存NPZ契約のadapter dummyを使う|入力担当＋測定責任者、実ファイル受入前|実機adapter受入。経路/UIは可|
|U03|非共置/多センサー|現v1は共置p/u 1ペアを維持|物理/入力/統合、必要性確定時|その新schemaのみ|
|U04|モデル形式/固定モデル推論|現行fit/score/saveとjoblibをbaseline。ロードCLIは未実装|モデル/統合、推論入口着手前|運用推論結合。特徴/既存モデル開発は可|
|U05|plugin登録方式の一般化|新規候補クラス直接test、登録とvalidate修正は統合担当|統合、最初の候補結合前|CLI経由の新plugin呼出しだけ|
|U06|外部API、認証、ID受領方針|不変Bundle＋ローカルreceipt、remote transportはstub|出力担当＋接続先、実接続前|実接続。ローカル契約試験は可|
|U07|実測性能目標/データ量/閾値|既存経験分位点を比較用固定。現場合格率は設定しない|評価/測定責任者、最終性能試験前|現場採否。機能結合は可|
|U08|数値最適化の許容差|既存試験値を維持、変えるなら根拠付きCR|物理/評価/統合、変更merge前|当該最適化のmergeのみ|
|U09|実行並列化/共有cache|現行逐次、サービスはrun内固定config|統合/評価、別案件で検討|ランタイム並列化のみ|
|U10|拡張schemaのversion運用|保存schema1.0厳密。未知非互換拒否。勝手に1.1を付けない|統合＋reader/writer責任者、境界変更前|破壊的変更。既存互換拡張は可|

## 6. 着手判断

設計上、既存境界を据え置く合意と所有者の割当ができれば、入力adapter、物理、A/B/C/D候補、モデル候補、viewer、出力adapter、評価を直ちに別ファイルで進められる。**コードを物理的に分割し終わることを待つ必要はない。** 新しいクラスの直接テストを先行し、共有ファイルの接続だけを統合担当が順に適用する。

本調査ではコード変更・Git設定・テスト実装・テスト実行を行っていない。既存32試験の過去成功記録は別資料にあるが、今回の契約テスト案を実行済みとは扱わない。
