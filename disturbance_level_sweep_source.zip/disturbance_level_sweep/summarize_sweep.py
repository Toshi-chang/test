"""Discrete, paired normal-acceptance analysis; no monotonicity assumption."""
import html
from bridge.adapter import read,write

def prefix_limit(cells):
    if cells[0]['within']!=cells[0]['n']:return {'baseline_pass':False,'last_consecutive_db':None,'first_failure_db':None}
    last=None
    for c in cells[1:]:
        if c['within']!=c['n']:return {'baseline_pass':True,'last_consecutive_db':last,'first_failure_db':c['db']}
        last=c['db']
    return {'baseline_pass':True,'last_consecutive_db':last,'first_failure_db':None}

def summarize(reader,dataset,out):
    levels=read(dataset/'case_levels.json');lookup={c['case_id']:c for c in levels};rows=[];routes={}
    for row in reader.tables['route_case_results']:
        c=lookup[row['case_id']];key=row['route_key']
        rows.append(dict(c,route=key,decision=row['decision'],score=row['case_score'],coverage=row['coverage_status'],threshold=read(reader.path/'models'/f'{key}_threshold.json')['value']))
    lines=['# 外乱音圧と正常判定の維持範囲','', '対象は常に正常。外乱220 Hz・固定位置の音源だけを増減。正面受音点の外乱成分単独RMS（基準20 µPa、無補正）。学習20個体をfit16/cal4に分け、各経路を一度だけ学習。独立評価3群を全音圧で繰り返す。受音点・運転条件を個体数に数えない。','', '|経路|外乱なし|連続して3/3正常の最終試験点|最初に崩れた試験点|','|---|---|---|---|'];charts=[]
    for key in sorted({r['route'] for r in rows}):
        rr=[r for r in rows if r['route']==key];cells=[]
        for li in sorted({r['level_index'] for r in rr}):
            rs=[r for r in rr if r['level_index']==li]
            if len({r['family'] for r in rs})!=len(rs):raise AssertionError('duplicate family')
            cells.append({'db':rs[0]['requested_db_spl'],'n':len(rs),**{d:sum(r['decision']==d for r in rs) for d in ['within','outside','undetermined']}})
        limit=prefix_limit(cells);routes[key]={'levels':cells,'limit':limit}
        last=limit['last_consecutive_db'];fail=limit['first_failure_db']
        lines.append(f'|{key}|{cells[0]["within"]}/{cells[0]["n"]}|'+('定義不可' if not limit['baseline_pass'] else ('追加外乱なしのみ' if last is None else f'{last} dB SPL'))+'|'+('—' if fail is None else f'{fail} dB SPL')+'|')
        svg=['<svg viewBox="0 0 860 230" role="img" aria-label="正常判定数の音圧依存"><path d="M50 20V180H830" fill="none" stroke="#aaa"/>']
        points=[]
        for i,c in enumerate(cells):
            x=65+i*57;y=180-140*c['within']/c['n'];points.append(f'{x},{y}')
            svg.append(f'<circle cx="{x}" cy="{y}" r="5" fill="#147d92"/><text x="{x}" y="{y-10}" text-anchor="middle">{c["within"]}/{c["n"]}</text><text x="{x}" y="205" text-anchor="middle">{c["db"] if c["db"] is not None else "なし"}</text>')
        svg.append('<polyline points="'+' '.join(points)+'" fill="none" stroke="#147d92" stroke-width="2"/></svg>')
        charts.append('<section><h2>'+key+'：正常判定数</h2>'+''.join(svg)+'<p>横軸：外乱単独の dB SPL。線は試験点の接続であり、点間の性能保証ではありません。</p></section>')
    lines+=['','## 各音圧の正常 / 誤判定 / 判定不可','', '|経路|dB SPL|正常|誤判定|判定不可|','|---|---:|---:|---:|---:|']
    for key,s in routes.items():
        for c in s['levels']:lines.append(f'|{key}|{c["db"] if c["db"] is not None else "追加なし"}|{c["within"]}/{c["n"]}|{c["outside"]}/{c["n"]}|{c["undetermined"]}/{c["n"]}|')
    lines+=['','## 解釈と再現性','', '- 外乱なしで誤判定する経路には許容音圧を定義しない。途中で正常へ戻っても連続維持範囲は延長しない。', '- 5 dB間隔の観測結果であり、境界補間・一般環境への保証はしない。3群、220 Hz、固定位置・方向に限定。', '- pとベクトルuへ同じ倍率を適用。受音点ごとの実音圧・Pa・倍率はdataset/acoustic_levels.jsonに保存。20 dB=0.0002 Pa、80 dB=0.2 Pa。', '- 通常の背景音は正常側にも含む。「追加なし」は無音ではない。音圧比は正常観測全体対追加外乱であり対象音だけのSNRではない。', '- 正解成分は合成と事後評価だけに使い、入力Adapterは観測波形と取得メタデータのみ読む。学習・特徴量への正解やIDの混入は行わない。', '- cases.jsonに個体群・スコア・閾値・状態を保存。元区間への逆引きはviewer.htmlと保存Bundleで確認できる。', '- 自由空間の等価音源モデル。壁や筐体の散乱・透過、実測への妥当性は未検証。']
    write(out/'summary.json',routes);write(out/'cases.json',rows)
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (out/'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8"><title>外乱音圧掃引</title><style>body{font:16px sans-serif;max-width:1000px;margin:35px auto;background:#eef3f5;color:#173346}section{background:white;padding:20px;margin:20px 0}svg{width:100%}text{font-size:13px}pre{white-space:pre-wrap}</style><h1>外乱が強くなっても正常判定を保てるか</h1><p>モデル・閾値固定／正常3群／外乱220 Hz／20–80 dB SPL</p><a href="viewer.html">元波形・判定根拠を開く</a>'+''.join(charts)+'<section><pre>'+html.escape('\n'.join(lines))+'</pre></section></html>',encoding='utf-8')
    return routes
