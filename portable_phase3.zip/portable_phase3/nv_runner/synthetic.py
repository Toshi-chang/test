"""Simplified paired signals, not an acoustic field or a disturbance-separation simulator."""
from pathlib import Path
import numpy as np
from .common import write_json, sha


def generate(root, settings):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=False)
    seed = settings["seed"]
    fs, duration = settings["sample_rate_hz"], settings["duration_seconds"]
    if fs < 800 or duration < 2:
        raise ValueError("synthetic v1 requires fs >= 800 Hz and duration >= 2 s")
    n = int(fs * duration)
    t = np.arange(n) / fs
    kinds = ["normal", "band", "order", "event", "relation", "mixed", "disturbance"]
    manifests = {"train": [], "eval": []}
    truth = {"schema_version": "1.0", "data_kind": "synthetic", "seed": seed,
             "settings": settings, "model_limit": "simplified signals; not a physical acoustic field", "cases": [], "training_cases": [],
             "signal_parameters": {"normal": {"specimen_gain_uniform": [.9, 1.1], "measurement_gain_uniform": [.97, 1.03],
                 "phase_radians_uniform": [.03, .13], "stationary_hz_uniform": [95, 105], "steady_rpm_uniform": [1300, 1400],
                 "ramp_rpm": [1100, 1800], "order_amplitudes_pa": {"1": .32, "3": .11}, "stationary_amplitude_pa": .14,
                 "pressure_noise_std_pa": .016, "velocity_scale": 1/410, "event_amplitude_pa_uniform": [.55, .65],
                 "event_frequency_hz": 300, "event_gaussian_sigma_seconds": .045, "event_center_fractions": [.26, .72],
                 "event_center_jitter_seconds": [-.08, .08]},
                 "injection": {"interval_fraction": [.4, .62], "band": {"hz": 180, "amplitude_pa": 1.1},
                    "order": {"order": 3, "amplitude_pa": 1.0}, "event": {"hz": 300, "amplitude_pa": 2.5, "sigma_seconds": .03, "center_fraction": .51},
                    "relation": {"u_multiplier": -2}, "disturbance": {"hz": 220, "p_amplitude_pa": .5, "phase_radians": 1.1}}}}
    count = 0
    for split, labels in [("train", ["normal"] * settings["train_specimens"]),
                          ("eval", kinds * settings["eval_repeats"])]:
        for kind in labels:
            count += 1
            sid, cid = f"s{count:04d}", f"c{count:04d}"
            rng = np.random.default_rng(np.random.SeedSequence([seed, count]))
            gain, phase = rng.uniform(.9, 1.1), rng.uniform(.03, .13)
            case_truth = {"case_id": cid, "specimen_id": sid, "label": "normal" if kind in ("normal", "disturbance") else "abnormal",
                          "scenario": kind, "regions": [], "normal_events": []}
            for repeat in range(settings["measurements_per_specimen"]):
                mid = f"m{count:04d}_{repeat}"
                ramp = repeat % 2 == 1
                rpm = np.full(n, rng.uniform(1300, 1400)) if not ramp else np.linspace(1100, 1800, n)
                angle = 2 * np.pi * np.cumsum(rpm / 60) / fs
                freq = rng.uniform(95, 105)
                amp = gain * rng.uniform(.97, 1.03)
                p = amp * (.32 * np.sin(angle) + .11 * np.sin(3 * angle) + .14 * np.sin(2 * np.pi * freq * t))
                u = amp / 410 * (.32 * np.sin(angle - phase) + .11 * np.sin(3 * angle - phase) + .14 * np.sin(2 * np.pi * freq * t - phase))
                p += rng.normal(0, .016, n)
                u += rng.normal(0, .016 / 410, n)
                for center in (.26 * duration, .72 * duration):
                    center += rng.uniform(-.08, .08)
                    envelope = np.exp(-.5 * ((t - center) / .045) ** 2)
                    event = rng.uniform(.55, .65) * envelope * np.sin(2 * np.pi * 300 * t)
                    p += event
                    u += event / 410
                    case_truth["normal_events"].append({"measurement_id": mid, "start_sample": max(0, int((center - .13) * fs)),
                        "end_sample": min(n, int((center + .13) * fs)), "frequency_hz": [280, 320]})
                start, end = int(.4 * n), int(.62 * n)
                mask = np.zeros(n)
                mask[start:end] = 1
                anomalies = ["band", "order", "event", "relation"] if kind == "mixed" else [kind]
                for anomaly in anomalies:
                    band, sensor = None, ["p", "u"]
                    if anomaly == "band":
                        addition = 1.1 * mask * np.sin(2 * np.pi * 180 * t)
                        p += addition
                        u += addition / 410
                        band = [170, 190]
                    elif anomaly == "order":
                        addition = 1.0 * mask * np.sin(3 * angle)
                        p += addition
                        u += addition / 410
                        band = [float(3 * rpm[start:end].min() / 60), float(3 * rpm[start:end].max() / 60)]
                    elif anomaly == "event":
                        addition = 2.5 * np.exp(-.5 * ((t - .51 * duration) / .03) ** 2) * np.sin(2 * np.pi * 300 * t)
                        addition *= mask
                        p += addition
                        u += addition / 410
                        band = [270, 330]
                    elif anomaly == "relation":
                        u[start:end] = -2 * u[start:end]
                        band, sensor = [0, fs / 2], ["u"]
                    elif anomaly == "disturbance":
                        p += .5 * mask * np.sin(2 * np.pi * 220 * t + 1.1)
                        band, sensor = [210, 230], ["p"]
                    if band is not None:
                        case_truth["regions"].append({"measurement_id": mid, "kind": anomaly,
                            "role": "disturbance" if anomaly == "disturbance" else "target_anomaly",
                            "start_sample": start, "end_sample": end, "frequency_hz": band, "sensors": sensor})
                source = root / f"{mid}.npz"
                np.savez_compressed(source, waveform=np.column_stack([p, u]), shaft_rpm=rpm)
                meta = {"schema_version": "1.0", "specimen_id": sid, "case_id": cid, "measurement_id": mid,
                    "derived_group_id": sid, "data_kind": "synthetic", "protocol": "paired steady/ramp, shared clock, equal duration",
                    "channels": [{"name": name, "quantity": quantity, "unit": unit, "position_m": [0, 0, .1],
                                  "direction": [1, 0, 0], "pair_id": "pair_1"}
                                 for name, quantity, unit in [("p", "pressure", "Pa"), ("u", "particle_velocity", "m/s")]],
                    "timebase": {"sample_rate_hz": fs, "start_seconds": 0, "signal_sync": "shared_clock", "rpm_sync": "shared_clock"},
                    "calibration": {"status": "calibrated", "reference": "synthetic_SI_v1", "units": ["Pa", "m/s"]},
                    "operating_conditions": {"mode": "ramp" if ramp else "steady", "rpm_key": "shaft_rpm", "shaft": "primary"}, "validity": []}
                write_json(root / f"{mid}.json", meta)
                manifests[split].append({"metadata_path": f"{mid}.json", "source_path": source.name,
                    "source_sha256": sha(source), "mapping": {"signals": "waveform", "rpm": "shaft_rpm", "axes": ["time", "channel"]}})
            if split == "eval":
                truth["cases"].append(case_truth)
            else:
                truth["training_cases"].append(case_truth)
    for split, items in manifests.items():
        write_json(root / f"{split}_manifest.json", {"schema_version": "1.0", "role": split,
            "normal_only_attested": split == "train", "measurements": items})
    # Only post-inference metrics/viewer reads this sidecar; manifests do not link it.
    write_json(root / "truth.json", truth)
    write_json(root / "generation.json", {"schema_version": "1.0", **settings, "signal_parameters": truth["signal_parameters"]})
    return root
