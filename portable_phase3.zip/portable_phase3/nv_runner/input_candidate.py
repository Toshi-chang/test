"""Independent dummy column-JSON adapter; real instrument integration is untested.

No unit guessing, calibration fitting, truth loading or runtime registration.
The canonical NPZ is the C01 source; the original container is traced separately.
"""
from pathlib import Path
import argparse
import json
import tempfile
import numpy as np
from .common import read_json, write_json, sha
from .input_adapter import InputAdapter


class ColumnInputAdapter:
    """Convert one explicit column observation to an immutable canonical directory."""

    def convert(self, source_path, destination):
        source = Path(source_path).resolve()
        digest = sha(source)
        raw = read_json(source)
        if raw.get("format") != "nv_dummy_columns" or raw.get("format_version") != "1.0":
            raise ValueError("unsupported dummy column format/version")
        if raw.get("axes") != ["sample"]:
            raise ValueError("explicit column axes [sample] required")
        columns = raw["columns"]
        required = {"time_seconds", "pressure_pa", "velocity_m_s"}
        if not required <= columns.keys() or columns.keys() - required - {"rpm_rev_min"}:
            raise ValueError("required/unknown observation columns")
        values = {}
        for key, value in columns.items():
            array = np.asarray(value)
            if array.dtype.kind not in "fiu" or array.ndim != 1 or len(array) < 2:
                raise ValueError(f"numeric one-dimensional column required: {key}")
            array = array.astype(float)
            if not np.isfinite(array).all():
                raise ValueError(f"non-finite column: {key}")
            values[key] = array
        if len({len(a) for a in values.values()}) != 1:
            raise ValueError("column length mismatch")
        # Whitelist observations; top-level truth and unknown metadata never enter C01.
        keys = ("schema_version", "specimen_id", "case_id", "measurement_id",
                "derived_group_id", "channels", "timebase", "calibration",
                "operating_conditions", "validity", "protocol", "data_kind")
        meta = {key: raw["metadata"][key] for key in keys}
        if "acoustic_contract" in raw["metadata"]:
            meta["acoustic_contract"] = raw["metadata"]["acoustic_contract"]
        timebase = meta["timebase"]
        for key in ("sample_rate_hz", "start_seconds"):
            number = timebase[key]
            if isinstance(number, bool) or not isinstance(number, (float, int)) or not np.isfinite(number):
                raise ValueError(f"finite numeric timebase required: {key}")
        fs = timebase["sample_rate_hz"]
        if fs <= 0:
            raise ValueError("positive sample_rate_hz required")
        n = len(values["time_seconds"])
        expected = timebase["start_seconds"] + np.arange(n) / fs
        if not np.allclose(values["time_seconds"], expected, rtol=0, atol=1e-10):
            raise ValueError("column time axis must match explicit uniform timebase")
        if meta["calibration"].get("units") != ["Pa", "m/s"]:
            raise ValueError("calibration units must be [Pa, m/s]")
        arrays = {"waveform": np.column_stack([values["pressure_pa"], values["velocity_m_s"]])}
        rpm_key = "shaft_rpm" if "rpm_rev_min" in values else None
        if rpm_key:
            arrays[rpm_key] = values["rpm_rev_min"]
        target = Path(destination).resolve()
        if target.exists():
            raise FileExistsError(f"destination must be new: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="column_adapter_", dir=target.parent) as temporary:
            staged = Path(temporary) / "converted"
            staged.mkdir()
            np.savez_compressed(staged / "signal.npz", **arrays)
            write_json(staged / "metadata.json", meta)
            manifest = {"schema_version": "1.0", "measurements": [{
                "source_path": "signal.npz", "source_sha256": sha(staged / "signal.npz"),
                "metadata_path": "metadata.json", "mapping": {
                    "signals": "waveform", "rpm": rpm_key, "axes": ["time", "channel"]}}]}
            write_json(staged / "manifest.json", manifest)
            # Existing C01 validator is authoritative for IDs, SI, p/u and metadata.
            InputAdapter().load(staged / "manifest.json")
            if sha(source) != digest:
                raise ValueError("original source changed during conversion")
            write_json(staged / "provenance.json", {
                "adapter_provenance_version": "1.0", "adapter": "ColumnInputAdapter",
                "original_path": str(source), "original_sha256": digest,
                "canonical_sha256": manifest["measurements"][0]["source_sha256"],
                "measurement_id": meta["measurement_id"], "derived_group_id": meta["derived_group_id"],
                "transform": "column_stack(pressure_pa, velocity_m_s); no resampling or scaling",
                "source_sample_range": [0, n], "truth_used": False})
            staged.rename(target)
        return target / "manifest.json"

    def load(self, source_path, destination):
        return InputAdapter().load(self.convert(source_path, destination))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("destination")
    args = parser.parse_args()
    manifest = ColumnInputAdapter().convert(args.source, args.destination)
    print(json.dumps({"manifest": str(manifest), "records": len(InputAdapter().load(manifest))}))


if __name__ == "__main__":
    main()
