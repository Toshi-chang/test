"""Write explicit example scene definitions; no generated measurement data."""
from pathlib import Path
import copy,json
from da_engine.engine import SCHEMA

def base():
    return {'schema_version':SCHEMA,'propagation':'free_space_equivalent',
        'medium':{'density_kg_m3':1.2,'sound_speed_m_s':343.},
        'simulation':{'sample_rate_hz':2048,'duration_seconds':1.,'guard_seconds':.25,'seed':42},
        'receivers':[{'id':'front','position_m':[0,0,.20],'axis':[0,0,1]},
                     {'id':'offset','position_m':[.15,0,.20],'axis':[0,0,1]},
                     {'id':'side','position_m':[.20,0,0],'axis':[1,0,0]}],
        'sources':[],'interpretation':'Equivalent sources in free space; shape is not a solid enclosure.'}

def source(geometry,id='target'):
    return {'id':id,'geometry':geometry,'strength_mode':'total_volume_velocity','drive_unit':'m^3/s',
            'drive_rms':1e-5,'distribution':{'kind':'uniform'},'phase':{},
            'excitation':{'kind':'tone','frequency_hz':200.,'phase_rad':0.}}

def examples():
    shapes={'point':{},'rectangle':{'size_m':[.12,.08]},'disk':{'radius_m':.06},
        'box_surface':{'size_m':[.12,.08,.06]},'box_volume':{'size_m':[.12,.08,.06]},
        'sphere_surface':{'radius_m':.06},'sphere_volume':{'radius_m':.06},
        'cylinder_surface':{'radius_m':.04,'height_m':.10},'cylinder_volume':{'radius_m':.04,'height_m':.10}}
    result={}
    for kind,args in shapes.items():
        scene=base(); scene['sources']=[source({'kind':kind,'resolution':6,**args})]; result[kind]=scene
    baffle=base(); baffle['propagation']='baffled_plane'; baffle['receivers']=baffle['receivers'][:2]
    baffle['interpretation']='Prescribed normal velocity on a disk in an infinite rigid baffle; upper half-space only.'
    s=source({'kind':'disk','radius_m':.06,'resolution':8})
    s.update(strength_mode='surface_density',drive_unit='m/s',drive_rms=.001)
    baffle['sources']=[s]; result['baffled_disk']=baffle
    rect=copy.deepcopy(baffle); rect['sources'][0]['geometry']={'kind':'rectangle','size_m':[.12,.08],'resolution':10}
    rect['sources'][0]['phase']={'opposite_halves_axis':0}
    rect['interpretation']='Opposite-phase halves of a planar patch in one infinite baffle.'
    result['baffled_rectangle_opposite']=rect
    parts=base()
    for i,(xyz,ex) in enumerate([
        ([-.03,0,0],{'kind':'order','start_rpm':1200,'end_rpm':1800,'order':3}),
        ([.03,0,0],{'kind':'noise','band_hz':[100,400],'seed_key':101}),
        ([0,.02,0],{'kind':'event','frequency_hz':350,'center_seconds':.5,'sigma_seconds':.03})]):
        s=source({'kind':'point','center_m':xyz},['shaft','bearing','local_event'][i]); s['excitation']=ex; parts['sources'].append(s)
    parts['container_annotation']={'kind':'box','size_m':[.12,.08,.06],'acoustic_boundary':'none'}
    parts['interpretation']='Three internal component locations; container is annotation only, no wall transmission.'
    result['internal_components']=parts
    local=copy.deepcopy(result['box_surface'])
    local['sources'][0]['distribution']={'kind':'gaussian','center_m':[.06,0,0],'sigma_m':.025}
    local['sources'][0]['phase']={'delay_gradient_s_per_m':[.001,0,0]}
    result['box_surface_localized']=local
    return result

if __name__=='__main__':
    root=Path(__file__).resolve().parent/'configs'; root.mkdir(exist_ok=True)
    for name,scene in examples().items():
        (root/(name+'.json')).write_text(json.dumps(scene,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(examples())} explicit scenarios written')
