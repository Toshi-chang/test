import bootstrap
from bootstrap import ROOT,verify_engines
from pathlib import Path
import copy,json,shutil,unittest,uuid
import numpy as np
from bridge.adapter import DistributedAdapter,read,write,sha
from nv_runner.input_adapter import InputAdapter
from nv_runner.runner import validate_config,ExperimentRunner
from nv_runner.bundle import BundleReader

class Bridge(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.demo=ROOT/'outputs/quick_v1'
        if not (cls.demo/'validation.json').exists():raise RuntimeError('Run fixed quick integration first: outputs/quick_v1')
        cls.result=read(cls.demo/'validation.json')
        if cls.result['status']!='passed':raise RuntimeError('quick integration did not pass')
        cls.data=cls.demo/'dataset';cls.work=ROOT/'tests/_work'/uuid.uuid4().hex;cls.work.mkdir(parents=True)
        cls.raw=cls.data/'raw/c00000_m0'

    def convert(self,raw,dest):
        return DistributedAdapter().convert(raw/'acquisition.json',dest,{'specimen_id':'sample','case_id':'case','derived_group_id':'family','capture_id':'capture'})

    def test_01_observations_only_no_truth_dependency(self):
        raw=self.work/'minimal';raw.mkdir()
        for name in ['acquisition.json','observations.npz','rpm_observation.npz']:shutil.copyfile(self.raw/name,raw/name)
        dest=self.work/'converted';items,refs=self.convert(raw,dest)
        write(dest/'manifest.json',{'schema_version':'1.0','measurements':items})
        records=InputAdapter().load(dest/'manifest.json');self.assertEqual(len(records),3)
        with np.load(raw/'observations.npz') as a:
            for i,r in enumerate(records):
                # IDs are sorted by reader; resolve receiver index explicitly.
                ref=next(v for v in refs if v['measurement_id']==r.meta['measurement_id']);idx=ref['receiver_index']
                np.testing.assert_array_equal(r.signals[:,0],a['pressure_pa'][:,idx])
                np.testing.assert_array_equal(r.signals[:,1],a['axial_velocity_m_s'][:,idx])
        self.assertEqual(len({r.meta['specimen_id'] for r in records}),1)
        self.assertEqual(len({r.meta['derived_group_id'] for r in records}),1)

    def test_02_reject_units_coordinates_hash_and_version(self):
        changes=[lambda m:m.update(schema_version='2'),lambda m:m.update(units=['V','V']),
                 lambda m:m['receivers'][0].update(axis=[0,0,2]),lambda m:m['observations'].update(sha256='0'*64),
                 lambda m:m['receivers'][1].update(id=m['receivers'][0]['id'])]
        for i,fn in enumerate(changes):
            raw=self.work/f'bad{i}';raw.mkdir()
            for name in ['observations.npz','rpm_observation.npz']:shutil.copyfile(self.raw/name,raw/name)
            m=read(self.raw/'acquisition.json');fn(m);write(raw/'acquisition.json',m)
            with self.subTest(i=i),self.assertRaises(ValueError):self.convert(raw,self.work/f'bad_out{i}')

    def test_03_missing_rpm_remains_missing(self):
        raw=self.work/'no_rpm';raw.mkdir();shutil.copyfile(self.raw/'observations.npz',raw/'observations.npz')
        m=read(self.raw/'acquisition.json');m['rpm']=None;write(raw/'acquisition.json',m)
        dest=self.work/'no_rpm_out';items,_=self.convert(raw,dest);write(dest/'manifest.json',{'schema_version':'1.0','measurements':items})
        self.assertTrue(all(r.rpm is None for r in InputAdapter().load(dest/'manifest.json')))

    def test_04_groups_split_and_receiver_count(self):
        _,train,evaluation,fit,cal,split=validate_config(self.demo/'experiment.json')
        self.assertEqual((len(train),len(evaluation)),(48,42))
        self.assertEqual((len(split['fit_specimens']),len(split['calibration_specimens'])),(6,2))
        for records in [train,evaluation]:
            ids={r.meta['specimen_id'] for r in records}
            self.assertTrue(all(sum(r.meta['specimen_id']==sid for r in records)==6 for sid in ids))
        for key in ['specimen_id','derived_group_id','source_sha256']:
            sets=[{r.meta[key] for r in records} for records in [fit,cal,evaluation]]
            self.assertFalse(sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])

    def test_05_paired_normal_fields_identical(self):
        cfg=read(ROOT/'configs/dataset_quick.json');normal_count=len(cfg['template_scene']['sources'])
        for mi in [0,1]:
            with np.load(self.data/f'raw/c00008_m{mi}/generator_truth.npz') as a:
                base=a['source_pressure_pa'][:normal_count].copy();vel=a['source_velocity_m_s'][:normal_count].copy()
            for case in range(9,15):
                with np.load(self.data/f'raw/c{case:05d}_m{mi}/generator_truth.npz') as a:
                    np.testing.assert_array_equal(base,a['source_pressure_pa'][:normal_count])
                    np.testing.assert_array_equal(vel,a['source_velocity_m_s'][:normal_count])

    def test_06_bundle_ids_coordinates_and_truth_regions(self):
        reader=BundleReader(self.result['bundle']).validate();samples=reader.tables['samples']
        self.assertEqual({s['sample_id'] for s in samples},{s['sample_id'] for s in reader.tables['sample_results']})
        refs={r['measurement_id']:r for r in read(self.data/'conversion_index.json')['measurements']}
        for s in samples:
            ref=refs[s['measurement_id']];self.assertLessEqual(s['end_sample'],ref['sample_range'][1])
        for m in reader.tables['measurements']:
            r=refs[m['measurement_id']];acq=read(r['acquisition_path']);position=acq['receivers'][r['receiver_index']]['position_m']
            self.assertEqual(m['channels'][0]['position_m'],position)
        truth=read(Path(self.result['bundle'])/'truth.json')
        self.assertTrue(all(r['measurement_id'] in refs for c in truth['cases'] for r in c['regions']))

    def test_07_shuffle_adapter_mapping(self):
        original=read(self.data/'canonical/eval_manifest.json');reverse=copy.deepcopy(original)
        for m in reverse['measurements']:
            for k in ['source_path','metadata_path']:m[k]=str(self.data/'canonical'/m[k])
        reverse['measurements'].reverse();write(self.work/'reversed.json',reverse)
        a=InputAdapter().load(self.data/'canonical/eval_manifest.json');b=InputAdapter().load(self.work/'reversed.json')
        self.assertEqual([r.meta['measurement_id'] for r in a],[r.meta['measurement_id'] for r in b])
        for x,y in zip(a,b):np.testing.assert_array_equal(x.signals,y.signals)

    def test_08_eval_and_truth_change_does_not_change_model_threshold(self):
        altered=self.work/'altered';shutil.copytree(self.data/'canonical',altered)
        manifest=read(altered/'eval_manifest.json')
        for m in manifest['measurements']:
            p=altered/m['source_path']
            with np.load(p) as a:arrays={k:a[k].copy() for k in a.files}
            arrays['waveform']*=1.7;np.savez_compressed(p,**arrays);m['source_sha256']=sha(p)
        write(altered/'eval_manifest.json',manifest)
        truth=read(altered/'truth.json')
        for c in truth['cases']:c['label']='abnormal' if c['label']=='normal' else 'normal';c['regions']=[]
        write(altered/'truth.json',truth)
        cfg=read(self.demo/'experiment.json')
        # Keep original training input references strictly unchanged.
        cfg['eval_manifest']=str(altered/'eval_manifest.json');cfg['truth_path']=str(altered/'truth.json')
        cfg['export']['output_dir']=str(self.work/'reruns');write(self.work/'changed.json',cfg)
        second=ExperimentRunner().execute(self.work/'changed.json');BundleReader(second).validate()
        for p in (Path(self.result['bundle'])/'models').iterdir():
            self.assertEqual(sha(p),sha(second/'models'/p.name),p.name)

    def test_09_frozen_engines(self):self.assertGreater(verify_engines(),100)

if __name__=='__main__':unittest.main()
