"""Set source drives once at a reference receiver; never normalize each output."""
import copy
import numpy as np

def reference_levels(config,machine_db=60.,background_db=25.,fault_relative_db=-20.,external_relative_db=-20.):
    from physics import synthesize
    c=copy.deepcopy(config)
    # Keep source indices stable so reference phases are reproducible.
    probe=copy.deepcopy(c)
    for s in probe['sources']:s['variation']=0
    if probe.get('rotation'):probe['rotation'].update(variation=0,ripple=0)
    rec=synthesize(probe,3 if probe.get('rotation',{}).get('include_combined') else 2,probe['seed'],components=True)
    grouped={k:[] for k in ('machine','background','external','abnormal')}
    for i,s in enumerate(c['sources']):
        group=('background' if s.get('background') else 'machine') if s['role']=='normal' else s['role']
        grouped[group].append(i)
    targets=dict(machine=machine_db,background=background_db,external=machine_db+external_relative_db,abnormal=machine_db+fault_relative_db)
    for group,indices in grouped.items():
        if not indices:continue
        measured=np.sqrt(np.mean(np.sum(rec['components'][indices,0],axis=0)**2))
        if measured<1e-15:raise ValueError('基準音源がゼロです')
        factor=20e-6*10**(targets[group]/20)/measured
        for i in indices:c['sources'][i]['level_rms']*=factor
    c['level_reference']=dict(machine_db_spl=machine_db,background_db_spl=background_db,
        fault_relative_db=fault_relative_db,external_relative_db=external_relative_db,
        seed=probe['seed'],note='Reference receiver only; drives stay fixed when distance or RPM changes.')
    return c

def calibrated_preset(base):
    c=copy.deepcopy(base);c['sources'][1]['background']=True
    return reference_levels(c)
