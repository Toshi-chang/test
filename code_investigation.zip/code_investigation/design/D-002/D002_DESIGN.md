# D-002 PhysicalRecording v1：意味的共通データ契約案

2026-10-20 / 設計草案 rev.1。**未実装・未採用。PoC・製品試験は実行していない。** PhysicalRecordingは意味的な境界の名称であり、Pythonクラス、保存形式、既存schemaの改版を意味しない。

読む順序：本書 → [As-Is・判断台帳](D002_ASIS_DECISIONS.md) → [比較PoC計画](D002_COMPARISON_POC.md)。根拠の全パス・SHA-256・照合結果は[evidence.json](evidence.json)。round01/round02およびソースは変更しない。

## 1. 設計結論と確定状態

D-002の課題は、収録値にCH、単位、時計、校正、センサー、由来を結び付け、独立PoCが**同じ意味の入力**を比較できるようにすることである。データを一つの配列へ揃えるだけでは解決しない。

- **F（静的事実）**：Observer開発版とBridge既定referenceは異なる。電圧波形、校正TF、周期AC校正波形、DL窓、NV入力は別契約。ゼロplaceholder、CH最初一致、任意由来欄などがあり、名前や拡張子から意味を確定できない。
- **F（第2回の追加事実）**：strict経路にはraw/probe/config捕捉・hash結合・親品質継承がある。計算成功、成果物公開、実機適合、用途別利用許可は同じではない。通常exportには同じ保証がない。
- **I（要求からの推論）**：全CHを同時計・常時校正済みに強制すると、欠損CHや別時計RPMなど研究上必要な入力を失う。逆に不足を既定値で埋めると位相・方向を使う比較の根拠を失う。
- **P（推奨）**：不変の収録根を持つPhysicalRecording、変更ごとのSignalRevision、選択だけを行うSignalView、変換結果のDerivedArtifactを分離する。値・構造の妥当性と用途別利用可否を分離する。
- **FIX**：Windows、外部ファイル受領、DAQ制御対象外、原本保護、追跡性、独立検証、GUI分離はユーザー指定。48 kHz/120秒/12 PUは固定上限にしない。
- **EARLY**：IDスコープ、半開区間、CH状態、校正領域、品質と利用可否の分離を下記案で早期合意する。今回の文書作成を承認済み契約への昇格としない。
- **SELECT**：NumPy＋型付き構造を暫定第一候補とするが、A/B/C比較と部分読込性能で選ぶ。保存形式は別判断。
- **U**：実CSV第1列の意味・列配置、メタデータ照合キー、実機時計精度、配線・方向・係数適用帯域は未確認。これらを仮の物理事実として埋めない。

本書の設計規定は、特記がない限りすべて**P/EARLY**である。F/I/P/U/VとFIX/EARLY/SELECT/DEFERは別軸。Vは実行証拠を伴う場合だけ使用し、本件の機能・科学的Vは0件。ファイルhash照合は資料の完全性確認である。

## 2. 責務と最小構造

```mermaid
flowchart LR
  S[SourceAsset 原本bytesとhash] --> R[PhysicalRecording 不変manifest]
  M[外部測定メタデータ snapshot] --> R
  R --> I[Identity / TimeBases / Channels]
  R --> P[SensorMapping / Context / Quality]
  R --> V[SignalView 選択参照]
  V --> C[独立した校正・解析]
  C --> D[DerivedArtifact + Provenance]
  D --> SR[時間波形ならSignalRevision]
  SR --> V2[別のSignalView]
```

|要素|所有する意味|外部に置ける実体・責務外|
|---|---|---|
|PhysicalRecording|一つの収録解釈revision、root recording、CH/時間/センサー/条件の参照と状態|信号大容量bytes、原本、証明書、処理実装の保存場所。実行エンジンは持たない|
|SignalRevision|処理後の時間波形・時間軸・状態と親への対応。rootは維持しrevision/derived IDを新規発行|FFT等を無理に時間CHへ戻さない|
|SignalView|revisionを固定したCH/ペア/区間の読み取り選択|校正、補間、resampling、欠損補完はしない|
|DerivedArtifact|TF、PSD、窓列、次数、特徴量等の型別結果と元SignalView参照|個別数式・正規化の詳細はD-003。保存配置はD-004|
|CalibrationRecord / QualityFinding / ProcessingRecord|校正適用と証拠、品質所見、変換の意味|大きい係数表・環境lock等はhash付き外部asset参照|

暫定6要素にTimeBase複数化、Calibration/Quality、SignalRevisionを追加する。理由は、別時計と校正領域の差を一つのstage文字列へ押し込めないため。代替の「すべてをPhysicalRecordingの可変辞書へ格納」は簡単だが同一IDの意味が実行中に変わる。採用を推奨しない。全成果物を巨大DAGとして常駐させる必要もない。親refと必要な対応情報を辿れればよい。

## 3. 共通記法・参照・バージョン

表のM=必須、O=任意、C=条件付き必須。Mは不明を捏造して埋める意味ではない。状態付き値 `Known(value,evidence_ref)` / `Unknown(reason)` / `NotApplicable(reason)` を用いる項目では状態自体が必須。空文字、NaN、ゼロをUnknownの代用にしない。

`EntityRef={entity_id, revision_id}` は不変の版を指定する。外部実体を参照するときは `AssetRef={asset_id, sha256, byte_length, media_type, locator}`。locatorは移設可能な解決先でありIDではない。sha256は64桁16進、lengthは非負整数。リモート/ローカルの可用性とhash一致は別所見。外部の任意実行コードを参照から起動しない。

|フィールド|必須性・型|意味・制約|
|---|---|---|
|contract_name, contract_version|M string|提案値 PhysicalRecording / 1.0.0。実装済み版ではない|
|required_capabilities|M list[string]|解釈必須の追加意味。未知なら拒否|
|identity|M RecordingIdentity|次節|
|timebases|M map[id,TimeBase]|最低1個。未確定時間はstate unresolvedで表す|
|channels|M map[id,SignalChannel]|最低1個の登録CH。取得不能CHも登録できる|
|sensor_mapping|M object|sensors/frames/pairs。情報未登録は空集合＋理由|
|context_ref|M 状態付きEntityRef|条件不明を既定正常条件と解釈しない|
|provenance_ref|M EntityRef|原本→読込の変換を含む|
|quality_refs|M list[EntityRef]|空なら未評価。全項目合格ではない|
|extensions|O map[namespace,object]|既存意味の上書き禁止。意味必須ならcapabilityへ登録|

版は文字列major.minor.patch。未知major、未対応minor、未知required capabilityは消費前に拒否する。minorの自動前方互換は認めず、対応表に明記された組合せのみ許可。意味・必須性・単位変更は非互換、任意拡張のみ互換候補、patchは意味を変えない修正。旧Observer/Bridge/NV schemaを版番号だけで受け入れない。明示Adapterが損失と不足を出力する。既存ResultBundle 1.0/C01〜C08は変更しない。

## 4. RecordingIdentity

|フィールド|必須性・型|意味・発行・不変条件|
|---|---|---|
|recording_id|M opaque string|収録根のID。取込登録主体がnamespace付きUUID等で発行。ファイル名から生成しない|
|revision_id|M opaque string|読込解釈/metadata snapshotを含む不変revision。変更時は新規発行|
|source_refs / source_id|M 非空AssetRef列|原本bytesの識別。1CSVなら1件、分割原本は複数。source_idはasset_idの別称で二重保存不要|
|source_hash|M source_refs内|各原本bytesのSHA-256。CSV数値だけのhashとは区別|
|measurement_id|M 状態付き外部ID|測定行為・実施記録との関係。未登録はUnknown。recording_idと同一視しない|
|context_ref|M 状態付きref|トップレベルと同一参照。実装では一箇所だけ保持|
|derived_id / parent_refs|C ID / 非空ref列|校正・再標本化等の派生revisionなら必須。元Recordingはderived_idなし|
|issuer / registered_at|M string / timestamp|ID発行主体・登録時刻。registered_atを収録開始時刻にしない|

**同じCSV再読込**：hash一致だけで同じ測定と断定しない。既存登録のsourceと明示measurement紐付けが一致し、parser設定・context snapshotも同じなら既存revisionを再利用可能。紐付けが不明なら同じsource assetへの別registrationを保持し、重複候補を通知する。ID発行の完全な冪等化・登録DBはD-006。別名コピーもsource bytes同一候補になる。

**同じCSVに別校正**：root recordingとraw revisionを維持し、異なるderived_id/revision_id、CalibrationRecord、ProcessingRecordを作る。出力が偶然同じでも処理履歴を統合しない。ファイル改変は同じpathでも新source assetとし、既存参照のhash不一致は拒否する。

measurementは測定行為、experimentは比較計画、runは一度の処理実行、specimenは対象個体、caseは評価条件/ケース。Bridge record/window番号は局所IDとしてnamespaceとsourceを添えて保持する。Observer UUIDやNV measurement IDを検証なしに新IDへ昇格させない。正解ラベルと学習分割はRecording必須属性にせず、D-006の別参照として入力特徴量から隔離する。

## 5. TimeBase

|フィールド|必須性・型/単位|意味・条件|
|---|---|---|
|timebase_id / revision_id|M ID|一つの時刻解釈を固定|
|sample_count|M int ≥0|0なら空取得、数値解析不可|
|grid_kind|M enum|uniform / explicit / unresolved|
|interval_s, sampling_frequency_hz|C 正有限数|uniformでは片方を正とするauthoritative_fieldが必須。両方記載時は相互整合を検証|
|relative_origin_s|C finite|uniformの最初のsample時刻。原点の由来をorigin_definitionで明記|
|time_values_ref|C AssetRef・実数[N], s|explicitでは必須。原CSV列そのものとは限らない|
|origin_definition|M enum＋理由|acquisition_start / first_sample / external_event / unknown。first_sample=0は局所座標であり機器の開始時刻ではない|
|original_time_column_ref / interpretation|C ref / enum|入力に時刻関連列がある場合。timestamp / interval / other / unresolved。原値を保存|
|absolute_origin|M 状態付き値|既知ならtimezone付き時刻、時系、精度/出典。登録時刻と分離|
|clock_ref|M 状態付きID|同一fs・同じNは同一時計の証拠にしない|
|sync_relations|M list|他timebaseへのoffset/drift/uncertainty、有効区間、証拠、補正済みか。未知は明記|
|tolerance_policy|M object|測定丸め/時計/数値誤差を区別、policy IDと根拠。未設定なら等間隔認定不可|
|parent_timebase_ref, transform_ref|C refs|再構成・補間・再標本化した場合必須|

uniformの定義は `t(i)=origin+i*dt, 0≤i<N`。explicitは有限で厳密単調増加。逆転/重複がある原本は保護して残すが、その時間軸に従う解析をUnavailableとする。欠落sampleを黙って詰めない。非等間隔も保持できるがFFT等のconsumerがuniformを要求するときはUnavailable。時間解釈不明ならsample単位の診断表示のみ可能で、秒範囲選択・周波数解析は禁止。

p/uとRPMは別TimeBaseを許可する。時計関係不明でも各CHの単独表示はできるが、回転同期/PU位相解析は不可。補間はSignalViewで自動実行せず、方式・境界・遅延・誤差を持つ派生操作とする。丸め時刻の正規格子化も派生であり原列を置き換えない。

秒区間[a,b)は実sample時刻が `a≤t(i)<b` のsampleを選ぶ。uniformでも境界丸めを無条件epsilonで動かさず、要求範囲・決定した[start,stop)・実時刻を併記する。explicitでは順序探索相当。最終sampleの後端時刻を非等間隔軸から推測しない。index範囲は常に0≤start<stop≤N、stop=Nを終端sentinelとして表す。同期や格子許容差は計測精度・解析周波数帯の要求に基づき決め、既存16epsや1e-6を新標準へコピーしない。

## 6. SignalChannels

|フィールド|必須性・型|意味・許容値|
|---|---|---|
|channel_id|M string|Recording根内で一意、revisionを跨いで同じ取得CHを識別。CH表示名は別|
|source_binding|M object|source asset＋列番号/名称＋データ開始行＋parser ref。派生ではparent channel/refも必須|
|physical_quantity / unit|M enum/string|voltage V、pressure Pa、particle_velocity m/s、rotation_speed rpm。未解釈はunknownで物理解析不可|
|measurement_role|M 状態付きenum|pressure_sensor_output / velocity_sensor_output / rotation / other。raw Vの取得役割を示し、physical_quantityを上書きしない|
|signal_ref|C array ref|presentのとき必須。arrayのdtype、shape、axes、hash、対象member/sliceを指定|
|timebase_ref|M EntityRef|信号長とsample_count一致|
|sensor_id|M 状態付きID|既知ならsensor表へ解決。raw電圧だけならUnknownを許す|
|calibration_ref|C EntityRef|校正を適用した物理値で必須。合成物理値はorigin syntheticと生成由来を必須化し、実機校正済みとはしない|
|value_stage|M enum|raw_voltage / physical_waveform / unknown。TF補正はこのstageを変更しない|
|availability|M enum|present / missing / unavailable / unknown。値と別管理|
|validity|M enum|unchecked / valid / invalid / partial。validは明示policy範囲でのデータ検査合格|
|origin|M enum|measured / synthetic / derived / legacy_placeholder / unknown|
|valid_regions / quality_refs|C index区間 / refs|partialなら有効区間必須。invalid/missing等は理由必須|

意味的標準はCHごとの実数1D `[sample]`。共通格子のCHを物理格納で `[sample,channel]` にまとめてもよいがcolumn→channel_idの一対一対応が必須。CH順は意味を持たず、名前による選択で取り出す。TF複素値は別DerivedArtifact。変換時のdtype縮小・量子化は処理履歴へ記録する。

presentかつvalidな領域ではfiniteを要求する。非有限/クリップ等の領域は明示invalid/partialで保持できるが、消費側へ通常値として流さない。missingのsignal_refはなし。旧placeholderを監査用に残す場合はそのassetを診断参照に置き、present信号として公開しない。実測の全ゼロはmissingとはしない（定値品質検査は別）。p-only/u-onlyを構造違反にしない。最大24CHをschema制約にしない。

## 7. SensorMapping

|フィールド|必須性・型|意味・整合性|
|---|---|---|
|sensors[id]|M map（空可）|sensor ID、種類、serial/probe IDの状態付き値、証拠。probe係数キーと実体IDを区別|
|frames[id]|M map（空可）|軸名、handedness、原点、長さ単位m、親frameとtransform/証拠。未確認なら座標変換不可|
|pairs[pair_id]|M map（空可）|pair IDはRecording内で一意|
|pressure_channel_id / velocity_channel_id|M 状態付きCH ID|既知なら役割・unit整合、別CH。欠損側はUnknown/missing理由を明示|
|pressure_sensor_id / velocity_sensor_id / probe_id|M 状態付きID|同じprobeと仮定しない。別probeでも構造拒否しない|
|position / frame_ref|M 状態付き[m,m,m] / ref|p/u別位置を保持。pair中心の一座標で共置性を偽装しない|
|velocity_positive_direction|M 状態付き3-vector|既知ならframe内の単位方向。符号/極性/証拠も保持。未知を[1,0,0]にしない|
|sync_ref / calibration_refs|M 状態付きref / list|CH/timebaseにある情報を参照して重複値を持たない|
|mapping_evidence / pair_quality_refs|M refs（空可）|未取得なら未確認。配線宣言と物理照合を別所見とする|

raw V段階のpairはmeasurement_roleとsensor bindingを照合し、Pa/m/sを要求しない。物理波形段階では加えてphysical_quantity/unitを照合する。役割未確認はUnknownであり矛盾とは別に扱う。既知参照のCH不在、役割逆転、同一CHをp/uに指定、pair_id/CH ID重複は意味検証エラー。異なるpairが同じCHを共有する場合は、明示aliasと用途があるときだけ許す案とし、デフォルトは曖昧な共有を拒否する。多方向プローブで一つのpを複数uと組にする用途はaliasで表現できる。装置上の可否は別確認。

ペア宣言の整合性とIntensity可否は別。位置・方向・位相補正・相対同期・適用帯域などconsumerの必要条件が不足すれば、その解析だけUnavailable。非共置測定を全体拒否せず、距離/方法の適用条件を確認するまで局所Intensityとして扱わない。方向不明でも単独pressure解析は継続できる。

## 8. Calibration / Quality

|CalibrationRecord項目|必須性|意味|
|---|---|---|
|calibration_id / revision_id|M|不変適用記録。モデルthreshold calibrationと無関係|
|input_refs / output_refs / channel_sensor_binding|M|どの値にどのsensor係数を使ったか。output側はこの記録を参照|
|method_id / implementation_ref / parameters_ref|M|感度、周波数依存、位相等の方式、版とコードhash、正規化/境界条件|
|coefficient_asset_refs / coefficient_units|M|使用した係数snapshotとhash、対応sensor/probe、証明書は状態付き参照|
|domain / corrections|M|time_waveform / spectrum / time_frequency、およびsensitivity/frequency_response/phase等の集合|
|applicability|M 状態付き構造|帯域、期間、温湿度、gain、方向、対象sample/CH、境界、除去DC/Nyquist、前提|
|execution_state / execution_ref|M|not_run / succeeded / failed / unsupported、実行証跡/理由。succeededは数値出力の成立|
|physical_validation / evidence_refs|M|not_assessed / supported / failed / inconclusive、検証範囲と証拠|
|uncertainty / warnings|M 状態付き値 / list|不明はUnknown。係数・結果の不確かさをゼロとしない|

TF上だけの補正で時間波形をphysical_waveformへ昇格させない。単一感度の適用は位相補正済みを意味しない。校正宣言だけの旧データは `declared_only` の品質所見を持ち、履歴がないまま校正recordを捏造しない。これを受領する場合、calibration_refは状態付きUnknownとして限定受領し、上表の完全なCalibrationRecord適合とは区別する。時間波形の申告物理値として保持できても、証跡を要求する解析にはUnavailableとする。

QualityFindingは `finding_id, scope(recording/channel/pair/view/process + revision/range), check_id, check_version, outcome(pass/fail/inconclusive/not_assessed/unsupported), reason_code, evidence_refs, assessed_at` を必須とする。severityと用途ごとのrequiredはpolicyが決める。親所見を消さず継承し、修復した場合は対象領域・新証拠を付けた解決関係で記録する。単一「calibrated」「valid」で全範囲の物理保証をしない。

## 9. ProcessingProvenance / Context

|ProcessingRecord項目|必須性|意味|
|---|---|---|
|process_id / run_id / method_id|M|操作の識別・実行識別・方式。experiment IDと別|
|implementation_ref / environment_ref|M 状態付きref|実装版/hashと選択root、依存版、環境。unknownなら再現性制限|
|input_refs / output_refs|M|実際に読んだimmutable asset/revisionをhashで拘束|
|parameters / calibration_refs|M object/ref|デフォルト展開済み値、単位、seedを使う場合はseed/RNG方式も記録|
|coordinate_mapping|M object|identity_slice / index_map / resampled_support / aggregate_support。元CH/sample区間へ到達|
|execution_state / quality_refs / duration|M|成功/失敗/未実行を別記。途中成果物は完了として消費しない|
|intermediate_refs|O|観察・再開に必要な中間成果物。保存政策はD-004|

provenanceは有向非循環の親参照。raw parse操作も含める。raw→校正→resample→windowで直接元sampleへ一対一に戻れない場合、実際に寄与した区間・kernel support・遅延/境界処理を返す。表示上の中心時刻と計算supportを別記する。パスがあるだけ/64桁hashがあるだけを完全性確認としない。再現可否はinputs_available、integrity_verified、implementation_available、environment_resolvedを別所見とする。

原本を上書きせず、処理対象の捕捉bytesとhashを一致させることを推奨する。原本同梱と外部immutable store参照はD-004で選択。原pathが消えても検証済みsnapshotがあるなら再現可能、hashだけで実体がないなら追跡参照は残るが再実行不可。処理前後の検証/公開手順はD-004/D-006へ要求として渡す。

MeasurementContextは `context_id, revision_id, measurement_id, binding_evidence, planned_ref, actual_record_ref, fields` を持つ。fieldsには運転回転数/負荷（値・単位）、温度/湿度、センサー配置ref、測定イベント、外乱、装置状態を状態付きで記載する。条件が変化する場合はtimebaseに結び付いた区間/系列を用い、設定RPMと実測RPMを区別する。必須なのは項目状態と出典であり、温湿度の未測定を全Recording拒否にしない。用途policyが必要条件を選ぶ。

外部metadataとの照合キーはU。推奨は収録source hashを含む明示bindingと測定実施IDの照合。hashは測定意味の証明ではない。ファイル名近似だけで自動結合しない。未登録はUnknownとして診断可能、不一致はcontext結合を拒否し、値だけを流用しない。実CSV先頭5行/第6行以降/第1列の情報はユーザー提供D-001条件であり、この調査で実ファイルを実証したものではない。

## 10. SignalView

|項目|必須性・意味|
|---|---|
|view_id / contract_version|M 不変選択ID/対応版|
|recording_ref / signal_revision_ref|M rootと具体的なrevision。最新版への可変参照禁止|
|selection|M ordered channel IDs、任意pair ID、timebase別[start,stop)または秒要求。両指定なら一致を検証|
|resolved_ranges|M 各CH/timebaseのsample範囲、実時刻、元source対応|
|units / stages / calibration_refs / sync_refs|M 親の情報を保持する読取結果。GUI側で再推測しない|
|quality_refs / eligibility|M 対象範囲の所見と用途別結果|
|read_contract|M 軸・dtype・shape・chunk条件。値を返すとき選択との対応を維持|

区間は半開。負index、逆順、空区間、範囲外、未知CHは明示拒否し、自動clipしない。秒範囲内にsampleがない場合はEMPTY_SELECTIONとしてUnavailable。p/u/RPMが別時計なら別範囲を返し、同長matrixへ暗黙結合しない。同期を必要とするconsumerは共通軸または証明済み変換を要求する。

SignalViewは読み取り専用という**意味契約**を持つ。NumPy writeable=Falseだけでは外部aliasによる改変を防げない。メモリviewは高速だがowner管理が必要、コピーは隔離が強いが大容量、遅延providerは部分読込に向くが寿命/失敗/原本差替えを扱う必要がある。推奨はimmutable snapshotを指す選択descriptor＋read-only providerで、小規模PoCではコピーを基準に比較する（SELECT）。同一snapshot・選択・校正状態を複数PoCへ渡し、片方の処理が他方の入力を変えないことをT-06で検証する。

## 11. 派生データとの境界

全DerivedArtifactに `artifact_id, type/version, input_view_refs, axes(name/unit/coordinates), values_ref, processing_ref, source_support, quality_refs` を要求する案とする。特徴量のIDと値は同じ行対応で保持し、シャッフル後も一致すること。具体的な数式と実行APIはD-003。

|処理|D-002で要求する追跡・意味|D-003以降で決める項目|
|---|---|---|
|固定時間窓|窓ID、start/stop、元timebase/CH、表示中心と計算区間|窓長/overlap、端部/padding|
|回転同期窓・次数|角度/回転軸と元時刻対応、RPM参照、補間support|角度再標本化法、次数分解能、低速/逆転条件|
|FFT/STFT/PSD|周波数Hz、時間座標、元窓、複素/実数、正規化ID、単位、片側/両側、DC/Nyquist|窓関数、FFT長、振幅/パワー/PSD換算の数式と検証|
|cross/MSC/位相差|CH順序、共役規約、正規化/平均区間、Hz、rad/deg等、同期・校正証拠|推定量、平均法、信頼性/成立条件|
|Active/Reactive Intensity|p/uの組・方向/符号・cross規約、単位W/m²の解釈、計算support|推定式、スペクトル密度なら単位/Hz、適用物理条件|
|特徴量/ML入力|feature schema、軸順序、単位/変換、元区間群、処理履歴|特徴定義、標準化のfit対象、モデル/分割/閾値|

例えば未正規化abs(FFT)²をPSDと呼ぶことは拒否できるが、D-002で唯一のPSDアルゴリズムを強制しない。選択mask、切出し矩形、表示範囲、実計算supportは別欄。混合窓/複数元区間を一つの連続区間へ偽装しない。

## 12. 不変条件・Validator

|ID|推奨不変条件|違反時の最小範囲|
|---|---|---|
|INV-01|root→source asset/hash/取込解釈への到達|root参照矛盾はRecording拒否。原本可用性不足は別所見|
|INV-02|quantity/unit/stage/origin整合|既知の矛盾はCH受領拒否。不明は該当物理解析不可|
|INV-03|CH長とtimebase一致、選択範囲一致|当該CH解析不可。構造のshape虚偽は受領拒否|
|INV-04|root内CH ID一意、参照先一意|Recording拒否。後勝ち/最初一致禁止|
|INV-05|pair参照/役割整合、重複共有明示|pair拒否。独立CHは利用可|
|INV-06|適用校正の入力/出力/係数/方法/範囲追跡|証跡必要解析不可。校正済み状態への無証拠昇格禁止|
|INV-07|派生から元区間supportへの到達|当該成果物の研究比較利用不可|
|INV-08|要求された同期/方向/位相条件を明示検証|依存する解析のみUnavailable|
|INV-09|原本・revision・View意味の不変性、hash一致|改変したasset/revisionを拒否。既存値に黙って更新しない|
|INV-10|missing/unsupported/invalidと実測ゼロを分離|違反CH拒否、0補完禁止|
|INV-11|品質/校正の領域限定と親所見維持|該当派生利用拒否、品質消去不可|
|INV-12|契約版・必須capability認識|不対応オブジェクトを実行前拒否|

Validatorは入力を書き換えず、次の4層の結果を返す案とする。

1. **構造**：型、必須欄、enum、配列記述。報告 `accepted/rejected`。未知版、重複ID、参照の曖昧さ、実体hash不一致などは拒否。
2. **意味/参照**：単位、段階、CH/time/pair、原本連鎖。範囲別findingを生成。未知と矛盾を区別。
3. **処理実行可能性**：consumerのrequirements＋対象View＋policyで `Ready / Ready with warning / Unavailable`。requiredにunknown/fail/unsupportedがあればUnavailable。warningでrequiredを迂回しない。
4. **科学的妥当性**：物理証拠の評価結果・適用範囲を保持。汎用schema検査だけでPASSを付けない。独立した試験/証明がない場合not_assessed/inconclusive。

戻り値の提案：`ValidationReport(contract_version, object_ref, structural_status, findings[], eligibility[{consumer_profile, target_ref, state, reasons, policy_ref}], checked_assets[])`。単一boolは禁止。構造拒否したデータは診断用隔離対象であり通常consumerへ渡さない。部分利用の場合は、合格したCH/Viewだけを明示して渡す。

|reason code案|種別・挙動|
|---|---|
|UNSUPPORTED_VERSION / UNKNOWN_CAPABILITY|契約拒否。unsupportedを正常としない|
|HASH_MISMATCH / AMBIGUOUS_CHANNEL_ID|全体または該当asset受領拒否|
|PAIR_ROLE_MISMATCH / DANGLING_REFERENCE|pair/派生の意味拒否、非依存CHは利用可|
|TIME_UNRESOLVED / SYNC_UNKNOWN / DIRECTION_UNKNOWN|依存解析Unavailable、単独sample表示などは残す|
|CHANNEL_MISSING / EMPTY_SELECTION|データ無し・選択無し。計算失敗と分離|
|CALIBRATION_DECLARED_ONLY / PHYSICAL_NOT_ASSESSED|policy次第でwarningまたはUnavailable。科学的合格にはしない|
|ASSET_UNAVAILABLE|一時I/O/未移送。実体改変と区別、再取得で再評価可能|
|COMPUTATION_FAILED|処理例外。入力invalidと断定せずエラー参照を保存|

例外は読込/処理の機械的失敗、警告は利用条件付きの所見、missingは未取得、unsupportedは能力/表現の未対応である。いずれもスコア0/正常へ変換しない。

## 13. 擬似データ例（提案・非実行fixture）

次は説明用抜粋であり完全な適合JSONではない。`Hraw`等は実hashではない。実fixtureはPoCで生成する。

```yaml
identity: {recording_id: org:R1, revision_id: rev:raw1, source_refs: [asset:csv1]}
timebases:
  tb: {grid_kind: uniform, sample_count: 30000, interval_s: 0.001,
       relative_origin_s: 0, origin_definition: first_sample, clock_ref: Unknown}
channels:
  ch01: {physical_quantity: voltage, unit: V, timebase_ref: tb,
         availability: present, origin: measured, value_stage: raw_voltage}
  ch02: {physical_quantity: voltage, unit: V, timebase_ref: tb,
         availability: present, origin: measured, value_stage: raw_voltage}
```

取込metadataでch01がpressureセンサー、ch02がvelocityセンサーに対応すると宣言されても、このraw値のquantityはvoltageのまま。校正process K1後にderived:D1/rev:physical1を作り、同じ取得CHの派生表現をPa/m/sにする。pair03はそのrevisionのCHを参照する。

SignalView V1はrev:physical1/pair03/10≤t<20 sを選び `[10000,20000)` を解決する。親rawにも同じindexが対応するのはK1が時間格子を変えない場合だけ。方向・相対同期がUnknownならpの単独波形解析はpolicy条件次第で可能だが、PU IntensityはUnavailable。別校正K2はderived:D2を生成しV1を変更しない。

## 14. D-003以降への引継ぎ

|工程|D-002から渡す要求|ここで確定しないもの|
|---|---|---|
|D-001 外部入力|原CSV保存、列/時間解釈/配線/metadata bindingの根拠、Unknown保持|実列配置・第1列の意味・外部ツールの照合方式|
|D-003 独立PoC|View/DerivedArtifact参照、requirementsと利用可否、単位/軸/正規化宣言|実行API、数式、モデル、例外ラッパーの実装|
|D-004 保存|immutable revision/asset、hash検証、部分読込、親解決、途中成果物識別|NPZ/HDF5/ディレクトリ/commit方式|
|D-005 組合せ|能力/契約版不一致を実行前拒否、方式変更で履歴を分離|Registry/DAG/Plugin基盤の採用|
|D-006 再現|run/experimentとrecording分離、snapshot/seed/実装環境/比較入力固定|登録DB、実験UI、完全再現環境の配布|
|D-007 GUI|読み取りモデル、状態/理由/元範囲表示、値・校正のGUI内複製禁止|画面構成、非同期/キャンセルAPI|

実装前に決める最小事項は判断台帳J03〜J10。実ファイルが未入手でもT-01〜09の合成契約比較は可能だが、それをD-001や実機校正の実証にしてはならない。追加調査はround02 U1〜U8の必要分に限定し、全体再読込しない。
