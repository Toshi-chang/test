# 異常×外乱：固定条件の対比較

独立正常実現3群、重複対照を除く評価36シナリオ個体。受音点は個体数に数えない。

|経路|正常・外乱なし FP/n|正常・外乱あり FP/n|異常・外乱なし TP/n|異常・外乱あり TP/n|
|---|---:|---:|---:|---:|
|A_full|3/3|3/3|15/15|15/15|
|A_selected|0/3|3/3|15/15|15/15|
|B_order|0/3|3/3|15/15|15/15|
|C_event|0/3|3/3|15/15|15/15|
|D_patch|0/3|3/3|12/15|15/15|

判定不可はfactorial_results.jsonの各セルに別保存。FP/TPの母数に判定不可も含める。
**外乱のみでoutsideになる場合、異常＋外乱でoutsideとなっても対象異常を識別できた証拠にはならない。**

## 外乱追加による判定遷移

|経路|within→outside|outside→within|判定不可が関係する比較|
|---|---:|---:|---:|
|A_full|0|0|0|
|A_selected|0|0|0|
|B_order|0|0|0|
|C_event|0|0|0|
|D_patch|3|0|0|

## 異常種類別の範囲外判定

|経路|対象異常|外乱なし outside/n|外乱あり outside/n|
|---|---|---:|---:|
|A_full|band|3/3|3/3|
|A_full|order|3/3|3/3|
|A_full|event|3/3|3/3|
|A_full|relation|3/3|3/3|
|A_full|mixed|3/3|3/3|
|A_selected|band|3/3|3/3|
|A_selected|order|3/3|3/3|
|A_selected|event|3/3|3/3|
|A_selected|relation|3/3|3/3|
|A_selected|mixed|3/3|3/3|
|B_order|band|3/3|3/3|
|B_order|order|3/3|3/3|
|B_order|event|3/3|3/3|
|B_order|relation|3/3|3/3|
|B_order|mixed|3/3|3/3|
|C_event|band|3/3|3/3|
|C_event|order|3/3|3/3|
|C_event|event|3/3|3/3|
|C_event|relation|3/3|3/3|
|C_event|mixed|3/3|3/3|
|D_patch|band|3/3|3/3|
|D_patch|order|3/3|3/3|
|D_patch|event|3/3|3/3|
|D_patch|relation|0/3|3/3|
|D_patch|mixed|3/3|3/3|

## 外乱なし正常の誤判定：最大スコアを作った入力

特徴量zはfit全入力に対する偏差であり、Isolation Forestの寄与度・因果説明ではない。時間・周波数の範囲は計算入力の範囲。

- A_full / family_100000: score=0.59316, threshold=0.570767。
  最大入力：c00020_m1_side、受音点side、ramp、[1.0, 2.0]秒、[0, 512.0]Hz。
  偏差上位：pu_correlation: z=-1.99, p_crest: z=-1.96, p_rms: z=-1.37。通常イベントとの区間重なり：['usual2']。

- A_full / family_100001: score=0.605549, threshold=0.570767。
  最大入力：c00027_m0_front、受音点front、steady、[1.0, 2.0]秒、[0, 512.0]Hz。
  偏差上位：p_band_150_240: z=3.44, p_crest: z=-1.98, p_rms: z=-1.59。通常イベントとの区間重なり：['usual2']。

- A_full / family_100002: score=0.572303, threshold=0.570767。
  最大入力：c00034_m0_offset、受音点offset、steady、[1.0, 2.0]秒、[0, 512.0]Hz。
  偏差上位：p_rms: z=-2.25, p_crest: z=-1.97, u_rms: z=-1.56。通常イベントとの区間重なり：['usual2']。

## 判定根拠と制約

- clean/evidence.json、disturbed/evidence.json：各ケースの上位3入力、sample ID、座標、時間、周波数、特徴量偏差。
- 受音点別max、閾値超過入力数、受音点を一つ除いたmaxも保存。後者は同じ閾値の診断であり、新方式の性能ではない。
- p/Uの正常・対象成分は対比較で完全一致、外乱追加差分は外乱寄与と一致することをpairing.jsonで検証。
- 既存Runnerに固定モデル推論CLIがないため同一正常データで決定論的に再学習し、全モデル・閾値ファイルのSHA一致を必須とした。
- 外乱学習、特徴追加、受音点集約変更、閾値調整は行っていない。今回の結果を使って改良する場合、次の独立評価条件を別途確保する。
