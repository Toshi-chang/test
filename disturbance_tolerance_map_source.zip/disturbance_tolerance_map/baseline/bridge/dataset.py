"""Generate paired synthetic scenes; evaluation labels never enter the Adapter."""
from pathlib import Path
import copy
import numpy as np
from da_engine.artifacts import run as generate_scene
from .adapter import read,write,sha,DistributedAdapter,ACQUISITION

VERSION='distributed-nv-dataset/1.0'
def realize(cfg,family,mode_index,scenario):
    scene=copy.deepcopy(cfg['template_scene']);mode=cfg['modes'][mode_index]
    seed=int(np.random.SeedSequence([cfg['seed'],family,mode_index]).generate_state(1)[0])
    scene['simulation']['seed']=seed
    for i,s in enumerate(scene['sources']):
        rg=np.random.default_rng(np.random.SeedSequence([cfg['seed'],family,i,1]))
        rm=np.random.default_rng(np.random.SeedSequence([cfg['seed'],family,i,mode_index,2]))
        s['drive_rms']*=rg.uniform(*cfg['specimen_gain_range'])*rm.uniform(*cfg['measurement_gain_range'])
    if scenario!='normal':scene['sources']+=copy.deepcopy(cfg['additions'][scenario])
    for s in scene['sources']:
        if s['excitation']['kind']=='order':s['excitation'].update(start_rpm=mode['start_rpm'],end_rpm=mode['end_rpm'])
    return scene

def region(pair,fs):
    scale=np.max(abs(pair),axis=0);relative=np.max(abs(pair)/np.maximum(scale,1e-30),axis=1)
    support=np.flatnonzero(relative>1e-3)
    if not len(support):return None
    energy=(abs(np.fft.rfft(pair,axis=0))/np.maximum(scale,1e-30))**2
    curve=np.cumsum(energy.sum(axis=1));curve/=max(curve[-1],1e-30)
    freq=np.fft.rfftfreq(len(pair),1/fs);indices=np.searchsorted(curve,[.0005,.9995]).clip(0,len(freq)-1)
    return {'start_sample':int(support[0]),'end_sample':int(support[-1]+1),'frequency_hz':freq[indices].tolist(),
        'sensors':['p','u'],'support_definition':'source contribution > 0.001 channel peak; weak tails remain',
        'frequency_definition':'99.9% combined channel-normalized source energy; not a sharp band limit'}

def generate(config_path,output):
    cfg=read(config_path)
    if cfg.get('schema_version')!=VERSION:raise ValueError('unknown dataset version')
    if cfg['train_families']<5 or cfg['eval_families']<1:raise ValueError('insufficient family counts')
    if cfg['scenarios']!=['normal','disturbance','band','order','event','relation','mixed']:raise ValueError('unknown scenario protocol')
    root=Path(output).resolve()
    if root.exists():raise ValueError('fresh dataset output required')
    root.mkdir(parents=True);canonical=root/'canonical';canonical.mkdir()
    write(root/'generation.json',cfg);manifests={'train':[],'eval':[]};origins=[]
    truth={'schema_version':'1.0','model_limit':cfg['truth_semantics'],'cases':[],'training_cases':[],
           'evaluation_design':{'independent_base_families':cfg['eval_families'],'scenarios_per_family':7,
            'receiver_policy':'same specimen, simultaneous captures; not independent specimens'}}
    jobs=[('train',i,'normal') for i in range(cfg['train_families'])]
    jobs += [('eval',100000+i,kind) for i in range(cfg['eval_families']) for kind in cfg['scenarios']]
    for index,(split,family,kind) in enumerate(jobs):
        sid=f's{index:05d}';cid=f'c{index:05d}';group=f'family_{family:06d}'
        ct={'specimen_id':sid,'case_id':cid,'label':'normal' if kind in ('normal','disturbance') else 'abnormal',
            'scenario':kind,'independent_family_id':group,'regions':[],'normal_events':[]}
        for mi,mode in enumerate(cfg['modes']):
            capture=f'{cid}_m{mi}';scene=realize(cfg,family,mi,kind)
            input_config=root/'scene_configs'/f'{capture}.json';input_config.parent.mkdir(exist_ok=True);write(input_config,scene)
            raw=generate_scene(input_config,root/'raw'/capture)
            fs=scene['simulation']['sample_rate_hz'];duration=scene['simulation']['duration_seconds'];n=round(fs*duration)
            t=np.arange(n)/fs;rpm=mode['start_rpm']+(mode['end_rpm']-mode['start_rpm'])*t/duration
            np.savez_compressed(raw/'rpm_observation.npz',rpm=rpm)
            acquisition={'schema_version':ACQUISITION,'units':['Pa','m/s'],'axes':['time','receiver'],
                'sample_rate_hz':fs,'n_samples':n,'receivers':scene['receivers'],'rpm_sync':'shared_clock',
                'calibration':{'reference':'analytic_SI_distributed_v1'},
                'observations':{'path':'observations.npz','sha256':sha(raw/'observations.npz')},
                'rpm':{'path':'rpm_observation.npz','sha256':sha(raw/'rpm_observation.npz')},
                'operating_conditions':{'mode':mode['name'],'start_rpm':mode['start_rpm'],'end_rpm':mode['end_rpm'],
                                       'rpm_key':'shaft_rpm','shaft':'primary'}}
            write(raw/'acquisition.json',acquisition)
            items,refs=DistributedAdapter().convert(raw/'acquisition.json',canonical,
                {'specimen_id':sid,'case_id':cid,'derived_group_id':group,'capture_id':capture})
            manifests[split]+=items;origins+=refs
            # Ground truth construction happens outside the adapter, after conversion.
            normal_count=len(cfg['template_scene']['sources'])
            with np.load(raw/'generator_truth.npz',allow_pickle=False) as arrays:
                for si,s in enumerate(scene['sources']):
                    injected=si>=normal_count;normal_event=s['id'] in cfg['normal_events']
                    if not injected and not normal_event:continue
                    for ri,r in enumerate(scene['receivers']):
                        pair=np.column_stack([arrays['source_pressure_pa'][si,:,ri],arrays['source_velocity_m_s'][si,:,ri]@np.asarray(r['axis'])])
                        span=region(pair,fs)
                        if span:
                            span.update(measurement_id=refs[ri]['measurement_id'],source_id=s['id'],
                                source_geometry=s['geometry'],kind=kind if injected else 'normal_event',
                                role='disturbance' if kind=='disturbance' and injected else ('target_anomaly' if injected else 'normal_event'),
                                raw_truth_sha256=sha(raw/'generator_truth.npz'))
                            ct['regions' if injected else 'normal_events'].append(span)
        truth['training_cases' if split=='train' else 'cases'].append(ct)
    for split,items in manifests.items():write(canonical/f'{split}_manifest.json',{'schema_version':'1.0','role':split,'normal_only_attested':split=='train','measurements':items})
    write(canonical/'truth.json',truth)
    write(root/'conversion_index.json',{'schema_version':'distributed-conversion/1.0','measurements':origins})
    write(root/'status.json',{'status':'complete','train_specimens':cfg['train_families'],
        'evaluation_variants':7*cfg['eval_families'],'independent_eval_families':cfg['eval_families'],
        'train_measurements':len(manifests['train']),'eval_measurements':len(manifests['eval'])})
    return canonical
