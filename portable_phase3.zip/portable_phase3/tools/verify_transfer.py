"""Verify packaged files with Python standard library only; extra files are allowed."""
import hashlib
import json
from pathlib import Path
import sys


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root / "TRANSFER_MANIFEST.json").read_text(encoding="utf-8"))
    if manifest.get("version") != "1.0":
        raise ValueError("unsupported transfer manifest")
    for relative, expected in manifest["files"].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError(f"missing/invalid member: {relative}")
        if path.stat().st_size != expected["bytes"] or digest(path) != expected["sha256"]:
            raise ValueError(f"changed member: {relative}")
    return {"status": "verified", "files": len(manifest["files"]), "root": str(root)}


if __name__ == "__main__":
    print(json.dumps(verify(sys.argv[1]), ensure_ascii=False))
