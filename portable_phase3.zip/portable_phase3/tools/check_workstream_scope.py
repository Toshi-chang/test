"""Review supplied changed paths without invoking Git. Not an OS permission boundary."""
import argparse
from fnmatch import fnmatchcase
import json
from pathlib import PurePosixPath, Path

ROOT=Path(__file__).resolve().parents[1]

def permitted(owner, path, policy):
    path=path.replace('\\','/')
    p=PurePosixPath(path)
    if p.is_absolute() or '..' in p.parts or ':' in path or str(p)!=path:
        return False
    if any(fnmatchcase(path,pattern) for pattern in policy['frozen']): return False
    return any(fnmatchcase(path,pattern) for pattern in policy['owners'].get(owner,[]))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owner',required=True)
    parser.add_argument('paths',nargs='+',help='complete changed-path list, relative to project root')
    args=parser.parse_args(); policy=json.loads((ROOT/'development/ownership.json').read_text(encoding='utf-8'))
    denied=[p for p in args.paths if not permitted(args.owner,p,policy)]
    print(json.dumps({'owner':args.owner,'checked':args.paths,'denied':denied},ensure_ascii=False,indent=2))
    raise SystemExit(bool(denied))
