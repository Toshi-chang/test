# 対象異常×外乱：固定条件の対比較PoC

2026-11-07。分布音源と既存5経路の接続実証を変更せず、誤判定の根拠分析と外乱の影響を分離した実験を追加。

## 今回の問い

1. 正常誤判定を起こした入力はどの受音点・時刻・帯域か。
2. 同じ異常へ外乱を追加すると、判定とスコアがどう変わるか。
3. 異常＋外乱の範囲外判定は、外乱だけへの反応と区別できるか。

モデル・前処理・選択・閾値・正常学習条件は変更しない。効果を良く見せるための条件調整をしない。新しい方式の最適化は今回の範囲外。

## 実験構成

|対象状態|外乱なし|外乱あり|
|---|---|---|
|正常|normal|disturbance|
|異常|band/order/event/relation/mixed|各異常＋同じdisturbance|

独立正常実現ごとに正常2条件＋異常5×2条件=12条件。comparisonは独立正常実現3群、重複を除いて36評価シナリオ個体。受音点3×運転2は同一個体の6測定であり、独立個体数に加算しない。

実装は既存の7シナリオ生成器を改変せず2回使う。cleanは従来7条件、disturbedは5異常に外乱を追加（正常2条件は対照として重複生成）。集計では正常対照を1回だけ数える。正常学習は両方20個体で、fit16/cal4。quickは学習8（fit6/cal2）、評価独立1群。

既存Runnerに固定モデルだけを読み込む推論CLIはない。そのため同じ正常データで決定論的に2回学習し、入力ファイル・分割・全モデル・全閾値のハッシュ一致を必須とする。新しい推論APIを実装済みとして扱わない。

## 使い方

Python 3.12 64bit、依存はbaseline/requirements.txt。baseline/に実装・設定の固定コピーを含み、元作業フォルダは実行時に不要。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r baseline/requirements.txt
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -B run_factorial.py --profile comparison --output outputs/comparison_v1
```

必ず未作成の出力先を使用。再実行時は末尾名を変える。失敗時はstatus.json/error.logを残す。baselineのコード・設定を変更して試験を通さない。baseline/release_manifest.jsonで164ファイルを起動時／完了時に照合する。

過去Bundleの根拠分析だけなら `python diagnose.py --bundle <Bundle> --output <新規JSON>`。元Bundleを変更しない。信頼済みBundleReaderによる完全性確認後、保存された入力特徴とスコアを読む。モデルpickleのロードはしない。

## 結果の読み方

- outputs/comparison_v1/index.html：4条件の集計と両Bundle viewerへのリンク。
- REPORT.md：正常誤判定の最大入力と判定遷移。
- factorial_results.json：各条件のoutside/within/undetermined、異常種類別・独立正常実現別の対比較。
- pairing.json：学習データ・分割・モデル・閾値一致、正常／異常成分の不変、外乱差分の検証。
- clean/evidence.json、disturbed/evidence.json：各ケース上位入力、時間・周波数・受音点、fit特徴偏差、受音点別max。
- reports/BASELINE_DIAGNOSIS.md：以前のcomparison結果の読取分析。

Feature zはfit全入力の平均・標準偏差から計算した記述統計で、モデルの特徴寄与ではない。受音点除外maxは元閾値を使う診断値であり、再校正した別方式の成績ではない。

## 正解情報

既存生成器は追加音源を対象異常としてまとめるため、今回の新規実行側でexternal_extraだけをdisturbanceへ明示訂正する。観測データ・モデル入力は変更しない。異常＋外乱の正解は対象異常ありを維持する。

入力Adapterは引き続き観測・収録メタデータだけを読む。正解は推論後の評価・可視化専用。全音源寄与はrawに保存し、同じ正常・異常成分へ外乱だけが追加されたことを確認する。

## 限界

外乱のみでoutsideの場合、異常＋外乱もoutsideだからといって対象異常の識別に成功したとは言えない。判定改善ではなくスコアの変化・遷移をまず報告する。今回の外乱は固定位置・固定220Hzの1条件で、未知外乱への汎化は未確認。

筐体透過・構造連成・実測性能・PU情報の独立した有効性・受音点配置最適化は対象外。今回の探索結果を使って方式や閾値を変更した後は、別の未使用正常実現・外乱条件で評価する。
