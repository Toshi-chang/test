"""Kinematic rotation drives, not a structural engine/gearbox simulation."""
import copy
import numpy as np

DEFAULT_ROTATION = dict(rpm_start=1800., rpm_end=1800., variation=.15,
                       ripple=.01, ripple_hz=2., include_combined=True)

def validate_rotation(config):
    raw=config.get('rotation')
    if raw is None:return
    r={**DEFAULT_ROTATION,**raw};config['rotation']=r
    for key in DEFAULT_ROTATION:
        if key=='include_combined':
            if not isinstance(r[key],bool):raise ValueError('複合条件は真偽値で指定してください')
            continue
        r[key]=float(r[key])
        if not np.isfinite(r[key]):raise ValueError('回転数設定は有限値が必要です')
    if not 60<=r['rpm_start']<=30000 or not 60<=r['rpm_end']<=30000:
        raise ValueError('RPMは60〜30000です')
    if not 0<=r['variation']<=.5 or not 0<=r['ripple']<=.1 or not 0<=r['ripple_hz']<=20:
        raise ValueError('RPMばらつき0〜0.5、揺らぎ0〜0.1、揺らぎ周波数0〜20 Hzです')

def rotation_trace(t,duration,rotation,seed):
    rng=np.random.default_rng(np.random.SeedSequence([int(seed),9871]))
    factor=rng.uniform(1-rotation['variation'],1+rotation['variation'])
    phase=rng.uniform(0,2*np.pi)
    rpm=(rotation['rpm_start']+(rotation['rpm_end']-rotation['rpm_start'])*np.clip(t/duration,0,1))*factor
    rpm*=1+rotation['ripple']*np.sin(2*np.pi*rotation['ripple_hz']*t+phase)
    # Integrate frequency, so accelerations never introduce phase discontinuities.
    cycles=np.zeros_like(t)
    cycles[1:]=np.cumsum((rpm[:-1]+rpm[1:])*.5*np.diff(t)/60)
    cycles-=np.interp(0,t,cycles)
    return rpm,cycles

def validate_rotating_source(s,c):
    if s['kind'] not in ('gear','rotation_fault'):return
    if c.get('rotation') is None:raise ValueError('回転音源にはRPM設定が必要です。回転機械プリセットを読み込んでください')
    for key,default in dict(shaft_ratio=1.,teeth=20,harmonics=3,depth=.2).items():
        s[key]=float(s.get(key,default))
        if not np.isfinite(s[key]):raise ValueError('ギア設定は有限値が必要です')
    if not .05<=s['shaft_ratio']<=10 or not 1<=s['teeth']<=200 or int(s['teeth'])!=s['teeth']:
        raise ValueError('軸回転比0.05〜10、歯数1〜200の整数です')
    if not 0<=s['depth']<=1:raise ValueError('回転同期変調度は0〜1です')
    r=c['rotation'];low=min(r['rpm_start'],r['rpm_end'])*(1-r['variation'])*(1-r['ripple'])/60*s['shaft_ratio']
    high=max(r['rpm_start'],r['rpm_end'])*(1+r['variation'])*(1+r['ripple'])/60*s['shaft_ratio']
    if s['kind']=='gear':
        if low*s['teeth']<25 or high*(s['teeth']*s['harmonics']+1)>=.45*c['fs']:
            raise ValueError('RPM・歯数・倍音数の組合せが帯域外です。回転数/倍音数を下げるかfsを上げてください')
    elif s['frequency_hz']+6*high>=.45*c['fs'] or s['frequency_hz']-6*high<25:
        raise ValueError('同期異常音の共振周波数と回転側帯域が帯域外です')

def rotating_excitation(t,s,cycles,phase):
    angle=2*np.pi*cycles*s['shaft_ratio']+phase
    if s['kind']=='gear':
        x=sum(np.sin(j*s['teeth']*angle)/j for j in range(1,int(s['harmonics'])+1))
        return x*(1+s['depth']*np.cos(angle))
    # Smooth once-per-revolution pulse train driving an acoustic carrier.
    # A fixed periodic envelope makes the anomaly phase-locked to the shaft.
    envelope=((1+np.cos(angle))*.5)**6
    return envelope*np.sin(2*np.pi*s['frequency_hz']*t+phase)

def rotating_presets(base):
    c=copy.deepcopy(base);c['rotation']=dict(DEFAULT_ROTATION)
    a=copy.deepcopy(c['sources'][0]);a.update(name='入力軸ギア・20歯',kind='gear',shaft_ratio=1.,teeth=20,harmonics=3,depth=.15)
    b=copy.deepcopy(a);b.update(name='中間軸ギア・30歯',shaft_ratio=.5,teeth=30,level_rms=.0015)
    # Different independent source; distance is handled by the monopole field.
    noise=copy.deepcopy(c['sources'][3]);noise.update(name='遠方の工場雑音',model='monopole',distance_m=5.,axis_angle_deg=60,level_rms=.0001)
    fault=copy.deepcopy(c['sources'][4]);fault.update(name='軸同期の周期的異音',kind='rotation_fault',shaft_ratio=1.,teeth=1,frequency_hz=1800,level_rms=.001)
    c['sources']=[a,b,noise,fault]
    accel=copy.deepcopy(c);accel['rotation'].update(rpm_start=1200.,rpm_end=2400.)
    quiet=copy.deepcopy(c);quiet['sources'][-1]['level_rms']=.0002
    reference=copy.deepcopy(c)
    reference['fs']=16384
    reference['rotation'].update(rpm_start=1000.,rpm_end=1000.,variation=0.,ripple=0.)
    gear=copy.deepcopy(a)
    gear.update(name='基準ギア・60歯（噛み合い1〜3倍）',teeth=60,depth=0.,variation=0.)
    background=copy.deepcopy(base['sources'][2])
    background.update(name='常在する広帯域暗騒音・25〜7000 Hz',kind='white_noise',model='plane',
                      band_low_hz=25.,band_high_hz=7000.,level_rms=.08,variation=0.,axis_angle_deg=60.)
    reference['sources']=[gear,background,copy.deepcopy(noise),copy.deepcopy(fault)]
    return {'回転機械：定速・複数ギア＋同期異音＋遠方外乱':c,
            '回転機械：加速1200→2400 RPM':accel,
            '回転機械：微弱な同期異音':quiet,
            '回転機械：1000 RPM・60歯・3倍音＋広帯域暗騒音':reference}
