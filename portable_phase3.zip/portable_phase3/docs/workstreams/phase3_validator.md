# Phase 3 Agent V：共通設定 Validator

実施日：2026-10-15 JST。担当は新規 `nv_runner/plugin_validation.py` と
`tests/test_plugin_validation.py`。既存実装・既存試験・契約文書は編集していない。
Runnerへの接続は統合担当I、Descriptor登録時の呼び出しは担当Pが所有する。

## 境界と互換性

- `validate_schema(schema) -> None`：宣言の型、対応keyword、再帰構造を検証。
- `validate_route_config(config, schema) -> None`：既存model種別・selection検査と宣言schemaの検査。失敗時例外、設定変更・既定値補完なし。
- Registry、候補プラグイン、科学計算コードをimportしない。プラグイン名の分岐なし。
- modelは従来の `isolation_forest` / `pca` のみ。modelやselectionの欠落・構造不正に対する既存KeyError/TypeErrorを独自の成功判定に変換しない。
- 既存selectionはAND/OR、2子以上、既存7物理fieldと4比較演算。無効selectionのconditionは検査しない。
- 旧必須正数は `type:number, exclusiveMinimum:0, allow_bool:true, finite:false` と宣言し、旧Pythonのbool/NaN/Inf境界を維持。ファイルJSONの非有限数拒否は従来のread_jsonが行う。candidate固有の厳密検査は担当Pのvalidatorから呼ぶ。
- 新しいnumber/integer宣言は既定でbool・非有限値を拒否する。追加propertyの既定は許可、厳密な新機能は `additionalProperties:false` を明示する。

## 対応する最小schema

JSON Schema全仕様ではない。未知keywordは拒否する。

|場所|対応|
|---|---|
|全型|`type`, `enum`（空リスト不可、比較は値とPython型の一致）|
|type|object / array / number / integer / string / boolean / null|
|object|properties / required / additionalProperties(bool)|
|array|items / minItems / maxItems|
|number / integer|minimum / exclusiveMinimum / maximum / exclusiveMaximum / allow_bool / finite|

`default`, `$ref`, `oneOf`, 正規表現、依存schemaなどは非対応。必要になった時だけ独立拡張する。
requiredは宣言済みpropertyの重複しないリスト。schemaルートはroute用にobjectを要求する。
型変換、単位換算、データ補正は行わない。観測・PreparedSet・Bundleの実データ検証は既存境界の責務であり、本モジュールに移していない。

## 単独検証と再実行

PoCディレクトリで以下を実行する。

```powershell
.venv/Scripts/python.exe -m unittest discover -s tests -p test_plugin_validation.py -v
```

初回：12試験成功、0.002秒。`reports/phase3/V/attempt01.txt` に全結果を保存。
実入力の生成・学習は不要で、全fixtureは専用試験ファイルの小さなdict/listに閉じている。
試験では旧許容値・負例・strictな新宣言・未知schema・モデル/selection・設定非変更を検証。
既存97試験とCLI/Bundlesの統合回帰は担当Iが実施するため、この単独結果を統合成功とは扱わない。

再開時は専用試験を再実行し、Pの登録宣言とIの接続結果を確認する。
この担当の作業で失敗した試験はない。初回ログを上書きせず追加のattempt番号で残す。
