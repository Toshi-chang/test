"""Opt-in full-window route with bounded, vectorized feature computation.

Uses the C03 lifecycle without importing other candidate implementations.
Feature definitions match legacy A; IDs intentionally include candidate config.
"""
import math
import numpy as np
from .routes import PreparedSet, RoutePlugin
from .signals import valid_interval


def validate_candidate_config(config):
    """Validate only candidate-owned parameters; global validation remains C08."""
    if config.get("plugin") != "fixed_window_candidate":
        raise ValueError("candidate plugin must be fixed_window_candidate")
    for name in ("window_seconds", "hop_seconds"):
        value = config.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be a finite positive number")
    selection = config.get("selection", {"enabled": False})
    if not isinstance(selection, dict) or selection.get("enabled", False) is not False:
        raise ValueError("fixed_window_candidate supports full-window selection.enabled=false only")


def _features(windows, fs):
    """windows: [window,time,channel]; Hann bin mean square, no detrending."""
    width = windows.shape[1]
    rms = np.sqrt(np.mean(windows * windows, axis=1))
    p = windows[:, :, 0]
    crest = np.max(np.abs(p), axis=1) / np.maximum(rms[:, 0], 1e-12)
    correlation = np.mean(p * windows[:, :, 1], axis=1) / np.maximum(rms[:, 0] * rms[:, 1], 1e-20)
    taper = np.hanning(width)
    spectrum = np.fft.rfft(p * taper, axis=1)
    factor = np.full(spectrum.shape[1], 2.)
    factor[0] = 1.
    if width % 2 == 0:
        factor[-1] = 1.
    power = np.abs(spectrum) ** 2 * (factor / (width * np.sum(taper ** 2)))
    frequency = np.fft.rfftfreq(width, 1 / fs)
    bands = [(0, 80), (80, 150), (150, 240), (240, fs / 2 + 1)]
    powers = [power[:, (frequency >= low) & (frequency < high)].sum(axis=1) for low, high in bands]
    return np.column_stack([rms, crest, correlation, *powers])


class FixedWindowCandidate(RoutePlugin):
    """Full A equivalent; vectorized batches limited to 64 windows in memory."""
    def __init__(self, config):
        validate_candidate_config(config)
        super().__init__(config)

    def feature_schema(self):
        return [("p_rms", "Pa"), ("u_rms", "m/s"), ("p_crest", "1"),
                ("pu_correlation", "1"), ("p_band_0_80", "Pa^2"),
                ("p_band_80_150", "Pa^2"), ("p_band_150_240", "Pa^2"),
                ("p_band_240_nyquist", "Pa^2")]

    def prepare(self, records, service):
        out = PreparedSet()
        # Full-window features need observations only; service maps remain untouched.
        for record in records:
            fs = record.meta["timebase"]["sample_rate_hz"]
            width = round(fs * self.config["window_seconds"])
            hop = round(fs * self.config["hop_seconds"])
            if width < 3 or hop < 1:
                raise ValueError("candidate requires window >= three samples and hop >= one sample")
            n = len(record.signals)
            starts = range(0, n - width + 1, hop)
            last = 0
            for offset in range(0, len(starts), 64):
                batch = list(starts[offset:offset + 64])
                valid = [s for s in batch if valid_interval(record, s, s + width)]
                values = {}
                if valid:
                    windows = np.stack([record.signals[s:s + width] for s in valid])
                    values = dict(zip(valid, _features(windows, fs)))
                for start in batch:
                    last = start + width
                    self.add(out, record, start, last, [0, fs / 2], values.get(start),
                             None if start in values else "invalid_input_range")
            out.coverage[record.meta["measurement_id"]] = {
                "reason": "too_short" if last == 0 else None,
                "incomplete": last == 0, "excluded_ranges": [[last, n]] if last < n else []}
        return out
