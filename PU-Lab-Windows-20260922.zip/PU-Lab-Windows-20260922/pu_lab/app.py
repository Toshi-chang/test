"""Offline loopback UI. python app.py, then open the printed local address."""
from __future__ import annotations
import argparse,json,mimetypes,secrets,threading,time,webbrowser,socket
from datetime import datetime
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,unquote
import numpy as np
from physics import default_config,presets,validate_config,synthesize,spectral_summary,json_safe,VERSION,case_names
from dataset import make_dataset,load_dataset
from dl import train_model
from integration import import_legacy, saved_runs
from rpm_sensor import DEFAULT_SENSOR
import experiments
import planning

ROOT=Path(__file__).resolve().parent

class LocalServer(ThreadingHTTPServer):
    allow_reuse_address=False
    def server_bind(self):
        if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()

class LabState:
    def __init__(self,root=ROOT):
        self.root=Path(root);self.outputs=self.root/'outputs';self.outputs.mkdir(exist_ok=True,parents=True)
        self.token=secrets.token_urlsafe(32);self.lock=threading.Lock();self.stop=threading.Event()
        self.job={'running':False,'logs':[],'kind':None,'result':None,'error':None}
    def log(self,s):
        with self.lock:self.job['logs']=(self.job['logs']+[str(s)])[-100:]
    def snapshot(self):
        with self.lock:return json.loads(json.dumps(self.job))
    def path(self,relative):
        p=(self.outputs/relative).resolve()
        if not p.is_relative_to(self.outputs.resolve()):raise ValueError('出力フォルダ外は指定できません')
        return p
    def start(self,kind,work):
        with self.lock:
            if self.job['running']:raise ValueError('実行中の処理が終わるか停止してから操作してください')
            self.stop.clear();self.job={'running':True,'logs':[],'kind':kind,'result':None,'error':None}
        def worker():
            try:
                result=work()
                with self.lock:self.job['result']=result
            except Exception as exc:
                with self.lock:self.job['error']=str(exc)
            finally:
                with self.lock:self.job['running']=False
        threading.Thread(target=worker,daemon=True).start()
    def new_folder(self,prefix):
        path=self.outputs/(prefix+'_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(2))
        path.mkdir();return path


def handler_for(state):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send_bytes(self,data,typ='application/json; charset=utf-8',status=200):
            self.send_response(status);self.send_header('Content-Type',typ)
            self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
        def reply(self,obj,status=200):self.send_bytes(json.dumps(json_safe(obj),ensure_ascii=False,allow_nan=False).encode(),status=status)
        def allowed(self):
            host=self.headers.get('Host','').split(':')[0]
            return host in ('127.0.0.1','localhost')
        def do_GET(self):
            try:
                if not self.allowed():return self.reply({'error':'Invalid host'},403)
                route=unquote(urlparse(self.path).path)
                if route=='/':
                    html=(ROOT/'static/index.html').read_text(encoding='utf-8').replace('__LAB_TOKEN__',state.token)
                    return self.send_bytes(html.encode(),'text/html; charset=utf-8')
                if route.startswith('/static/'):
                    p=(ROOT/route.lstrip('/')).resolve()
                    if not p.is_relative_to((ROOT/'static').resolve()) or not p.is_file():return self.reply({'error':'Not found'},404)
                    return self.send_bytes(p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
                if route.startswith('/files/'):
                    p=state.path(route[len('/files/'):])
                    if not p.is_file():return self.reply({'error':'Not found'},404)
                    return self.send_bytes(p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
                if self.headers.get('X-Lab-Token')!=state.token:return self.reply({'error':'Invalid token'},403)
                if route=='/api/bootstrap':
                    choices=presets();selected='評価基準：機械60 dB SPL・暗騒音25 dB SPL・1000 RPM'
                    return self.reply({'version':VERSION,'config':choices[selected],'default_preset':selected,'presets':choices,'rpm_sensor_defaults':DEFAULT_SENSOR})
                if route=='/api/status':return self.reply(state.snapshot())
                if route=='/api/plans':
                    plans=[]
                    for p in sorted(state.outputs.glob('plan_*/plan.json'),reverse=True):
                        item=planning.detail(state,p.parent.relative_to(state.outputs).as_posix())
                        item['plan']={k:item['plan'][k] for k in ('name','purpose','counts')};plans.append(item)
                    return self.reply({'plans':plans})
                if route=='/api/history':return self.reply({'runs':saved_runs(state.outputs)})
                if route=='/api/comparisons':
                    return self.reply({'comparisons':[dict(folder=p.parent.relative_to(state.outputs).as_posix(),name=experiments.read(p.parent/'plan.json').get('name',p.parent.name),
                        **experiments.read(p)) for p in sorted(state.outputs.glob('comparison_*/state.json'),reverse=True)]})
                if route=='/api/datasets':
                    paths=sorted(state.outputs.rglob('dataset.npz'),key=lambda x:x.stat().st_mtime,reverse=True)
                    return self.reply({'datasets':[p.relative_to(state.outputs).as_posix() for p in paths]})
                return self.reply({'error':'Not found'},404)
            except Exception as e:self.reply({'error':str(e)},400)
        def do_POST(self):
            try:
                if not self.allowed() or self.headers.get('X-Lab-Token')!=state.token:return self.reply({'error':'Invalid request'},403)
                route=urlparse(self.path).path;size=int(self.headers.get('Content-Length',0))
                if size<0 or size>450_000_000:return self.reply({'error':'Request too large'},413)
                raw=self.rfile.read(size)
                if route=='/api/import':
                    folder=state.new_folder('import');path=folder/'dataset.npz';path.write_bytes(raw)
                    try:load_dataset(path)
                    except Exception:path.unlink(missing_ok=True);raise
                    return self.reply({'dataset':path.relative_to(state.outputs).as_posix()})
                data=json.loads(raw or b'{}')
                if route=='/api/plan-fields':return self.reply({'fields':planning.fields(validate_config(data['config']))})
                if route=='/api/plan-preview':return self.reply(planning.build(data))
                if route=='/api/plan-save':return self.reply({'folder':planning.create(state,planning.build(data))})
                if route=='/api/plan-detail':return self.reply(planning.detail(state,data['folder']))
                if route=='/api/plan-run':
                    folder=data['folder'];planning.detail(state,folder)
                    state.start('planned',lambda:planning.run(state,folder));return self.reply({'started':True})
                if route=='/api/comparison-plan':return self.reply(experiments.plan(state,data))
                if route=='/api/comparison-start':
                    proposal=experiments.plan(state,data)
                    def work():return experiments.run(state,experiments.create(state,proposal))
                    state.start('comparison',work);return self.reply({'started':True})
                if route in ('/api/comparison-detail','/api/comparison-resume'):
                    folder=state.path(data['folder'])
                    if folder.parent!=state.outputs.resolve() or not folder.name.startswith('comparison_'):
                        raise ValueError('実験比較フォルダを選択してください')
                    if route.endswith('resume'):
                        experiments.read(folder/'plan.json')
                        state.start('comparison',lambda:experiments.run(state,folder));return self.reply({'started':True})
                    return self.reply(dict(folder=data['folder'],plan=experiments.read(folder/'plan.json'),
                        state=experiments.read(folder/'state.json'),
                        summary=experiments.read(folder/'summary.json') if (folder/'summary.json').exists() else {'rows':[]}))
                if route=='/api/comparison-records':
                    folder=state.path(data['folder']);task=str(data['task'])
                    if not task.startswith('eval_') or not task[5:].isdigit():raise ValueError('不正な評価IDです')
                    return self.reply(experiments.read(folder/(task+'.json')))
                if route=='/api/result':
                    folder=state.path(data['folder'])
                    result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
                    return self.reply(dict(folder=folder.relative_to(state.outputs).as_posix(),
                        channels=result['metrics']['channels'],**result))
                if route=='/api/dataset-config':
                    folder=state.path(data['dataset']).parent
                    if (folder/'provenance.json').exists():
                        raise ValueError('旧版データの設定は物理モデルと互換性がありません。波形はそのままDL入力に使用できます。')
                    cfg=json.loads((folder/'config.json').read_text(encoding='utf-8-sig'))
                    return self.reply({'config':validate_config(cfg)})
                if route=='/api/preview':
                    cfg=validate_config(data['config']);result=[]
                    for case in range(len(case_names(cfg))):
                        # Same seed shares normal sources for a controlled visual comparison.
                        rec=synthesize(cfg,case,cfg['seed'],components=True)
                        sp=spectral_summary(rec['observed'],cfg['fs'])
                        result.append(dict(case=case,time_s=rec['time_s'],p=rec['observed'][0],u=rec['observed'][1],
                          p_true=rec['truth'][0],u_true=rec['truth'][1],spectra=sp,sources=rec['sources'],rpm=rec['rpm'],rpm_true=rec['rpm_true']))
                    return self.reply({'cases':result,'comparison':'shared normal-source seed in preview only'})
                if route=='/api/generate':
                    cfg=validate_config(data['config'])
                    def work():
                        folder=state.new_folder('data');summary=make_dataset(cfg,folder,state.log,state.stop.is_set)
                        return {'dataset':(folder/'dataset.npz').relative_to(state.outputs).as_posix(),
                                'folder':folder.relative_to(state.outputs).as_posix(),'summary':summary}
                    state.start('generate',work);return self.reply({'started':True})
                if route=='/api/train':
                    path=state.path(data['dataset'])
                    if not path.is_file():raise ValueError('データセットがありません')
                    channels=data.get('channels','pu');epochs=int(data.get('epochs',80))
                    if channels not in ('pu','p','u','all','pu_rpm','compare_rpm'):raise ValueError('入力チャンネルが不正です')
                    if channels in ('pu_rpm','compare_rpm') and 'train_rpm' not in load_dataset(path):
                        raise ValueError('RPM付きデータが必要です。回転機械プリセットから生成してください')
                    if not 1<=epochs<=500:raise ValueError('学習回数は1〜500です')
                    def work():
                        folder=state.new_folder('training');results=[]
                        for ch in (['p','u','pu'] if channels=='all' else ['pu','pu_rpm'] if channels=='compare_rpm' else [channels]):
                            if state.stop.is_set():raise InterruptedError('比較を停止しました')
                            state.log(f'入力 {ch} の学習を開始')
                            output=folder/ch;res=train_model(path,output,epochs,ch,state.log,state.stop.is_set)
                            results.append(dict(channels=ch,folder=output.relative_to(state.outputs).as_posix(),**res))
                        return {'runs':results,'folder':folder.relative_to(state.outputs).as_posix()}
                    state.start('train',work);return self.reply({'started':True})
                if route=='/api/cancel':state.stop.set();return self.reply({'stopping':True})
                return self.reply({'error':'Not found'},404)
            except Exception as e:self.reply({'error':str(e)},400)
    return Handler


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
    state=LabState()
    imported=[]  # Clean distribution: no automatic legacy-data import
    if imported:print(f'旧版データを利用可能: {len(imported)} 件',flush=True)
    try:server=LocalServer(('127.0.0.1',args.port),handler_for(state))
    except OSError as exc:raise SystemExit(f'起動できません: {exc}\n別ポート: python app.py --port 8766')
    address=f'http://127.0.0.1:{server.server_port}'
    print(f'PU Lab {VERSION}\n{address}\n終了: Ctrl+C',flush=True)
    if not args.no_browser:threading.Timer(.5,lambda:webbrowser.open(address)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:state.stop.set()
    finally:server.server_close()

if __name__=='__main__':main()
