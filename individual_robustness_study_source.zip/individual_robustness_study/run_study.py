import bootstrap_study
from bootstrap_study import ROOT,BASELINE,verify_baseline
from pathlib import Path
import argparse,time,traceback,copy
import numpy as np
import joblib
from bridge.adapter import read,write,sha
from nv_runner.routes import REGISTRY
from nv_runner.input_adapter import InputAdapter
from data import normal_fields,extra_fields,make_case
from experiment import partitions,prepare,subset,score
from evidence_view import case_page
from summarize import summarize

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output.resolve()
    if out.exists():raise ValueError('fresh output required; no automatic overwrite')
    out.mkdir(parents=True);start=time.perf_counter();status={'status':'running'};write(out/'status.json',status)
    protocol=read(ROOT/'protocol.json');assert protocol['schema_version']=='individual-robustness/1.0';splits=partitions(protocol)
    cfg=read(BASELINE/'configs/dataset_comparison.json');experiment=read(BASELINE/'configs/experiment.json')
    assert cfg['seed']==protocol['model_seed']==experiment['seed']==42
    write(out/'protocol.json',protocol);write(out/'splits.json',splits);write(out/'generation.json',cfg);write(out/'experiment.json',experiment)
    write(out/'source_hashes.json',{p.name:sha(p) for p in ROOT.glob('*.py')})
    try:
        pool=[];by_family={}
        for family in range(protocol['pool_families']):
            base=normal_fields(cfg,family);records=make_case(out/'pool'/f'f{family}',f'train_f{family}',family,base,None,None,None,cfg);pool+=records;by_family[family]=records
            if family%10==0:print('normal pool',family,flush=True)
        write(out/'pool_attestation.json',{'normal_only_attested':True,'families':list(by_family),'measurement_ids':[r.meta['measurement_id'] for r in pool],'method':'normal_fields only; no target additions, no added external; baseline ambient retained'})
        prepared_pool=prepare(pool,experiment);models={};thresholds={};validation={'prepared_subset_equivalence':[],'same_fit_different_calibration_models_identical':True}
        for name,s in splits.items():
            fit=[r for f in s['fit'] for r in by_family[f]];cal=[r for f in s['calibration'] for r in by_family[f]];folder=out/'models'/name;folder.mkdir(parents=True);models[name]={};thresholds[name]={}
            independent=prepare(fit,experiment) if name==next(iter(splits)) else None
            for rc in experiment['routes']:
                key=rc['key'];plugin=REGISTRY[rc['plugin']](rc);fp=subset(prepared_pool[key],fit);cp=subset(prepared_pool[key],cal)
                if independent is not None:
                    direct=independent[key];assert sorted(fp.values)==sorted(direct.values)
                    for sid in fp.values:np.testing.assert_array_equal(fp.values[sid],direct.values[sid])
                    validation['prepared_subset_equivalence'].append(key)
                model=plugin.fit(fp,rc['model'],protocol['model_seed']);model.save(folder/f'{key}.joblib')
                scores=plugin.score(model,cp,experiment['batch_size']);calrows=plugin.aggregate(cp,scores,cal);threshold=plugin.calibrate(calrows,experiment['calibration']);assert threshold['value'] is not None
                models[name][key]=model;thresholds[name][key]=threshold;write(folder/f'{key}_threshold.json',threshold);write(folder/f'{key}_calibration_cases.json',calrows)
                write(folder/f'{key}_fit_ids.json',sorted(fp.values))
            print('trained',name,flush=True)
        for seed in protocol['partition_seeds']:
            for rc in experiment['routes']:
                key=rc['key'];a1=out/'models'/f's{seed}_fit16_cal4'/f'{key}.joblib';a2=out/'models'/f's{seed}_fit16_cal8'/f'{key}.joblib';assert sha(a1)==sha(a2)
        model_hashes={p.relative_to(out/'models').as_posix():sha(p) for p in (out/'models').rglob('*') if p.is_file()};write(out/'model_hashes.json',model_hashes)
        primary=protocol['primary'];assert primary in models;write(out/'training_validation.json',validation)
        jobs=[(None,None,None)]+[(d,f,l) for d in protocol['positions_m'] for f in protocol['frequencies_hz'] for l in protocol['levels_db_spl']]
        allrows=[];stability=[];total=0
        pool_keys={k:{r.meta[k] for r in pool} for k in ['specimen_id','case_id','derived_group_id','source_sha256']}
        for family in protocol['evaluation_families']:
            base=normal_fields(cfg,family);additions={kind:None if kind=='normal' else extra_fields(cfg,family,kind) for kind in protocol['scenarios']};external_cache={}
            for ji,(direction,freq,level) in enumerate(jobs):
                if direction is None:external=None
                else:
                    token=(direction,freq)
                    if token not in external_cache:external_cache[token]=extra_fields(cfg,family,'disturbance',protocol['positions_m'][direction],freq)
                    external=external_cache[token]
                for kind in protocol['scenarios']:
                    cid=f'f{family}_j{ji:02d}_{kind}';dest=out/'cases'/cid
                    records=make_case(dest,cid,family,base,additions[kind],external,level,cfg)
                    for k,values in pool_keys.items():assert not values&{r.meta[k] for r in records},k
                    p=prepare(records,experiment)
                    # The selected primary is fixed by protocol before any evaluation is loaded.
                    rows=score(records,p,experiment,models[primary],thresholds[primary],dest)
                    for r in rows:r.update(family=family,scenario=kind,label='normal' if kind=='normal' else 'abnormal',direction=direction,frequency_hz=freq,db_spl=level,variant=primary,detail=f'cases/{cid}/index.html')
                    write(dest/'results.json',rows);case_page(rows,records,dest)
                    # Copied generic viewer is annotated explicitly: anomaly regions differ per scenario.
                    page=(dest/'index.html').read_text(encoding='utf-8').replace('生成器の正解：対象は正常、追加外乱は全記録の連続単音。黄色は異常の正解領域ではありません。',f'生成条件：対象={kind}、追加外乱={level} dB SPL。黄色はモデル入力区間であり、異常注入の正解領域ではありません。注入条件はm0/m1のgeneration.jsonに保存。')
                    (dest/'index.html').write_text(page,encoding='utf-8')
                    allrows+=rows
                    if direction is None:
                        for name in models:
                            rr=rows if name==primary else score(records,p,experiment,models[name],thresholds[name])
                            for r in rr:stability.append({k:v for k,v in dict(r,family=family,scenario=kind,label='normal' if kind=='normal' else 'abnormal',variant=name).items() if k not in ['evidence_refs','top_inputs']})
                    write(dest/'complete.json',{'hashes':{f.relative_to(dest).as_posix():sha(f) for f in dest.rglob('*') if f.is_file() and f.name!='complete.json'}})
                    total+=1
                write(out/'progress.json',{'cases_complete':total,'cases_total':1008,'family':family,'condition':ji});print(f'{family} condition {ji}/27 ({total}/1008)',flush=True)
            write(out/'stability_rows.json',stability);write(out/'map_rows.json',allrows);summarize(allrows,stability,protocol,out)
        assert model_hashes=={p.relative_to(out/'models').as_posix():sha(p) for p in (out/'models').rglob('*') if p.is_file()}
        status.update(status='passed',cases=total,primary_route_rows=len(allrows),stability_route_rows=len(stability),baseline_files=verify_baseline(),model_artifacts_unchanged=True,elapsed_seconds=time.perf_counter()-start)
    except BaseException as e:
        status.update(status='failed',error=str(e));(out/'error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:write(out/'status.json',status)
if __name__=='__main__':main()
