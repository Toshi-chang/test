"""Synthetic RPM measurement chain; parameters are scenarios, not device specs."""
import numpy as np
from scipy.signal import lfilter

DEFAULT_SENSOR=dict(update_hz=100.,delay_ms=0.,smoothing_ms=0.,gain_error_pct=0.,
    offset_rpm=0.,noise_rms_rpm=0.,interference_rpm=0.,interference_hz=10.,
    quantization_rpm=0.,dropout_probability=0.,pulses_per_rev=0)

def validate_sensor(raw):
    if raw is None:return None
    c={**DEFAULT_SENSOR,**raw}
    bounds={'update_hz':(1,2000),'delay_ms':(0,1000),'smoothing_ms':(0,2000),
      'gain_error_pct':(-50,50),'offset_rpm':(-1000,1000),'noise_rms_rpm':(0,1000),
      'interference_rpm':(0,1000),'interference_hz':(0,500),'quantization_rpm':(0,1000),
      'dropout_probability':(0,.9),'pulses_per_rev':(0,10000)}
    for key,(low,high) in bounds.items():
        c[key]=float(c[key])
        if not np.isfinite(c[key]) or not low<=c[key]<=high:raise ValueError(f'RPMセンサー {key}: {low}〜{high}')
    if int(c['pulses_per_rev'])!=c['pulses_per_rev']:raise ValueError('1回転のパルス数は整数です')
    return c

def measure_rpm(t,true_rpm,cycles,raw,seed):
    if raw is None:return true_rpm.copy()
    c=validate_sensor(raw);dt=1/c['update_hz'];delay=c['delay_ms']/1000
    times=np.arange(t[0],t[-1]+dt,dt)
    delayed=times-delay
    value=np.interp(delayed,t,true_rpm)
    if c['pulses_per_rev']:
        # Count pulse crossings within each reporting gate; finite resolution.
        phase=np.interp(delayed,t,cycles)*c['pulses_per_rev']
        previous=np.interp(delayed-dt,t,cycles)*c['pulses_per_rev']
        value=(np.floor(phase)-np.floor(previous))*60/(c['pulses_per_rev']*dt)
    value=value*(1+c['gain_error_pct']/100)+c['offset_rpm']
    if c['smoothing_ms']:
        a=np.exp(-dt/(c['smoothing_ms']/1000))
        value,_=lfilter([1-a],[1,-a],value,zi=[a*value[0]])
    rng=np.random.default_rng(np.random.SeedSequence([int(seed),9987]))
    value+=rng.normal(0,c['noise_rms_rpm'],len(value))
    value+=c['interference_rpm']*np.sin(2*np.pi*c['interference_hz']*times+rng.uniform(0,2*np.pi))
    if c['quantization_rpm']:value=np.round(value/c['quantization_rpm'])*c['quantization_rpm']
    missing=rng.random(len(value))<c['dropout_probability'];missing[0]=False
    indices=np.maximum.accumulate(np.where(missing,0,np.arange(len(value))))
    value=np.maximum(value[indices],0)
    return value[np.clip(np.searchsorted(times,t,side='right')-1,0,len(value)-1)]
