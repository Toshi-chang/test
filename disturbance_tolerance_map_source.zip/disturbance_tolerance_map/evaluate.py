"""Experiment adapter over unchanged prepare/score/aggregate/decide interfaces."""
import numpy as np
from nv_runner.routes import REGISTRY
from nv_runner.signals import SignalService
from bridge.adapter import write

def evaluate(records,cfg,models,thresholds,folder=None):
    service=SignalService(cfg['signal']);results=[];metadata={r.meta['measurement_id']:r.meta for r in records}
    for rc in cfg['routes']:
        if not rc.get('enabled',True):continue
        key=rc['key'];plugin=REGISTRY[rc['plugin']](rc)
        p=plugin.prepare(records,service);scores=plugin.score(models[key],p,cfg['batch_size'])
        rows=plugin.decide(plugin.aggregate(p,scores,records),thresholds[key]);lookup={s['sample_id']:s for s in p.samples}
        good=sorted([s for s in scores if s['anomaly_score'] is not None],key=lambda s:(-s['anomaly_score'],s['sample_id']))
        top=[]
        for s in good[:3]:
            sample=lookup[s['sample_id']];x=p.values[s['sample_id']];model=models[key];z=model.scaler.transform(np.asarray([x]))[0];schema=plugin.feature_schema()
            ix=np.argsort(-abs(z),kind='stable')[:5];m=metadata[sample['measurement_id']]
            top.append({'sample':sample,'score':s['anomaly_score'],'position_m':m['channels'][0]['position_m'],'operating_conditions':m['operating_conditions'],
                'features':[{'name':schema[i][0],'unit':schema[i][1],'value':float(x[i]),'fit_z':float(z[i])} for i in ix]})
        for row in rows:row.update(threshold=thresholds[key]['value'],top_inputs=top)
        results+=rows
        if folder:
            write(folder/f'{key}_samples.json',{'samples':p.samples,'scores':scores,'coverage':p.coverage,'feature_schema':plugin.feature_schema()})
            ids=sorted(p.values)
            if ids:np.savez_compressed(folder/f'{key}_features.npz',sample_ids=np.asarray(ids),features=np.asarray([p.values[i] for i in ids]))
            for mid,assets in p.assets.items():np.savez_compressed(folder/f'{key}_{mid}_selection.npz',**assets)
    return results
