"""Independent selection tests: no generated data/models needed."""
import unittest
import numpy as np
from nv_runner.selection import select_mask
from nv_runner.signals import select_mask as legacy_import
from nv_runner.routes import select_mask as route_import

class Selection(unittest.TestCase):
    def test_existing_imports_reach_independent_implementation(self):
        self.assertIs(select_mask,legacy_import)
        self.assertIs(select_mask,route_import)
        self.assertEqual(select_mask.__module__,'nv_runner.selection')

    def test_nested_selection_frequency_axis_and_no_mutation(self):
        maps={'msc':np.array([[.2,.65,.9],[.8,.1,.7]]),
              'intensity':np.array([[1.,-1.,2.],[3.,0.,-2.]]),
              'frequency_hz':np.array([10.,20.,30.])}
        condition={'op':'and','children':[
            {'field':'msc','comparison':'>=','value':.65},
            {'op':'or','children':[{'field':'intensity','comparison':'>','value':0},
                                   {'field':'frequency_hz','comparison':'<=','value':20}]}]}
        before={k:v.copy() for k,v in maps.items()}
        np.testing.assert_array_equal(select_mask(condition,maps),[[False,True,True],[True,False,False]])
        for k in maps: np.testing.assert_array_equal(maps[k],before[k])
        for op,expected in [('>',[False,False,True]),('>=',[False,True,True]),('<',[True,False,False]),('<=',[True,True,False])]:
            result=select_mask({'field':'frequency_hz','comparison':op,'value':20},maps)
            np.testing.assert_array_equal(result,[expected,expected])

    def test_existing_exception_behavior(self):
        maps={'msc':np.ones((2,3))}
        with self.assertRaisesRegex(ValueError,'selection op must be and/or'):
            select_mask({'op':'xor','children':[]},maps)
        with self.assertRaises(KeyError):
            select_mask({'field':'unknown','comparison':'>','value':0},maps)
        with self.assertRaises(KeyError):
            select_mask({'field':'msc','comparison':'==','value':0},maps)
