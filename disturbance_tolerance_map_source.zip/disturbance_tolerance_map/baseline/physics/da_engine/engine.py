"""p and vector U from the same linear Green function, exp(+j omega t)."""
import copy
import numpy as np
from .geometry import quadrature, frame, vector, positive, check_receiver

SCHEMA='distributed-acoustics/1.0'
MODES={'total_volume_velocity':'m^3/s', 'surface_density':'m/s', 'volume_density':'1/s'}

def validate_scene(scene):
    if scene.get('schema_version')!=SCHEMA: raise ValueError('unsupported scene schema')
    if set(scene)-{'schema_version','propagation','medium','simulation','sources','receivers','interpretation','container_annotation'}:
        raise ValueError('unsupported scene property')
    if scene.get('container_annotation',{}).get('acoustic_boundary','none')!='none':
        raise ValueError('container is annotation only; physical enclosure boundary is unsupported')
    if scene.get('propagation') not in ('free_space_equivalent','baffled_plane'):
        raise ValueError('unsupported propagation; enclosure transmission is not implemented')
    positive(scene['medium']['density_kg_m3'],'density')
    positive(scene['medium']['sound_speed_m_s'],'sound speed')
    if not scene.get('sources') or not scene.get('receivers'): raise ValueError('sources and receivers required')
    if len({s['id'] for s in scene['sources']})!=len(scene['sources']): raise ValueError('duplicate source ID')
    if len({r['id'] for r in scene['receivers']})!=len(scene['receivers']): raise ValueError('duplicate receiver ID')
    plane=None
    for s in scene['sources']:
        if set(s)-{'id','geometry','strength_mode','drive_unit','drive_rms','distribution','phase','excitation','role'}:
            raise ValueError('unsupported source property')
        if not isinstance(s['id'],str) or not s['id']: raise ValueError('source id required')
        g=s['geometry']; q=quadrature(g)
        mode=s['strength_mode']
        if mode not in MODES or s['drive_unit']!=MODES[mode]: raise ValueError('source strength/unit mismatch')
        if mode=='surface_density' and q['dimension']!=2: raise ValueError('surface density requires surface')
        if mode=='volume_density' and q['dimension']!=3: raise ValueError('volume density requires volume')
        positive(s['drive_rms'],'drive_rms')
        ex=s.get('excitation')
        if ex is not None:
            fields={'tone':{'kind','frequency_hz','phase_rad'},'event':{'kind','frequency_hz','phase_rad','sigma_seconds','center_seconds'},
                    'order':{'kind','start_rpm','end_rpm','order','phase_rad'},'noise':{'kind','band_hz','seed_key'}}
            if ex.get('kind') not in fields or set(ex)-fields[ex['kind']]:raise ValueError('unsupported excitation/property')
        if scene['propagation']=='baffled_plane':
            if g['kind'] not in ('rectangle','disk') or mode!='surface_density': raise ValueError('baffle requires planar normal velocity [m/s]')
            normal=q['normal_world']; origin=q['center_m']
            if plane is None: plane=(normal,origin)
            if not np.allclose(normal,plane[0],rtol=0,atol=1e-10) or abs(np.dot(origin-plane[1],normal))>1e-10:
                raise ValueError('all baffle patches must share one oriented infinite plane')
        for r in scene['receivers']:
            x=vector(r['position_m'],'receiver position'); e=vector(r['axis'],'receiver axis')
            if not np.isclose(np.linalg.norm(e),1,rtol=0,atol=1e-10): raise ValueError('receiver axis must be unit vector')
            check_receiver(g,x,1e-6)
            if scene['propagation']=='baffled_plane' and np.dot(x-q['center_m'],q['normal_world'])<=1e-6:
                raise ValueError('receiver must be strictly in front of baffle')
        element_weights(s,q)
    return scene

def element_weights(source,q):
    distribution=source.get('distribution',{'kind':'uniform'})
    p=q['local_points_m']; kind=distribution.get('kind','uniform')
    allowed={'kind'} if kind=='uniform' else {'kind','center_m','sigma_m'}
    if set(distribution)-allowed: raise ValueError('unsupported distribution property')
    if kind=='uniform': a=np.ones(len(p))
    elif kind=='gaussian':
        center=vector(distribution.get('center_m',[0,0,0]),'distribution center')
        sigma=positive(distribution['sigma_m'],'sigma')
        a=np.exp(-np.sum((p-center)**2,axis=1)/(2*sigma*sigma))
    else: raise ValueError('unsupported spatial amplitude distribution')
    weights=q['weights']*a
    if not np.isfinite(weights).all() or weights.sum()<=0: raise ValueError('empty/underflowed distribution')
    if source['strength_mode']=='total_volume_velocity': weights=weights/weights.sum()
    phase=source.get('phase',{})
    allowed={'offset_rad','gradient_rad_per_m','delay_gradient_s_per_m','opposite_halves_axis'}
    if set(phase)-allowed: raise ValueError('unsupported phase definition')
    angles=float(phase.get('offset_rad',0))+p@vector(phase.get('gradient_rad_per_m',[0,0,0]),'phase gradient')
    delays=p@vector(phase.get('delay_gradient_s_per_m',[0,0,0]),'delay gradient')
    if 'opposite_halves_axis' in phase:
        ax=phase['opposite_halves_axis']
        if ax not in (0,1,2): raise ValueError('opposite half axis must be 0,1,2')
        angles=angles+np.where(p[:,ax]>=0,np.pi,0)
    if not np.isfinite(angles).all(): raise ValueError('nonfinite phase')
    return weights,angles,delays

def source_transfer(frequency_hz,source,receivers,medium,propagation='free_space_equivalent'):
    """Outputs P[F,R] and U[F,R,xyz], per unit source drive; never sum powers."""
    f=np.asarray(frequency_hz,dtype=float)
    if f.ndim!=1 or not np.isfinite(f).all() or np.any(f<0): raise ValueError('finite nonnegative frequency axis required')
    validate_scene({'schema_version':SCHEMA,'propagation':propagation,'sources':[source],'receivers':receivers,'medium':medium})
    rho=float(medium['density_kg_m3']); c=float(medium['sound_speed_m_s']); omega=2*np.pi*f; k=omega/c
    q=quadrature(source['geometry']); weights,angles,delays=element_weights(source,q)
    p_out=np.zeros((len(f),len(receivers)),complex); u_out=np.zeros((len(f),len(receivers),3),complex)
    denominator=2*np.pi if propagation=='baffled_plane' else 4*np.pi
    # Frequency and element blocks bound the temporary memory footprint.
    for ri,rec in enumerate(receivers):
        x=vector(rec['position_m'],'receiver')
        delta=x-q['points_m']; radii=np.linalg.norm(delta,axis=1)
        if np.any(radii<=1e-6): raise ValueError('receiver too close to quadrature source; no clipping')
        for fi in range(0,len(f),128):
            sl=slice(fi,fi+128); kk=k[sl,None]; oo=omega[sl,None]
            for start in range(0,len(weights),256):
                es=slice(start,start+256); r=radii[es][None,:]
                phase=np.exp(1j*angles[es][None,:]-1j*oo*delays[es][None,:])
                common=weights[es][None,:]*phase*np.exp(-1j*kk*r)/denominator
                p_out[sl,ri]+=np.sum(1j*oo*rho*common/r,axis=1)
                radial=(1+1j*kk*r)*common/(r*r)
                u_out[sl,ri,:]+=radial@(delta[es]/radii[es,None])
    p_out[f==0]=0; u_out[f==0]=0
    return p_out,u_out

def response(scene,frequency_hz):
    """Complex response for simultaneously coherent unit drivers (RMS strength applied)."""
    validate_scene(scene)
    parts=[]
    for s in scene['sources']:
        p,u=source_transfer(frequency_hz,s,scene['receivers'],scene['medium'],scene['propagation'])
        parts.append((p*float(s['drive_rms']),u*float(s['drive_rms'])))
    return sum(p for p,u in parts),sum(u for p,u in parts)

def driver(ex, t, fs, duration, seed):
    """Dimensionless waveform, unit central RMS after envelope/filter; no p/u renormalization."""
    kind=ex['kind']; phase=float(ex.get('phase_rad',0))
    if kind in ('tone','event'):
        freq=positive(ex['frequency_hz'],'frequency')
        if freq>=.44*fs: raise ValueError('carrier outside declared passband')
        x=np.cos(2*np.pi*freq*t+phase)
        if kind=='event':
            sigma=positive(ex['sigma_seconds'],'event sigma')
            center=float(ex['center_seconds'])
            if not 0<=center<=duration: raise ValueError('event center outside record')
            x*=np.exp(-.5*((t-center)/sigma)**2)
    elif kind=='order':
        start=positive(ex['start_rpm'],'start rpm'); end=positive(ex['end_rpm'],'end rpm'); order=positive(ex['order'],'order')
        slope=(end-start)/duration
        rpm=start+slope*t
        if rpm.min()<=0 or order*rpm.max()/60>=.44*fs: raise ValueError('rotation outside passband/positive domain')
        x=np.cos(2*np.pi*order*(start*t/60+slope*t*t/120)+phase)
    elif kind=='noise':
        band=np.asarray(ex['band_hz'],float)
        if band.shape!=(2,) or not np.isfinite(band).all() or not 0<band[0]<band[1]<.44*fs: raise ValueError('noise band invalid')
        key=ex['seed_key']
        if isinstance(key,bool) or not isinstance(key,int) or key<0: raise ValueError('nonnegative noise seed_key required')
        x=np.random.default_rng(np.random.SeedSequence([seed,key])).normal(size=len(t))
        freq=np.fft.rfftfreq(len(t),1/fs); spectrum=np.fft.rfft(x)
        spectrum[(freq<band[0])|(freq>band[1])]=0; x=np.fft.irfft(spectrum,n=len(t))
    else: raise ValueError('unsupported excitation')
    f=np.fft.rfftfreq(len(t),1/fs); spec=np.fft.rfft(x)
    spec[(f<=0)|(f>=.44*fs)]=0; x=np.fft.irfft(spec,n=len(t))
    core=(t>=0)&(t<duration); rms=np.sqrt(np.mean(x[core]**2))
    if not np.isfinite(rms) or rms<=1e-15: raise ValueError('empty driver')
    return x/rms

def synthesize(scene):
    validate_scene(scene)
    sim=scene['simulation']; fs=positive(sim['sample_rate_hz'],'fs'); duration=positive(sim['duration_seconds'],'duration')
    guard=positive(sim['guard_seconds'],'guard')
    n=round(fs*duration); ng=round(fs*guard)
    if n<32 or ng<16 or not np.isclose(n,fs*duration) or not np.isclose(ng,fs*guard): raise ValueError('integer sample count and sufficient guard required')
    seed=sim['seed']
    if isinstance(seed,bool) or not isinstance(seed,int) or seed<0: raise ValueError('nonnegative integer seed required')
    t=(np.arange(n+2*ng)-ng)/fs; f=np.fft.rfftfreq(len(t),1/fs)
    p_total=np.zeros((len(f),len(scene['receivers'])),complex)
    u_total=np.zeros((len(f),len(scene['receivers']),3),complex)
    parts_p=[]; parts_u=[]; drivers=[]
    for s in scene['sources']:
        drive=driver(s['excitation'],t,fs,duration,seed)*float(s['drive_rms'])
        d=np.fft.rfft(drive); p,u=source_transfer(f,s,scene['receivers'],scene['medium'],scene['propagation'])
        pp=p*d[:,None]; uu=u*d[:,None,None]; p_total+=pp; u_total+=uu
        parts_p.append(np.fft.irfft(pp,n=len(t),axis=0)[ng:ng+n])
        parts_u.append(np.fft.irfft(uu,n=len(t),axis=0)[ng:ng+n])
        drivers.append(drive[ng:ng+n])
    p=np.fft.irfft(p_total,n=len(t),axis=0)[ng:ng+n]
    uvec=np.fft.irfft(u_total,n=len(t),axis=0)[ng:ng+n]
    axes=np.array([r['axis'] for r in scene['receivers']]); u=np.einsum('nri,ri->nr',uvec,axes)
    if not np.isfinite(p).all() or not np.isfinite(uvec).all(): raise ValueError('nonfinite generated field')
    return {'time_s':np.arange(n)/fs,'pressure_pa':p,'velocity_m_s':uvec,'axial_velocity_m_s':u,
            'source_pressure_pa':np.array(parts_p),'source_velocity_m_s':np.array(parts_u),
            'source_drives':np.array(drivers),'scene':copy.deepcopy(scene)}
