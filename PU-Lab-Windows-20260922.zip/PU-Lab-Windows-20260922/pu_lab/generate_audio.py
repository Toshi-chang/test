"""Generate configurable physics-based p/u datasets without opening the GUI."""
import argparse,json
from pathlib import Path
from physics import default_config
from dataset import make_dataset

def main():
    p=argparse.ArgumentParser();p.add_argument('--config');p.add_argument('--out',default='outputs/generated')
    p.add_argument('--write-default',help='Write a default JSON configuration and exit')
    args=p.parse_args()
    if args.write_default:
        Path(args.write_default).write_text(json.dumps(default_config(),ensure_ascii=False,indent=2),encoding='utf-8');return
    config=json.loads(Path(args.config).read_text(encoding='utf-8')) if args.config else default_config()
    print(make_dataset(config,args.out,progress=print))
if __name__=='__main__':main()
