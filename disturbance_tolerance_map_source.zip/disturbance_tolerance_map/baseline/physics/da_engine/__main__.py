import argparse,json
from .artifacts import run,inspect,view
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('run');p.add_argument('--config',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('inspect');p.add_argument('--result',required=True)
    p=sub.add_parser('view');p.add_argument('--result',required=True);p.add_argument('--output',required=True)
    a=ap.parse_args()
    if a.command=='run':print(run(a.config,a.output))
    elif a.command=='inspect':print(json.dumps(inspect(a.result)))
    else:print(view(a.result,a.output))
if __name__=='__main__':main()
