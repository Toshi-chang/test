# 分布音源 → NV解析経路：独立接続PoC

2026-11-06。Phase3 0.2.0 / C01〜C08 / ResultBundle 1.0と分布音源PoC 0.1.0を、変更しないスナップショットとして保持し、新しいAdapterを挟んだ。元nv_route_runner_poc、元distributed_acoustics_poc、先行の移植パッケージには書き込まない。

## 実行経路

```text
固定した分布音源シーン（正常・外乱・異常）
          ↓ physics/da_engine
観測p/u・時刻 ＋ 独立した収録メタデータ ＋ 理想RPM
          ↓ bridge/adapter.py（正解・音源定義を読まない）
各受音点を2CH測定へ変換、同じ個体/派生元IDを保持
          ↓ runtime/nv_runner（固定版、無改修）
正常個体のfit/cal分割 → A全/A選択/B/C/Dの学習・閾値
          ↓
評価個体の推論 → ケース内集約 → Bundle 1.0
          ↓ 推論後のみ正解を使用
検出・誤判定・見逃し・判定不可 → 既存viewer/出力Adapter
```

## 最初に見る結果

- `outputs/quick_v1/viewer.html`
- `outputs/comparison_v1/viewer.html`
- `reports/RESULTS.md`：結果と限界（生成済みの場合）。
- `outputs/*/validation.json`：分割・測定数・metrics・処理状態。

今回の正常モデルは分布音源データで新たに学習する。旧点音源のモデルを流用しない。旧comparisonの成績との直接比較は、距離・励振定義・データ規模も異なるため行わない。

## 再実行

Python 3.12 64bit、Windowsで確認。このディレクトリを作業ディレクトリにする。runtimeとphysicsだけを抜き出すのではなく本フォルダ一式を持ち出す。元プロジェクトや元の仮想環境は必要ない。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -B -c "import bootstrap; print(bootstrap.verify_engines())"
.\.venv\Scripts\python.exe -B run_integration.py --profile quick --output outputs/quick_v1
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -B run_integration.py --profile comparison --output outputs/comparison_v1
```

出力先は未作成のディレクトリ。出力済みなら別名で実行する。接続専用試験は`outputs/quick_v1`の固定条件での成功結果を前提とするため、新環境ではまずそこへquickを生成する。失敗しても既存成果物は消さず、別の新規展開で同じ手順を再開する。条件を変更して通さない。

既存130試験の独立回帰はruntimeを作業ディレクトリにして、ルートの仮想環境Pythonから `-m unittest discover -s tests -v` を実行する。契約22試験はその中に含まれる。物理PoCの20試験はphysicsで同様に実行できる。異なる試験群を重複カウントしない。

`make_protocol.py`は開発時に設定を作るヘルパー。通常の再実行では起動せず、configsのJSONを正本として使用する。生成後に検出結果を見て閾値・モデル・異常強度を調整していない。

## 固定条件

|設定|quick|comparison|
|---|---:|---:|
|正常学習の独立個体|8|20|
|評価の独立正常実現|1|3|
|評価シナリオ個体（7条件×正常実現）|7|21|
|受音点／運転条件|3／2|3／2|
|学習測定数|48|120|
|評価測定数|42|126|
|fs／測定長／seed|1024Hz／3秒／42|同左|

各個体は定常・RPM変化の2収録、各収録は3受音点。6測定を6個体として数えない。評価の正常・外乱のみ・5異常は同じ正常実現を共有する対比較なので、21独立実現とも扱わない。

正常音源：箱表面の回転次数、100Hz定常音、300Hz通常イベント2件、離れた点の背景雑音。異常：局所面180Hz、内部点の3次、局所イベント、反対側100Hz音源、混合。外乱のみは外部点220Hzの追加。物理的な故障原因や筐体透過を解いたモデルではない。

ケース内集約は旧方式と同じ最大スコア。複数受音点を増やすと最大値が変わり得るため、全受音点を含む同一構成で学習・calibration・評価する。保存されたobserved_secondsは旧Runnerが測定時間を足した「測定チャネルの累積時間」であり、同時収録の実経過時間とは区別する。

## Adapterの境界

`acquisition.json` version=`distributed-acquisition/1.0` と観測NPZ/RPM NPZだけを読む。scene.json、generator_truth.npz、ラベル、注入条件はAdapter不要。未知版・単位・軸・重複受音点・非単位方向・時刻不整合・hash不一致を拒否する。RPM欠落を捏造せずNoneで維持。

校正status=calibratedは既存C01に合わせた表現だが、reference=`analytic_SI_distributed_v1`、meaningに「SIで直接生成、実測校正証明なし」を明記する。RPMは回転励振と同じ始点・終点・時刻式から生成した理想系列で、実機回転センサー検証ではない。

生成器のイベント強度は分布音源PoCと同じく包絡・帯域制限後の記録区間RMS。旧acousticの包絡前RMSとは異なる。今回のband/order/relation/disturbanceは記録全体に存在し、旧acousticの0.4〜0.62区間注入と同一ではない。検出成績を旧データと混ぜない。

## 元データと正解への追跡

- dataset/raw/<capture>/observations.npz：全受音点の元観測。
- dataset/raw/<capture>/acquisition.json：独立した収録情報。
- dataset/canonical：旧InputAdapter用の受音点別NPZ/metadata/manifest。
- dataset/conversion_index.json：measurement_id → capture_id、受音点index、元ファイルhash、sample範囲。
- metadataのcalibration：元観測・収録情報のhash。operating_conditions：capture/receiver ID。
- dataset/canonical/truth.json：正解ケース・音源寄与領域・源形状。観測manifestから参照しない。
- rawのgenerator_truthは生成器の正解。領域は源寄与の相対ピークとスペクトルエネルギーから求めた説明用範囲で、物理的な故障領域の同定ではない。

旧Bundleには評価用正解領域が入るが、分布音源の全正解波形・全3D配置を新しいartifactとして追加していない。元観測までの追跡を別環境で保つ場合はdatasetとconversion_indexも保存し、移設先のパス対応を管理する。viewer HTMLだけでは再学習できない。

## 完了範囲と次の研究

今回の完了条件は、分布音源を旧契約で接続して実学習・評価・追跡ができること。検出率100%や正常誤判定0は条件にしない。形状ごとの優劣、センサー配置の最適化、未知形状への汎化、実測への適用、外乱分離の実証は未実施。comparison設定も同じ基本形状で独立実現数を増やすもので、13形状のベンチマークではない。

受音点の増減・形状・励振条件を変える研究は別設定／別runとして記録する。既存のcalibration閾値を無条件流用しない。将来、筐体境界や実測Adapterを追加する場合も本スナップショットを上書きしない。
