# NV経路実験ランナー：実装準備仕様 v0.1

作成日：2026-10-11 JST

位置づけ：新規実装のための設計・受渡し仕様。実装済みソフトウェアではない。既存PoC・実ファイル・接続先APIは未確認。本書の値は明示したものを除き仮設定であり、性能保証値ではない。

## 1. 今回作る箱

ユーザーが「正常学習用データ」「評価用データ」「実験設定」を指定すると、正常学習データの内部分割、経路別入力生成、学習、閾値設定、評価、結果梱包までを実行する。梱包した結果を経路評価用システムへ渡す。

主目的は測定対象個体の正常範囲内／範囲外の評価。時間・周波数・運転条件・センサー位置へのトレースを保持する。部品故障や発音メカニズムの推定は対象外。

初版の成果は経路比較を可能にする実験基盤。総合判定は任意の追加出力であり、結果収集の完了と個体判定の成立を混同しない。閾値を確定できなくてもスコア・状態・根拠を返す。

## 2. モジュール構成と責務

| モジュール | 責務 | 下流への出力 |
|---|---|---|
| InputAdapter | 実ファイルを標準入力へ変換、キー・単位・chを検査 | MeasurementRecord |
| DatasetPlanner | 個体単位で学習fit／calibration／評価を固定 | SplitManifest |
| SignalService | 校正・同期、波形・STFT・物理量・座標管理 | AnalysisArtifact |
| RoutePlugin | 経路固有の切出し、入力生成、正常モデル学習、評価 | SampleResult、RouteCaseResult |
| ExperimentRunner | 依存順序、実行状態、再開、経路例外の隔離 | RunManifest |
| ResultCollector | 必須フィールド・参照・件数・完全性の検査、梱包 | ResultBundle |
| EvaluationAdapter | 経路評価システムへ結果を受渡し | 受領結果 |
| FusionEvaluator | 任意の個体総合判定 | CaseResult |

経路は他経路を直接呼ばない。共通計算の再利用はSignalService経由。初版は逐次実行とし、並列化は契約を変えず後で追加する。可視化UIはランナーから分離する。

## 3. 入力契約

### 3.1 ユーザー入力

- train_manifest.json：正常として学習に利用する測定一覧。
- eval_manifest.json：評価対象の測定一覧。正解ラベルは任意。
- experiment.json：有効経路、各経路条件、内部分割、結果出力先。
- 実際の測定ファイル。初期の標準コンテナ候補は数値配列NPZ＋JSONメタデータ。

既存ファイルがこの形式であるとは仮定しない。元NPZのキー名・形状を推測せず、InputAdapterのmappingで明示的に対応する。NPZのobject配列やpickleに依存しない。

### 3.2 MeasurementRecordの必須情報

| フィールド | 型・規約 |
|---|---|
| specimen_id | 個体識別。ファイル名からの自動推定は禁止 |
| case_id | 1回の個体評価に使用する測定一式の識別 |
| measurement_id | 測定の識別 |
| source_path、source_sha256 | 元ファイルの所在と同一性 |
| signals | 数値配列。各系列の軸順を明記 |
| channels | ch名、物理量、単位、センサー位置・方向、p–uペア |
| timebase | サンプル周波数、開始時刻または時刻配列、同期情報 |
| calibration | 校正済みか、校正参照、適用単位 |
| operating_conditions | 時刻に対応した運転情報。未知ならunknown |
| validity | 使用不可範囲と理由 |

回転パルス、rpm、走行モードは任意。ただし必要な経路では必須条件になる。同期していない系列を同じサンプル番号で結合しない。欠落した単位や校正状態を勝手に補完しない。

1 caseは1 specimenのみ。再測定を同じcaseへ束ねるか別caseとするかは入力manifestで指定し、測定時間の長い個体を無制限に有利・不利にしないよう測定プロトコルも記録する。

## 4. データ分割と学習の境界

1. trainとevalの個体ID重複・元ファイルハッシュ重複を検査。既定では拒否。
2. trainを個体単位でfitとcalibrationへ分割し、一覧を保存。
3. fitのみで標準化、特徴選択、次元削減、正常モデルを学習。
4. calibrationを固定モデルで評価し、経路内集約後のcaseスコアから閾値を設定。
5. evalを同じ固定処理で評価。evalの正解ラベルは結果解析にのみ使用。

同一個体の複数caseは同じ分割へ置く。合成データが元測定を共有する場合は派生元グループでも分離する。小窓をシャッフルして学習・calibrationに分けない。

内部分割の試行値はfit 80%／calibration 20%、seed固定。個体数不足なら分割を無理に作らずcalibration_unavailableとする。明示的な既存閾値がなければ評価スコアのみ返し、正常／異常は未確定とする。

閾値候補はcalibration caseスコアの上側経験分位点。分位点、補間法、比較演算子、校正個体数を記録。少数個体で高い分位点を指定しても誤検出率が保証されたとは表示しない。

実験設定の手動比較を繰り返したevalは開発用評価になる。性能を最終確認する際は別の未使用個体群を確保する。

## 5. 経路設計

### A：固定時間窓・特徴量経路（最初の実装対象）

校正波形 → 固定時間窓 → 全体特徴量／時間周波数物理量 → 複合条件による選択 → 選択特徴量と占有率 → 入力表 → 正常モデル → 窓スコア → case集約。

- 入力1件：一定時間窓。試行設定は1秒窓、0.5秒hop。短い末尾は除外して除外範囲を記録。
- 最初の動作確認：p/uのRMS等の単純な特徴量と正常モデル。次の段階でMSC・インテンシティ・位相・複合マスクを追加。
- 特徴量は名前、単位、順序、演算、参照領域をschemaで固定。
- 初期モデル候補：標準化＋Isolation Forest。API固有の符号をアダプタで変換し、共通出力は値が大きいほど異常とする。ライブラリ組込み閾値をそのまま採用しない。
- 選択領域なしの場合も窓の台帳は保持。選択特徴量が必須なら当該窓は未評価。初版では学習済みの欠損補完を勝手に追加しない。全領域版と選択領域版を別route variantとして比較可能にする。
- case集約の基準案：有効窓スコアの最大。上位分位、閾値超過時間等は診断値として保存。重複窓の時間を単純加算しない。
- 最大値判定の閾値はcase単位calibrationで決定し、測定時間・有効窓数も出力する。

### B：回転同期・次数経路

音響信号＋回転信号 → パルス品質検査 → 回転角と元時刻の対応 → 一定回転数分の区間 → 角度リサンプリング → 次数特徴量 → 正常モデル → 回転区間スコア → case集約。

- 入力1件：設定した回転数分。試行値10回転、5回転hop。
- 必須条件：pulse_per_rev、欠落パルス検査、同期、対象回転軸の定義。無効な回転角を補間して評価を強行しない。
- 回転停止区間は対象外。回転センサーなしはnot_applicableとして返す。
- 回転角／リサンプル点から元時刻への対応と補間条件を保存。
- モデルはAと同じプラグインを利用可能だが、学習済みモデル・標準化器は別。
- case集約の基準案は有効区間スコア最大。次数からHzへの対応はrpm変化を含む時間依存の範囲として保持。

### C：イベント経路

解析物理量 → 候補マスク → 短領域除外・近接結合 → 余白付き切出し → イベント特徴量 → 正常イベントモデル → イベントスコア → 回数・長さを含めたcase評価。

- 入力1件：イベント1つ。検出コア領域と余白付き入力範囲を別に保持。
- 検出条件、AND/ORの括弧、最短長、結合間隔、余白を設定化。
- 正常学習データからも同じ検出器でイベントを生成。正常イベントが不足したらモデル未学習とし、単なる検出結果だけ返す。
- 探索範囲、検出0件、入力不良による未探索を分ける。
- 異常スコア最大に加え、観測時間当たりイベント数等を出力。必要なら正常個体の回数分布を別途fitして頻度異常を扱う。
- イベント0件の扱いは経路定義で明記。原則no_eventsでスコアnull。検出0件が正常受入条件であると検証されている設定だけ正常とする。

### D：時間周波数パッチ経路

信号 → 時間周波数／物理量マップ → 座標を揃えた複数チャネル → パッチ切出し → fit済み変換 → パターンモデル → パッチ異常度 → case集約。

- 入力1件：設定された時間×周波数パッチ。元座標と有効性マスクを保存。
- 最初の比較用モデルはPCA再構成誤差等の軽量モデルとし、DLモデルへ交換可能な契約を作る。PCAもfitデータだけで学習。
- DL化は同じprepare／fit／score契約で追加。GPUやDLフレームワークを初期動作の必須条件にしない。
- パッチごとの振幅正規化は既定で行わず、fit集合由来の変換を使う。絶対レベルを消すvariantは明示する。
- 出力がパッチスコアのみなら局所化もパッチまで。誤差マップがあっても物理的な異常位置の真値とは扱わない。

## 6. 選択・物理量・由来の共通規約

- 時間の元位置は半開区間[start_sample,end_sample)。表示時刻だけで元位置を識別しない。
- STFT/RMS/平滑化の表示中心と計算支持範囲を区別。
- 周波数範囲、bin番号は解析artifactの軸定義とセットで保持。
- 周波数マスクは波形のサンプルマスクではない。波形化には明示的な再構成処理が必要。
- 物理量は推定方法、単位、方向、符号・絶対値、窓・平均化条件を保存。
- MSC等の統計的推定に必要な平均化を定義し、単一係数の演算で意味のない値を出さない。
- 各マップの格子が異なる場合の対応方法を明示。自動的な配列位置合わせを禁止。
- 要求した選択条件、格子に適用した条件、実際の採用maskを分離。
- マスク外を外乱と確定しない。物理量の閾値だけで音源帰属が保証される前提を置かない。
- 派生物はparent_refs、operation、config、software_versionを保持。合流では親参照を複数持つ。

## 7. IDの役割

| ID | 識別対象 |
|---|---|
| specimen_id | 物理的な個体 |
| case_id | 今回評価する測定一式 |
| measurement_id | 元測定 |
| run_id | 実験実行1回 |
| artifact_id | 保存された解析・モデル・設定・結果など |
| sample_id | 特定経路・処理条件で生成したML入力1件 |

IDは短い連番の見た目で意味を推定しない。処理内容が変わった入力は別sample_id。route_keyは人が指定する経路名＋variantであり、生成物IDとは別の設定キー。

sampleの再利用は入力内容・由来・処理条件が同一と検証できる場合のみ。データ内の各binへUUIDを付けずartifact_id＋座標で識別する。

## 8. 接続インターフェース（言語非依存の仕様）

RoutePluginは次を提供する。以下は擬似インターフェースであり、そのまま動くコードではない。

```text
capabilities() -> 必須ch、回転条件、入力仕様、対応版
prepare(measurements, config, context) -> PreparedSet
fit(prepared_fit, model_config, seed) -> ModelArtifact
score(model, prepared_set) -> SampleResults
aggregate(sample_results, case_coverage, policy) -> RouteCaseResults
calibrate(calibration_case_results, policy) -> ThresholdArtifact
decide(route_case_results, threshold) -> RouteCaseResultsWithDecision
```

PreparedSetは入力値＋sample_id＋由来台帳＋除外・無効レコードを持つ。バッチ内でIDを一緒に運び、結果との対応を検証する。fit済み変換器はModelArtifactに含める。

経路固有の前処理に学習が必要ならfit内へ置く。prepareでevalの統計を学習しない。

ResultCollectorはcollect(route_outputs)→検証→export(bundle_path)。EvaluationAdapterはimport_bundle(bundle_path)→receipt。初版の接続方式はローカルディレクトリの受渡し。ネットワークAPIを先に作らない。

接続先システムの現行仕様は未確認なので、本契約を実装目標とする。既存APIへ接続済みとは扱わない。

## 9. 出力ResultBundle v1

```text
run_<id>/
  manifest.json
  experiment.json
  dataset_split.json
  environment.json
  specimens.jsonl
  cases.jsonl
  measurements.jsonl
  artifacts.jsonl
  samples.jsonl
  sample_results.jsonl
  route_case_results.jsonl
  case_results.jsonl
  metrics.json
  errors.jsonl
  models/
  arrays/
  logs/
```

JSONはUTF-8、数値NaN/Infinityは禁止しnull＋reasonで表現。日時はUTC ISO8601。配列はNPZ等へ保存し、JSONには相対パス・キー・shape・dtype・ハッシュを記録。元測定の原本は既定で複製せず参照。別PCで元データが見つからない場合はsource_unavailableと明示し、path mappingで再接続する。

SampleResult必須列：run_id、route_key、case_id、sample_id、model_ref、status、anomaly_score、score_definition_ref、evidence_ref。スコアの大小方向は統一しても経路間で数値平均しない。

RouteCaseResult必須列：run_id、route_key、case_id、execution_status、coverage_status、decision、case_score、threshold_ref、aggregation_ref、n_created、n_scored、reason、evidence_refs。

decisionはwithin／outside／undetermined。execution_statusはcompleted／failed／skipped。coverage_statusはsufficient／insufficient／not_applicable。イベント0件等はreasonに記録。数値0と未評価nullを区別。

case_resultsは統合無効時も全caseについてundetermined、reason=fusion_disabledを出力。

metricsはラベルがあれば個体単位の混同行列、正常の誤判定数、異常の見逃し数と母数を出す。undeterminedは別カウントし、母数から黙って除外しない。ラベルなしでは分布・coverage・成功件数・所要時間のみ。異常ラベルがないデータで検出率を主張しない。

## 10. 原子的な完了・部分失敗・再開

stagingへ書込 → 参照・shape・件数・ハッシュの検証 → 完了manifestを最後に確定 → 受渡し可能。

manifestにはschema_version、run_id、全メンバーの相対パス・byte数・SHA256、requested_routes、completed_routes、bundle_statusを保存。bundle_statusはcomplete／partial。partialも読めるがUIは未完了経路を明示。途中書込のstagingは読まない。

一経路の失敗で他経路の評価結果を失わない。個々のsample失敗も台帳とerrorsへ残す。キャンセル時はcancelled状態を記録。評価システムへの受渡し失敗でもbundleは保持する。

同じrun_id・同じmanifestハッシュの再取込は冪等。同じrun_idで異なるハッシュは競合として拒否。

再開は元データ・設定・コード・モデル等の依存ハッシュが一致する完了段階だけ再利用。初版で複雑な再開が難しければ、新runとして全再実行し、壊れた中間物を使わない。

## 11. 実験設定の例

以下は設定形状の例。時間・回転数・閾値候補は試行値。物理量閾値は実測条件を確認して設定し、未設定のselectionは明示的に無効。

```json
{
  "schema_version": "1.0",
  "train_manifest": "inputs/train_manifest.json",
  "eval_manifest": "inputs/eval_manifest.json",
  "seed": 42,
  "split": {"group_by": "specimen_id", "calibration_fraction": 0.2},
  "routes": [
    {"key": "A_full", "plugin": "fixed_window", "enabled": true,
     "window_seconds": 1.0, "hop_seconds": 0.5,
     "selection": {"enabled": false}, "model": "isolation_forest"},
    {"key": "B_order", "plugin": "order_window", "enabled": true,
     "revolutions": 10, "hop_revolutions": 5,
     "model": "isolation_forest", "missing_required_input": "skip"},
    {"key": "C_event", "plugin": "event", "enabled": false,
     "reason": "event_detector_config_required"},
    {"key": "D_patch", "plugin": "tf_patch", "enabled": false,
     "reason": "patch_and_map_config_required"}
  ],
  "aggregation": {"method": "max_valid_sample_score"},
  "calibration": {"method": "empirical_case_quantile", "quantile": 0.95},
  "fusion": {"enabled": false},
  "export": {"format": "result_bundle_v1", "output_dir": "runs"}
}
```

有効な未実装pluginは設定エラー。回転不足によるskipとは別。C/Dの有効化は必須設定を満たした時だけ許可。未実装経路を実行成功と見せない。

## 12. 実行フロー

1. 設定の構文・版・必須項目を検証。
2. manifestと実データを検査し、caseと個体の対応を確定。
3. train/eval漏洩検査とfit/calibration分割を保存。
4. 各経路でcapability確認。対象外・失敗も結果行を作成。
5. fit入力生成→モデル学習→モデル保存。
6. calibration入力生成→スコア→case集約→閾値保存。
7. eval入力生成→スコア→case集約→判定。
8. 全経路出力を収集。任意のfusion、評価指標を計算。
9. bundle検証・完了確定。
10. 経路評価システムへimport。取込結果と未解決の原本参照を返す。

CLI案：nv-run validate --config experiment.json、nv-run execute --config experiment.json、nv-run inspect --bundle runs/run_x、nv-eval import --bundle runs/run_x。実装時に提供するコマンドであり現時点では未実装。

## 13. 経路評価用システム側の最小機能

- 実験一覧：実行状態、使用データ、設定、経路、失敗理由。
- 個体×経路の比較表：判定、スコア、閾値、coverage、処理時間。
- 経路詳細：入力結果一覧、点群、時間軸スコア。
- 点・行の選択：sample_idから元時間・周波数・運転条件・センサー位置へ移動。
- 選択マスクと計算支持範囲を重ねて表示。
- 原本がなくても結果表・保存済み入力は閲覧可能。原波形表示は参照解決が必要。
- 複数runの比較は個体/caseと測定構成を確認して行う。異なる経路スコアを共通尺度のように描かない。

## 14. 実装順序と受入条件

| 段階 | 作業 | 完了条件 |
|---|---|---|
| M0 | 標準データ・契約・bundle読込 | 合成fixtureで参照・型・ハッシュを検証 |
| M1 | A_fullの学習→評価→出力 | 二つの入力manifestだけで一連の処理が完走 |
| M2 | 評価画面の取込と逆引き | 個体→経路→入力→元範囲へ戻れる |
| M3 | A_selectedと複合条件 | マスク、空選択、特徴量由来を追跡 |
| M4 | B/C/Dを個別追加 | 成功・対象外・データ不足が同じ出口へ届く |
| M5 | 任意の統合判定 | 明示ルールと寄与根拠を保存 |

必須の意味ある試験：

1. 入力順をシャッフルしてもscoreとsample_idの対応が一致。
2. 一個体に短い異常を注入し、学習完走・結果出力・元範囲参照ができる。検出性能の保証とは分ける。
3. trainとevalで個体重複・元データ重複を拒否。
4. evalの値・ラベルを変更してもfit済みモデルと閾値が変わらない。
5. 回転信号なしでBがskipとなりAの結果は保存される。
6. 空選択・イベント0件・処理失敗が正常値0へ置換されない。
7. bundle破損・ハッシュ不一致・途中書込を拒否。
8. 同じrun再取込で行が重複しない。
9. 窓の重複を含む範囲を正しく元サンプルへ戻せる。
10. calibration不足時はスコア出力を維持し、判定未確定を明示。

## 15. コーディング開始時に確認する外部情報

構造設計は本書で着手可能。次の項目は実データ接続時に確認し、仮定で埋めない。

- 実測ファイル1例のキー・shape・dtype、サンプル周波数、ch対応。
- 校正状態、p/uの単位・向き・位置、同期方法。
- specimen_idと測定ファイル・caseの対応表。
- 回転パルス仕様、rpm時系列の有無。
- 経路評価用システムのリポジトリ、読込APIまたは新規構築の範囲。
- 正常個体数と測定条件の分布。calibrationを分けられるか。

これらが未入手でも、数値配列の合成fixtureでM0〜M2の基盤開発を進める。既存PoCを参照する場合も、既存の点群配列から追跡情報を復元できるとは仮定しない。

## 16. 実装担当者への指示

新しい独立ディレクトリで構築し、既存PoCを上書きしない。最初はCLI＋ファイル受渡しでM0/M1を完了し、接続先が未確定ならbundle検証・閲覧の最小readerを作る。接続済みとは報告しない。

初期依存候補はPython、NumPy、SciPy、scikit-learn。PySide6/Matplotlibは閲覧側。具体的な版・API・インストール可否は実装環境を確認して固定する。DLは任意依存として後付け可能にする。

ダミースコアで実モデルの学習・評価を代用しない。合成データ利用と実測データ利用を結果に明示する。納品時は動作範囲、未実装経路、受入試験結果、実測接続の残件を報告する。
