"""Independent C01 adapter tests; generated inputs live in tests/_work/D/<uuid>."""
import copy
from pathlib import Path
import subprocess
import sys
import unittest
import uuid
import numpy as np
from nv_runner.common import read_json, write_json, sha
from nv_runner.input_adapter import InputAdapter, DatasetPlanner
from nv_runner.input_candidate import ColumnInputAdapter
from nv_runner.signals import SignalService

ROOT = Path(__file__).resolve().parents[1]


def fixture():
    meta = copy.deepcopy(read_json(ROOT / "docs/parallel_contracts/fixtures.json")["record_minimal"]["metadata"])
    n, fs = 2048, 1024
    t = np.arange(n) / fs
    p = np.sqrt(2) * .2 * np.sin(2 * np.pi * 128 * t)
    return {"format": "nv_dummy_columns", "format_version": "1.0", "axes": ["sample"],
            "metadata": meta, "columns": {"time_seconds": t.tolist(), "pressure_pa": p.tolist(),
            "velocity_m_s": (p / (1.2 * 343)).tolist(), "rpm_rev_min": np.full(n, 1200.).tolist()},
            "truth": {"label": "normal", "seed": None, "note": "analytic deterministic fixture"}}


class InputCandidateTests(unittest.TestCase):
    def setUp(self):
        self.root = ROOT / "tests/_work/D" / uuid.uuid4().hex
        self.root.mkdir(parents=True)
        self.raw = fixture()

    def convert(self, raw=None, name="converted"):
        source = self.root / (name + ".json")
        write_json(source, self.raw if raw is None else raw)
        return ColumnInputAdapter().load(source, self.root / name)[0]

    def test_01_numeric_conversion_and_existing_reader(self):
        record = self.convert()
        np.testing.assert_array_equal(record.signals[:, 0], self.raw["columns"]["pressure_pa"])
        np.testing.assert_array_equal(record.signals[:, 1], self.raw["columns"]["velocity_m_s"])
        np.testing.assert_array_equal(record.rpm, self.raw["columns"]["rpm_rev_min"])
        same = InputAdapter().load(self.root / "converted/manifest.json")[0]
        self.assertEqual(record.meta, same.meta)
        self.assertEqual(record.meta["mapping"]["axes"], ["time", "channel"])

    def test_02_provenance_and_truth_are_separate(self):
        self.raw["metadata"]["truth"] = {"label": "fault"}
        record = self.convert()
        provenance = read_json(self.root / "converted/provenance.json")
        self.assertEqual(provenance["original_sha256"], sha(self.root / "converted.json"))
        self.assertEqual(provenance["canonical_sha256"], record.meta["source_sha256"])
        self.assertEqual(provenance["derived_group_id"], record.meta["derived_group_id"])
        self.assertNotIn("truth", record.meta)
        self.assertNotIn("truth", read_json(self.root / "converted/metadata.json"))
        old_hash = provenance["original_sha256"]
        self.raw["truth"] = {"label": "abnormal", "seed": 999}
        changed = self.convert(name="changed_truth")
        np.testing.assert_array_equal(changed.signals, record.signals)
        self.assertEqual(changed.meta["metadata_sha256"], record.meta["metadata_sha256"])
        self.assertNotEqual(old_hash, read_json(self.root / "changed_truth/provenance.json")["original_sha256"])

    def test_03_missing_rpm_is_explicit(self):
        del self.raw["columns"]["rpm_rev_min"]
        record = self.convert()
        self.assertIsNone(record.rpm)
        self.assertIsNone(record.meta["mapping"]["rpm"])

    def test_04_reject_versions_and_axes(self):
        for key, value in [("format_version", "2.0"), ("format", "unknown"), ("axes", ["channel", "time"])]:
            with self.subTest(key=key):
                raw = fixture()
                raw[key] = value
                with self.assertRaises(ValueError):
                    self.convert(raw, key)
        self.raw["metadata"]["schema_version"] = "99"
        with self.assertRaises(ValueError):
            self.convert()

    def test_05_reject_bad_pu_units_position_direction_pair(self):
        changes = [("unit", "mPa"), ("quantity", "pressure"), ("position_m", [1, 0, 0]),
                   ("direction", [2, 0, 0]), ("pair_id", "other")]
        for key, value in changes:
            with self.subTest(key=key):
                raw = fixture()
                raw["metadata"]["channels"][1][key] = value
                with self.assertRaises(ValueError):
                    self.convert(raw, key)

    def test_06_reject_columns(self):
        for value in [[0.], [[0., 1.]], ["0", "1"], [True, False]]:
            with self.subTest(value=value):
                raw = fixture()
                raw["columns"]["pressure_pa"] = value
                with self.assertRaises(ValueError):
                    self.convert(raw, uuid.uuid4().hex)
        raw = fixture()
        raw["columns"]["truth"] = [0] * 2048
        with self.assertRaises(ValueError):
            self.convert(raw)

    def test_07_reject_time_and_sync(self):
        mutations = [lambda r: r["columns"]["time_seconds"].__setitem__(10, .123),
                     lambda r: r["metadata"]["timebase"].update(sample_rate_hz=True),
                     lambda r: r["metadata"]["timebase"].update(sample_rate_hz=0),
                     lambda r: r["metadata"]["timebase"].update(signal_sync="unknown"),
                     lambda r: r["metadata"]["timebase"].update(rpm_sync="unknown")]
        for i, mutate in enumerate(mutations):
            with self.subTest(i=i):
                raw = fixture()
                mutate(raw)
                with self.assertRaises(ValueError):
                    self.convert(raw, str(i))

    def test_08_reject_missing_metadata_ids_calibration_and_validity(self):
        mutations = [lambda m: m.pop("operating_conditions"), lambda m: m.update(measurement_id="../bad"),
                     lambda m: m["calibration"].update(status="unknown"),
                     lambda m: m["calibration"].update(units=["Pa", "unknown"]),
                     lambda m: m.update(validity=[{"start_sample": 0, "end_sample": 2049, "reason": "bad"}])]
        for i, mutate in enumerate(mutations):
            with self.subTest(i=i):
                raw = fixture()
                mutate(raw["metadata"])
                with self.assertRaises((ValueError, KeyError)):
                    self.convert(raw, str(i))
                self.assertFalse((self.root / str(i)).exists())

    def test_09_source_is_unchanged_and_destination_cannot_be_overwritten(self):
        source = self.root / "raw.json"
        write_json(source, self.raw)
        before = sha(source)
        ColumnInputAdapter().convert(source, self.root / "out")
        self.assertEqual(sha(source), before)
        with self.assertRaises(FileExistsError):
            ColumnInputAdapter().convert(source, self.root / "out")

    def test_10_reject_nonfinite_json(self):
        source = self.root / "nan.json"
        source.write_text('{"invalid": NaN}', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "non-finite"):
            ColumnInputAdapter().convert(source, self.root / "out")

    def test_11_existing_signal_consumer_and_no_mutation(self):
        record = self.convert()
        before = record.signals.copy()
        maps = SignalService({"nfft": 128, "hop_samples": 32, "average_frames": 5}).maps(record)
        self.assertEqual(maps["msc"].shape, (61, 65))
        np.testing.assert_array_equal(record.signals, before)

    def test_12_ancestry_leakage_rejected_by_existing_planner(self):
        first = self.convert()
        self.raw["metadata"].update(specimen_id="s2", case_id="c2", measurement_id="m2")
        self.raw["columns"]["pressure_pa"][0] += .01
        second = self.convert(name="second")
        with self.assertRaisesRegex(ValueError, "derived_group_id"):
            DatasetPlanner().plan([first], [second], {"calibration_fraction": .2}, 42)

    def test_13_cli_separate_process(self):
        source = self.root / "source.json"
        write_json(source, self.raw)
        completed = subprocess.run([sys.executable, "-m", "nv_runner.input_candidate", str(source),
                                    str(self.root / "cli")], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(len(InputAdapter().load(self.root / "cli/manifest.json")), 1)


if __name__ == "__main__":
    unittest.main()
