# 契約テスト計画

本書は**案**。新規CT01〜CT08の実行/合格は未確認。既存32試験を置き換えず追加する。fixtures.jsonは契約の具体例であり、そのまま完全Bundleとして読ませるものではない。

## 1. fixtureの作成・共有

Q担当が将来 `tests/contract_fixtures.py` を作る。入力は本フォルダfixtures.json。標準ライブラリ＋既存NumPyで、各test専用 `tests/_work/<agent>/<uuid>` にNPZ/metadata/manifestを生成し、実ファイルからhashを計算する。手書きの偽hashでInputAdapter検査を回避しない。

- record_minimal：8点p/uとrpm、完全な登録meta。InputAdapterの最小境界用で、標準STFTには短すぎることも負例に使う。
- wave_recipe：2048点の解析平面波と同期rpm。SignalServiceの正常/ゼロ/軸反転の比較用。全経路の実学習fixtureの代用ではない。
- prepared_recipe：2sample、values1件、unscored1件。RoutePlugin.addで実IDを生成する。テストだけのstub scorerを使う場合は本番モデルではないと明示。
- feature_rows：3特徴×fit6件、eval2件。IF/PCAのshape/不変性用で、異常検出率のoracleにしない。
- decision_cases：閾値同値、超過、coverage不足、nullを含む期待判定。
- bundle_recipe：既存acoustic quickで作る**実Bundle**。保存後はreadonlyとして各consumerへ渡し、破損テストではコピーを使う。生成物をGitへ登録しない。
- receipt_recipe/run_recipe：取込・経路部分失敗の具体的変異。新規生成物だけで試験可能。

fixtureのshape/意味/期待値変更はCR。巨大な保存goldenを配布せず、seed/config/生成コードhashを共有して各checkoutで再生成する。異OSではjoblibのバイト一致を横断の一般条件にしない。

## 2. 契約ごとの試験案

|ID / 境界|producer→consumerの実接続|正例・期待|負例/境界・期待|既存試験の根拠と追加点|
|---|---|---|---|---|
|CT01 C01|fixture NPZ→InputAdapter→DatasetPlanner/route|shape[N,2]・Pa/m/s・rpm[N]/None、派生元を跨がないfit/cal、metaを保存|未知単位/版、非有限、非共置、軸長不正、hash不整合は拒否。同ID別波形再利用、consumerによる変更をsnapshotで検出|Acceptance05/06/12、AcousticPipeline14を再利用。immutability監視は追加|
|CT02 C02|wave→maps/diagnostics→A選択/D/保存配列|61×65、axis長、支持範囲、bin和の時間平均二乗一致、CpU符号、キー互換|ゼロpower valid全false、未知規約拒否、短すぎ入力拒否、cache同ID変更禁止、戻りmapをconsumerが書換えない|AcousticPhysics01〜13を再利用。consumer後のmap不変、全キーschema照合は追加|
|CT03 C03|担当plugin.prepare→fit/score→runner入力行|ID集合一致、schema幅一致、finite、sample2/values1、unscoredを残す、反転順/batch1と7でID対応後同値|重複ID、誤feature幅、欠落coverage、他測定の座標参照、非finite入力/scoreを検出。model無しはunscored|Acceptance03/08/15/17。現在readerが全異常を検知する保証はないので新しいCTでgapを報告|
|CT04 C04|NormalModel候補→RoutePlugin.score/save|IF/PCA実fit、score長/finite、fitのみScaler、同seed同入力の安定性、評価変更でmodel/threshold不変|不足入力の指定例外、列順/幅不一致を拒否。追加モデルmetadataがIF/PCA説明のままなら結合失敗|Acceptance01/04、AcousticPipeline15。新モデル記述とloaderは未実装で、loader試験は別CR|
|CT05 C05|aggregate/calibrate/decide→collector/metrics/view|fixturesの6case期待値。95% higher、overlap union、判定不可母数、単位/座標|nullを0/withinへ変換すると失敗。partial coverage超過はoutside可。同値と不足を区別。fusion多経路の全真理値|Acceptance07/08/11/14/16。多経路fusion全真理値は新規追加（既存16は単一経路のみ）|
|CT06 C06|runner→Collector→Reader→viewer|fresh quick complete、全refs/shape/hash整合、元データ不要でBundle配列から表示、任意truthなしでも表示|member改変/余分file/不正shape/不正model ref/unknown版/staging拒否。truth無しで再生成したBundleを使用し、完成Bundleのtruthだけ消さない|Acceptance02/09/17。原本到達不能・truthなし・任意診断なしのconsumer試験は追加|
|CT07 C07|BundleReader→候補adapter→receipt consumer|初回imported/再送already_imported、原本全hash一致で未解決0、入力Bundle不変|同ID別manifest競合、未解決原本を通知、不完全Bundle拒否。remote stubの失敗を成功に偽装しない|Acceptance10、tools/replay_saved_checks.py。remoteの相手受入は未実施|
|CT08 C08|candidate class→config検査→runner→保存|既存plugin互換設定で完走、登録表/必須parameter整合、truthは推論後|未知plugin/model/版を拒否、全経路同key拒否、run_recipeでA保持/他null/partial、truth変更でfit不変|Acceptance04/07/12、AcousticPipeline15。共通前処理/constructor/truth失敗は現行「全てpartial」保証外を明示|

## 3. 許容差と合格ゲート

- 入出力のID集合、単位、状態enum、参照、null規則、hashは厳密一致。新schemaを旧readerが黙って受理することを合格にしない。
- 数値は既存試験を基準とする。score順序/batch比較はrtol=atol=1e−12、Parsevalは既存rtol1e−14、Euler試験は既存rtol2e−7/atol1e−10など。新しい近似アルゴリズムの許容差はCTを勝手に緩めず、精度根拠をCRで提示。
- 物理検証と検出性能を分離。IF/PCAが学習できたことと正解を全検出したことは別。契約試験の合格にTP100%は要求しない。
- feature_schema変更は変更前後の値一致で判定せず、shape/名前/単位/score定義と新しい同条件再現性を確認する。変更を隠して旧モデルを流用しない。
- 固定seedの合成生成で境界を再現し、独立個体性能の統計評価は別タスクとする。

## 4. 実行順序とコマンド

**以下でcontractファイルを指定するコマンドは、Qが新規CTを実装した後だけ有効。現時点ではファイル未作成。**

```text
python -m unittest discover -s tests -p test_contract_c01.py -v
python -m unittest discover -s tests -p 'test_contract_c*.py' -v
python -m unittest discover -s tests -p test_acceptance.py -v
python -m unittest discover -s tests -p test_acoustics.py -v
python -m nv_runner.verify_physics --output reports/parallel_physics
python -m nv_runner demo --generator acoustic --profile quick --output demos/parallel_quick_<unique>
python -m nv_runner demo --generator acoustic --profile comparison --output demos/parallel_comparison_<unique>
```

契約テスト0件を成功としない。test runnerの件数とCT01〜08の存在を確認する。新規candidate単体はtests/test_<担当>_candidate.pyで実行し、未登録のままclass直接呼出しを使う。観測adapter↔route、route↔model、runner↔reader、reader↔viewer/outputの両側結合まで行う。

## 5. 成果物・不足の扱い

各担当はコード/config/fixture recipe/hash、コマンド、依存環境、試験IDと件数、成功/失敗/未実施、生成Bundle manifest SHA、未解決CRを小さいレポートに残す。データ/model/HTML/logは担当専用生成領域へ保存、Gitへは登録しない。

既存の検証要件書 `../CLAUDE_CODE_VALIDATION_REQUIREMENTS.md` が詳細な再実行根拠。今回の計画では既存試験を実行し直していない。API破綻を示すCTが追加された場合、原因が既存gapならIが小さな修正CRへ切り出し、依存しない担当は開発継続する。
