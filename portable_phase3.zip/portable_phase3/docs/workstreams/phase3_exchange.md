# Phase 3 Agent T：独立プラグインと設定交換の試験

## 専有範囲と実装

- `tests/test_plugin_exchange.py`：交換・登録・実行前拒否・無効化・削除を検証。
- `tests/phase3_fixture_plugin.py`：既存FixedWindow数値処理を再利用する、テスト専用の独立entrypoint。偽スコアや正解ラベルは使わない。
- `configs/parallel/plugin_exchange_legacy.json` と `plugin_exchange_candidate.json`：実験設定の `routes` 要素に入れる経路設定断片。完全な実験設定ではない。
- 本書、`reports/phase3/T/`、一時出力 `tests/_work/P3T/<uuid>/`。

本番共有コード・既存97試験・共通契約はT担当では編集しない。P/Vが登録と宣言検証を実装し、Iが既存Runnerを接続する。

## 試験と判定根拠

1. 上記二つの設定断片だけでfixed_window / fixed_window_candidateを選択。同じ元測定・半開sample範囲でfeature_schema、単位、支持範囲、表示位置、状態・理由を比較する。特徴値は既存候補試験と同じ `rtol=atol=1e-12`。plugin名が変わるためsample IDは異なってよい。Isolation ForestはID順による訓練行順が変わるので、異なるplugin ID間で異常スコアの厳密一致は要求しない。
2. `PluginDescriptor`を信頼済みPythonコードから登録し、変更していないRunnerのvalidate_config / executeを通す。正常fit、calibration、evaluationを実モデルで完走し、Bundle 1.0 Readerが受理し、全入力にfiniteスコアがあることを要求。実行直前・直後のrunner/routes/registry/validatorのSHAを比較する。
3. 拡張専用の `template_tag` schema不一致は出力ディレクトリ作成前に拒否。
4. API版・Descriptor版・入力契約・出力契約・モデル契約の不一致を登録時または実行前検証で拒否。
5. 選択したentrypointの依存module欠落を出力ディレクトリ作成前に拒否。
6. 拡張登録を削除しても、独立した既存構成の検証は通り、削除済みpluginの選択は拒否。
7. 新規Pythonプロセスで候補と欠落moduleへのimportを禁止。登録済みだが無効な拡張と未選択candidateを読み込まず、既定5経路を完走する。

既存 `test_parallel_integration.py` は選択candidate入りの実CLI・学習・閲覧も継続検証する。本試験はそれを変更せず、汎用登録の検証を追加する。

## 生成・実行・再開

PoCルートで実行：

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -p test_plugin_exchange.py -v
```

入力は `acoustic_settings('quick')`、正常学習6個体、3秒、標準seed=42、fs=1024 Hz、評価7シナリオの再生成。ほかは現行quick設定。IFは16本、fit-only StandardScaler、通常の個体分割・calibration閾値設定を使う。候補の比較は観測評価データを使い、truthを入力へ渡さない。

各実行は新しいUUID出力先を使用し、他担当・過去実行のデータを再利用しない。登録は各試験のtearDownで解除する。中断時も新プロセスで同じコマンドを実行できる。過去Bundleを移送する必要はない。

`central_unchanged_evidence.json` に比較した共有ファイルSHA・完成Bundleパス・入力スコア件数を保存する。Bundleにはモデル、特徴配列、分割、閾値、元波形、結果、実行環境が保存される。テストログの保存先は `reports/phase3/T/`。

## 制約

テスト専用entrypointを通常CLIで使うには、信頼済み起動コードがそのmoduleをimport可能な環境で明示登録する必要がある。任意configのmodule名を動的実行する機能は追加しない。外部接続・実測での性能評価・新モデル種別の統合は本担当の対象外。

## 実行結果（2026-10-15 JST）

Iの接続後に上記コマンドを実行し、**7試験すべて成功、12.669秒**。
ログ：`reports/phase3/T/exchange_tests.log`。新規登録だけでの実モデル学習・閾値設定・評価・Bundle読込と、共有4ファイルSHA不変を確認した。全97試験との回帰・baseline CLI一致はI担当で別途実施する。
