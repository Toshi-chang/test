"""Package only source/configs/reports; no generated measurements or models."""
from pathlib import Path
import hashlib,json,zipfile

ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    files=[]
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if any(part in {'outputs','_work','__pycache__','.venv'} for part in rel.parts):continue
        if not p.is_file() or p.suffix=='.zip' or p.name=='source_manifest.json':continue
        files.append({'path':rel.as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
    manifest=ROOT/'reports/source_manifest.json'
    manifest.write_text(json.dumps({'schema_version':'1.0','files':files},ensure_ascii=False,indent=2),encoding='utf-8')
    target=ROOT.parent/'distributed_acoustics_poc_source.zip'
    if target.exists():raise ValueError('Archive exists; choose a new release filename')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for f in files:z.write(ROOT/f['path'],'distributed_acoustics_poc/'+f['path'])
        z.write(manifest,'distributed_acoustics_poc/reports/source_manifest.json')
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:raise ValueError('archive CRC failure')
        for f in files:
            if hashlib.sha256(z.read('distributed_acoustics_poc/'+f['path'])).hexdigest()!=f['sha256']:raise ValueError('archive content mismatch')
    print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'files':len(files),'sha256':sha(target)}))
if __name__=='__main__':main()
