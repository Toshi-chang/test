"""Read-only saved Bundle evidence. Feature deviations are NOT model attribution."""
import bootstrap_lab
from pathlib import Path
import argparse,collections
import numpy as np
from bridge.adapter import read,write
from nv_runner.bundle import BundleReader

def diagnose(bundle,output):
    reader=BundleReader(bundle).validate();root=reader.path;tables=reader.tables
    samples={s['sample_id']:s for s in tables['samples']};scores={s['sample_id']:s for s in tables['sample_results']}
    artifacts={a['artifact_id']:a for a in tables['artifacts']};measurements={m['measurement_id']:m for m in tables['measurements']}
    labels={c['case_id']:c for c in read(root/'truth.json')['cases']};arrays={};fit_reference={}
    def features(s):
        a=artifacts[s['input_ref']];key=a['array_file']['path']
        if key not in arrays:
            with np.load(root/key,allow_pickle=False) as data:arrays[key]=data['features'].copy()
        return arrays[key][s['input_row']],a['feature_schema']
    for key in reader.manifest['completed_routes']:
        ss=[s for s in samples.values() if s['route_key']==key and s['split']=='fit' and s.get('input_ref')]
        if ss:
            x=np.array([features(s)[0] for s in ss]);fit_reference[key]=(x.mean(axis=0),x.std(axis=0))
    evidence=[]
    for row in tables['route_case_results']:
        key=row['route_key'];label=labels.get(row['case_id'],{});threshold=read(root/'models'/f'{key}_threshold.json')['value']
        ss=[s for s in samples.values() if s['case_id']==row['case_id'] and s['route_key']==key and s['split']=='evaluation' and scores[s['sample_id']]['anomaly_score'] is not None]
        ss.sort(key=lambda s:(-scores[s['sample_id']]['anomaly_score'],s['sample_id']))
        maxima={};receiver_counts=collections.Counter();receiver_above=collections.Counter()
        for s in ss:
            r=measurements[s['measurement_id']]['operating_conditions'].get('receiver_id','unknown');score=scores[s['sample_id']]['anomaly_score']
            maxima[r]=max(maxima.get(r,-float('inf')),score);receiver_counts[r]+=1
            if threshold is not None and score>threshold:receiver_above[r]+=1
        top=[]
        for s in ss[:3]:
            m=measurements[s['measurement_id']];x,schema=features(s);mean,std=fit_reference[key]
            z=(x-mean)/np.where(std>0,std,1);ix=np.argsort(-abs(z),kind='stable')[:5]
            overlaps=[r.get('source_id',r.get('kind')) for r in label.get('normal_events',[]) if r['measurement_id']==s['measurement_id'] and r['start_sample']<s['end_sample'] and r['end_sample']>s['start_sample']]
            top.append({'sample_id':s['sample_id'],'measurement_id':s['measurement_id'],'receiver':m['operating_conditions'].get('receiver_id'),
                'mode':m['operating_conditions']['mode'],'sample_range':[s['start_sample'],s['end_sample']],
                'time_seconds':[s['start_sample']/m['timebase']['sample_rate_hz'],s['end_sample']/m['timebase']['sample_rate_hz']],
                'frequency_hz':s['frequency_hz'],'position_m':m['channels'][0]['position_m'],'score':scores[s['sample_id']]['anomaly_score'],
                'normal_event_overlap':overlaps,'feature_deviations':[{'feature':schema[i][0],'unit':schema[i][1],'value':float(x[i]),
                    'fit_mean':float(mean[i]),'fit_std':float(std[i]),'z':float(z[i])} for i in ix]})
        evidence.append({'route':key,'case_id':row['case_id'],'specimen_id':row['specimen_id'],'scenario':label.get('scenario'),
            'family':label.get('independent_family_id'),'label':label.get('label'),'decision':row['decision'],'coverage':row['coverage_status'],
            'score':row['case_score'],'threshold':threshold,'margin':row['case_score']-threshold if row['case_score'] is not None and threshold is not None else None,
            'n_inputs':len(ss),'receiver_max_scores':maxima,'receiver_input_counts':dict(receiver_counts),'receiver_above_threshold_counts':dict(receiver_above),
            'top_inputs':top,
            'leave_one_receiver_out_max':{r:max((v for rr,v in maxima.items() if rr!=r),default=None) for r in maxima}})
    report={'schema_version':'factorial-evidence/1.0','bundle':str(root),'cases':evidence,
            'caution':'Feature z-scores describe fit-distribution deviations, not causal importance or IsolationForest attribution. Dropped-receiver maxima use original threshold and are diagnostic only.'}
    write(output,report);return report

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--bundle',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    diagnose(a.bundle,a.output)
