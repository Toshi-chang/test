'use strict';
// All computation and persisted reports stay on the local server.
const comparisonPanel=document.createElement('section');
comparisonPanel.id='comparison';comparisonPanel.className='panel';
comparisonPanel.innerHTML=`
<div class="card"><h2>04 実験比較</h2><p class="muted">条件をまとめて実行し、同じ評価データで入力・RPM正規化・学習条件を比較します。評価データの正解ラベルは学習・閾値設定に使用しません。</p>
<div class="toolbar"><label>実行方法<select id="cmp-mode"><option value="fixed">固定モデル：学習後、全評価データへ適用</option><option value="retrain">学習比較：学習データごとに学習し、共通評価</option><option value="existing">既存モデル：保存済みの重み・閾値で評価</option></select></label><button id="cmp-refresh">データ一覧を更新</button></div>
<div class="comparison-grid"><label id="cmp-train-wrap">学習データ（固定モデルは1件）<select id="cmp-trains" multiple size="7"></select></label><label id="cmp-model-wrap" hidden>保存済みモデル<select id="cmp-model"></select></label><label>評価データ（複数選択可）<select id="cmp-tests" multiple size="7"></select></label></div>
<div class="toolbar"><span class="muted">Ctrl / Shiftで複数選択</span><span class="spacer"></span><button id="cmp-suite">60 dB評価セットを全選択</button><button id="cmp-clear">評価選択を解除</button></div>
<div id="cmp-learning"><div id="cmp-variants" class="toolbar"><label class="checkbox"><input type="checkbox" value="p">p</label><label class="checkbox"><input type="checkbox" value="u">u</label><label class="checkbox"><input type="checkbox" value="pu" checked>p＋u</label><label class="checkbox"><input type="checkbox" value="pu_rpm_std" checked>p＋u＋RPM：標準偏差</label><label class="checkbox"><input type="checkbox" value="pu_rpm_fixed" checked>p＋u＋RPM：固定幅</label></div>
<div class="toolbar"><label>最大エポック数<input type="number" id="cmp-epochs" value="80" min="1" max="500"></label><label>RPM正規化の固定幅 [RPM]<input type="number" id="cmp-scale" value="10000" min="1"></label></div><p class="muted">RPMは学習平均を引き、標準偏差（下限1 RPM）または固定幅で割ります。固定幅10000では5 RPMの雑音は0.0005になります。音響入力の正規化は共通です。既存モデルには保存された係数を使います。</p></div>
<div class="toolbar"><button id="cmp-plan">実行予定を確認</button><button id="cmp-start" class="primary job-start">この条件で一括実行</button></div><p id="cmp-proposal" role="status">先に実行予定を確認してください。</p>
<p class="muted">実行は順次処理です。下部の「処理を停止」で中断でき、保存済み実験から未完了分を再開できます。中断した学習1件は先頭エポックから再実行します。</p></div>
<div class="card"><h2>実験履歴と進捗</h2><div class="toolbar"><label class="wide">保存済み比較<select id="cmp-history"></select></label><button id="cmp-resume" class="job-start">未完了・失敗分を再実行</button></div><p id="cmp-progress" role="status"></p><div id="cmp-task-errors"></div><div id="cmp-links" class="download-row"></div></div>
<div class="card"><h2>条件別の結果</h2><p class="muted">①外乱の発報は機械故障の検出成功とは区別します。同じ評価データの行で比較してください。各割合は独立収録単位、括弧内は95% Wilson区間です。行を選ぶとスコアを重ねて表示します（最大4行）。</p><label>評価データで絞り込み<select id="cmp-filter"></select></label><details><summary>絞り込んだ評価データの生成設定</summary><pre id="cmp-conditions" class="comparison-config"></pre></details><div id="cmp-table" class="comparison-table"></div></div>
<div class="plot-card"><h3>選択した評価結果の異常スコア</h3><p>横軸は条件ごとにまとめた収録順、縦軸はスコア÷各モデルの閾値。1を超えると発報。モデルが異なる場合の比較は閾値に対する比率です。</p><div id="cmp-legend" class="result-legend"></div><canvas id="cmp-chart"></canvas></div>`;
$('guide').before(comparisonPanel);
const comparisonTab=document.createElement('button');comparisonTab.className='tab';comparisonTab.dataset.tab='comparison';comparisonTab.textContent='04　実験比較';comparisonTab.onclick=()=>{tab('comparison');refreshComparisons().catch(showError);};
document.querySelector('[data-tab="guide"]').before(comparisonTab);
let comparisonDetail=null,comparisonApproved=null,comparisonCurves=[];
const comparisonLabels={p:'p',u:'u',pu:'p＋u',pu_rpm_std:'p＋u＋RPM / 標準偏差',pu_rpm_fixed:'p＋u＋RPM / 固定幅'};
const selectedValues=id=>Array.from($(id).selectedOptions,o=>o.value);
function comparisonRequest(){return {mode:$('cmp-mode').value,training_datasets:selectedValues('cmp-trains'),datasets:selectedValues('cmp-tests'),variants:Array.from(document.querySelectorAll('#cmp-variants input:checked'),x=>x.value),epochs:Number($('cmp-epochs').value),rpm_fixed_scale:Number($('cmp-scale').value),model:$('cmp-model').value};}
async function refreshComparisonInputs(){
 const [datasetsResult,history]=await Promise.all([api('datasets'),api('history')]);
 for(const id of ['cmp-trains','cmp-tests']){const previous=selectedValues(id);$(id).replaceChildren();for(const path of datasetsResult.datasets){const option=new Option(path,path);option.selected=previous.includes(path);$(id).add(option);}if(!previous.length){const base=Array.from($(id).options).find(o=>o.value.includes('/A_seed_1/'));if(base)base.selected=true;}}
 const previous=$('cmp-model').value;$('cmp-model').replaceChildren();for(const r of history.runs)if(!r.folder.startsWith('legacy/'))$('cmp-model').add(new Option(`${r.folder} (${r.channels})`,r.folder+'/model_weights.npz'));if(Array.from($('cmp-model').options).some(o=>o.value===previous))$('cmp-model').value=previous;
 comparisonApproved=null;
}
$('cmp-refresh').onclick=()=>refreshComparisonInputs().catch(showError);
$('cmp-mode').onchange=()=>{const existing=$('cmp-mode').value==='existing';$('cmp-learning').hidden=existing;$('cmp-train-wrap').hidden=existing;$('cmp-model-wrap').hidden=!existing;};
$('cmp-suite').onclick=()=>{for(const o of $('cmp-tests').options)o.selected=o.value.startsWith('evaluation_60dB/');comparisonApproved=null;};
$('cmp-clear').onclick=()=>{for(const o of $('cmp-tests').options)o.selected=false;comparisonApproved=null;};
$('cmp-plan').onclick=async()=>{try{clearError();const data=comparisonRequest();const p=await api('comparison-plan',data);comparisonApproved=JSON.stringify(data);$('cmp-proposal').textContent=`学習 ${p.training_count}件 ＋ 評価 ${p.evaluation_count}件 ＝ ${p.tasks.length}処理。最大${p.epochs}エポック、モデルごとに閾値を固定して評価。計算量は窓数・窓長にも依存します。`;}catch(e){comparisonApproved=null;showError(e);}};
$('cmp-start').onclick=async()=>{try{clearError();const data=comparisonRequest();if(JSON.stringify(data)!==comparisonApproved)throw Error('現在の条件で「実行予定を確認」を押してください。');await api('comparison-start',data);await refreshComparisons(true);}catch(e){showError(e);}};
$('cmp-resume').onclick=async()=>{try{clearError();if(!$('cmp-history').value)throw Error('保存済み比較を選択してください');await api('comparison-resume',{folder:$('cmp-history').value});}catch(e){showError(e);}};
$('cmp-history').onchange=()=>loadComparison().catch(showError);
async function refreshComparisons(newest=false){
 const {comparisons}=await api('comparisons');const previous=$('cmp-history').value;$('cmp-history').replaceChildren();for(const c of comparisons)$('cmp-history').add(new Option(`${c.name||c.folder} / ${c.status}`,c.folder));if(!newest&&comparisons.some(c=>c.folder===previous))$('cmp-history').value=previous;await loadComparison();
}
async function loadComparison(){
 const folder=$('cmp-history').value;if(!folder)return;const d=await api('comparison-detail',{folder});
 if($('cmp-history').value!==folder)return;
 const changed=JSON.stringify(d.summary.rows)!==JSON.stringify(comparisonDetail?.summary.rows)||d.folder!==comparisonDetail?.folder;
 comparisonDetail=d;const counts={};for(const t of d.state.tasks)counts[t.status]=(counts[t.status]||0)+1;
 const recovered='';
 $('cmp-progress').textContent=`${d.state.status} / 完了 ${counts.complete||0} / 全 ${d.state.tasks.length} / 実行中 ${counts.running||0} / 未実行 ${counts.pending||0} / 失敗 ${counts.failed||0} / 学習待ち ${counts.blocked||0} ${recovered}`;
 $('cmp-task-errors').replaceChildren();for(const t of d.state.tasks.filter(t=>t.error)){const p=document.createElement('p');p.textContent=`${t.id}: ${t.error}`;$('cmp-task-errors').append(p);}
 $('cmp-links').replaceChildren();link($('cmp-links'),folder+'/plan.json','実行設定JSON');link($('cmp-links'),folder+'/state.json','進捗JSON');if(d.summary.tasks){for(const [file,label] of [['summary.json','集計JSON'],['report.md','確認レポート Markdown']])link($('cmp-links'),folder+'/'+file,label);if(d.summary.rows.length)link($('cmp-links'),folder+'/summary.csv','集計CSV');}
 if(changed){const previous=$('cmp-filter').value;$('cmp-filter').replaceChildren(new Option('すべて',''));for(const dataset of [...new Set(d.summary.rows.map(r=>r.dataset))])$('cmp-filter').add(new Option(dataset,dataset));if(Array.from($('cmp-filter').options).some(o=>o.value===previous))$('cmp-filter').value=previous;renderComparisonTable();}
}
function renderComparisonTable(){
 $('cmp-conditions').textContent=$('cmp-filter').value?JSON.stringify(comparisonDetail?.plan.metadata[$('cmp-filter').value]?.config??'生成設定がありません',null,2):'評価データを絞り込むと生成設定を表示します。';
 comparisonCurves=[];drawComparisonCurves();const rows=(comparisonDetail?.summary.rows||[]).filter(r=>!$('cmp-filter').value||r.dataset===$('cmp-filter').value);
 const table=document.createElement('table');table.innerHTML='<thead><tr><th>重ねる</th><th>入力 / 学習データ</th><th>評価データ</th><th>⓪正常誤検知</th><th>①外乱発報</th><th>②異音検出</th><th>③外乱＋異音</th><th>学習 / 評価秒</th><th>最良epoch / RPM幅</th></tr></thead>';
 for(const row of rows){const tr=document.createElement('tr');const td=document.createElement('td');const check=document.createElement('input');check.type='checkbox';check.setAttribute('aria-label',row.id+' のスコアを表示');td.append(check);tr.append(td);
 check.onchange=async()=>{try{if(!check.checked){comparisonCurves=comparisonCurves.filter(r=>r.id!==row.id);drawComparisonCurves();return;}if(comparisonCurves.length>=4){check.checked=false;throw Error('スコアの重ね表示は4行までです');}const folder=comparisonDetail.folder;const result=await api('comparison-records',{folder,task:row.id});if(!check.isConnected||!check.checked||comparisonDetail.folder!==folder)return;if(comparisonCurves.length>=4){check.checked=false;return;}comparisonCurves.push(result);drawComparisonCurves();}catch(e){check.checked=false;showError(e);}};
 const rate=k=>row[`class${k}_rate`]==null?'—':`${(100*row[`class${k}_rate`]).toFixed(1)}% (${(100*row[`class${k}_low`]).toFixed(1)}–${(100*row[`class${k}_high`]).toFixed(1)}) / ${row[`class${k}_flagged`]}/${row[`class${k}_records`]}`;
 for(const text of [`${comparisonLabels[row.variant]||row.variant} / ${row.training_dataset||'保存モデル'}`,row.dataset,...[0,1,2,3].map(rate),`${row.training_seconds?.toFixed(1)??'—'} / ${row.seconds.toFixed(1)}`,`${row.best_epoch??'—'} / ${row.rpm_scale??'—'}`]){const cell=document.createElement('td');cell.textContent=text;tr.append(cell);}table.append(tr);
 }$('cmp-table').replaceChildren(table);
}
$('cmp-filter').onchange=renderComparisonTable;
function drawComparisonCurves(){
 $('cmp-legend').replaceChildren();const series=comparisonCurves.map((r,i)=>{const color=colors[i];const label=document.createElement('span');label.style.color=color;label.textContent=`● ${r.id} ${comparisonLabels[r.variant]||r.variant} / ${r.dataset}`;$('cmp-legend').append(label);const records=[...r.records].sort((a,b)=>a.label-b.label||a.id-b.id);return {x:records.map((a,j)=>j),y:records.map(a=>a.ratio),color};});
 if(series.length)chart($('cmp-chart'),series,{scatter:true,logy:true,baseline:1,xlabel:'Recording order (class 0 / 1 / 2 / 3)',ylabel:'Score / threshold'});else{const c=$('cmp-chart');c.getContext('2d').clearRect(0,0,c.width,c.height);}
}
window.addEventListener('resize',drawComparisonCurves);
new MutationObserver(()=>{if(comparisonPanel.classList.contains('active'))requestAnimationFrame(drawComparisonCurves);}).observe(comparisonPanel,{attributes:true,attributeFilter:['class']});
async function comparisonPoll(){try{if(comparisonPanel.classList.contains('active'))await refreshComparisons();}catch(e){showError(e);}setTimeout(comparisonPoll,3000);}
refreshComparisonInputs().then(()=>refreshComparisons()).catch(showError);comparisonPoll();
