import copy
import unittest
import numpy as np
from contract_fixtures import SPEC, record, pipeline
from nv_runner.signals import SignalService, select_mask, mean_square_spectrum, pu_diagnostics
from nv_runner.routes import FixedWindow
from nv_runner.runner import validate_config
from nv_runner.common import write_json

class C02(unittest.TestCase):
    def test_maps_and_consumer_do_not_mutate(self):
        r = record(True); original = r.signals.copy()
        service = SignalService(SPEC['wave_recipe']['signal'])
        maps = service.maps(r)
        self.assertEqual(maps['msc'].shape, (61,65))
        for key in ('p_power','u_power','intensity','reactive_intensity','phase','valid','p_log_power','u_log_power'):
            self.assertEqual(maps[key].shape, (61,65))
        self.assertEqual(len(maps['frequency_hz']),65)
        self.assertTrue(np.all(maps['support_start']<=maps['frame_start']))
        self.assertTrue(np.all(maps['support_end']>=maps['frame_end']))
        before = {k:v.copy() for k,v in maps.items()}
        rc = {'key':'A_selected','plugin':'fixed_window','window_seconds':1,'hop_seconds':.5,
              'selection':{'enabled':True,'condition':{'field':'msc','comparison':'>=','value':.65}}}
        FixedWindow(rc).prepare([r],service)
        for k in before: np.testing.assert_array_equal(before[k],maps[k])
        np.testing.assert_array_equal(original,r.signals)
        self.assertIs(service.maps(r),maps)  # ID-only cache: caller must not reuse ID for new data.

    def test_power_phase_and_zero(self):
        r = record(True)
        p = r.signals[:128,0]; w = np.hanning(128)
        np.testing.assert_allclose(mean_square_spectrum(p).sum(),np.sum((p*w)**2)/np.sum(w*w),rtol=1e-14)
        maps = SignalService(SPEC['wave_recipe']['signal']).maps(r)
        self.assertGreater(maps['intensity'][10,16],0)
        self.assertAlmostEqual(maps['phase'][10,16],0,places=12)
        r.signals[:] = 0
        self.assertFalse(SignalService(SPEC['wave_recipe']['signal']).maps(r)['valid'].any())
        with self.assertRaises(ValueError):
            SignalService(SPEC['wave_recipe']['signal']).maps(record())

    def test_unknown_convention_rejected_at_config_boundary(self):
        root,cfg,_ = pipeline(); cfg = copy.deepcopy(cfg)
        cfg['signal']['spectral_convention']='unknown'
        path=root/'bad_spectral.json'; write_json(path,cfg)
        with self.assertRaisesRegex(ValueError,'spectral'):
            validate_config(path)
