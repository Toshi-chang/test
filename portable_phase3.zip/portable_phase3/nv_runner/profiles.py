"""Editable starting configurations; all numeric choices are PoC trial settings."""
def settings(profile):
    return {"seed": 42, "train_specimens": 12 if profile == "quick" else 40, "eval_repeats": 1 if profile == "quick" else 4,
            "measurements_per_specimen": 2, "sample_rate_hz": 1024, "duration_seconds": 4 if profile == "quick" else 6}


def experiment(data_dir, output_dir, only_a=False):
    forest = {"kind": "isolation_forest", "n_estimators": 64, "min_samples": 3}
    routes = [{"key": "A_full", "plugin": "fixed_window", "enabled": True, "window_seconds": 1, "hop_seconds": .5,
               "selection": {"enabled": False}, "model": forest},
              {"key": "A_selected", "plugin": "fixed_window", "enabled": True, "window_seconds": 1, "hop_seconds": .5,
               "selection": {"enabled": True, "condition": {"op": "and", "children": [
                   {"field": "msc", "comparison": ">=", "value": .65},
                   {"field": "intensity", "comparison": ">", "value": 1e-9},
                   {"op": "or", "children": [{"field": "frequency_hz", "comparison": "<=", "value": 140},
                                                 {"field": "frequency_hz", "comparison": ">=", "value": 160}]}]}}, "model": forest}]
    if not only_a:
        routes += [
            {"key": "B_order", "plugin": "order_window", "enabled": True, "revolutions": 10, "hop_revolutions": 5,
             "samples_per_revolution": 64, "max_order": 8, "model": forest},
            {"key": "C_event", "plugin": "event", "enabled": True, "highpass_hz": 250, "envelope_seconds": .02,
             "threshold_pa": .10, "min_seconds": .02, "merge_seconds": .04, "margin_seconds": .06, "model": forest},
            {"key": "D_patch", "plugin": "tf_patch", "enabled": True, "frequency_bins": 16, "time_frames": 8,
             "hop_bins": 8, "hop_frames": 4, "model": {"kind": "pca", "components": 4, "min_samples": 5}}]
    return {"schema_version": "1.0", "seed": 42, "train_manifest": data_dir+"/train_manifest.json",
        "eval_manifest": data_dir+"/eval_manifest.json", "truth_path": data_dir+"/truth.json", "batch_size": 128,
        "split": {"group_by": "specimen_id", "calibration_fraction": .2, "min_fit_groups": 3, "min_calibration_groups": 2},
        "signal": {"nfft": 128, "hop_samples": 32, "average_frames": 5}, "routes": routes,
        "aggregation": {"method": "max_valid_sample_score"}, "calibration": {"quantile": .95, "min_specimens": 2},
        "fusion": {"enabled": False, "rule": "any_outside_all_within"},
        "export": {"format": "result_bundle_v1", "output_dir": output_dir}}


def acoustic_experiment(data_dir, output_dir):
    config = experiment(data_dir,output_dir)
    config["signal"].update(spectral_convention="mean_square_bin_v2",relative_power_floor=1e-8)
    config["routes"][1]["selection"]["condition"] = {"op":"and","children":[
        {"field":"msc","comparison":">=","value":.65},
        {"field":"frequency_hz","comparison":">=","value":10},
        {"op":"or","children":[{"field":"intensity","comparison":">","value":1e-10},
                                    {"field":"reactive_intensity","comparison":">","value":1e-10}]}]}
    config["routes"][3]["threshold_pa"] = .025
    config["physical_assumptions"] = {"generator":"acoustic_1.0","u_axis":"outward radial target axis",
        "selection":"positive axial active OR reactive intensity plus MSC; trial settings, not source attribution",
        "threshold_tuning":"predeclared for all scenarios; no eval-label tuning"}
    return config
