# M: model

正式な担当指示は ../parallel_contracts/AGENT_TASKS.md を参照。

専用編集範囲:

- `nv_runner/model_candidate.py`
- `tests/test_model_candidate.py`
- `configs/parallel/model_*.json`
- `docs/workstreams/model.md`

## Agent C 実装済み（2026-10-15 JST）

`CandidateNormalModel.fit(values, config, seed) -> self / score(values) -> float[N] / save(path)` を独立実装。
本体は既存 `models.py` と他担当候補をimportしない。依存は既設のNumPy、scikit-learn、joblib、threadpoolctl、標準ライブラリのみ。
IF（負のscore_samples）とPCA（標準化空間の再構成二乗誤差）を実学習する。StandardScalerはfitのみに適合し、評価中の更新・閾値変更はしない。
科学的アルゴリズムは比較可能な既存方式を使用。独立した入力検証、意味schema検証、失敗時に学習状態を維持する生命周期を専用モジュールで所有する。

任意の候補内 `FeatureBatch(values, feature_schema, processing, schema_version='1.0')` を用意。
列名・順序・単位・処理条件のcanonical JSONを保存しSHA256を記録、score時は完全一致検査する。
未対応schema版、幅、重複列名、不正な数値や設定、異なるschemaを拒否する。typed学習後の裸配列への後退も拒否。
既存C04の裸ndarrayはそのまま使用可能。ただし裸配列の列順入替・誤単位・誤った処理条件は検出できない（実際に試験で制約を確認）。
FeatureBatchの宣言自体が虚偽なら値から意味を推測できない。正常のみの学習はcallerのmanifest表明・データ分割責務であり、モデルに真値ラベルは渡さない。

## 単独試験と比較

```text
.venv/Scripts/python.exe -m unittest discover -s tests -p test_model_candidate.py -v
.venv/Scripts/python.exe tools/check_workstream_scope.py --owner M nv_runner/model_candidate.py tests/test_model_candidate.py configs/parallel/model_comparison.json docs/workstreams/model.md
```

10件合格、最終単独実行1.957秒。内訳は既存モデル比較、seed再現性、batch/順序不変、保存hash不変、schemaの名前/順序/単位/処理条件/版、型/幅/不足、未知設定、未学習、入力不変・失敗refit不変、PCA異常方向、音響データ結合。
範囲チェックはdenied=[]。共有コード・契約・既存59試験・Git設定は編集していない。

音響試験は既存 `generate_acoustic` → `InputAdapter` → `DatasetPlanner` → `FixedWindow` → 候補モデルを直接接続。
seed=42、正常訓練6個体、各2測定、3秒、1024Hz、fit4個体/cal2個体、評価7個体を新規生成。
fit40行/cal20行/eval70行の8特徴。生成後のtruthファイル/配列はモデル試験で読まない。
設定は `configs/parallel/model_comparison.json`、元の生成・実験・分割設定も生成領域へ保存。
IF16木とPCA2成分の双方で、既存NormalModelとの同一batchの最大score絶対差は0。
既存RoutePlugin.scoreへ裸配列モデルを接続し、異なるbatchサイズでもscoreは既存契約rtol=atol=1e-12以内、ID・状態・理由・参照は厳密一致。

初回試験は10件中1件失敗：PCAの異なるbatchサイズの端数差を辞書ごと厳密比較していた。
数値だけを既存契約の1e-12で照合し、その他fieldの厳密比較を維持して修正。
初回失敗と最終合格ログは `reports/parallel_development/C/` に保持する。既存契約の許容差変更はない。

## 保存・再開・未実施

成功データ：`tests/_work/M/37a4fa42248a45608e48fcc7e68dfe0f/`。
配下に観測/真値（生成器出力）、generation.json、experiment.json、split.json、feature_rows.npz、学習モデル、comparison.json。
レポート `reports/parallel_development/C/result.json` に実行時刻・環境・変更ファイルhashを保存。
再開時はレポートとhashを照合し、単独コマンドで新UUID領域へ再生成できる。大容量生成物の移送は不要。

モデル候補の本番登録、typed metadataの共通契約化、モデルロードAPI、推論専用CLI、実測性能、検出率改善は未実施。
今回の候補内開発に必要なCRはない。schemaを全経路で必須化する場合はC03/C04境界のCRが必要。
将来の本番登録はIがkind制限・モデル選択・前処理/score説明・schema保存を確認して接続する。
既存Bundle schema1.0やrunnerへ候補の新fieldを自動追加しない。未採用のまま他機能へのimport依存はない。

共有ファイルの編集・CLIへの接続は統合担当Iへ差分を提出する。契約に変更が必要なら当該実装を止め、INTEGRATION.mdのCR手順に従う。

提出時に `python tools/check_workstream_scope.py --owner M <変更ファイル一覧>` を実行する。これは申告パスの検査でありOS権限制御や変更検出ではない。
