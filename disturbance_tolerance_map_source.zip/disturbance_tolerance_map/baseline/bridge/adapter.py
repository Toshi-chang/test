"""Reads observations and acquisition metadata only; never scene/truth arrays."""
from pathlib import Path
import json,hashlib,re
import numpy as np

ACQUISITION='distributed-acquisition/1.0'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def valid_id(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}',value):raise ValueError('invalid identity')
    return value
def member(root,entry):
    p=(root/entry['path']).resolve()
    if not p.is_relative_to(root) or not p.is_file() or sha(p)!=entry['sha256']:raise ValueError('source integrity mismatch')
    return p

class DistributedAdapter:
    def convert(self,acquisition_path,destination,identity):
        acquisition_path=Path(acquisition_path).resolve();root=acquisition_path.parent
        m=read(acquisition_path)
        if m.get('schema_version')!=ACQUISITION:raise ValueError('unsupported acquisition version')
        if m.get('units')!=['Pa','m/s'] or m.get('axes')!=['time','receiver']:raise ValueError('units/axes mismatch')
        for k in ['specimen_id','case_id','derived_group_id','capture_id']:valid_id(identity[k])
        if m.get('calibration',{}).get('reference')!='analytic_SI_distributed_v1':raise ValueError('unknown SI origin')
        fs=m['sample_rate_hz'];n=m['n_samples']
        if not isinstance(fs,(float,int)) or not np.isfinite(fs) or fs<=0 or not isinstance(n,int) or n<2:raise ValueError('invalid timebase')
        observations=member(root,m['observations'])
        with np.load(observations,allow_pickle=False) as a:
            p=a['pressure_pa'].copy();u=a['axial_velocity_m_s'].copy();t=a['time_s'].copy()
        receivers=m['receivers']
        if p.shape!=(n,len(receivers)) or u.shape!=p.shape or t.shape!=(n,) or not all(np.isfinite(x).all() for x in [p,u,t]):raise ValueError('invalid observation shapes/values')
        if not np.allclose(t,np.arange(n)/fs,rtol=0,atol=1e-12):raise ValueError('timebase mismatch')
        if len({r['id'] for r in receivers})!=len(receivers):raise ValueError('duplicate receiver')
        rpm=None
        if m.get('rpm') is not None:
            rp=member(root,m['rpm'])
            with np.load(rp,allow_pickle=False) as a:rpm=a['rpm'].copy()
            if rpm.shape!=(n,) or not np.isfinite(rpm).all() or m['rpm_sync']!='shared_clock':raise ValueError('RPM mismatch')
        for r in receivers:
            valid_id(r['id']);pos=np.asarray(r['position_m'],float);axis=np.asarray(r['axis'],float)
            if pos.shape!=(3,) or axis.shape!=(3,) or not np.isfinite(pos).all() or not np.isfinite(axis).all() or not np.isclose(np.linalg.norm(axis),1,rtol=0,atol=1e-10):raise ValueError('invalid receiver coordinates')
        dest=Path(destination).resolve();dest.mkdir(parents=True,exist_ok=True);items=[];origins=[]
        for i,r in enumerate(receivers):
            mid=identity['capture_id']+'_'+r['id'];valid_id(mid)
            signal=dest/(mid+'.npz');meta_path=dest/(mid+'.json')
            if signal.exists() or meta_path.exists():raise ValueError('measurement already exists')
            arrays={'waveform':np.column_stack([p[:,i],u[:,i]])}
            if rpm is not None:arrays['shaft_rpm']=rpm
            np.savez_compressed(signal,**arrays)
            meta={'schema_version':'1.0',**{k:identity[k] for k in ['specimen_id','case_id','derived_group_id']},
                'measurement_id':mid,'data_kind':'synthetic','protocol':'distributed simulation; one receiver per measurement; simultaneous receivers share capture and specimen',
                'channels':[{'name':name,'quantity':quantity,'unit':unit,'position_m':r['position_m'],'direction':r['axis'],'pair_id':r['id']}
                            for name,quantity,unit in [('p','pressure','Pa'),('u','particle_velocity','m/s')]],
                'timebase':{'sample_rate_hz':fs,'start_seconds':0,'signal_sync':'shared_clock','rpm_sync':'shared_clock' if rpm is not None else 'unavailable'},
                'calibration':{'status':'calibrated','reference':'analytic_SI_distributed_v1','units':['Pa','m/s'],
                    'meaning':'generated directly in SI; no measured calibration certificate',
                    'observation_sha256':sha(observations),'acquisition_sha256':sha(acquisition_path)},
                'operating_conditions':{**m['operating_conditions'],'capture_id':identity['capture_id'],'receiver_id':r['id'],
                    'rpm_origin':'ideal simulator clock; no sensor-error model'},'validity':[]}
            write(meta_path,meta)
            items.append({'metadata_path':meta_path.name,'source_path':signal.name,'source_sha256':sha(signal),
                'mapping':{'signals':'waveform','rpm':'shaft_rpm' if rpm is not None else None,'axes':['time','channel']}})
            origins.append({'measurement_id':mid,'capture_id':identity['capture_id'],'receiver_index':i,'receiver_id':r['id'],
                'observation_path':str(observations),'observation_sha256':sha(observations),
                'acquisition_path':str(acquisition_path),'acquisition_sha256':sha(acquisition_path),'sample_range':[0,n]})
        return items,origins
