# RC: route_c

正式な担当指示は ../parallel_contracts/AGENT_TASKS.md を参照。

専用編集範囲:

- `nv_runner/route_c_candidate.py`
- `tests/test_route_c_candidate.py`
- `configs/parallel/route_c_*.json`
- `docs/workstreams/route_c.md`

候補moduleは必要時にこの名前で作成する。未実装の雛形APIは追加しない。既存moduleをread-onlyで参照し、候補を直接呼ぶ専用試験で開始できる。生成物は `tests/_work/RC/<uuid>/` に保存する。

共有ファイルの編集・CLIへの接続は統合担当Iへ差分を提出する。契約に変更が必要なら当該実装を止め、INTEGRATION.mdのCR手順に従う。

提出時に `python tools/check_workstream_scope.py --owner RC <変更ファイル一覧>` を実行する。これは申告パスの検査でありOS権限制御や変更検出ではない。
