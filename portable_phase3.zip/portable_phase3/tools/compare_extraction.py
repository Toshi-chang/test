"""Compare before/after runs from the SAME config and observations (no retraining shortcut)."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from nv_runner.bundle import BundleReader, TABLES
from nv_runner.common import read_json, sha, write_json

IGNORED = {'run_id','route_elapsed_seconds','elapsed_seconds'}

def stable(value):
    if isinstance(value,dict): return {k:stable(v) for k,v in value.items() if k not in IGNORED}
    if isinstance(value,list): return [stable(v) for v in value]
    return value

def compare(before,after):
    a,b=BundleReader(before).validate(),BundleReader(after).validate()
    checked=[]
    for table in TABLES:
        if stable(a.tables[table]) != stable(b.tables[table]):
            raise AssertionError('table changed: '+table)
        checked.append(table+'.jsonl')
    for name in ('experiment.json','dataset_split.json','metrics.json','truth.json'):
        if (a.path/name).exists() != (b.path/name).exists(): raise AssertionError(name)
        if (a.path/name).exists():
            if stable(read_json(a.path/name))!=stable(read_json(b.path/name)): raise AssertionError(name)
            checked.append(name)
    for sub in ('models','arrays'):
        names={p.relative_to(a.path).as_posix() for p in (a.path/sub).glob('*')}
        if names!={p.relative_to(b.path).as_posix() for p in (b.path/sub).glob('*')}: raise AssertionError(sub)
        for name in sorted(names):
            if sha(a.path/name)!=sha(b.path/name): raise AssertionError('artifact bytes changed: '+name)
        checked.extend(sorted(names))
    for key in ('requested_routes','completed_routes','bundle_status','schema_version'):
        if a.manifest[key]!=b.manifest[key]: raise AssertionError(key)
    return {'status':'passed','before':str(a.path),'after':str(b.path),
            'before_manifest_sha256':sha(a.path/'manifest.json'),'after_manifest_sha256':sha(b.path/'manifest.json'),
            'comparison':'exact values and model/array bytes, same machine/environment',
            'excluded':['run_id','route_elapsed_seconds','elapsed_seconds','environment.json (code hashes)',
                        'logs/run.json (wall clock)','manifest member hashes and completed_at'],
            'checked_files':checked,'sample_count':len(a.tables['samples']),
            'route_case_count':len(a.tables['route_case_results'])}

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--before',required=True); p.add_argument('--after',required=True); p.add_argument('--output',required=True)
    args=p.parse_args(); result=compare(args.before,args.after); write_json(args.output,result)
    print(json.dumps({k:v for k,v in result.items() if k!='checked_files'},ensure_ascii=False,indent=2))
