import numpy as np
from nv_runner.routes import REGISTRY,PreparedSet
from nv_runner.signals import SignalService
from bridge.adapter import write

def partitions(protocol):
    splits={}
    for seed in protocol['partition_seeds']:
        order=np.random.default_rng(seed).permutation(protocol['pool_families']).tolist()
        for name,(nf,nc) in protocol['variants'].items():
            fit=order[:nf];cal=order[32:32+nc]
            if set(fit)&set(cal) or (set(fit)|set(cal))&set(protocol['evaluation_families']):raise ValueError('family leakage')
            splits[f's{seed}_{name}']={'fit':fit,'calibration':cal,'partition_seed':seed}
    return splits

def subset(p,records):
    mids={r.meta['measurement_id'] for r in records};samples=[s for s in p.samples if s['measurement_id'] in mids];ids={s['sample_id'] for s in samples}
    return PreparedSet(samples,{k:v for k,v in p.values.items() if k in ids},{k:v for k,v in p.assets.items() if k in mids},{k:v for k,v in p.coverage.items() if k in mids})

def prepare(records,cfg):
    service=SignalService(cfg['signal'])
    return {rc['key']:REGISTRY[rc['plugin']](rc).prepare(records,service) for rc in cfg['routes']}

def score(records,prepared,cfg,models,thresholds,folder=None):
    output=[]
    for rc in cfg['routes']:
        key=rc['key'];p=prepared[key];plugin=REGISTRY[rc['plugin']](rc);scored=plugin.score(models[key],p,cfg['batch_size']);rows=plugin.decide(plugin.aggregate(p,scored,records),thresholds[key]);lookup={s['sample_id']:s for s in p.samples};meta={r.meta['measurement_id']:r.meta for r in records}
        good=sorted([s for s in scored if s['anomaly_score'] is not None],key=lambda s:(-s['anomaly_score'],s['sample_id']));top=[]
        for s in good[:3]:
            sample=lookup[s['sample_id']];x=p.values[s['sample_id']];z=models[key].scaler.transform([x])[0];ix=np.argsort(-abs(z),kind='stable')[:5];schema=plugin.feature_schema();m=meta[sample['measurement_id']]
            top.append({'sample':sample,'score':s['anomaly_score'],'position_m':m['channels'][0]['position_m'],'operating_conditions':m['operating_conditions'],'features':[{'name':schema[i][0],'unit':schema[i][1],'value':float(x[i]),'fit_z':float(z[i])} for i in ix]})
        for r in rows:r.update(threshold=thresholds[key]['value'],top_inputs=top)
        output+=rows
        if folder:
            write(folder/f'{key}_samples.json',{'samples':p.samples,'scores':scored,'coverage':p.coverage,'feature_schema':plugin.feature_schema()})
            ids=sorted(p.values)
            if ids:np.savez_compressed(folder/f'{key}_features.npz',sample_ids=ids,features=np.array([p.values[i] for i in ids]))
            for mid,a in p.assets.items():np.savez_compressed(folder/f'{key}_{mid}_selection.npz',**a)
    return output
