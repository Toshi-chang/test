import copy
import numpy as np
from bridge.adapter import write,sha,DistributedAdapter
from bridge.dataset import realize
from da_engine.engine import synthesize
from nv_runner.input_adapter import InputAdapter

def normal_fields(cfg,family):return [synthesize(realize(cfg,family,mi,'normal')) for mi in range(len(cfg['modes']))]

def extra_fields(cfg,family,kind,direction=None,frequency=None):
    out=[]
    for mi in range(len(cfg['modes'])):
        scene=realize(cfg,family,mi,'normal');scene['sources']=copy.deepcopy(cfg['additions'][kind])
        if direction is not None:
            scene['sources'][0]['geometry']['center_m']=direction
            scene['sources'][0]['excitation']['frequency_hz']=frequency
        out.append(synthesize(scene))
    return out

def make_case(folder,cid,family,base,addition,external,db,cfg):
    folder.mkdir(parents=True,exist_ok=True);canonical=folder/'canonical';canonical.mkdir(exist_ok=True);items=[];origins=[];audit=[]
    for mi,b in enumerate(base):
        scene=b['scene'];fs=scene['simulation']['sample_rate_hz'];t=b['time_s'];receivers=scene['receivers'];ref=next(i for i,r in enumerate(receivers) if r['id']=='front')
        p=b['pressure_pa'].copy();u=b['velocity_m_s'].copy();gain=0.
        if addition is not None:p+=addition[mi]['pressure_pa'];u+=addition[mi]['velocity_m_s']
        if external is not None:
            target=2e-5*10**(db/20);gain=target/np.sqrt(np.mean(external[mi]['pressure_pa'][:,ref]**2))
            p+=gain*external[mi]['pressure_pa'];u+=gain*external[mi]['velocity_m_s']
            np.testing.assert_allclose(np.sqrt(np.mean((gain*external[mi]['pressure_pa'][:,ref])**2)),target,rtol=1e-12,atol=1e-15)
        axes=np.array([r['axis'] for r in receivers]);axial=np.einsum('nri,ri->nr',u,axes)
        if addition is None and external is None:np.testing.assert_array_equal(axial,b['axial_velocity_m_s'])
        raw=folder/f'm{mi}';raw.mkdir(exist_ok=True);mode=cfg['modes'][mi];rpm=mode['start_rpm']+(mode['end_rpm']-mode['start_rpm'])*t/scene['simulation']['duration_seconds']
        np.savez_compressed(raw/'observations.npz',time_s=t,pressure_pa=p,velocity_m_s=u,axial_velocity_m_s=axial);np.savez_compressed(raw/'rpm.npz',rpm=rpm)
        acq={'schema_version':'distributed-acquisition/1.0','units':['Pa','m/s'],'axes':['time','receiver'],'sample_rate_hz':fs,'n_samples':len(t),'receivers':receivers,'rpm_sync':'shared_clock','calibration':{'reference':'analytic_SI_distributed_v1'},'observations':{'path':'observations.npz','sha256':sha(raw/'observations.npz')},'rpm':{'path':'rpm.npz','sha256':sha(raw/'rpm.npz')},'operating_conditions':{'mode':mode['name'],'start_rpm':mode['start_rpm'],'end_rpm':mode['end_rpm'],'rpm_key':'shaft_rpm','shaft':'primary'}}
        write(raw/'acquisition.json',acq)
        write(raw/'generation.json',{'normal':scene,'addition':None if addition is None else addition[mi]['scene'],'external':None if external is None else external[mi]['scene'],'external_gain':float(gain),'use':'generation provenance only, never model input'})
        new,refs=DistributedAdapter().convert(raw/'acquisition.json',canonical,{'specimen_id':cid,'case_id':cid,'derived_group_id':f'family_{family}','capture_id':f'{cid}_m{mi}'});items+=new;origins+=refs
        for i,r in enumerate(receivers):
            rms=0. if external is None else float(np.sqrt(np.mean((gain*external[mi]['pressure_pa'][:,i])**2)))
            audit.append({'measurement_id':refs[i]['measurement_id'],'external_rms_pa':rms,'external_spl_db':None if rms==0 else float(20*np.log10(rms/2e-5))})
    write(canonical/'manifest.json',{'schema_version':'1.0','role':'eval','normal_only_attested':False,'measurements':items});write(folder/'origins.json',origins);write(folder/'acoustics.json',audit)
    return InputAdapter().load(canonical/'manifest.json')
