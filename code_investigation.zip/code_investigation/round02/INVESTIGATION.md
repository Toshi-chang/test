# 第2回：D-002に向けた契約境界の追加調査

2026-10-20。仕様解読のみ。D-002の契約確定・実装・改修は行っていない。ソース変更、新規実装、テスト実行なし。round01は変更していない。

## 1. 根拠の再利用と確認状態

開始時、round01/source_inventory.jsonの44ファイルをSHA-256照合し、**変更0件**だった。第1回の型・軸・版・単位・基本校正式を再利用し、全ファイルを読み直していない。今回は入口選択、上位の拒否条件、品質/公開、原本捕捉と再照合について不足していた範囲を追加した。

- **S：静的確認**。実装から読める分岐・保持項目・拒否条件。実行成功や実測適合を意味しない。
- **I：静的根拠からの推論**。到達可能性や再利用上の注意。動的実証はない。
- **U：未確認**。今回の範囲では不明。未実装/不存在とは断定しない。
- **V：今回の実行検証済み挙動**はない。実施したハッシュ照合・文書整合確認は、解析機能の実行試験ではない。

前回のFもコードの静的確認として再利用する。テスト関数が存在することとその試験が今回成功したことは区別する。過去のログを新規実証へ転用していない。

### 根拠ファイル索引

パスはworkspace相対。行番号は1始まり。`R1-Sxx`はround01/INVESTIGATION.mdの同ID（元ファイルhashも照合済み）。Q番号は今回の追加読解。source_inventory.jsonに省略しないパス、hash、参照範囲、拡張理由を保存した。

|ID|ファイル|主な追加範囲と理由|
|---|---|---|
|Q01|09_DL-NPZ_Bridge/Start-Evaluation.cmd|1–6：実入口確認|
|Q02|09_DL-NPZ_Bridge/scripts/Start-Evaluation.ps1|1–26：Python/PYTHONPATH選択|
|Q03|09_DL-NPZ_Bridge/src/offline_evaluator/__main__.py|6–42：CLI分岐、legacy指定|
|Q04|09_DL-NPZ_Bridge/src/offline_evaluator/runner.py|34–43、120–173：strict選択、原本/例外|
|Q05|09_DL-NPZ_Bridge/observer_dev/Tool_A/app.py|20–32：UI controllerの実import名|
|Q06|09_DL-NPZ_Bridge/src/offline_evaluator/inspection.py|76–164：CH/time/品質の上位検査|
|Q07|09_DL-NPZ_Bridge/src/offline_evaluator/calibration.py|17–176：係数選択、snapshot、失敗、保存。前回部分読解を補完|
|Q08|09_DL-NPZ_Bridge/observer_dev/Tool_A/services/calibration_audit.py|24–158：監査出力の実能力|
|Q09|09_DL-NPZ_Bridge/src/offline_evaluator/strict_integration.py|76–111、177–206、268–306、339–407：校正がOfflineBoundaryを要求するため追加|
|Q10|09_DL-NPZ_Bridge/src/shared_contract/artifact_state.py|107–127、264–311、326–360、387–428：Q09が依存する捕捉/公開/受領|
|Q11|09_DL-NPZ_Bridge/src/observer_exporter/window_generator.py|35–98：開始位置と無効区間の実処理|
|Q12|09_DL-NPZ_Bridge/src/observer_exporter/metadata_builder.py|60–99：由来項目の必須/任意の区別|
|Q13|09_DL-NPZ_Bridge/src/offline_evaluator/model_runner.py|25–67：Q09.validate_nativeの直接依存、校正NPZ受領と区間由来。学習本体は調査外|

`observer_dev/Tool_A/main.py`は検索時に存在せず、作成も推測もせず、実在するapp.pyへ対象を限定した。実行中GUIの起動コマンドや環境変数は取得していない。名前が同じ関数でも、reference/observer_devのどちらで実行されたかは別の証拠が必要。

## 2. 契約境界表

表Aと表Bを同じIDで結合すると、入力/出力、型、前提、拒否条件、保持情報、依存、根拠、確認状態が揃う。旧形式・strict形式・NV形式を同一の共通契約として扱わない。

### 表A：責務、入出力、不変条件と検査

|境界|責務・入力→出力、型/軸/単位|前提・実際の検査/拒否|
|---|---|---|
|A1 実装選択|信頼済みPythonコード＋参照root→Observerクラス/関数のNamespace。数値軸なし|reference_connectionは必要4ファイルの存在、既存domain/services/data_io各moduleのoriginが選択root配下か確認。衝突はImportError。CLIはstrict既定、legacyは別分岐。|
|B1 Excel CH/probe解決|ChannelMappingTable.pairs＋CH名→(probe_id,quantity,key)、ProbeCalibration＋感度情報dict|CH正規化後の最初一致。CH不在/probe不在はValueError。重複CH全件拒否ではない。probe辞書は後勝ち。status/use_for_phase/csv_columnを照合関数は参照しない。|
|B2 観測側PU校正|TFData[F,T]複素電圧＋p/uの指定CH＋mapping/probes→校正TF、Pa/m/s|build_calibrated_tfはprobe解決後、p指定にpressure式/u指定にvelocity式を適用。BridgeのようなCH別quantity照合はこの入口にない。開発側Resolverはstage/units、二重校正、generation/入力変更、有限出力を追加検査。|
|B3 Bridge明示PU入力|計測器CSV→time[N],p[N],u[N],fs。最初はV/V|load_instrument_voltage_recordは異なるCH1/CH2、正有限fs、全時刻一致、finiteを要求。校正wrapperはCH異同/quantity/probe存在/共通実数1D格子を検査。異なるprobe ID同士を一律拒否はしない。|
|B4 offline点検|読込配列[N,3]（時刻秒,CH1 V,CH2 V）＋fmt→check群、統計、時刻残差|CH1/CH2割当て不明はINCONCLUSIVE。stage/units不一致はFAIL。不正fs/丸め精度不明はINCONCLUSIVE、時刻逆転/格子不一致はFAIL。実配線一致は別確認。|
|C1 offline校正|B4合格データ＋config＋probe JSON→p/u/time[N]、original_time[N]、Pa/m/s、metadataのNPZ|必須prior check非PASSなら実行しない。method=record_fft_periodic_v1、periodic根拠、uncorr/phase true、dataset_kind一致、係数単位宣言、probe ID整合、必須係数finiteを検査。係数欠如等はInputProblem。一般非周期への適用保証なし。|
|C2 校正監査CSV|TFの正周波数と明示probe/CH設定→周波数別感度/位相/変換式CSV|正周波数0件・未知modeを拒否。設定から係数を再計算して出す。実行済み校正結果と同じ設定だったことを自動証明する機能ではない。|
|D1 通常Bridge export|record群→校正窓float32[W,2,L]＋record_ids[W]＋start_samples[W]＋metadata_json|元record IDの一意性・明示4split・存在source・共通fsを検査。窓は同長finite1D入力、無効範囲、窓長/overlapを検査し交差窓を除去。開始座標は原配列のまま。|
|D2 DL NPZ受領|pu_physical_waveform_dataset整数版1→検証済みdict、source_for_window→source文字列|shape/単位/finite/record split重複/metadata/任意start整合を検査。trace helperはsplit/index、record一致一意性を検査。helperはsource hashを再照合しない。|
|D3 strict入力捕捉|path,role,native_id→InputSnapshot（immutable bytes＋参照）|captureは実ファイルbytesを読み、参照hashを算出。verify_currentは現path bytesとの一致を検査。CHの科学的妥当性はこの層の責務ではない。|
|D4 strict成果物公開/受領|draft＋native members＋quality→committed artifact→VerifiedArtifact/利用許否|processing/validation/commitを別管理。validate/publish前後に元input再照合、member一致、最後にmanifest公開。readは版/状態/member hash/品質構造を検査。consumeはnative/由来/用途別品質条件も確認。|
|D5 校正record再利用|pu_calibration_evaluation_record整数版1のbytes→float32[W,2,L], contract, provenance|p/u/time同長finite、Pa/m/s、fs/time格子、校正方式/DC/Nyquist/stage/mode、dataset_kind、実装hash存在と原本hash存在を検査。window開始はarange。strict上位がraw/probe実bytesのhashと結合する。|
|N1 NV受領/派生|manifest＋metadata＋NPZ[N,2]、任意rpm[N]→MeasurementRecord→fit/cal/eval|2CH/SI/共置pair/方向/共有clock/校正宣言/原本hashを検査。Plannerは個体・派生元・sourceを分割境界で検査。Column candidateはSI列のみ、電圧校正なし。|

### 表B：ID・時間・CH・校正・品質・依存・根拠

|境界|保持と追跡の実際|外部依存・根拠・状態|
|---|---|---|
|A1|選択rootとobserver_selection。stft bridgeはimport時に関数をbindする。sys.pathは戻すがsys.modulesは残る。entrypointだけでは個々の実行の選択rootを証明できない|importlib/os/sys/RLock、配置されたreference。R1-S09:19–78、R1-S11:15–24、Q01:1–6/Q02:1–26/Q03:22–32/Q04:34–43/Q05:26。S、実稼働選択はU|
|B1|pair_no/probe_id/CH名/calibration_key、Optional係数・unit・date等。CH名のグローバル一意ID、位置/方向、配線証明ではない|openpyxl、domain.models。R1-S02:146–176、R1-S04:134–195,378–426,461–517。S|
|B2|開発側TFViewはsource_dataset_key/signal_ref/generationとmapping/probe/settings/実装hash snapshot。reference TFにはこの追加状態がない。p_rms/u_rmsの0は校正済み実RMSではない|校正式/domain、FrozenTF。R1-S06:108–186、R1-S07:115–176、R1-S25:144–175。S。上位全UI拒否網羅はU|
|B3|CH役割、指定fsと旧推定fs、raw stage、任意periodic宣言。センサー位置方向・配線実態を取得しない|既定reference loader、numpy。R1-S10:6–38、R1-S11:202–235。S（対象関数の範囲）|
|B4|元CSV行番号、record_id、check_id/status/reason、time精度/共通原点許容区間。定値CHはFAIL、ADC閾値なしはINCONCLUSIVEでrequired=false|read_instrument_bytes、fmt/acceptance。Q06:76–164。S|
|C1|probe JSON hash/コピー、source hash/path、boundary_evidence、time_normalization、校正実装ファイルhash、元時刻。実行成功と物理適合を別checkへ保存|OfflineBoundary、reference.ProbeCalibration、周期FFT校正。Q07:17–20,32–135、Q09:393–407。S|
|C2|周波数/CH/probe ID、感度/位相、mode、単位、変換式。rawのhash・元係数ファイルbytes・校正run IDの必須記録はこの関数にない|校正式、csv。Q08:24–35,77–158。S。UIから常時呼ばれるかU|
|D1|record_id、source_file/hash、p/u CH/probe、input_metadata、window_start_samples、processing。source_fileと渡されたsignalが同じ内容かまではこの関数は検査しない|校正/窓/metadata/exporter。R1-S13:34–82、Q11:35–98、Q12:60–99。S、signal-source拘束不足はI|
|D2|record IDとsource pathの解決、start位置はmetadata/配列に別保持。一般schemaではrecords/startが必ずあるとは限らず、trace helperは不足で拒否|numpy allow_pickle=False、schema validator。R1-S16:68–72,123–165、R1-S17:34–86、R1-S18:6–16。S|
|D3|path,size,sha256,role,captured_at,native_id。config/raw/probe/expectedをrole別捕捉。config辞書と捕捉bytesの内容相違も拒否|Path/sha256。Q10:107–127、Q09:271–302。S|
|D4|artifact_key、producer_run/task、input_refs、member hashes、quality、binding roots/parents。source bytes自体をinputs/*.binに同梱。親の非PASS品質を継承して照合|ArtifactDraft/native validator/EligibilityPolicy。Q09:76–111,177–206,339–385、Q10:264–311,326–360,387–428。S|
|D5|record_id、元raw hash、派生NPZ hash、probe hash、group/split/ground_truth、starts/sample_count/time_start。hash形だけの検査とstrictの実体照合は別|numpy、JSON、record consumer。Q13:25–67、Q09:90–111。S|
|N1|specimen/case/measurement/derived_group、source/metadata hash、timebase、channel位置/方向/pair、校正reference、validity。変換元の追加由来はprovenance.json|InputAdapter/Planner/common、既存Runner。R1-S19:17–136、R1-S20:18–95、R1-S21:48–50。S（第1回再利用）|

## 3. 追加で確定した静的事実

### A：実行実装の選択

Start-Evaluation.cmdはPowerShell launcherへ接続する。launcherは明示Pythonまたはプロジェクト内runtime/.venv_cを選び、PYTHONPATHをsrcにして `-B -m offline_evaluator` を呼ぶ。PU_OBSERVER_REFERENCE_ROOTを設定/消去する処理はこのlauncherにはない（Q01/Q02）。したがって親環境の設定が選択へ影響し得る【I】。

CLIはinspect/calibrateをrun_inspectionへ渡し、train/infer/evaluateはmodel_runnerへ渡す。`--legacy-development`は別呼出しを選ぶ。run_inspection自体もartifact_mode=legacy_developmentで診断経路へ切替、未指定はstrict（Q03:22–32、Q04:34–43）。strictと通常export_raw_recordsを一括して「Bridgeの保存保証」と呼ばない。

Observer開発側の実在app.pyは `ui.controllers.AppController` をimportし、controllers_.pyを指定していない（Q05:26）。ただし現在表示中のGUIがこのapp.pyから起動したことや、環境変数の過去値は未確認【U】。

第1回のreferenceとの差分hashを再利用：校正式calibration.pyとExcel loaderは一致、models/loaders/calibrated_tf/tf_transformは不一致。referenceは旧型、開発側はCH状態/immutable view/校正状態等を持つ。stft_calibration_bridgeはimport時に `_observer` と関数をbindするので、実行途中に環境変数を書き換えても安全に再選択できる契約とは読めない【I】。別rootの旧トップレベルmoduleが既に存在する場合はconnectionが拒否する（R1-S09/S11）。

### B：CH一意性・ペアの妥当性・位置/同期

次の検証は同じではない。

1. CH名がmappingのどれかに一致する（最初一致）。
2. 指定CHがpressure/velocityの期待quantityで、probeがある（Bridge wrapper）。
3. CH1/CH2を別役割に割り当てた（instrument adapter/inspection）。
4. 実配線がその役割・センサーであり、位置/方向・時計が物理的に妥当（今回のコード確認だけでは証明されない）。

開発側のTF校正はresolveしたprobeをp/u用の式へ渡すが、当該入口にCHのquantity役割照合はない。CalibrationResolverが拒否するのは主にstage、二重校正、source変更、係数情報不在、計算失敗/非有限。これをBridge側の役割検査と混同しない（R1-S06/S07/S11）。

offlineはprobe JSONのpressure_probe_id/velocity_probe_idを使って別々のChannelPairMapping行を作る。両者が同一probe IDでなければならないという条件ではなく、ID存在・係数内ID一致を検査する（Q07:62–87）。共置性・向きはこの対応だけでは検証されない。旧mappingのstatus/use_for_phase/csv_columnについて、調査したservices/calibrated_tf、analysis_context、ui/controllers、比較dialog、Bridge入力/校正範囲には適用処理を見いだしていない。**リポジトリ全体で未使用との断定ではない**。

旧Observer/Bridgeの対象入力から位置/方向を取得する経路は今回も特定できず、NVは入力metadataのposition_m/direction/pair_idを要求する。NVは既に宣言された情報を検証する受領境界であり、実計測器のCH表から生成する経路が確認できたわけではない（R1-S19）。

時刻について、通常Bridge adapterはfs明示＋厳密格子検査で修復なし。offline inspectionはexact/rounded_decimalを分け、丸め幅qが1/fs未満の場合に共通原点許容区間を調べる。校正段階でrounded_decimalを使う場合、grid_normalization=validated_uniform_gridの明示がなければ実行しない。明示時は許容区間中央値を原点に派生timeを作り、original_timeと最大変更量を保存する（Q06:80–122、Q07:88–104,120–122）。これは別センサー間遅延補正や自動位相整列ではない。

### C：校正成立と再現可能性

offlineはconfigからprobe_manifestを解決して捕捉し、dataset_kindと由来説明、係数単位宣言、probe対応、使用するpressure/uncorr velocityの必須係数を検査する（Q07:43–84）。「必須係数finite」は「全係数正」「校正証明書の正当性」「有効帯域/期限/温度適合」と同義ではない。実際の式側のguardも残るが、機器適合はE40_INSTRUMENT=INCONCLUSIVEとして別扱い（Q07:133–135）。

校正前検査が必須非PASS、方式/周期根拠/校正JSON不足なら実行を見送りINCONCLUSIVE。設定型・ID/単位・係数不正はInputProblem、数値/I/O例外はrunnerがFAILとして記録する。後続recordを処理するtryはrecord単位（Q07:27–58、Q04:163–173）。strict record成果物は出力ファイルとE40_EXECUTION PASSがなければNATIVE_GENERATION_INCOMPLETE（Q09:393–407）。

成功経路は校正JSONの内容コピー、元raw/probe hash、boundary根拠、time変更、校正コードhashを保存し、書込NPZのdtype/shape/値の再読込一致を検査する（Q07:108–129）。コードhash対象は周期FFT関数のファイルと読み込まれたdomain/services/data_ioのファイル群。これを「全依存の実装が完全に保存される」とは言えない。コードbytesやPython/全依存の復元性・証明書の有効性は別確認。

calibration_auditは周波数ごとの係数CSVを再計算して保存する【S】。対象services/ui内の呼出検索では定義以外を特定できなかった【U】。CSVの存在や関数名だけで毎回校正と結び付いた監査が自動保存されるとは扱わない。

### D：Recording・派生・窓・hash

旧Observerのsignal_ref/dataset_key/generation、Bridgeのrecord_id、strictのartifact_key、NVのmeasurement/specimen/derived_groupは異なる識別体系。新システムのRecording IDが既に共通実装されているという根拠はない。byte hashは内容同一性であり、同一個体/収録セッションを定義するIDではない。

通常record exporterは渡されたsignalを処理し、指定source_fileの存在とhashを別に保存する。両者のbyte/数値同一性を直接拘束する処理ではない【S/I】。metadata_builderのsource_file/hash、probe、CH、calibration_sourceは任意引数がある場合の記録（Q12:79–97）。これに対しstrictは捕捉bytesから入力を読む（Q04:120–145）ため、処理した入力と証拠の結合が強い。

InputSnapshot.capture→reference hash→ArtifactDraft.validate/publishで元input bytes再照合、公開member再照合、最後にmanifestを置く。native validationはraw/probe/config root必須、raw/probe hash・original_time/fs・calibration_metadata・channel_mappingを結合して照合する（Q09:76–111、Q10:264–311）。入力が後から削除/変更されれば公開前検査は失敗し得る。公開後read_committedは保存memberを検証し、原本pathを毎回開くわけではない。strict bindingにはinputs/*.binとして捕捉bytesが含まれる（Q09:365–367、Q10:326–360）。

品質FAILを含むこと自体でartifactの構造的公開を禁止する設計ではない。公開済み・validation passedと解析利用可能は別で、EligibilityPolicyがdiagnostic_view/exploratory/formal_analysisごとにnative/由来/品質を評価する。formalはrequired品質のPASSが必要。親の非PASS品質の消失/改変はverify_provenanceで拒否する（Q09:177–206、Q10:387–428）。このartifact schemaはNV ResultBundle 1.0と同一ではない。

窓は元sample座標の半開区間[start,start+L)。無効範囲交差窓を除外しても再連結や座標詰め直しをしない。固定窓数指定はlinspaceの整数開始位置で、要求数が大きい場合の重複開始位置を一意にする処理は当該範囲にない【S】。出力dtype=float32、shape=[W,2,L]（Q11:47–98）。

offline decode_record_bytesは派生NPZ bytesのhash、original_source_sha256、probe_manifest_sha256、starts/time_startを返す。原本hash/コードhashの存在・長さ検査だけの部分と、strict上位での捕捉実体との照合を区別する（Q13:25–67、Q09:90–111）。source_for_windowは通常NPZのsource文字列解決だけで、原本実体・区間完全性の検証ではない（R1-S18）。

## 4. 未解決事項と追加調査の必要性

|課題|D-002に影響する未確認事項|追加確認と範囲|
|---|---|---|
|U1 実起動|過去/現在の実行がどのroot・環境・import状態だったか|必要な実行の起動記録/保存環境情報を限定確認。今回の静的入口情報から推測しない。|
|U2 CH重複/有効性|全GUI/外部取得経路で重複・status・phase利用不可を拒否するか|実際に使うUIのCH選択イベントと設定保存だけを追加追跡。全GUI一括読込は不要。|
|U3 センサー実体|CH→sensor serial→probe係数→位置/向き→時計の実測証拠|実在する測定メタデータ/計測器仕様/校正証明書が必要。未入手を未実装と断定しない。|
|U4 係数適合|P4原仕様、帯域、温度、有効期限、取得系gain、符号/極性の正しさ|式と実係数の独立照合。今回のfinite/単位検査では決まらない。|
|U5 実装再現|code hash集合が全依存と選択rootを十分再現するか|保存環境情報、bridge wrapper/依存版/式の保存方式を限定追跡。今回runtime検証なし。|
|U6 多CH/別時計|現在の2CH契約を超える同時計/非同時計、多位置の扱い|追加取得経路の存在確認が必要。現行2CHを一般仕様として採用しない。|
|U7 改変/欠損の端部|原本更新競合、親artifact欠落、突然終了の動的挙動|今回は試験禁止。次の承認された検証工程で既存試験の実行証拠を取得。静的拒否分岐は本書に保存。|
|U8 型横断|通常NPZ、offline校正record、strict artifact、NV Bundle間の接続|必要な変換項目・意味の欠損をD-002側で判断。自動変換実装の存在は未確認。|

## 5. 再利用候補（採用未確定）

|候補|再利用できそうな責務【I】|条件/制約|
|---|---|---|
|reference_connection|参照root選択とimport衝突拒否|旧namespace予約、import時bind、対象rootを明示。一般plugin loaderではない。|
|inspection.inspect_arrays|明示fs・時刻丸め・CH宣言・ADC品質の検査|2CH電圧CSV専用、実配線/物理適合は別。check語彙の採用は未決。|
|周期FFT校正wrapper|明示周期ACの変換と除去成分の記録|任意収録へ一般化しない。校正式と参照実装の固定が必要。|
|InputSnapshot / ArtifactDraft|不変bytesの取得、公開前後の照合、commit marker|strict schema依存。元path可用性・保存容量・失敗運用を設計側で検討。|
|binding / verify_provenance|raw/probe/configと派生、親品質を結ぶ受領検証|native record/model schemaとの結合が強い。generic共通契約として即採用しない。|
|window_generator|元座標を保った有効窓抽出|float32化、重複start、境界、無効範囲の意味を確認。|
|NV InputAdapter/Planner|SI正規入力と個体/派生元漏洩の検査|校正実行を担わず、2CH・共置/共有clock制約。|

## 6. D-002への引継ぎ

### 確認済みの事実（すべて静的）

- 入力電圧、校正TF、校正時間波形、学習窓は異なるデータ段階。名称p/uやNPZ拡張子だけでは単位・意味が決まらない。
- CH名一意性、役割一致、probe存在、物理的PU妥当性は別の検査で、現行経路間で保証が異なる。
- 校正の計算完了・期待値照合・実機適合・学習性能・公開状態・用途別利用可否は独立に扱う実装が存在する。
- raw/probe/configを捕捉するstrict経路では証拠bytesと派生の結合がある。一方通常export/trace helperに同じ保証はない。
- 配列軸・版表現・ID・分割単位は互換ではない。NV calibration分割とセンサー校正は別概念。
- 元時刻を保持した派生時間軸と、元sample位置を保った窓の仕組みが存在する。

### 設計判断が必要な事項（今回決定しない）

1. Recording/Channel/Sensor/PU Pair/Calibration/DerivedDataの識別スコープと一意性。
2. 時刻原点・時計・遅延・丸め/派生格子・欠損区間・座標系の契約。
3. 校正情報の必須内容（係数bytes/参照hash/単位/由来/証明/有効条件/実装版）。
4. 未確認/不成立/未評価/除外/無効を品質・処理状態・利用条件にどう割り当てるか。
5. 再現のための原本同梱とhash参照の範囲、公開後に原本がない場合の保証。
6. 型/版不一致の拒否と変換、旧データの限定受入、個体/派生元分離の基準。

次の担当はまず本書とsource_inventory.jsonを読む。R1の44件は変更なしとして根拠を再利用する。U1〜U8のうち設計上必要なものだけ追加調査し、静的根拠を動的な「検証済み」へ格上げしない。新設計は本As-Is資料とは分離する。
