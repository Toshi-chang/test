"""Agent V: declarative validation independent of registry/entrypoint loading."""
import copy
import math
import unittest

from nv_runner.plugin_validation import validate_schema, validate_route_config


def route(**kwargs):
    return {"key": "test", "plugin": "arbitrary_new_route", "model": {"kind": "pca"}, **kwargs}


def object_schema(properties=None, required=None, additional=True):
    return {"type": "object", "properties": properties or {},
            "required": required or [], "additionalProperties": additional}


LEGACY = object_schema({"window_seconds": {"type": "number", "exclusiveMinimum": 0,
                                         "allow_bool": True, "finite": False}}, ["window_seconds"])


class PluginValidation(unittest.TestCase):
    def test_01_legacy_positive_and_extra_properties_accepted_unchanged(self):
        for value in (True, 1, .5, float("inf"), float("nan")):
            config = route(window_seconds=value, independent_option={"x": [1, 2]})
            before = copy.deepcopy(config)
            validate_route_config(config, LEGACY)
            self.assertEqual(config.keys(), before.keys())
            self.assertEqual(config["independent_option"], before["independent_option"])
            self.assertIs(config["window_seconds"], value)
        schema = copy.deepcopy(LEGACY)
        validate_route_config(route(window_seconds=1), schema)
        self.assertEqual(schema, LEGACY)

    def test_02_legacy_invalid_values_and_missing_rejected(self):
        for value in (False, 0, -1, "1", None, [], {}):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "invalid/missing window_seconds"):
                validate_route_config(route(window_seconds=value), LEGACY)
        with self.assertRaisesRegex(ValueError, "invalid/missing window_seconds"):
            validate_route_config(route(), LEGACY)

    def test_03_new_numeric_defaults_are_strict(self):
        schema = object_schema({"level": {"type": "number", "minimum": 0, "maximum": 1}}, ["level"])
        for value in (True, False, float("nan"), math.inf, -math.inf, -.001, 1.001, "0.5"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_route_config(route(level=value), schema)
        for value in (0, .5, 1):
            validate_route_config(route(level=value), schema)

    def test_04_required_unknown_and_defaults_not_injected(self):
        schema = object_schema({"model": {"type": "object"}, "count": {"type": "integer"}}, ["model"], False)
        config = {"model": {"kind": "pca"}}
        before = copy.deepcopy(config)
        validate_route_config(config, schema)
        self.assertEqual(config, before)
        self.assertNotIn("count", config)
        with self.assertRaisesRegex(ValueError, "unknown configuration properties"):
            validate_route_config({**config, "typo": 1}, schema)

    def test_05_nested_array_enum_boolean_string_and_null(self):
        schema = object_schema({"options": object_schema({
            "counts": {"type": "array", "items": {"type": "integer", "minimum": 1}, "minItems": 1, "maxItems": 2},
            "mode": {"type": "string", "enum": ["fast", "slow"]},
            "active": {"type": "boolean"}, "absent": {"type": "null"},
        }, ["counts", "mode", "active", "absent"], False)}, ["options"])
        good = {"counts": [1, 2], "mode": "fast", "active": False, "absent": None}
        validate_route_config(route(options=good), schema)
        for key, value in (("counts", []), ("counts", [1, 2, 3]), ("counts", [1.0]),
                           ("counts", [True]), ("counts", (1,)), ("mode", "typo"),
                           ("mode", 1), ("active", 1), ("absent", 0)):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_route_config(route(options={**good, key: value}), schema)

    def test_06_schema_unknown_keywords_and_type_rejected(self):
        for schema in ({}, [], {"type": "future"}, {"type": ["number"]},
                       {"type": "number", "default": 1}, {"type": "string", "minimum": 1},
                       {"type": "object", "$ref": "untrusted"},
                       object_schema({"x": {"type": "number", "mimimum": 1}})):
            with self.subTest(schema=schema), self.assertRaises(ValueError):
                validate_schema(schema)

    def test_07_schema_malformed_definitions_rejected(self):
        schemas = [
            {"type": "object", "required": "x"},
            {"type": "object", "required": ["x"]},
            object_schema({"x": {"type": "number"}}, ["x", "x"]),
            {"type": "object", "properties": []},
            {"type": "object", "properties": {1: {"type": "number"}}},
            {"type": "object", "additionalProperties": {}},
            {"type": "number", "enum": []}, {"type": "number", "enum": "one"},
            {"type": "number", "minimum": True}, {"type": "number", "maximum": math.inf},
            {"type": "integer", "allow_bool": 1}, {"type": "number", "finite": 1},
            {"type": "array", "minItems": True}, {"type": "array", "maxItems": -1},
            {"type": "array", "minItems": 2, "maxItems": 1},
        ]
        for schema in schemas:
            with self.subTest(schema=schema), self.assertRaises(ValueError):
                validate_schema(schema)

    def test_08_existing_model_whitelist(self):
        for kind in ("pca", "isolation_forest"):
            validate_route_config(route(model={"kind": kind}), object_schema())
        with self.assertRaisesRegex(ValueError, "unknown model"):
            validate_route_config(route(model={"kind": "future_model"}), object_schema())
        with self.assertRaises(KeyError):
            validate_route_config({}, object_schema())

    def test_09_existing_selection_and_or_and_predicates(self):
        leaves = [{"field": field, "comparison": comparison, "value": True}
                  for field in ("frequency_hz", "msc", "intensity", "reactive_intensity", "phase", "p_power", "u_power")
                  for comparison in (">", ">=", "<", "<=")]
        condition = {"op": "and", "children": [leaves[0], {"op": "or", "children": leaves}]}
        config = route(selection={"enabled": True, "condition": condition})
        before = copy.deepcopy(config)
        validate_route_config(config, object_schema())
        self.assertEqual(config, before)

    def test_10_existing_bad_selection_conditions(self):
        leaf = {"field": "msc", "comparison": ">", "value": .5}
        bad = [{"op": "xor", "children": [leaf, leaf]}, {"op": "and", "children": [leaf]},
               {**leaf, "field": "truth"}, {**leaf, "comparison": "=="}, {**leaf, "value": ".5"}]
        for condition in bad:
            with self.subTest(condition=condition), self.assertRaises(ValueError):
                validate_route_config(route(selection={"enabled": True, "condition": condition}), object_schema())
        # Disabled selection still does not inspect irrelevant malformed payload.
        validate_route_config(route(selection={"enabled": False, "condition": "unused"}), object_schema())

    def test_11_route_schema_and_config_must_be_objects(self):
        with self.assertRaisesRegex(ValueError, "route schema must be object"):
            validate_route_config(route(), {"type": "number"})
        with self.assertRaisesRegex(ValueError, "route configuration must be object"):
            validate_route_config([], object_schema())

    def test_12_exclusive_and_inclusive_bounds(self):
        schema = object_schema({"x": {"type": "number", "exclusiveMinimum": 0, "exclusiveMaximum": 2}}, ["x"])
        validate_route_config(route(x=1), schema)
        for value in (0, 2):
            with self.assertRaises(ValueError):
                validate_route_config(route(x=value), schema)


if __name__ == "__main__":
    unittest.main()
