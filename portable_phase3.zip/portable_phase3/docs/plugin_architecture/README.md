# モジュール独立性・選択的実行の設計検証案

2026-10-14 / 設計案0.1 / 既存PoC 0.2.0・ResultBundle schema1.0を変更しない

## 結論と成果物

**既存PoCの並列開発と、将来基盤の実証を独立した2本の作業として進める。** 既存側はC01〜C08の境界と担当専用ファイルを使って着手できる。新基盤は明示的な登録・選択・ポート接続・版一致だけを備えた隔離PoCから始め、既存runnerを全面置換しない。

|成果物|内容|
|---|---|
|[DESIGN.md](DESIGN.md)|Plugin Descriptor、実行interface、Contract Validator、Composition Planner、A/B/C例|
|[ACCEPTANCE.md](ACCEPTANCE.md)|交換/追加/廃止/無効化、負例、独立エージェントの受入試験|
|[WORK_AND_MIGRATION.md](WORK_AND_MIGRATION.md)|Task Aの実装指示、Git調査、競合、作業分割、Task Dの段階移行|
|[examples.json](examples.json)|提案descriptorと構成の具体例。実行可能な基盤ではない|
|[baseline_hashes.json](baseline_hashes.json)|現行コード・設定・契約等の無変更確認用|

今回は新規設計文書と例示JSONのみ作成。コード、C01〜C08、既存設定、既存テスト、Git設定、配布ZIPを変更しない。以下の新interface/試験/PoCフォルダは**提案・未実装・未実行**。A/B/Cは既存の経路A/B/Cとは無関係な機能名である。

## 現状と目標の差分

確認済み資料：../parallel_contracts/{CONTRACTS_MINIMUM,AGENT_TASKS,CONTRACT_TEST_PLAN,INTEGRATION}.md。現行runner.py、routes.py、bundle.pyの登録・検証・保存接続も再確認した。

|観点|現行0.2.0|隔離PoCで実証する最小形|今すぐ行わないこと|
|---|---|---|---|
|機能登録|routes.REGISTRYとvalidate_configの固定辞書|別catalogがdescriptorとfactoryを対応付け、engineは具体classを知らない|自動package探索・marketplace・hot reload|
|機能選択|routes[].enabled、plugin/model名に固定検証|compositionのnodeがplugin_id＋実装版を明示選択|曖昧な最適候補選択/自動fallback|
|設定検証|runnerにplugin別の必須値がある|各descriptorに小さな閉じたconfig定義、共通validatorで検査|任意Pythonコードを設定から実行|
|入出力|Record/PreparedSetと具体dict、暗黙artifact名|独立のport契約・単位・座標・型を検査|既存Record/Bundleへの新field必須化|
|依存|runnerが決めた順序、SignalService共有|入力portのbindingからDAGを作成、循環/欠落を起動前拒否|分散実行、thread安全化、scheduler最適化|
|実装交換|登録/validator/説明文の変更が必要な場合あり|同じsemantic capabilityと契約を持つA↔Bを選択変更だけで交換|互換性のないモデルを名前だけで交換|
|結果|runnerがResultBundle1.0へ組立|隔離PoC独自LabRunReport、kernelが共通化|LabRunReportをBundleと偽装|
|機能削除|参照/設定/実装が混在|未選択のcatalog entryを削除しても他が動く。参照が残ればpreflight失敗|依存nodeの無断自動無効化|
|学習|正常fit/cal/eval、モデル/前処理/閾値を保存|最初は純粋な決定的数値処理で交換性だけを試す|学習ライフサイクルの汎用化を初回実証の条件にする|

現行の問題点は「モジュールがない」ことではなく、共有ファイル内の登録・検証・保存説明・artifact命名が一体になっている点。候補module単独開発は既に可能なので、将来基盤の完成を待たせない。

## 現在の境界と隔離PoCの関係

```mermaid
flowchart LR
  subgraph Existing[維持する既存PoC 0.2.0]
    I[InputAdapter / 分割] --> R[現行runner / routes / model]
    R --> B[ResultBundle 1.0]
    B --> V[既存viewer / output]
  end
  subgraph Lab[将来実装する隔離PoC]
    CAT[明示catalog + descriptors] --> PLAN[Planner / Validator]
    COMP[composition + external inputs] --> PLAN
    PLAN --> E[固定engine]
    E --> A[ダミーA または B]
    A --> C[追加ダミーC]
    E --> REP[LabRunReport]
  end
  B -. 後段の読取adapter .-> COMP
  R -. 将来の単経路wrapper実証 .-> Lab
```

点線は移行候補であり現時点で未接続。新基盤は既存にimportされず、最初はnv_runnerにも依存しない。提案配置は `nv_route_runner_poc/plugin_lab_poc/` の独立package `plugin_lab`。今回そのruntimeディレクトリは作成しない。

## 現在可能なことと将来能力を分ける

- **現在の実装で可能**：既存C01〜08を守る担当専用候補、class直接test、既存Bundle読取、ローカル受渡し。登録/共有編集は統合担当へ集約。
- **小さい追加実装で実証可能**：本案のdescriptor/port validator/DAG/逐次engine＋ダミー3種。新しい依存は原則不要、標準ライブラリと既存NumPyで足りる設計。
- **未実証で将来検討**：学習状態のplugin間交換、DL/GPU、任意pluginの安全隔離、非同期stream、実行中交換、remote実行、複数版自動解決、既存経路全体への適用。

契約テストだけの一次検証は形・意味宣言・oracleに対する適合を調べる。任意の実装が全入力で数学的に同等、性能十分、悪意がないことの証明ではない。

## 最小の固定判断

今回は案として選択を絞る：Python同期逐次、ローカル明示catalog、必須portのみ、単一出力port、正確な版pin、単位の暗黙変換なし、閉じたconfig、依存の自動起動なし、動的model loadなし。これらを既存C契約へ追加するのではなく、隔離PoC専用規則とする。

外部情報待ちは「実際に利用するGit repo/基準commit」と「将来の実測/外部接続条件」だけ。後者は今回のダミー実証を止めない。学習plugin仕様などは初版のスコープ外とし、未決定事項を先行タスクとして増やさない。
