"""Public orchestration: fixed scenes -> adapter -> unmodified five-route Runner."""
import bootstrap
from bootstrap import ROOT,verify_engines
import argparse,json,subprocess,sys,time,traceback
from pathlib import Path
from bridge.adapter import read,write,sha
from bridge.dataset import generate
from nv_runner.runner import ExperimentRunner,validate_config
from nv_runner.bundle import BundleReader,EvaluationAdapter

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['quick','comparison'],default='quick');ap.add_argument('--output',required=True,type=Path)
    a=ap.parse_args();out=a.output.resolve()
    if out.exists():raise ValueError('fresh run directory required')
    out.mkdir(parents=True);report={'status':'running','profile':a.profile,'engine_files':verify_engines(),'commands':[]}
    write(out/'validation.json',report);start=time.perf_counter()
    try:
        data_config=ROOT/'configs'/f'dataset_{a.profile}.json'
        data=generate(data_config,out/'dataset')
        cfg=read(ROOT/'configs/experiment.json')
        for k,f in [('train_manifest','train_manifest.json'),('eval_manifest','eval_manifest.json'),('truth_path','truth.json')]:cfg[k]=str(data/f)
        cfg['export']['output_dir']=str(out/'runs');write(out/'experiment.json',cfg)
        _,train,evaluation,fit,cal,split=validate_config(out/'experiment.json')
        if not fit or not cal:raise ValueError('fit/calibration unavailable')
        for key in ['specimen_id','derived_group_id','source_sha256']:
            groups=[{r.meta[key] for r in records} for records in [fit,cal,evaluation]]
            if any(groups[i]&groups[j] for i in range(3) for j in range(i)):raise AssertionError('split leakage '+key)
        bundle=ExperimentRunner().execute(out/'experiment.json');reader=BundleReader(bundle).validate()
        if reader.manifest['bundle_status']!='complete' or len(reader.manifest['completed_routes'])!=5:raise AssertionError('not all routes completed')
        for key in reader.manifest['completed_routes']:
            if not (bundle/'models'/f'{key}.joblib').exists() or read(bundle/'models'/f'{key}_threshold.json')['value'] is None:raise AssertionError('model or threshold unavailable '+key)
        proc=subprocess.run([sys.executable,'-B','-m','nv_runner','view','--bundle',str(bundle),'--output',str(out/'viewer.html')],
                            cwd=ROOT/'runtime',capture_output=True,text=True,encoding='utf-8',errors='replace')
        (out/'viewer.log').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
        if proc.returncode:raise RuntimeError('separate viewer failed')
        receipt=EvaluationAdapter().import_bundle(bundle,out/'evaluation_inbox')
        if receipt['unresolved_sources']:raise AssertionError('unresolved source references')
        write(out/'receipt.json',receipt);metrics=read(bundle/'metrics.json')
        report.update(status='passed',bundle=str(bundle),fit_specimens=len(split['fit_specimens']),calibration_specimens=len(split['calibration_specimens']),
            eval_specimens=len({r.meta['specimen_id'] for r in evaluation}),train_measurements=len(train),eval_measurements=len(evaluation),
            independent_eval_families=read(data_config)['eval_families'],metrics=metrics,
            dataset_config_sha256=sha(data_config),experiment_template_sha256=sha(ROOT/'configs/experiment.json'),elapsed_seconds=time.perf_counter()-start)
        verify_engines()
    except Exception as e:
        report.update(status='failed',error=str(e));(out/'error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:write(out/'validation.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='metrics'},ensure_ascii=False))
if __name__=='__main__':main()
