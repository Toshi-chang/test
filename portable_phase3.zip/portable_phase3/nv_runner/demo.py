"""One command produces a fresh, self-contained experiment and offline report."""
from pathlib import Path
from datetime import datetime, timezone
import uuid
from .profiles import experiment, settings
from .synthetic import generate
from .runner import ExperimentRunner
from .viewer import render
from .bundle import EvaluationAdapter
from .common import write_json, read_json


def demo(profile, output=None, generator="acoustic"):
    project = Path(__file__).resolve().parent.parent
    name = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:6]
    root = Path(output).resolve() if output else project / "demos" / (generator+"_"+profile + "_" + name)
    root.mkdir(parents=True, exist_ok=False)
    if generator=="acoustic":
        from .acoustic_generator import generate_acoustic, acoustic_settings
        from .profiles import acoustic_experiment
        generate_acoustic(root/"data",acoustic_settings(profile))
        write_json(root/"experiment.json",acoustic_experiment("data","runs"))
    else:
        generate(root / "data", settings(profile))
        write_json(root / "experiment.json", experiment("data", "runs"))
    bundle = ExperimentRunner().execute(root / "experiment.json")
    viewer = render(bundle, root / "viewer.html")
    receipt = EvaluationAdapter().import_bundle(bundle, root / "evaluation_inbox")
    summary = {"schema_version": "1.0", "profile": profile, "generator":generator,"root": str(root), "bundle": str(bundle),
               "viewer": str(viewer), "receipt": receipt, "metrics": read_json(bundle / "metrics.json")}
    write_json(root / "summary.json", summary)
    write_json(project / "reports" / ("latest_" + generator+"_"+profile + ".json"), summary)
    print(f"Viewer: {viewer}")
    return summary
