"""Declarations for the existing route lifecycle, not a new execution API."""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class PluginDescriptor:
    plugin_id: str
    implementation_version: str
    factory: str
    config_schema: dict
    api_version: str = "1.0"
    descriptor_version: str = "1.0"
    input_contracts: dict = field(default_factory=lambda: {"C01": "1.0", "C02": "1.0"})
    output_contracts: dict = field(default_factory=lambda: {"C03": "1.0", "C05": "1.0"})
    model_contract: str = "C04@1.0"
    validator: str | None = None
