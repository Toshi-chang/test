import bootstrap_study
import unittest
from bootstrap_study import ROOT
from bridge.adapter import read
from experiment import partitions
from summarize import paired,metrics
class StudyTests(unittest.TestCase):
    def test_disjoint(self):
        p=read(ROOT/'protocol.json')
        for s in partitions(p).values():
            self.assertFalse(set(s['fit'])&set(s['calibration']));self.assertFalse((set(s['fit'])|set(s['calibration']))&set(p['evaluation_families']))
    def test_nested(self):
        ss=partitions(read(ROOT/'protocol.json'))
        for seed in [201,202,203]:
            a=ss[f's{seed}_fit16_cal4'];b=ss[f's{seed}_fit16_cal8'];c=ss[f's{seed}_fit32_cal8']
            self.assertEqual(a['fit'],b['fit']);self.assertEqual(a['calibration'],b['calibration'][:4]);self.assertEqual(b['calibration'],c['calibration']);self.assertEqual(b['fit'],c['fit'][:16])
    def test_external_false_positive_not_success(self):
        rows=[{'family':1,'scenario':s,'decision':'outside'} for s in ['normal','band']]
        self.assertEqual(paired(rows)['both_correct'],0)
    def test_unavailable_not_normal(self):
        r=metrics([{'label':'normal','decision':'undetermined'}]);self.assertEqual(r['normal_correct'],0);self.assertEqual(r['normal_undetermined'],1)
    def test_duplicate_rejected(self):
        self.assertRaises(ValueError,paired,[{'family':1,'scenario':'normal','decision':'within'}]*2)
if __name__=='__main__':unittest.main()
