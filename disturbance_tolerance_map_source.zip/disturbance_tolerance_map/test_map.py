import bootstrap_map
import unittest,copy
from run_map import validate_protocol
from bridge.adapter import read
from bootstrap_map import ROOT
from report import counts
class Tests(unittest.TestCase):
    def test_protocol(self):validate_protocol(read(ROOT/'map_config.json'))
    def test_version(self):
        p=read(ROOT/'map_config.json');p['schema_version']='2';self.assertRaises(ValueError,validate_protocol,p)
    def test_overlap(self):
        p=read(ROOT/'map_config.json');p['families']=[0];self.assertRaises(ValueError,validate_protocol,p)
    def test_passband(self):
        p=read(ROOT/'map_config.json');p['frequencies_hz']=[512];self.assertRaises(ValueError,validate_protocol,p)
    def test_duplicate(self):self.assertRaises(ValueError,counts,[{'family':1,'decision':'within'}]*2)
    def test_unavailable(self):self.assertEqual(counts([{'family':1,'decision':'undetermined'}])['within'],0)
if __name__=='__main__':unittest.main()
