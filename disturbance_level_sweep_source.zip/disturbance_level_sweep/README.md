# 外乱音圧掃引：固定モデルでの正常判定評価

既存コードを変更せず、Phase 3派生の164ファイルをbaseline/へ固定コピーした独立試験です。モデル・閾値は各経路で一度だけ学習し、全音圧で共有します。正常20群（fit16/cal4）、独立評価3群、定常/回転変動、3受音点。追加外乱なし＋20–80 dB SPL（5 dB刻み）の42条件を評価します。seed42、1024 Hz、3秒。完全な生成設定はbaseline/configs/dataset_comparison.json、解析設定はbaseline/configs/experiment.jsonです。

## 再実行（Windows、Python 3.12：今回3.12.14で実行）

このフォルダを単独でコピーして、ここを作業ディレクトリにします。

```powershell
py -3.12 -m venv .venv
.venv/Scripts/python.exe -m pip install -r baseline/runtime/requirements.txt
.venv/Scripts/python.exe -B -m unittest discover -s . -p test_sweep.py -v
.venv/Scripts/python.exe -B run_sweep.py --output outputs/comparison_v1
```

既存出力への上書きは禁止です。中断・失敗時はstatus.json/error.logを確認し、新しい出力名で最初から再実行してください。途中からの再開APIはありません。過去データ・モデルは不要で、参照データも毎回再生成します。

## 物理条件と読み方

- 外乱は固定位置の220 Hz点音源。音圧とベクトル粒子速度を共通倍率で変化させ、p–u関係を保ちます。正面受音点の外乱成分単独の全記録RMSを指定します。基準20 µPa、無補正のdB SPLです。
- 追加外乱なしは無音ではありません。正常音側に背景音・通常イベント・正常ばらつきがあります。
- 学習と評価の個体群は分離。評価3群を各レベルで反復し、42独立個体とは扱いません。閾値や特徴量は調整しません。
- 合成器の音源別正解は合成時だけ使用。観測ファイルをInputAdapter経由でモデルへ渡し、正解は事後評価に隔離します。
- 正常判定=within。outsideは正常対象の誤判定、undeterminedは判定不可です。未評価を正常に数えません。
- 外乱なしから連続して全3群が正常であった**試験点**を報告。非単調な判定、5 dBの未試験区間、上限まで全正常の場合の打切りを区別してください。3群だけで母集団の許容音圧を保証できません。
- 自由空間等価音源の模擬です。散乱・筐体透過・実環境性能を実証したものではありません。

## 保存物

outputs内：reference（再生成元）、dataset（波形・音圧一覧・由来・真値）、split.json、experiment.json、runs（Bundle 1.0、モデル、入力・スコア・座標）、model_hashes.json、cases.json、summary.json、REPORT.md、index.html、viewer.html、status.json。

index.htmlが音圧依存の一覧、viewer.htmlが波形・領域・スコアの詳細です。閲覧は保存Bundleから別プロセスで生成し、実行中オブジェクトに依存しません。元波形やBundleは再生成可能なため配布ZIPから除外します。小容量の結果はreportsに添付します。
