"""Linear acoustic synthesis. SI units, exp(+j*w*t), U is a signed axial component.
See docs/MODELS.md for equations, conventions and sources.
"""
from __future__ import annotations
import copy
import json
import math
import numpy as np
from scipy import signal
from rotation import validate_rotation, validate_rotating_source, rotation_trace, rotating_excitation, rotating_presets
from rpm_sensor import validate_sensor,measure_rpm

VERSION = '1.2.0'
KINDS = ['tone','multitone','white_noise','pink_noise','band_noise','chirp','am','fm','bursts','impact','gear','rotation_fault']
MODELS = ['piston','monopole','plane','rigid_wall']
ROLES = ['normal','external','abnormal']
CASE_NAMES = ['0 Normal','1 External sound','2 Target extra sound']


def default_config():
    def src(name,role,kind,model,level,freq,**extra):
        return dict(name=name,role=role,kind=kind,model=model,level_rms=level,
                    frequency_hz=freq,end_hz=2400,modulation_hz=24,deviation_hz=80,
                    depth=.6,band_low_hz=100,band_high_hz=2800,harmonics=3,
                    distance_m=.03,radius_m=.0375,axis_angle_deg=0,incidence_deg=45,
                    variation=.1,onset_s=.15,width_s=.06,period_s=.25,**extra)
    return dict(schema_version=1,fs=8192,duration_s=1.0,window_samples=1024,
        windows_per_record=4,seed=20260919,rho=1.2,c=343.0,
        counts=dict(train=100,validation=25,calibration=40,test_per_class=40),
        sources=[src('基本定常音','normal','tone','piston',.003,256),
                 src('既知の周波数音','normal','tone','piston',.0015,1024),
                 src('暗騒音・剛体壁反射込み','normal','pink_noise','rigid_wall',.008,1000),
                 src('外部の広帯域音','external','band_noise','rigid_wall',.12,1000),
                 src('対象の追加周波数','abnormal','tone','piston',.0015,1792)],
        sensor=dict(p_gain_db=0.,u_gain_db=0.,p_phase_deg=0.,u_phase_deg=0.,
                    p_delay_us=0.,u_delay_us=0.,p_noise_rms=0.,u_noise_rms=0.))


def presets():
    a=default_config();b=copy.deepcopy(a);d=copy.deepcopy(a)
    b['sources'][3].update(kind='tone',frequency_hz=1024,level_rms=.2,name='既知音と同周波数の外乱')
    b['sources'][4].update(kind='bursts',frequency_hz=2000,level_rms=.002,name='対象の断続音')
    d['sources'][3].update(kind='chirp',frequency_hz=400,end_hz=2800,level_rms=.12,name='外部スイープ音')
    d['sources'][4].update(kind='impact',frequency_hz=2200,level_rms=.002,name='対象の減衰振動',onset_s=.45,width_s=.02)
    result={'定常音＋広帯域外乱':a,'同周波数外乱＋断続音':b,'スイープ外乱＋減衰振動':d,**rotating_presets(a)}
    from levels import calibrated_preset
    result['評価基準：機械60 dB SPL・暗騒音25 dB SPL・1000 RPM']=calibrated_preset(result['回転機械：1000 RPM・60歯・3倍音＋広帯域暗騒音'])
    return result

def case_names(config):
    return CASE_NAMES+(['3 External + target extra'] if config.get('include_combined',False) or (config.get('rotation') or {}).get('include_combined',False) else [])


def _finite(value,name):
    x=float(value)
    if not math.isfinite(x): raise ValueError(f'{name}: 有限の数値を入力してください')
    return x


def validate_config(config):
    c=copy.deepcopy(config)
    validate_rotation(c)
    if c.get('rpm_sensor') is not None:c['rpm_sensor']=validate_sensor(c['rpm_sensor'])
    if int(c.get('schema_version',1))!=1:raise ValueError('未対応の設定バージョンです')
    fs=c['fs']=int(c['fs']);duration=c['duration_s']=_finite(c['duration_s'],'収録時間')
    if not 2000<=fs<=96000:raise ValueError('fsは2000〜96000 Hzにしてください')
    if not .25<=duration<=10 or fs*duration>262144:raise ValueError('収録時間は0.25〜10秒、262144点以内です')
    n=round(fs*duration);w=c['window_samples']=int(c['window_samples'])
    k=c['windows_per_record']=int(c['windows_per_record'])
    if not 128<=w<=4096 or not 1<=k<=16 or w*k>n:raise ValueError('窓長128〜4096点、窓数1〜16で、窓長×窓数を収録点数以下にしてください')
    if not 0<=int(c['seed'])<2**32:raise ValueError('seedは0〜4294967295です')
    c['seed']=int(c['seed'])
    for key,lo,hi in [('rho',.5,2),('c',250,450)]:
        c[key]=_finite(c[key],key)
        if not lo<=c[key]<=hi:raise ValueError(f'{key}の範囲は{lo}〜{hi}です')
    counts=c['counts']
    for key in ['train','validation','calibration','test_per_class']:
        counts[key]=int(counts[key])
        if not 5<=counts[key]<=1000:raise ValueError('各収録件数は5〜1000です')
    if counts['train']<10:raise ValueError('学習用正常は10収録以上です')
    total=counts['train']+counts['validation']+counts['calibration']+len(case_names(c))*counts['test_per_class']
    if total*k*(3 if c.get('rotation') else 2)*w*4>400_000_000:raise ValueError('窓データが400 MBを超えます。件数・窓長を下げてください')
    if not 1<=len(c['sources'])<=20:raise ValueError('音源は1〜20個です')
    for s in c['sources']:
        if s['model'] not in MODELS or s['kind'] not in KINDS or s['role'] not in ROLES:raise ValueError('音源の種類・役割・音場モデルが不正です')
        for key in ['level_rms','frequency_hz','end_hz','modulation_hz','deviation_hz','depth','band_low_hz','band_high_hz','distance_m','radius_m','axis_angle_deg','incidence_deg','variation','onset_s','width_s','period_s']:
            s[key]=_finite(s[key],key)
        if not 0<=s['variation']<=.95 or not 0<s['level_rms']<=100:raise ValueError('RMSは正数、ばらつきは0〜0.95です')
        if not .001<=s['distance_m']<=20 or not .001<=s['radius_m']<=1:raise ValueError('距離は0.001〜20 m、ピストン半径は0.001〜1 mです')
        if not -180<=s['axis_angle_deg']<=180 or not 0<=s['incidence_deg']<=89:raise ValueError('軸角度は±180°、壁への入射角は0〜89°です')
        f=s['frequency_hz'];nyq=.45*fs
        if not 25<=f<nyq:raise ValueError('周波数は25 Hz以上、fsの45%未満です')
        h=s['harmonics']=int(s['harmonics'])
        if not 1<=h<=12:raise ValueError('倍音数は1〜12です')
        validate_rotating_source(s,c)
        if s['model']=='rigid_wall' and abs(np.sin(np.deg2rad(s['axis_angle_deg'])))>1e-8:raise ValueError('剛壁ケースの測定軸は壁法線（0°または180°）にしてください')
        if s['kind']=='multitone' and f*h>=nyq:raise ValueError('最大倍音がfsの45%以上です')
        if s['kind']=='chirp' and not 25<=s['end_hz']<nyq:raise ValueError('スイープ終端が帯域外です')
        if s['kind'] in ('am','fm'):
            if not 0<s['modulation_hz']<nyq or not 0<=s['depth']<=1 or s['deviation_hz']<0:raise ValueError('変調設定が不正です')
            margin=s['modulation_hz']+(s['deviation_hz'] if s['kind']=='fm' else 0)
            if f-margin<25 or f+margin>=nyq:raise ValueError('変調側帯域が生成帯域を外れます')
        if s['kind'] in ('white_noise','pink_noise','band_noise') and not 25<=s['band_low_hz']<s['band_high_hz']<nyq:raise ValueError('雑音帯域は25 Hz以上、fsの45%未満です')
        if s['kind'] in ('bursts','impact'):
            if not 0<=s['onset_s']<duration or not 1/fs<s['width_s']<=duration or s['period_s']<=0:raise ValueError('発生時刻・継続時間・周期を確認してください')
    if not any(s['role']=='normal' for s in c['sources']):raise ValueError('正常音源を1つ以上設定してください')
    for key in default_config()['sensor']:
        c['sensor'][key]=_finite(c['sensor'].get(key,0),key)
        v=c['sensor'][key]
        if 'noise' in key and not 0<=v<=10:raise ValueError('センサ雑音RMSが範囲外です')
        if 'delay' in key and abs(v)>1000:raise ValueError('相対遅延は±1000 μs以内です')
        if 'gain' in key and abs(v)>40:raise ValueError('残留ゲイン誤差は±40 dB以内です')
        if 'phase' in key and abs(v)>180:raise ValueError('位相誤差は±180°以内です')
    return c


def field_transfer(f,s,rho,c):
    """G_p, G_u from unit source drive. DC=0 excluded by synthesis.
    plane/wall drive: incident Pa; monopole: m³/s; piston: m/s.
    Angle refers to measurement axis vs outward propagation. Wall: axis normal.
    """
    omega=2*np.pi*np.asarray(f);k=omega/c;r=s['distance_m']
    projection=np.cos(np.deg2rad(s['axis_angle_deg']))
    if s['model']=='plane':
        gp=np.ones_like(k,dtype=complex);gu=gp*projection/(rho*c)
    elif s['model']=='monopole':
        e=np.exp(-1j*k*r)
        gp=1j*omega*rho*e/(4*np.pi*r)
        gu=(1+1j*k*r)*e/(4*np.pi*r*r)*projection
    elif s['model']=='piston':
        R=np.hypot(r,s['radius_m']);e=np.exp(-1j*k*r)
        # expm1 avoids cancellation for small path differences.
        delta=np.expm1(-1j*k*(R-r))
        gp=-rho*c*e*delta
        gu=e*((1-r/R)-r/R*delta)*projection
    elif s['model']=='rigid_wall':
        mu=np.cos(np.deg2rad(s['incidence_deg']));x=k*r*mu
        gp=2*np.cos(x).astype(complex)
        gu=-2j*mu*np.sin(x)/(rho*c) # positive axis points away from wall
        gu*=projection # constrained normal projection of the normal velocity only
    else:raise ValueError('Unknown field model')
    return gp,gu


def _excitation(t,s,duration,rng,fs,cycles=None):
    phase=rng.uniform(0,2*np.pi);f=s['frequency_hz'];kind=s['kind']
    if kind in ('gear','rotation_fault'):
        x=rotating_excitation(t,s,cycles,phase)
    elif kind in ('tone','am','fm','bursts','impact'):
        phase_array=2*np.pi*f*t+phase
        if kind=='fm':phase_array+=(s['deviation_hz']/s['modulation_hz'])*np.sin(2*np.pi*s['modulation_hz']*t)
        x=np.sin(phase_array)
        if kind=='am':x*=1+s['depth']*np.sin(2*np.pi*s['modulation_hz']*t+rng.uniform(0,2*np.pi))
        if kind in ('bursts','impact'):
            env=np.zeros_like(t)
            starts=[s['onset_s']] if kind=='impact' else np.arange(s['onset_s'],duration,s['period_s'])
            for start in starts:
                q=t-start
                if kind=='impact':env+=np.where(q>=0,np.exp(-np.maximum(q,0)/s['width_s']),0)
                else:
                    mask=(q>=0)&(q<s['width_s']);env[mask]+=np.sin(np.pi*q[mask]/s['width_s'])**2
            x*=env
    elif kind=='multitone':
        weights=1/np.arange(1,s['harmonics']+1)
        x=sum(w*np.sin(2*np.pi*f*(j+1)*t+rng.uniform(0,2*np.pi)) for j,w in enumerate(weights))
    elif kind=='chirp':
        q=np.clip(t,0,duration);slope=(s['end_hz']-f)/duration
        cycles=f*q+.5*slope*q*q+f*np.minimum(t,0)+s['end_hz']*np.maximum(t-duration,0)
        x=np.sin(2*np.pi*cycles+phase)
    else:
        x=rng.normal(size=len(t));freq=np.fft.rfftfreq(len(t),1/fs);X=np.fft.rfft(x)
        # All noise is explicitly band limited; pink is 1/f power in that band.
        if kind=='pink_noise':X/=np.sqrt(np.maximum(freq,1))
        X[(freq<s['band_low_hz'])|(freq>s['band_high_hz'])]=0
        x=np.fft.irfft(X,len(t))
    # Taper ONLY guard regions. The returned central record is untapered.
    guard=max(-t[0],1/fs)
    env=np.ones_like(t)
    left=t<0;right=t>=duration
    env[left]=np.sin(np.pi*.5*np.clip((t[left]+guard)/guard,0,1))**2
    env[right]=np.cos(np.pi*.5*np.clip((t[right]-duration)/guard,0,1))**2
    x*=env
    X=np.fft.rfft(x);freq=np.fft.rfftfreq(len(t),1/fs)
    # Suppress very low frequency/DC and alias-prone components of transient drives.
    hp=np.clip((freq-15)/10,0,1);lp=np.clip((fs*.48-freq)/(fs*.03),0,1)
    X*=hp*lp
    x=np.fft.irfft(X,len(t));central=(t>=0)&(t<duration)
    rms=np.sqrt(np.mean(x[central]**2))
    if rms<1e-15:raise ValueError('音源の励振がゼロです。発生時刻・周波数・帯域を確認してください')
    level=s['level_rms']*rng.uniform(1-s['variation'],1+s['variation'])
    return X*(level/rms),float(level)


def synthesize(config,case=0,seed=None,components=False):
    cfg=validate_config(config)
    if case not in range(len(case_names(cfg))):raise ValueError('未対応の評価条件です')
    rng=np.random.default_rng(cfg['seed'] if seed is None else seed)
    fs=cfg['fs'];n=round(cfg['duration_s']*fs)
    maxdist=max(s['distance_m']+s['radius_m'] for s in cfg['sources'])
    guard=max(.5,2*maxdist/cfg['c']+.05);g=math.ceil(guard*fs)
    nt=n+2*g;t=(np.arange(nt)-g)/fs;f=np.fft.rfftfreq(nt,1/fs)
    rpm,cycles=(rotation_trace(t,cfg['duration_s'],cfg['rotation'],cfg['seed'] if seed is None else seed)
                if cfg.get('rotation') else (None,None))
    measured_rpm=measure_rpm(t,rpm,cycles,cfg.get('rpm_sensor'),cfg['seed'] if seed is None else seed) if rpm is not None else None
    spectra=np.zeros((2,len(f)),complex);extra=np.zeros_like(spectra)
    source_info=[];parts=[]
    roles={'normal',*(['external'] if case==1 else ['abnormal'] if case==2 else [])}
    if case==3:roles={'normal','external','abnormal'}
    for index,s in enumerate(cfg['sources']):
        if s['role'] not in roles:continue
        source_rng=np.random.default_rng(np.random.SeedSequence([int(cfg['seed'] if seed is None else seed),index,1]))
        X,level=_excitation(t,s,cfg['duration_s'],source_rng,fs,cycles)
        gp,gu=field_transfer(f,s,cfg['rho'],cfg['c'])
        pair=np.stack([X*gp,X*gu]);pair[:,0]=0
        if nt%2==0:pair[:,-1]=0
        spectra+=pair
        if s['role']!='normal':extra+=pair
        source_info.append(dict(index=index,name=s['name'],role=s['role'],drive_rms=level,drive_unit={'piston':'m/s','monopole':'m3/s','plane':'Pa','rigid_wall':'Pa'}[s['model']]))
        if components:parts.append(np.fft.irfft(pair,nt,axis=-1)[:,g:g+n])
    truth=np.fft.irfft(spectra,nt,axis=-1)[:,g:g+n]
    added=np.fft.irfft(extra,nt,axis=-1)[:,g:g+n]
    measured=spectra.copy();sensor=cfg['sensor']
    for i,prefix in enumerate(['p','u']):
        H=10**(sensor[prefix+'_gain_db']/20)*np.exp(1j*np.deg2rad(sensor[prefix+'_phase_deg'])-2j*np.pi*f*sensor[prefix+'_delay_us']*1e-6)
        measured[i]*=H
    observed=np.fft.irfft(measured,nt,axis=-1)[:,g:g+n]
    for i,prefix in enumerate(['p','u']):
        sigma=sensor[prefix+'_noise_rms']
        if sigma:observed[i]+=rng.normal(0,sigma,n)
    if not np.isfinite(observed).all():raise ValueError('非有限波形が生成されました')
    return dict(time_s=np.arange(n)/fs,truth=truth,observed=observed,added=added,
                components=np.array(parts),sources=source_info,seed=int(cfg['seed'] if seed is None else seed),
                case=int(case),fs=fs,rpm=None if measured_rpm is None else measured_rpm[g:g+n],
                rpm_true=None if rpm is None else rpm[g:g+n])


def spectral_summary(wave,fs):
    """Welch spectra, C_pu=P conj(U), intensity density in W/m²/Hz."""
    p,u=wave;n=len(p);nseg=min(2048,2**int(np.floor(np.log2(n//4))))
    opts=dict(fs=fs,nperseg=nseg,noverlap=nseg//2,window='hann',detrend='constant',scaling='density')
    f,pp=signal.welch(p,**opts);_,uu=signal.welch(u,**opts)
    _,pu=signal.csd(u,p,**opts) # scipy: conj(first)*second
    mask=(pp>max(pp.max()*1e-10,1e-30))&(uu>max(uu.max()*1e-10,1e-30))
    coh=np.full_like(f,np.nan);coh[mask]=np.clip(abs(pu[mask])**2/(pp[mask]*uu[mask]),0,1)
    phase=np.full_like(f,np.nan);phase[mask]=-np.angle(pu[mask],deg=True)
    segments=1+(n-nseg)//(nseg//2)
    return dict(frequency_hz=f,p_psd=pp,u_psd=uu,coherence=coh,u_minus_p_phase_deg=phase,
                active_intensity_density=pu.real,reactive_intensity_density=pu.imag,
                welch_segments=segments,p_rms=float(np.sqrt(np.mean(p*p))),
                u_rms=float(np.sqrt(np.mean(u*u))),mean_intensity=float(np.mean(p*u)))


def json_safe(value):
    if isinstance(value,np.ndarray):return json_safe(value.tolist())
    if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [json_safe(v) for v in value]
    if isinstance(value,(np.integer,)):return int(value)
    if isinstance(value,(np.floating,float)):return float(value) if np.isfinite(value) else None
    return value
