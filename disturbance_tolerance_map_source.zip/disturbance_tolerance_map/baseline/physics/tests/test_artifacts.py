import json,subprocess,sys,unittest,uuid
from pathlib import Path
import numpy as np
from make_examples import examples
from da_engine.artifacts import run,inspect,view

class Artifacts(unittest.TestCase):
    def test_19_roundtrip_separate_process_and_tamper(self):
        root=Path(__file__).resolve().parent/'_work'/uuid.uuid4().hex;root.mkdir(parents=True)
        config=root/'scene.json';config.write_text(json.dumps(examples()['point']),encoding='utf-8')
        result=run(config,root/'result');info=inspect(result);self.assertEqual(info['receivers'],3)
        with np.load(result/'observations.npz') as a:
            self.assertEqual(set(a.files),{'time_s','pressure_pa','velocity_m_s','axial_velocity_m_s'})
        process=subprocess.run([sys.executable,'-B','-m','da_engine','view','--result',str(result),
                                '--output',str(root/'viewer.html')],cwd=Path(__file__).resolve().parents[1],capture_output=True)
        self.assertEqual(process.returncode,0,process.stderr)
        self.assertIn('<svg',(root/'viewer.html').read_text(encoding='utf-8'))
        with self.assertRaises(ValueError):run(config,result)
        with (result/'observations.npz').open('ab') as f:f.write(b'tamper')
        with self.assertRaises(ValueError):inspect(result)

    def test_20_unknown_result_version_rejected(self):
        root=Path(__file__).resolve().parent/'_work'/uuid.uuid4().hex;root.mkdir(parents=True)
        (root/'manifest.json').write_text(json.dumps({'schema_version':'unknown','status':'complete'}))
        with self.assertRaises(ValueError):inspect(root)
