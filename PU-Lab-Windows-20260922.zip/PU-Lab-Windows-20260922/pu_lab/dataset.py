"""Recording-level split generation and shared NPZ interface for the DL tool."""
from pathlib import Path
import hashlib,json
import numpy as np
from physics import VERSION,CASE_NAMES,validate_config,synthesize,case_names


def make_dataset(config,out,progress=lambda s:None,cancel=lambda:False,learning_dataset=None):
    cfg=validate_config(config);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    n=round(cfg['fs']*cfg['duration_s']);w=cfg['window_samples'];k=cfg['windows_per_record']
    counts=cfg['counts'];plan=[('train',0,counts['train']),('validation',0,counts['validation']),
          ('calibration',0,counts['calibration'])]+[('test',c,counts['test_per_class']) for c in range(len(case_names(cfg))) ]
    reference=load_dataset(learning_dataset) if learning_dataset else None
    if reference is not None:
        if reference['train'].shape[-1]!=w or float(reference['sampling_rate_hz'])!=cfg['fs']:raise ValueError('共通学習データとfs/窓長が異なります')
        plan=[entry for entry in plan if entry[0]=='test']
    total=sum(z[2] for z in plan)
    children=np.random.SeedSequence([cfg['seed'],1 if reference is not None else 0]).spawn(total)
    bins={name:[] for name in ['train','validation','calibration','test']}
    ids={name:[] for name in bins};starts_all={name:[] for name in bins}
    labels=[];extras=[];metadata=[];examples={};counter=0
    rpm_bins={name:[] for name in bins};true_rpm_bins={name:[] for name in bins}
    if reference is not None:counter=1+max(int(reference[s+'_record_ids'].max()) for s in ('train','validation','calibration'))
    seed_index=0
    # Equal, non-overlapping windows distributed across each recording.
    starts=np.linspace(0,n-w,k,dtype=int)
    for split,case,count in plan:
        for _ in range(count):
            if cancel():raise InterruptedError('データ生成を停止しました')
            seed=int(children[seed_index].generate_state(1)[0]);rec=synthesize(cfg,case,seed)
            rid=counter;counter+=1;seed_index+=1
            for start in starts:
                bins[split].append(rec['observed'][:,start:start+w].astype(np.float32))
                ids[split].append(rid);starts_all[split].append(int(start))
                if rec['rpm'] is not None:
                    rpm_bins[split].append(rec['rpm'][start:start+w].astype(np.float32))
                    true_rpm_bins[split].append(rec['rpm_true'][start:start+w].astype(np.float32))
                if split=='test':
                    labels.append(case);extras.append(np.sqrt(np.mean(rec['added'][:,start:start+w]**2,axis=1)))
            metadata.append(dict(record_id=rid,split=split,case=case,seed=seed,sources=rec['sources']))
            if split=='test' and case not in examples:
                examples[case]=rec
            if seed_index%10==0 or seed_index==total:progress(f'収録を生成 {seed_index}/{total}')
    cfgtext=json.dumps(cfg,ensure_ascii=False,sort_keys=True)
    arrays={name:np.stack(a) for name,a in bins.items() if a}
    arrays.update({name+'_record_ids':np.array(a,dtype=np.int64) for name,a in ids.items() if a})
    arrays.update({name+'_start_samples':np.array(a,dtype=np.int64) for name,a in starts_all.items() if a})
    if cfg.get('rotation'):
        arrays.update({name+'_rpm':np.stack(values) for name,values in rpm_bins.items() if values})
        arrays.update({name+'_rpm_true':np.stack(values) for name,values in true_rpm_bins.items() if values})
    if reference is not None:
        for split in ('train','validation','calibration'):
            for key in reference:
                if key==split or key.startswith(split+'_'):arrays[key]=reference[key]
        (out/'learning_reference.json').write_text(json.dumps(dict(path=str(Path(learning_dataset).resolve()),sha256=hashlib.sha256(Path(learning_dataset).read_bytes()).hexdigest()),indent=2),encoding='utf-8')
    arrays.update(test_labels=np.array(labels,dtype=np.int8),test_added_rms_si=np.array(extras),
                  sampling_rate_hz=np.array(cfg['fs']),time_s=np.arange(w)/cfg['fs'],
                  class_names=np.array(case_names(cfg)),config_json=np.array(cfgtext),
                  units=np.array(['Pa','m/s']),schema_version=np.array(1),
                  app_version=np.array(VERSION),config_sha256=np.array(hashlib.sha256(cfgtext.encode()).hexdigest()))
    temp=out/'dataset.partial.npz';np.savez_compressed(temp,**arrays);temp.replace(out/'dataset.npz')
    (out/'config.json').write_text(json.dumps(cfg,indent=2,ensure_ascii=False),encoding='utf-8')
    (out/'record_manifest.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False),encoding='utf-8')
    for case,rec in examples.items():
        np.savez_compressed(out/f'record_case{case}.npz',time_s=rec['time_s'],truth=rec['truth'],
                            observed=rec['observed'],added=rec['added'],seed=rec['seed'],fs=rec['fs'],**({'rpm':rec['rpm'],'rpm_true':rec['rpm_true']} if rec['rpm'] is not None else {}))
        np.savetxt(out/f'record_case{case}.csv',np.column_stack([rec['time_s'],rec['observed'].T,rec['truth'].T]+([rec['rpm'],rec['rpm_true']] if rec['rpm'] is not None else [])),
                   delimiter=',',header='time_s,p_Pa,u_m_s,p_true_Pa,u_true_m_s'+(',rpm_measured,rpm_true' if rec['rpm'] is not None else ''),comments='')
    summary=dict(path=str(out/'dataset.npz'),records=sum(len(np.unique(arrays[s+'_record_ids'])) for s in bins),generated_records=total,window_shape=[2,w],
                 windows={name:len(arrays[name]) for name in bins},fs=cfg['fs'],
                 window_seconds=w/cfg['fs'],schema_version=1,classes=len(case_names(cfg)),has_rpm=bool(cfg.get('rotation')))
    (out/'dataset_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return summary


def load_dataset(path):
    with np.load(path,allow_pickle=False) as z:d={key:z[key] for key in z.files}
    for key in ['train','validation','calibration','test','test_labels']:
        if key not in d:raise ValueError(f'NPZに{key}がありません')
    n=d['train'].shape[-1]
    for split in ['train','validation','calibration','test']:
        x=d[split]
        if x.ndim!=3 or x.shape[1:]!=(2,n) or len(x)<4 or not np.isfinite(x).all():raise ValueError(f'{split}: [件数,2,時間点数]の有限なp/u波形が必要です')
        key=split+'_record_ids'
        if key not in d:d[key]=np.arange(len(x))+{'train':0,'validation':10**7,'calibration':2*10**7,'test':3*10**7}[split]
        if d[key].shape!=(len(x),):raise ValueError('収録IDと窓数が一致しません')
    sets=[set(d[x+'_record_ids'].tolist()) for x in ['train','validation','calibration','test']]
    if any(sets[i]&sets[j] for i in range(4) for j in range(i)):raise ValueError('学習・検証・校正・評価間で収録IDが重複しています')
    if d['test_labels'].shape!=(len(d['test']),) or not np.isin(d['test_labels'],[0,1,2,3]).all():raise ValueError('正解ラベルは0/1/2/3で評価窓数と一致させてください')
    for rid in np.unique(d['test_record_ids']):
        if len(np.unique(d['test_labels'][d['test_record_ids']==rid]))!=1:raise ValueError('同一収録のラベルが不一致です')
    if 'sampling_rate_hz' not in d:
        if 'time_s' not in d or len(d['time_s'])<2:raise ValueError('fsまたは時間軸が必要です')
        d['sampling_rate_hz']=1/np.mean(np.diff(d['time_s']))
    fs=float(d['sampling_rate_hz'])
    if not np.isfinite(fs) or fs<=0:raise ValueError('不正なfsです')
    d.setdefault('class_names',np.array(CASE_NAMES))
    if len(d['class_names']) not in (3,4) or int(d['test_labels'].max())>=len(d['class_names']):raise ValueError('クラス名とラベルが一致しません')
    rpm_keys=[name+'_rpm' for name in ('train','validation','calibration','test')]
    if any(key in d for key in rpm_keys):
        for key in rpm_keys:
            split=key[:-4]
            if key not in d or d[key].shape!=(len(d[split]),n) or not np.isfinite(d[key]).all() or np.any(d[key]<0):
                raise ValueError('RPMは全分割に同期した[窓数,時間点数]の非負の有限値が必要です')
    return d
