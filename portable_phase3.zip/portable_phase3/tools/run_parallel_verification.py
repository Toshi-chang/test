"""Re-run all tests, compare unchanged defaults, execute opt-in route, save evidence.

The baseline directory must have been created by the PRE-INTEGRATION CLI demo.
Use a fresh --output directory. No Git operations or previous result mutation.
"""
import argparse
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nv_runner.common import read_json, write_json, sha
from nv_runner.bundle import BundleReader
from compare_extraction import compare


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    baseline=args.baseline.resolve(); out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    state={'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'stage':'tests'}
    write_json(out/'state.json',state)

    def run(name,arguments):
        result=subprocess.run([sys.executable,*arguments],cwd=ROOT,capture_output=True,text=True)
        (out/(name+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        if result.returncode:
            raise RuntimeError(f'{name} failed ({result.returncode}); see {out/(name+".log")}')
        return result

    try:
        tests=run('all_tests',['-m','unittest','discover','-s','tests','-v'])
        match=re.search(r'Ran (\d+) tests in ([\d.]+)s',tests.stderr)
        if not match or int(match[1])<59 or not tests.stderr.rstrip().endswith('OK'):
            raise RuntimeError('test count/result gate failed')
        state.update(stage='default_regression',tests=int(match[1]),test_seconds=float(match[2]))
        write_json(out/'state.json',state)
        default=run('default_cli',['-m','nv_runner','execute','--config',str(baseline/'experiment.json')])
        default_bundle=Path(default.stdout.strip().splitlines()[-1])
        comparison=compare(read_json(baseline/'summary.json')['bundle'],default_bundle)
        write_json(out/'default_comparison.json',comparison)
        state.update(stage='candidate_cli',default_comparison='passed')
        write_json(out/'state.json',state)
        config=copy.deepcopy(read_json(baseline/'experiment.json'))
        for name in ('train_manifest','eval_manifest','truth_path'):
            if config.get(name): config[name]=str((baseline/config[name]).resolve())
        config['export']['output_dir']=str(out/'candidate_runs')
        config['routes'].append(read_json(ROOT/'configs/parallel/route_a_candidate.json'))
        write_json(out/'candidate_experiment.json',config)
        candidate=run('candidate_cli',['-m','nv_runner','execute','--config',str(out/'candidate_experiment.json')])
        bundle=Path(candidate.stdout.strip().splitlines()[-1]); reader=BundleReader(bundle).validate()
        if reader.manifest['schema_version']!='1.0' or reader.manifest['bundle_status']!='complete' or 'A_candidate' not in reader.manifest['completed_routes']:
            raise RuntimeError('candidate completion/schema gate failed')
        run('candidate_viewer',['-m','nv_runner','view','--bundle',str(bundle),'--output',str(out/'viewer.html')])
        run('candidate_import',['-m','nv_runner','import','--bundle',str(bundle),'--output',str(out/'evaluation_inbox')])
        write_json(out/'candidate_metrics.json',read_json(bundle/'metrics.json'))
        state.update(status='complete',stage='done',finished_utc=datetime.now(timezone.utc).isoformat(),
                     default_bundle=str(default_bundle),candidate_bundle=str(bundle),
                     candidate_manifest_sha256=sha(bundle/'manifest.json'),
                     completed_routes=reader.manifest['completed_routes'],viewer=str(out/'viewer.html'),
                     pending_work=[])
    except Exception as exc:
        state.update(status='failed',error=str(exc),restart='Fix the reported cause; rerun with a new output directory. Preserve this failure log.')
        raise
    finally:
        write_json(out/'state.json',state)
    print(json.dumps(state,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
