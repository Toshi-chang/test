"""Integration gate for the legacy registry view and configuration identity."""
import ast
import copy
from pathlib import Path
import unittest
from nv_runner.plugin_catalog import DEFAULT_REGISTRY
from nv_runner.routes import REGISTRY
from nv_runner.profiles import acoustic_experiment
from nv_runner.common import identity, read_json


class PluginCompatibility(unittest.TestCase):
    def test_legacy_mapping_alias_and_no_default_injection(self):
        self.assertIs(REGISTRY, DEFAULT_REGISTRY)
        configs=acoustic_experiment('data','runs')['routes']
        configs.append(read_json(Path(__file__).resolve().parents[1]/'configs/parallel/route_a_candidate.json'))
        for config in configs:
            with self.subTest(plugin=config['plugin']):
                before=copy.deepcopy(config); digest=identity(config)
                REGISTRY.validate(config)
                plugin=REGISTRY[config['plugin']](config)
                self.assertEqual(config,before)
                self.assertEqual(identity(config),digest)
                self.assertEqual(plugin.config,config)
                self.assertNotIn('implementation_version',config)

    def test_runner_contains_no_route_specific_dispatch_or_schema(self):
        path=Path(__file__).resolve().parents[1]/'nv_runner/runner.py'
        tree=ast.parse(path.read_text(encoding='utf-8'))
        literals={n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
        self.assertFalse(set(REGISTRY)&literals)
        # Shared numeric/physical rules belong to the shared validator, not new route-name branches.
        self.assertNotIn('window_seconds',literals)
        self.assertNotIn('highpass_hz',literals)
