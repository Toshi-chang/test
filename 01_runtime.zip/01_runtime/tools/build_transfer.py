"""Build three independent transfer tiers, without environments or duplicate inboxes."""
import argparse
import json
from pathlib import Path
import shutil
import zipfile
from verify_transfer import digest


ROOT = Path(__file__).resolve().parents[1]


def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def tree(source, destination):
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "_work"))


def build(destination, runtime_only=False):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=False)
    runtime, viewing, evidence = [destination / name for name in ("01_runtime", "02_viewing", "03_evidence")]
    for folder in (runtime, viewing, evidence):
        folder.mkdir()
    for name in ("nv_runner", "configs", "docs", "tests", "tools"):
        tree(ROOT / name, runtime / name)
    for name in ("README.md", "requirements.txt", "run_demo.ps1"):
        copy(ROOT / name, runtime / name)
    copy(ROOT / ".gitignore", runtime / ".gitignore")
    if runtime_only:
        # Fresh environments do not have historical examples or reports.
        viewing.rmdir()
        evidence.rmdir()
        copy(ROOT / "docs" / "REVALIDATION_POLICY.md", runtime / "START_HERE.md")
        members = {p.relative_to(runtime).as_posix(): {"bytes": p.stat().st_size, "sha256": digest(p)}
                   for p in sorted(runtime.rglob("*")) if p.is_file()}
        (runtime / "TRANSFER_MANIFEST.json").write_text(json.dumps({"version": "1.0", "files": members}, indent=2), encoding="utf-8")
        archive = destination / "01_runtime.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for path in sorted(runtime.rglob("*")):
                if path.is_file():
                    z.write(path, path.relative_to(destination))
        info = {"name": "01_runtime", "files": len(members), "zip_bytes": archive.stat().st_size, "zip_sha256": digest(archive)}
        (destination / "PACKAGE_INDEX.json").write_text(json.dumps([info], indent=2), encoding="utf-8")
        print(json.dumps(info))
        return
    for name in ("ACOUSTIC_DELIVERY.md", "DELIVERY.md", "acceptance_tests.txt", "acoustic_tests.txt", "acoustic_regression_tests.txt", "viewer_test.json"):
        copy(ROOT / "reports" / name, viewing / "reports" / name)
    tree(ROOT / "reports" / "acoustic", viewing / "reports" / "acoustic")
    tree(ROOT / "docs", viewing / "docs")
    history = []
    for name in ("acoustic_quick", "acoustic_comparison", "quick", "comparison"):
        source = ROOT / "examples" / name
        for filename in ("viewer.html", "summary.json"):
            copy(source / filename, viewing / "examples" / name / filename)
        for folder in ("data", "runs"):
            tree(source / folder, evidence / "examples" / name / folder)
        for filename in ("experiment.json", "summary.json"):
            copy(source / filename, evidence / "examples" / name / filename)
        summary = json.loads((source / "summary.json").read_text(encoding="utf-8"))
        history.append({"name": name, "bundle": "examples/" + name + "/runs/" + Path(summary["bundle"]).name,
                        "generation": "acoustic_v0.2" if name.startswith("acoustic") else "legacy_v0.1"})
    (evidence / "history_index.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    for folder in (runtime, viewing, evidence):
        copy(ROOT / "docs" / "TRANSFER_GUIDE.md", folder / "TRANSFER_GUIDE.md")
    copy(ROOT / "docs" / "TRANSFER_GUIDE.md", destination / "START_HERE.md")
    sizes = []
    for folder in (runtime, viewing, evidence):
        members = {p.relative_to(folder).as_posix(): {"bytes": p.stat().st_size, "sha256": digest(p)}
                   for p in sorted(folder.rglob("*")) if p.is_file()}
        (folder / "TRANSFER_MANIFEST.json").write_text(json.dumps({"version": "1.0", "files": members}, indent=2), encoding="utf-8")
        archive = destination / (folder.name + ".zip")
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for path in sorted(folder.rglob("*")):
                if path.is_file():
                    z.write(path, path.relative_to(destination))
        sizes.append({"name": folder.name, "files": len(members), "uncompressed_bytes": sum(m["bytes"] for m in members.values()),
                      "zip_bytes": archive.stat().st_size, "zip_sha256": digest(archive)})
    (destination / "PACKAGE_INDEX.json").write_text(json.dumps(sizes, indent=2), encoding="utf-8")
    print(json.dumps(sizes, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--runtime-only", action="store_true")
    args = parser.parse_args()
    build(args.output, args.runtime_only)
