# 別環境への移植・継続検証 引継ぎガイド

作成日：2026-10-12。ソフトウェア0.2.0、ResultBundle schema 1.0。

## 何を持って行くか

|目的|必要なもの|不要なもの|
|---|---|---|
|過去の画面だけ見る|生成済みviewer.html 1個。最新は02_viewing/examples/acoustic_comparison/viewer.html|Python、元データ、モデル、サーバー|
|ダミーデータを新しく生成して継続検証|01_runtime全体＋移植先で構築するPython環境|過去のデータ・結果、既存DLツール|
|過去結果と検証経緯も参照|01_runtime＋02_viewing|過去モデルの再利用が不要なら03は省略可|
|既存モデル・閾値・全配列・元測定を保全し再解析|01_runtime＋03_evidence。画面もそのまま使うなら02も追加|元の.venv、evaluation_inboxの重複コピー、試験一時ファイル|
|実データ接続・外部受渡しの開発を続ける|01_runtime。既存結果で接続試験をするなら03_evidence|参照DLツールや作業ディレクトリ全体|

推奨は3つのZIPを保存し、日々の開発は01_runtimeで行う構成です。フォルダと同名ZIPは同じ内容なので、移送時はどちらか一方で十分です。02には旧版・物理更新後のquick/comparisonの4画面と報告・試験記録、03には4実験の元データとBundleを各1コピー収録しています。

**生成済みviewer.htmlと、ソースのnv_runner/viewer.htmlは別物です。** 後者はデータ未挿入のテンプレートで、単独では結果を見られません。現在のexamples/quickは旧物理モデルです。新規検証の基準はacoustic_quick / acoustic_comparisonです。

閲覧HTMLには評価用波形・図表・スコア・表示用正解情報を埋め込んでいますが、学習済みモデル、全fit/calibration配列、全音源別真値の代わりにはなりません。独自の再解析や完全性検証にはBundleが必要です。

## 構成と環境構築

01_runtimeにはnv_runner（PythonとHTMLテンプレート）、設定例、設計書、仕様書、テスト、移設支援ツール、依存関係、実行スクリプトを収録しています。コードだけの厳密な実行最小はnv_runner全体＋requirements.txtですが、継続検証用には設定・テスト・資料も残しています。

Python 3.12、64bitを用意します。検証元はWindows / Python 3.12.14。GPU、Node.js、HTTPサーバーは通常実行には不要です。

Windows PowerShell、01_runtime内で：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe tools/verify_transfer.py .
.\.venv\Scripts\python.exe tools/verify_transfer.py ../02_viewing
.\.venv\Scripts\python.exe tools/verify_transfer.py ../03_evidence
.\.venv\Scripts\python.exe -m nv_runner demo --generator acoustic --profile quick
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

macOS/Linuxの候補コマンドはpython3.12 -m venv .venv、.venv/bin/pythonで同じモジュールを実行します。PowerShellスクリプトは不要です。別OS・別CPUでの実行は未検証で、数値の完全一致は保証しません。まずquickと試験を実行してください。

依存ライブラリやPython本体はZIPに内包していません。ネット接続可能な移植先ではpipで取得します。閉域環境の場合は移植先と同じOS/CPU/Pythonの接続可能環境で以下を準備します。

```text
python -m pip download --only-binary=:all: -r requirements.txt -d wheels
python -m pip install --no-index --find-links wheels -r requirements.txt
```

wheelsとPythonインストーラは別途持ち込みます。既存.venvのコピーはパス/OS依存があるため使いません。任意の画面自動試験のみNode.js、Playwrightとブラウザーが追加で必要です。

## 既存結果の移設・再解析

03_evidence/examples/<実験>/runs/run_<ID>が不変のBundleです。内部ファイルを間引いたり、保存済み絶対パスを書き換えたりしないでください。Bundleのハッシュ検査が失敗します。元のsummary.jsonの絶対パスは履歴として残しています。現在位置はhistory_index.jsonと下記支援ツールで解決します。

01_runtimeから：

```powershell
.\.venv\Scripts\python.exe tools/prepare_history.py --archive ../03_evidence --output workspace/history
```

新しいworkspace/historyを作り、各実験にexperiment.json（元データへの移設後参照、新しい結果保存先）とpath_mapping.json（旧元測定パス→移設先の完全パス）を生成します。出力フォルダは毎回未作成の名前を使います。Windowsから他OSへの移設でも元パスの完全一致で対応させます。保存済みBundleは変更しません。

```powershell
.\.venv\Scripts\python.exe -m nv_runner validate --config workspace/history/acoustic_quick/experiment.json
.\.venv\Scripts\python.exe -m nv_runner execute --config workspace/history/acoustic_quick/experiment.json
```

これは保存済み元データからの**再学習・再評価**です。過去の固定済みモデルだけを読み込んで新データへ推論する専用CLIは現時点でありません。実運用で必要ならモデル読込・互換性確認・固定前処理/閾値による推論入口を追加します。モデルと閾値そのものはBundleに保全しています。

index.jsonのbundleを指定して：

```powershell
.\.venv\Scripts\python.exe -m nv_runner inspect --bundle "<移設後のBundleフォルダ>"
.\.venv\Scripts\python.exe -m nv_runner view --bundle "<移設後のBundleフォルダ>" --output workspace/restored_viewer.html
.\.venv\Scripts\python.exe -m nv_runner import --bundle "<移設後のBundleフォルダ>" --output workspace/inbox --path-mapping workspace/history/acoustic_quick/path_mapping.json
```

viewはBundle内配列だけで成立します。importは元測定参照も確認するので、移設時には対応する実験のpath_mappingを指定します。原本がない場合も受渡し結果にunresolved_sourcesが明記されます。これを原本参照成功として扱わないでください。

旧0.1実験は結果保全・比較閲覧用です。0.2で再実行しても旧ソフトウェアと完全一致は保証しません。各Bundleのenvironment.jsonに当時の版とソースハッシュを保存していますが、旧ソースの完全スナップショットは同梱していません。

## 実データ接続の引継ぎ

交換箇所：nv_runner/input_adapter.py のInputAdapter.load。現状の標準形式はNPZのwaveform [time,2]（p [Pa], u [m/s]）、任意の同期shaft_rpm [time]（rev/min）、metadata JSON、登録manifest JSON。配列キーはmanifest.mappingで指定できます。examples/acoustic_quick/data内に実際の雛形があります。ファイル形状・必須項目・状態・版はdocs/CONTRACTS.mdを参照してください。

接続前に必要な情報：

- ファイル形式、キー/shape/dtype、チャンネル順、単位と校正係数。
- p/u相対位相・時間遅延、サンプル周波数、共通時計、欠測区間。
- 共置条件、センサー位置、uの符号付き単位方向ベクトル。
- rpmまたはパルス仕様、回転軸、信号遅延、停止区間。
- 個体・測定・評価ケース・派生元ID、運転条件、正常学習データの確認。

測定機固有の読出し・単位変換・校正・同期化をアダプタに閉じ込め、その後は既存経路へ渡します。現状は共置p/u 1ペア、共通時間軸を要求し、未対応の非同期/非共置/多センサーを自動補完しません。実測では生成器truthを付けずtruth_pathを設定から外せます。正解がない検出精度は未評価として扱います。

## 外部システムへの受渡しの引継ぎ

交換箇所：nv_runner/bundle.pyのEvaluationAdapter.import_bundle。現状は版付きBundleのローカルコピーと受領記録です。相手側に渡す単位はrun_<ID>フォルダ全体。manifest.json、JSON/JSONL台帳、配列、モデル、前処理、設定、分割情報を一体として扱います。BundleReader.validateで版・ハッシュ・参照を確認します。

相手側と決める項目は、schema対応版、run_id重複処理、個体/ケースID対応、元測定へのアクセス方法、受領・再送・部分失敗の扱い、モデルの利用要否です。HTTP等はこのアダプタの輸送部分として追加できます。現時点で外部API接続や相手側受入試験は行っていません。

モデルjoblibは実行環境に依存します。互換な依存版を使い、自分たちが管理するモデルだけをロードしてください。通常のBundle閲覧はモデルをデシリアライズしません。第三者がモデルを必要としない場合も、既存Bundleから勝手に削除せず、将来の別出力契約として定義してください。

## 次の検証と完了判定

1. 新環境で移送ハッシュ検査、quick実行、受入試験、保存Bundleの閲覧を通す。
2. 物理条件のベンチマークを拡充（距離・角度・周波数・外乱・センサー位相誤差）。
3. 独立した正常実現を増やし、開発用/最終確認用を分離して経路比較する。
4. 実測1ペアの既知条件から接続し、符号・単位・位相・由来を検証する。
5. 固定モデル推論入口と、接続先に応じた出力アダプタを追加する。

現在の比較28ケースは4正常実現を共有した対比較で、28独立実現の性能試験ではありません。数理実装の検証結果を、実音場や外乱分離能力の実証に読み替えないでください。
