"""Resolve ONLY the local, hash-locked engine snapshots."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def verify_engines():
    lock=json.loads((ROOT/'engine_lock.json').read_text(encoding='utf-8'))
    if lock['version']!='1':raise ValueError('unknown engine lock version')
    for f in lock['files']:
        p=(ROOT/f['path']).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:
            raise ValueError('locked engine changed: '+f['path'])
    return len(lock['files'])
verify_engines()
for name,folder in [('nv_runner','runtime'),('da_engine','physics')]:
    if name in sys.modules and not Path(sys.modules[name].__file__).resolve().is_relative_to(ROOT/folder):
        raise ValueError('foreign engine already imported: '+name)
    sys.path.insert(0,str(ROOT/folder))
