"""Collect actual test evidence and package source only, no measurement migration."""
import bootstrap
from bootstrap import ROOT,verify_engines
from bridge.adapter import read,write,sha
import re,zipfile

def main():
    suites={'baseline_130.log':130,'physics_20.log':20,'bridge_tests.log':9}
    tests={}
    for name,count in suites.items():
        text=(ROOT/'reports'/name).read_text(encoding='utf-8-sig')
        if not re.search(r'Ran '+str(count)+r' tests?\b',text) or not re.search(r'^OK\s*$',text,re.M):raise ValueError('suite not passed: '+name)
        tests[name]={'count':count,'status':'passed','sha256':sha(ROOT/'reports'/name)}
    lines=['# 分布音源と既存解析経路の接続結果','', '2026-11-06。新しい接続PoC。旧データの再現実験ではない。','',
        '## 試験','', '|試験群|件数|結果|','|---|---:|---|']
    for name,v in tests.items():lines.append(f'|{name}|{v["count"]}|PASS|')
    result={'schema_version':'distributed-integration-validation/1.0','tests':tests,'engine_files_unchanged':verify_engines(),'runs':{}}
    for profile in ['quick','comparison']:
        run=read(ROOT/'outputs'/f'{profile}_v1'/'validation.json')
        if run['status']!='passed':raise ValueError('run failed '+profile)
        result['runs'][profile]={k:run[k] for k in ['status','fit_specimens','calibration_specimens','eval_specimens','independent_eval_families','train_measurements','eval_measurements','dataset_config_sha256','experiment_template_sha256','elapsed_seconds']}
        lines += ['',f'## {profile}','',f'fit {run["fit_specimens"]}、calibration {run["calibration_specimens"]}個体。評価{run["eval_specimens"]}シナリオ個体、独立正常実現{run["independent_eval_families"]}群。',
            '', '|経路|検出/異常|見逃し|誤判定/正常（外乱含む）|判定不可 正常/異常|','|---|---:|---:|---:|---:|']
        for route,r in run['metrics']['routes'].items():
            lines.append(f'|{route}|{r["true_positive"]}/{r["abnormal_total"]}|{r["false_negative"]}|{r["false_positive"]}/{r["normal_total"]}|{r["undetermined_normal"]}/{r["undetermined_abnormal"]}|')
        lines+=['','正常と外乱のみの内訳：','', '|経路|normal 範囲外/母数|disturbance 範囲外/母数|','|---|---:|---:|']
        for route,r in run['metrics']['routes'].items():
            cells=[]
            for scenario in ['normal','disturbance']:
                rows=[x for x in r['specimens'] if scenario in x['scenario']]
                cells.append(f'{sum(x["decision"]=="outside" for x in rows)}/{len(rows)}')
            lines.append('|'+route+'|'+'|'.join(cells)+'|')
    lines += ['','## 確認した境界','',
        '- 正解・音源定義ファイルが存在しない最小観測フォルダからAdapterが動作する。',
        '- 各受音点の値は元配列と完全一致。受音点index、座標、case/specimen/派生元を維持。',
        '- 6測定/個体としてfit/cal/evalを分離。ケース内最大値の旧集約規則は変更していない。',
        '- 評価波形を1.7倍、ラベルを反転、正解領域を空にして再実行してもモデルと閾値のSHAが不変。',
        '- 評価シナリオ間で正常音源寄与は同一。外乱・異常は追加音源としてのみ変更。',
        '- BundleReader、別プロセスのviewer生成、EvaluationAdapterのローカル受渡しが成功。',
        '- baselineのコード・契約・既存試験はスナップショットへバイト一致で複製。元を変更していない。',
        '', '## 制約・解釈','',
        'この結果は接続と検証経路が成立したことを示す。正常誤判定、見逃しを消すための調整は行っていない。',
        'case最大値を複数受音点で取る影響、少数calibration、未知正常実現による変動があり、誤判定の原因は未分離。',
        '旧点音源実験と生成強度・距離・注入時間・独立実現数が違うため成績の直接比較はできない。',
        'comparisonは箱表面の基本モデルで独立実現を増やしたもので、全13形状の方式評価ではない。',
        '実測、物理的な筐体透過、センサー誤差、実ブラウザーの操作、別PCでの再試験は未実施。',
        '物理源の全正解配列はrawに保存するが、既存Bundleへ新しい物理診断schemaとして埋め込んでいない。',
        '再実行時はREADMEとconfigsを使い、過去件数になるよう条件・試験を変更しない。']
    (ROOT/'reports/RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    write(ROOT/'reports/completion.json',result)
    files=[]
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if any(x in {'outputs','_work','__pycache__','.venv'} for x in rel.parts):continue
        if not p.is_file() or p.name=='release_manifest.json':continue
        files.append({'path':rel.as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
    write(ROOT/'release_manifest.json',{'schema_version':'1.0','files':files})
    target=ROOT.parent/'distributed_nv_integration_source.zip'
    if target.exists():raise ValueError('release archive already exists')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for f in files:z.write(ROOT/f['path'],'distributed_nv_integration/'+f['path'])
        z.write(ROOT/'release_manifest.json','distributed_nv_integration/release_manifest.json')
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:raise ValueError('archive integrity error')
    print(target,target.stat().st_size,'bytes; files:',len(files))

if __name__=='__main__':main()
